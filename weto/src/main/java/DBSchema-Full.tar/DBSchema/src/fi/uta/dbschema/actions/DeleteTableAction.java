/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.actions;

import java.awt.event.ActionEvent;
import java.util.Iterator;
import java.util.LinkedList;

import javax.swing.AbstractAction;
import javax.swing.JOptionPane;

import de.uni_paderborn.fujaba.app.FrameMain;
import de.uni_paderborn.fujaba.basic.BasicIncrement;
import de.uni_paderborn.fujaba.fsa.SelectionManager;
import de.uni_paderborn.fujaba.uml.UMLProject;
import fi.uta.dbschema.metamodel.DBQuery;
import fi.uta.dbschema.metamodel.DBTable;
import fi.uta.dbschema.metamodel.DBTableAttribute;
import fi.uta.dbschema.metamodel.DBView;
import fi.uta.dbschema.metamodel.DBViewAttribute;


/**
 * Delete last selected table.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:49 $
 * @version   $Revision: 1.4 $
 */
public class DeleteTableAction extends AbstractAction
{
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void actionPerformed (ActionEvent e)
   {
      Iterator iter;
      LinkedList selectedTables = new LinkedList();
      try
      {
         Object source = e.getSource();

         if (source instanceof DBTable)
         {
            // Single DBTable selected
            selectedTables.add (source);
         }
         else if (source instanceof DBTableAttribute)
         {
            // Single DBTableAttribute selected
            selectedTables.add ( ((DBTableAttribute) source).getParent());
         }
         else if (source instanceof DBView)
         {
            // Single DBView selected
            selectedTables.add (source);
         }
		else if (source instanceof DBViewAttribute)
		{
		   // Single DBViewAttribute selected
		   selectedTables.add (((DBViewAttribute) source).getParent());
		}
		else if (source instanceof DBQuery)
		{
		   // Single DBTable selected
		   selectedTables.add (source);
		}
         else
         {
            // Several DBTables are selected
            iter = SelectionManager.get().iteratorOfSelectionAsIncrements();

            // filter all DBTables from selection
            while (iter.hasNext())
            {
               BasicIncrement incr = (BasicIncrement) iter.next();
               if (incr instanceof DBTable)
               {
                  selectedTables.add (incr);
               }
               if (incr instanceof DBView)
               {
                  selectedTables.add (incr);
               }
			   if (incr instanceof DBQuery)
			   {
				  selectedTables.add (incr);
			   }
            }
         }
		int selection = JOptionPane.showConfirmDialog(FrameMain.get().getFrame(), "Are you sure you want to delete selected table(s)?", "Delete tables", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		if(selection == JOptionPane.NO_OPTION) {
			return;
		}

         iter = selectedTables.iterator();

         while (iter.hasNext())
         {
            BasicIncrement incr = (BasicIncrement) iter.next();
            incr.removeYou();
         }
         UMLProject.get().refreshDisplay();
      }
      catch (Exception e2)
      {
         e2.printStackTrace();
      }
      finally
      {
      }
   } // executeAction

}

/*
 * $Log: DeleteTableAction.java,v $
 * Revision 1.4  2003/10/07 07:21:49  ariseppi
 * misc. corrections
 *
 */
