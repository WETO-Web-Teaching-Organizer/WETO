/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.cs.dbswtool;

import java.util.Vector;


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:48 $
 * @version   $Revision: 1.3 $
 */
public class NameVector implements NameStore
{
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected Vector nameVector;


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @return   No description provided
    */
   public int size()
   {
      return nameVector.size();
   }


   /**
    * Constructor for class NameVector
    */
   public NameVector()
   {
      nameVector = new Vector();
   }


   /**
    * Get the vector attribute of the NameVector object
    *
    * @return   The vector value
    */
   public Vector getVector()
   {
      return nameVector;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void output()
   {
      System.out.println ("NameVector with size " + nameVector.size());
      for (int i = 0; i < nameVector.size(); i++)
      {
         String name = (String) nameVector.elementAt (i);
         System.out.print (name);
      }
      System.out.println();
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param name  No description provided
    * @return      No description provided
    */
   public boolean nameExists (String name)
   {
      boolean found = false;
      int i = 0;
      while ( (i < nameVector.size()) &&  (!found))
      {
         String s = (String) nameVector.elementAt (i);
         i++;
         if (s.equals (name))
         {
            found = true;
         }
      }
      return found;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @return   No description provided
    */
   public String commaList()
   {
      StringBuffer sb = new StringBuffer();
      if (nameVector.size() > 0)
      {
         String s1 = (String) nameVector.elementAt (0);
         sb.append (s1);
         for (int i = 1; i < nameVector.size(); i++)
         {
            sb.append (", ");
            String s2 = (String) nameVector.elementAt (i);
            sb.append (s2);
         }
      }
      String s = new String (sb);
      return s;
   }


   /**
    * Access method for an one to n association.
    *
    * @param newName  The object added.
    */
   public void addName (String newName)
   {
      //	output();
      if (!nameExists (newName))
      {
         nameVector.add (newName);
      }
   }

}

/*
 * $Log: NameVector.java,v $
 * Revision 1.3  2003/10/07 07:21:48  ariseppi
 * misc. corrections
 *
 */
