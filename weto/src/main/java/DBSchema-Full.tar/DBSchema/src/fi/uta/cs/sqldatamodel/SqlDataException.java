/*
 * Created on Oct 4, 2004
 */
package fi.uta.cs.sqldatamodel;

/**
 * Base class for exceptions thrown by Fujaba SQL classes.
 */
public class SqlDataException extends Exception {
	private static final long serialVersionUID = 6577311707407182688L;
	
	public SqlDataException() {	
		super();
	}
	
	public SqlDataException( String message ) {
		super(message);
	}
}

// End of file.
