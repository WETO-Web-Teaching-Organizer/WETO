/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this added code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.gui;

import java.awt.Cursor;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;

import javax.swing.JFrame;

import de.uni_paderborn.fujaba.asg.ASGElement;
import de.uni_paderborn.fujaba.gui.PEColumn;
import de.uni_paderborn.fujaba.gui.PEEditPanel;
import de.uni_paderborn.fujaba.gui.PETextField;
import de.uni_paderborn.fujaba.uml.UMLProject;
import de.upb.tools.fca.FLinkedList;
import fi.uta.dbschema.metamodel.DBSchema;
import fi.uta.dbschema.metamodel.DBTable;
import fi.uta.dbschema.metamodel.DBTableAttribute;
import fi.uta.dbschema.metamodel.DBTableJunction;
import fi.uta.dbschema.metamodel.DBView;
import fi.uta.dbschema.metamodel.DBViewAttribute;
import fi.uta.dbschema.metamodel.DBViewJoin;


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.3 $
 */
public class PEDBViewAttribute extends DBPropertyEditor
{
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PETextArea whereClause;

   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBAttrTableSelection attrSelection;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PETextField attributeName;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBViewAttrSelection viewAttrSelection;

   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   FLinkedList addAttributes = new FLinkedList();
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   FLinkedList delAttributes = new FLinkedList();

   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   FLinkedList addJoins = new FLinkedList();
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   FLinkedList delJoins = new FLinkedList();


   /**
    * Constructor for class PEDBViewAttribute
    *
    * @param frame  No description provided
    * @param title  No description provided
    * @param modal  No description provided
    */
   public PEDBViewAttribute (JFrame frame, String title, boolean modal)
   {
      super (frame);
      setModal (modal);
      setTitle (title);
      try
      {
         pack();
         this.setTitle ("View Editor");
      }
      catch (Exception e)
      {
         e.printStackTrace();
      }
      initPE();
   }


   /**
    * Constructor for class PEDBViewAttribute
    *
    * @param frame  No description provided
    */
   public PEDBViewAttribute (JFrame frame)
   {
      this (frame, "", false);
   }


   /**
    * Constructor for class PEDBViewAttribute
    *
    * @param frame  No description provided
    * @param modal  No description provided
    */
   public PEDBViewAttribute (JFrame frame, boolean modal)
   {
      this (frame, "", modal);
   }


   /**
    * Constructor for class PEDBViewAttribute
    *
    * @param frame  No description provided
    * @param title  No description provided
    */
   public PEDBViewAttribute (JFrame frame, String title)
   {
      this (frame, title, false);
   }


   /**
    * Sets the whereClause attribute of the PEDBViewAttribute object
    *
    * @param name  The new whereClause value
    */
   public void setWhereClause (String name)
   {
      whereClause.setText (name);
   }


   /**
    * Sets the current attributeName attribute of the PEDBViewAttribute object
    *
    * @param name  The new attributeName value
    */
   public void setAttributeName (String name)
   {
      attributeName.setText (name);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param panel  No description provided
    */
   protected void additionalProperties (PEEditPanel panel)
   {
      whereClause = new PETextArea (this, "Where Clause");

      attrSelection = new PEDBAttrTableSelection (this);
      attributeName = new PETextField (this, "Attribute Name");
      viewAttrSelection = new PEDBViewAttrSelection (this);

      whereClause.setStatus ("Enter the where clause of the view");
      attributeName.setStatus ("Enter the name of the attribute used in this view");

      viewAttrSelection.setAddListener (new PEDBView_addAttrButton_actionAdapter (this));
      viewAttrSelection.setRemoveListener (new PEDBView_removeAttrButton_actionAdapter (this));
      viewAttrSelection.setModifyListener (new PEDBView_modifyAttrButton_actionAdapter (this));

      PEColumn column = new PEColumn (this);

      column.add (whereClause);

      column.add (attrSelection);
      column.add (attributeName);
      column.add (viewAttrSelection);

      panel.add (column);
   }


   /**
    * Access method for an one to n association.
    *
    * @param e  The object added.
    */
   void addAttrButton_actionPerformed (ActionEvent e)
   {
      int[] selection = attrSelection.getRight().getSelectedIndices();
      if (selection.length == 1)
      {
         DBViewAttribute attr = new DBViewAttribute();

         DBTableAttribute tableAttribute = (DBTableAttribute) attrSelection.getRight().getSelectedIncrement();

         String newName = this.getAttributeName();
         if (newName.equals (""))
         {
            newName = tableAttribute.getName();
         }

         attr.setName (newName);
         attr.setAttribute (tableAttribute);

         addAttributes.add (attr);
         viewAttrSelection.addToList (attr);
         setAttributeName ("");
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   protected void removeAttrButton_actionPerformed (ActionEvent e)
   {
      ASGElement incr = viewAttrSelection.getListSelectedIncr();
      if (incr != null)
      {
         addAttributes.remove (incr);
         delAttributes.add (incr);
         viewAttrSelection.removeFromList (incr);
         setAttributeName ("");
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   void modifyAttrButton_actionPerformed (ActionEvent e)
   {
      ASGElement oldIncr = viewAttrSelection.getListSelectedIncr();
      if (oldIncr != null && oldIncr instanceof DBViewAttribute)
      {
         // Fix me: The new editor should make it better handling modified items.
         DBViewAttribute curAttr = (DBViewAttribute) oldIncr;

         DBViewAttribute newAttr = new DBViewAttribute();

         newAttr.setName (attributeName.getText());
         newAttr.setAttribute (attrSelection.getAttribute());

         delAttributes.add (curAttr);

         ArrayList attrList = new ArrayList();

         Enumeration enum = viewAttrSelection.getListList();
         while (enum.hasMoreElements())
         {
            attrList.add (enum.nextElement());
         }

         for (int i = 0; i < attrList.size(); i++)
         {
            PEDBItem item = (PEDBItem) attrList.get (i);

            ASGElement elem = item.getIncrement();

            viewAttrSelection.removeFromList (elem);
            if (elem != curAttr)
            {
               viewAttrSelection.addToList (elem);
            }
            else
            {
               viewAttrSelection.addToList (newAttr);
            }
         }

         addAttributes.remove (curAttr);
         addAttributes.add (newAttr);
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void unparse()
   {
      if (getIncrement() instanceof DBView)
      {
         DBView view = (DBView) getIncrement();
         viewAttrSelection.setIncrement (view);
         attrSelection.fillLeftList();
         viewAttrSelection.fillList();
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected void parse()
   {
      DBViewAttribute attr = null;

      DBView view = (DBView) getIncrement();

      DBSchema schema = (DBSchema) UMLProject.get().getCurrentDiagram();

      Iterator iter = addAttributes.iterator();
      while (iter.hasNext())
      {
         attr = (DBViewAttribute) iter.next();

         DBTableAttribute tableAttr = attr.getAttribute();

         if (!view.hasInTables (tableAttr.getParent()))
         {
            DBViewJoin newJoin = new DBViewJoin();

            DBTableJunction firstJunc = new DBTableJunction (view);
            DBTableJunction secondJunc = new DBTableJunction (tableAttr.getParent());

            secondJunc.setAdornment (DBTableJunction.FILLED_BOX);

            newJoin.setFirstJunction (firstJunc);
            newJoin.setSecondJunction (secondJunc);

            view.addToJoins (newJoin);

            schema.addToItems (newJoin);
         }

         attr.setParent (view);
      }
      addAttributes.clear();

      iter = delAttributes.iterator();
      while (iter.hasNext())
      {
         attr = (DBViewAttribute) iter.next();

         DBTable table = attr.getAttribute().getParent();

         attr.removeYou();

         if (!view.hasInTables (table))
         {
            Iterator iter2 = view.iteratorOfJoins();
            boolean found = false;
            while (!found && iter2.hasNext())
            {
               DBViewJoin join = (DBViewJoin) iter2.next();
               DBTableJunction junc = join.getSecondJunction();
               if (junc.getTarget() == table)
               {
                  join.removeYou();
                  found = true;
               }
            }
         }
      }
      delAttributes.clear();

      view.setWhereClause (this.getWhereClause());
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected void cancel()
   {
      setVisible (false);
      dispose();
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void buttonOK_actionPerformed (ActionEvent e)
   {
//      super.buttonOK_actionPerformed (e);
      if (getFrame() != null)
      {
         getFrame().setCursor (Cursor.getPredefinedCursor (Cursor.WAIT_CURSOR));
      } // if

      try
      {
         setVisible (false);
         parse();
         UMLProject.get().refreshDisplay();
      }
      finally
      {
         if (getFrame() != null)
         {
            getFrame().setCursor (Cursor.getPredefinedCursor (Cursor.DEFAULT_CURSOR));
         }
      }
   }


   /**
    * Sets the increment attribute of the PEDBViewAttribute object
    *
    * @param incr  The new increment value
    */
   public void setIncrement (ASGElement incr)
   {
      super.setIncrement (incr);
      if (incr instanceof DBView)
      {
         DBView view = (DBView) incr;
         whereClause.setText (view.getWhereClause());
      }

      if (getSchemaIncrement() != null)
      {
         setTitle ("View Editor");
      }
   }


   /**
    * Get the whereClause attribute of the PEDBViewAttribute object
    *
    * @return   The whereClause value
    */
   public String getWhereClause()
   {
      return whereClause.getText();
   }


   /**
    * Get the current attributeName attribute of the PEDBViewAttribute object
    *
    * @return   The attributeName value
    */
   public String getAttributeName()
   {
      return attributeName.getText();
   }


   /**
    * Set the tableJoin attribute of the PEDBViewAttribute object
    *
    * @param attr  The new tableAttribute value
    */
   public void setTableAttribute (DBTableAttribute attr)
   {
      if (attr != null)
      {
         DBTable table = attr.getParent();
         attrSelection.setTable (table);
         attrSelection.setAttribute (attr);
      }
   }


   /**
    * Get the tableJoin attribute of the PEDBViewAttribute object
    *
    * @return   The tableAttribute value
    */
   public DBTableAttribute getTableAttribute()
   {
      return attrSelection.getAttribute();
   }


   /**
    * Get the view attribute attribute of the PEDBViewAttribute object
    *
    * @return   The viewAttribute value
    */
   public DBViewAttribute getViewAttribute()
   {
      return viewAttrSelection.getAttribute();
   }


   /**
    * Set the view attribute attribute of the PEDBViewAttribute object
    *
    * @param viewAttr  The new viewAttribute value
    */
   public void setViewAttribute (DBViewAttribute viewAttr)
   {
      DBTableAttribute attr = viewAttr.getAttribute();
      DBTable table = attr.getParent();
      String name = viewAttr.getName();
      attrSelection.setTable (table);
      attrSelection.setAttribute (attr);
      this.setAttributeName (name);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.3 $
 */
class PEDBView_addAttrButton_actionAdapter implements java.awt.event.ActionListener
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBViewAttribute adaptee;


   /**
    * Constructor for class PEDBView_addAttrButton_actionAdapter
    *
    * @param adaptee  No description provided
    */
   PEDBView_addAttrButton_actionAdapter (PEDBViewAttribute adaptee)
   {
      this.adaptee = adaptee;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void actionPerformed (ActionEvent e)
   {
      adaptee.addAttrButton_actionPerformed (e);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.3 $
 */
class PEDBView_removeAttrButton_actionAdapter implements java.awt.event.ActionListener
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBViewAttribute adaptee;


   /**
    * Constructor for class PEDBView_removeAttrButton_actionAdapter
    *
    * @param adaptee  No description provided
    */
   PEDBView_removeAttrButton_actionAdapter (PEDBViewAttribute adaptee)
   {
      this.adaptee = adaptee;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void actionPerformed (ActionEvent e)
   {
      adaptee.removeAttrButton_actionPerformed (e);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.3 $
 */
class PEDBView_modifyAttrButton_actionAdapter implements java.awt.event.ActionListener
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBViewAttribute adaptee;


   /**
    * Constructor for class PEDBView_modifyAttrButton_actionAdapter
    *
    * @param adaptee  No description provided
    */
   PEDBView_modifyAttrButton_actionAdapter (PEDBViewAttribute adaptee)
   {
      this.adaptee = adaptee;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void actionPerformed (ActionEvent e)
   {
      adaptee.modifyAttrButton_actionPerformed (e);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.3 $
 */
class PEDBAttrTableSelection extends PEDoubleListSelection
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private PEDBViewAttribute viewEditor;


   /**
    * Constructor for class PEDBAttrTableSelection
    *
    * @param parent  No description provided
    */
   PEDBAttrTableSelection (DBPropertyEditor parent)
   {
      super (parent);
      viewEditor = (PEDBViewAttribute) parent;
      getLeft().setHeader ("Tables");
      getRight().setHeader ("Attributes");
      fillLeftList();
      fillRightList();
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void fillLeftList()
   {
      clearLeft();
      DBSchema schema = (DBSchema) UMLProject.get().getCurrentDiagram();
      Iterator iter = schema.iteratorOfItems();
      while (iter.hasNext())
      {
         Object obj = iter.next();
         if (obj instanceof DBTable)
         {
            addToLeft ((DBTable) obj);
         }
      }
   }


   /**
    * Get the table attribute of the PEDBAttrTableSelection object
    *
    * @return   The table value
    */
   public DBTable getTable()
   {
      DBTable table = (DBTable) left.getList().getSelectedIncrement();
      return table;
   }


   /**
    * Sets the table attribute of the PEDBAttrTableSelection object
    *
    * @param table  The new table value
    */
   public void setTable (DBTable table)
   {
      left.selectIncrement (table);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void fillRightList()
   {
      clearRight();
      DBTable table = this.getTable();
      if (table != null)
      {
         Iterator iter = table.iteratorOfAttributes();
         while (iter.hasNext())
         {
            DBTableAttribute obj = (DBTableAttribute) iter.next();
            this.addToRight (obj);
         }
      }
   }


   /**
    * Get the attribute attribute of the PEDBAttrTableSelection object
    *
    * @return   The attribute value
    */
   public DBTableAttribute getAttribute()
   {
      DBTableAttribute attr = (DBTableAttribute) right.getList().getSelectedIncrement();
      return attr;
   }


   /**
    * Sets the attribute attribute of the PEDBAttrTableSelection object
    *
    * @param attr  The new attribute value
    */
   public void setAttribute (DBTableAttribute attr)
   {
      right.selectIncrement (attr);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected void leftSelectionChanged()
   {
      this.fillRightList();
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.3 $
 */
class PEDBViewAttrSelection extends PESingleSelection
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private PEDBViewAttribute viewEditor;


   /**
    * Constructor for class PEDBViewJoinSelection
    *
    * @param parent  No description provided
    */
   public PEDBViewAttrSelection (DBPropertyEditor parent)
   {
      super (parent);
      getList().setHeader ("View attributes");
      viewEditor = (PEDBViewAttribute) parent;
   }


   /**
    * Get the attribute attribute of the PEDBViewAttrSelection object
    *
    * @return   The attribute value
    */
   public DBViewAttribute getAttribute()
   {
      DBViewAttribute attr = (DBViewAttribute) list.getList().getSelectedIncrement();
      return attr;
   }


   /**
    * Sets the attribute attribute of the PEDBViewAttrSelection object
    *
    * @param attr  The new attribute value
    */
   public void setAttribute (DBViewAttribute attr)
   {
      list.getList().selectIncrement (attr);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected void listSelectionChanged()
   {
      ASGElement incr = list.getSelectedIncrement();
      if (incr instanceof DBViewAttribute)
      {
         DBViewAttribute attr = (DBViewAttribute) incr;
         viewEditor.setViewAttribute (attr);
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void fillList()
   {
      clearList();
      DBView view = (DBView) viewEditor.getIncrement();
      if (view == null)
      {
         return;
      }
      Iterator iter = view.iteratorOfAttributes();
      while (iter.hasNext())
      {
         Object obj = iter.next();
         if (obj instanceof DBViewAttribute)
         {
            list.add ((DBViewAttribute) obj);
         }
      }
   }
}

/*
 * $Log: PEDBViewAttribute.java,v $
 * Revision 1.3  2003/10/07 07:21:52  ariseppi
 * misc. corrections
 *
 */
