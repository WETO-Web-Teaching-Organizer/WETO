/*
 * Created on Nov 30, 2004
 *
 */
package fi.uta.cs.sqldatamodel;

/**
 * Exception that indicates that the underlying database operation
 * has failed during iterator operation.
 * 
 * @author csvera
 */
public class SqlSelectionIteratorException extends RuntimeException {

	private static final long serialVersionUID = -6041895809432604202L;

	public SqlSelectionIteratorException() {	
		super();
	}
	
	public SqlSelectionIteratorException( String message ) {
		super(message);
	}
}

// End of file.

