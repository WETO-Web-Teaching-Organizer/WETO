/*
 * Created on 26.7.2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package fi.uta.dbschema.actions;

import java.awt.event.ActionEvent;
import java.util.Iterator;

import javax.swing.AbstractAction;

import de.uni_paderborn.fujaba.app.FrameMain;
import de.uni_paderborn.fujaba.asg.ASGElement;
import de.uni_paderborn.fujaba.uml.UMLProject;
import fi.uta.dbschema.gui.PEDBDecompose;
import fi.uta.dbschema.metamodel.DBTable;
import fi.uta.dbschema.metamodel.DBTableAttribute;

/**
 * @author as66033
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class DecomposeAction extends AbstractAction
{

	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e)
	{
		Object source = e.getSource();
		if (source instanceof Iterator)
		{
		   Iterator iter = (Iterator) source;
		   if (iter.hasNext())
		   {
			  source = iter.next();
		   }
		}

		DBTable dbTable = null;
		if (source instanceof DBTable)
		{
		   dbTable = (DBTable) source;
		} else if (source instanceof DBTableAttribute)
		{
		   dbTable = ((DBTableAttribute) source).getParent();
		}
		else
		{
		   return;
		}

		PEDBDecompose decomposeEditor = new PEDBDecompose (FrameMain.get().getFrame());
		decomposeEditor.setIncrement ((ASGElement)dbTable);
		decomposeEditor.showCentered();

		UMLProject.get().refreshDisplay();

	}

}
