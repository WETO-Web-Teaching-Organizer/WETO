/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.metamodel.unparse;

import java.awt.GridLayout;

import de.uni_paderborn.fujaba.fsa.FSAGrab;
import de.uni_paderborn.fujaba.fsa.FSAObject;
import de.uni_paderborn.fujaba.fsa.FSAPanel;
import de.uni_paderborn.fujaba.fsa.listener.AscendDescendMouseHandler;
import de.uni_paderborn.fujaba.fsa.listener.GrabMouseListener;
import de.uni_paderborn.fujaba.fsa.listener.SelectionListenerHelper;
import de.uni_paderborn.fujaba.fsa.listener.SelectionMouseListener;
import de.uni_paderborn.fujaba.fsa.listener.SelectionPropagationListener;
import de.uni_paderborn.fujaba.fsa.swing.JGrab;
import de.uni_paderborn.fujaba.fsa.swing.PanelGrabUI;
import de.uni_paderborn.fujaba.fsa.unparse.AbstractUnparseModule;
import de.uni_paderborn.fujaba.fsa.unparse.LogicUnparseInterface;
import fi.uta.dbschema.fsa.swing.JunctionLayout;
import fi.uta.dbschema.fsa.update.AttributeJunctionAdornmentUpdater;
import fi.uta.dbschema.fsa.update.JunctionGrabTargetUpdater;
import fi.uta.dbschema.metamodel.DBTableAttributeJunction;


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:53 $
 * @version   $Revision: 1.2 $
 */
public class UMDBTableAttributeJunction extends AbstractUnparseModule
{
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param parent  No description provided
    * @param incr    No description provided
    * @return        No description provided
    */
   public FSAObject create (FSAObject parent, LogicUnparseInterface incr)
   {
      DBTableAttributeJunction junc = (DBTableAttributeJunction) incr;

      FSAGrab grab = new FSAGrab (incr, getMainFsaName(), parent.getJComponent());
      PanelGrabUI ui = (PanelGrabUI) PanelGrabUI.createUI (grab.getJComponent());
      grab.setUI (ui);
      grab.getJComponent().setOpaque (false);
      SelectionListenerHelper.addSelectionListener (grab.getJComponent(),
         SelectionPropagationListener.get (SelectionPropagationListener.CHILDREN));
      grab.addToUpdater (new JunctionGrabTargetUpdater (junc, "target"));

      FSAPanel adornPanel = new FSAPanel (junc, "adornmentPanel", grab.getJComponent());
      adornPanel.getJComponent().setLayout (new GridLayout (1, 1));
      adornPanel.getJComponent().setOpaque (false);

      SelectionListenerHelper.addSelectionListener (adornPanel.getJComponent(),
         SelectionPropagationListener.get (SelectionPropagationListener.CHILDREN));
      SelectionListenerHelper.addSelectionListener (adornPanel.getJComponent(),
         SelectionPropagationListener.get (SelectionPropagationListener.PARENT));
      AscendDescendMouseHandler.addMouseInputListener (adornPanel.getJComponent(), SelectionMouseListener.get());
      AscendDescendMouseHandler.addMouseInputListener (adornPanel.getJComponent(), GrabMouseListener.get());
      ui.setGrabComponent (adornPanel.getJComponent());

      JunctionLayout layout = new JunctionLayout ((JGrab) grab.getJComponent(), adornPanel.getJComponent());
      grab.getJComponent().setLayout (layout);

      grab.addToUpdater (new AttributeJunctionAdornmentUpdater (junc));

      return grab;
   }
}

/*
 * $Log: UMDBTableAttributeJunction.java,v $
 * Revision 1.2  2003/10/07 07:21:53  ariseppi
 * misc. corrections
 *
 */
