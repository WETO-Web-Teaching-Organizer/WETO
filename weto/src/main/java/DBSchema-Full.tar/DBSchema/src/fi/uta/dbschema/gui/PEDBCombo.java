/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this added code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.gui;

// Based on de.uni_paderborn.fujaba.gui.PECombo

import java.awt.Dimension;
import java.awt.event.ItemListener;

import javax.swing.JComboBox;

import de.uni_paderborn.fujaba.basic.FontContainer;
import de.uni_paderborn.fujaba.gui.BasicPropertyEditor;
import de.uni_paderborn.fujaba.gui.PEHeaderComponent;
import fi.uta.dbschema.metamodel.DBSchemaItem;


/**
 * Similar to de.uni_paderborn.fujaba.gui.PECombo, but works with fi.uta.dbschema.metamodel.DBSchemaItem
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:51 $
 * @version   $Revision: 1.3 $
 */
public class PEDBCombo extends PEHeaderComponent
{
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   JComboBox combo;


   /**
    * Constructor for class PEDBCombo
    *
    * @param parent  No description provided
    * @param title   No description provided
    */
   public PEDBCombo (BasicPropertyEditor parent, String title)
   {
      super (parent, title);
   }


   /**
    * Get the comboBox attribute of the PEDBCombo object
    *
    * @return   The comboBox value
    */
   public JComboBox getComboBox()
   {
      return combo;
   }


   /**
    * Sets the readOnly attribute of the PEDBCombo object
    *
    * @param b  The new readOnly value
    */
   public void setReadOnly (boolean b)
   {
      combo.setEnabled (!b);
   }


   /**
    * Access method for an one to n association.
    */
   public void addComponents()
   {
      combo = new JComboBox();
      add (combo);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param item  No description provided
    */
   public void addObject (Object item)
   {
      combo.addItem (item);
   }


   /**
    * Get the selectedIndex attribute of the PEDBCombo object
    *
    * @return   The selectedIndex value
    */
   public int getSelectedIndex()
   {
      return combo.getSelectedIndex();
   }


   /**
    * Sets the selectedIndex attribute of the PEDBCombo object
    *
    * @param index  The new selectedIndex value
    */
   public void setSelectedIndex (int index)
   {
      combo.setSelectedIndex (index);
   }


   /**
    * Sets the selectedString attribute of the PEDBCombo object
    *
    * @param s  The new selectedString value
    */
   public void setSelectedString (String s)
   {
      for (int i = 0; i < combo.getItemCount(); i++)
      {
         if (combo.getItemAt (i) instanceof DBSchemaItem &&  ((DBSchemaItem) combo.getItemAt (i)).getName().equals (s))
         {
            combo.setSelectedIndex (i);
            i = combo.getItemCount();
         }
      }
      combo.setSelectedItem (s);
   }


   /**
    * Sets the selectedObject attribute of the PEDBCombo object
    *
    * @param obj  The new selectedObject value
    */
   public void setSelectedObject (Object obj)
   {
      combo.setSelectedItem (obj);
   }


   /**
    * Get the selectedString attribute of the PEDBCombo object
    *
    * @return   The selectedString value
    */
   public String getSelectedString()
   {
      return getSelectedItem().toString();
   }


   /**
    * Get the selectedObject attribute of the PEDBCombo object
    *
    * @return   The selectedObject value
    */
   public Object getSelectedObject()
   {
      return combo.getSelectedItem();
   }


   /**
    * Get the itemCount attribute of the PEDBCombo object
    *
    * @return   The itemCount value
    */
   public int getItemCount()
   {
      return combo.getItemCount();
   }


   /**
    * Access method for an one to n association.
    *
    * @param aListener  The object added.
    */
   public void addItemListener (ItemListener aListener)
   {
      combo.addItemListener (aListener);
   }


   /**
    * Get the selectedItem attribute of the PEDBCombo object
    *
    * @return   The selectedItem value
    */
   public Object getSelectedItem()
   {
      return combo.getSelectedItem();
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private final int prefWidth = getFontMetrics (FontContainer.getFont (FontContainer.DEFAULT_FONT)).stringWidth ("12345678901234567890");


   /**
    * Get the preferredSize attribute of the PECDBombo object
    *
    * @return   The preferredSize value
    */
   public Dimension getPreferredSize()
   {
      Dimension dim = super.getPreferredSize();
      // set the default width to 20 characters
      dim.width = prefWidth;

      return dim;
   }


   /**
    * Get the horzResizable attribute of the PEDBCombo object
    *
    * @return   The horzResizable value
    */
   public boolean isHorzResizable()
   {
      return false;
   }


   /**
    * Get the vertResizable attribute of the PEDBCombo object
    *
    * @return   The vertResizable value
    */
   public boolean isVertResizable()
   {
      return true;
   }


   /**
    * Removes all Items from the item list
    */
   public void removeAllItems()
   {
      combo.removeAllItems();
   } // removeAllItems

}

/*
 * $Log: PEDBCombo.java,v $
 * Revision 1.3  2003/10/07 07:21:51  ariseppi
 * misc. corrections
 *
 */
