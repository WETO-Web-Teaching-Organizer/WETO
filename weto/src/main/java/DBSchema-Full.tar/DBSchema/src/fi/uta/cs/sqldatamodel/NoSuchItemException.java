/*
 * Created on Oct 4, 2004
 */
package fi.uta.cs.sqldatamodel;

/**
 * An exception indicating that no item exists.
 */
public class NoSuchItemException extends SqlDataException {

	private static final long serialVersionUID = -5052449526435016218L;

	public NoSuchItemException() {
		super();
	}

	public NoSuchItemException(String message) {
		super(message);
	}
}

// End of file.
