/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.metamodel;

import java.lang.reflect.Constructor;
import java.util.Iterator;

import de.upb.tools.fca.FEmptyIterator;
import de.upb.tools.fca.FLinkedList;
import de.upb.tools.fca.FPropHashSet;
import fi.uta.cs.sqldatatypes.SqlDataType;

/**
 * DBTableAttribute has attributes name, sqlType, sqlSize, sqlScale, javaType primaryKeyValue.
 * DBTableAttribute has refereces to + DBUniques - uniques that they are part of (to be able
 * to easily remove the uniques when the attribute is removed)
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:53 $
 * @version   $Revision: 1.3 $
 */

public class DBTableAttribute extends DBSchemaItem
{
	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	private String name = "";

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	private String sqlType = "";
	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	private int sqlSize = NO_NUMBER;
	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	private int sqlScale = NO_NUMBER;
	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	private String javaType = "";

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	public final static int NO_NUMBER = -1;
	public final static int NOT_DEFINED = -2;

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	public final static String forKeyString = "(FK)";
	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	public final static String forKeyUniqueString = "(FK/U)";
	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	public final static String uniqueString = "(U)";

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	private boolean primaryKeyValue = false;
	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	private boolean notNullValue = false;

	/**
	 * Constructor for class DBTableAttribute
	 */
	public DBTableAttribute()
	{
		super();
	}

	/**
	 * Constructor for class DBTableAttribute
	 *
	 * @param name  No description provided
	 */
	public DBTableAttribute(String name)
	{
		this();
		setName(name);
	}

	/**
	 * Sets the name attribute of the DBTableAttribute object
	 *
	 * @param newName  The new name value
	 */
	public void setName(String newName)
	{
		if (!name.equals(newName))
		{
			String oldName = this.name;
			this.name = newName;
			firePropertyChange("name", oldName, newName);
			refreshLabel();
		}
	}
	
	public void refreshLabel()
	{
		String name = getName();
		String label = null;
		if (sizeOfJunctions() > 0 && sizeOfRevUniques() > 0)
		{
			label = name + " " + forKeyUniqueString;
		}
		else if (sizeOfJunctions() > 0)
		{
			label = name + " " + forKeyString;
		}
		else if (sizeOfRevUniques() > 0)
		{
			label = name + " " + uniqueString;
		}
		else {
			label = name;
		}
		this.setLabel(label);
	}
	
	public Object clone()
	{
		DBTableAttribute attr = new DBTableAttribute(getName());
		Iterator iter = iteratorOfExamples();
		while(iter.hasNext()) {
			attr.addToExamples((String) iter.next());
		}
		attr.setJavaType(getJavaType());
		attr.setSqlType(getSqlType());
		attr.setSqlSize(getSqlSize());
		attr.setSqlScale(getSqlScale());
		attr.setNotNullValue(getNotNullValue());
		attr.setPrimaryKeyValue(getPrimaryKeyValue());
		return attr;
	}
	
	
	private String label = "";

	/**
	 * Get the name attribute of the DBTableAttribute object
	 *
	 * @return   The name value
	 */
	public String getName()
	{
		return this.name;
	}

	public String getLabel()
	{
		return this.label;
	}

	public void setLabel(String newLabel) {
		if (!label.equals(newLabel))
		{
			String oldLabel = this.label;
			this.label = newLabel;
			firePropertyChange("label", oldLabel, newLabel);
		}
	}

	/**
	 * Sets the sqlType attribute of the DBTableAttribute object
	 *
	 * @param newType  The new sqlType value
	 */
	public void setSqlType(String newType)
	{
		if (!sqlType.equals(newType))
		{
			String oldType = this.sqlType;
			this.sqlType = newType;
			firePropertyChange("sqlType", oldType, newType);
		}
	}

	/**
	 * Get the sqlType attribute of the DBTableAttribute object
	 *
	 * @return   The sqlType value
	 */
	public String getSqlType()
	{
		return this.sqlType;
	}

	public String getCompleteSqlType()
	{
		String type = getSqlType();
		if(getSqlSize() > DBTableAttribute.NO_NUMBER)
		{
			type += "(" + getSqlSize();
			if(getSqlScale() > DBTableAttribute.NO_NUMBER)
			{
				type += "," + getSqlScale();
			}
			type += ")";
		}
		return type;
	}

	/**
	 * Sets the javaType attribute of the DBTableAttribute object
	 *
	 * @param newType  The new javaType value
	 */
	public void setJavaType(String newType)
	{
		if (!javaType.equals(newType))
		{
			String oldType = this.javaType;
			this.javaType = newType;
			firePropertyChange("javaType", oldType, newType);
		}
	}

	/**
	 * Get the javaType attribute of the DBTableAttribute object
	 *
	 * @return   The javaType value
	 */
	public String getJavaType()
	{
		return this.javaType;
	}

	/**
		* Get the javaType attribute of the DBTableAttribute object as a Class
		*
		* @return   The javaType value
		*/
	public SqlDataType getTypeClass()
	{
		Object sqlObject = null;
		Class thisClass = null;
		try
		{
			thisClass =
				Class.forName("fi.uta.cs.sqldatatypes." + this.javaType);
			int amountOfParameters = 1;
			if (sqlSize > DBTableAttribute.NO_NUMBER)
			{
				amountOfParameters++;
			}
			if (sqlScale > DBTableAttribute.NO_NUMBER)
			{
				amountOfParameters++;
			}
			Class[] parameters = new Class[amountOfParameters];
			Object[] values = new Object[amountOfParameters];
			if (sqlSize > DBTableAttribute.NO_NUMBER)
			{
				parameters[0] = int.class;
				values[0] = new Integer(sqlSize);
				if (sqlScale > DBTableAttribute.NO_NUMBER)
				{
					parameters[1] = int.class;
					parameters[2] = String.class;
					values[1] = new Integer(sqlScale);
					values[2] = null;
				} else
				{
					parameters[1] = String.class;
					values[1] = null;
				}
			} else
			{
				parameters[0] = String.class;
				values[0] = null;
			}
			Constructor constructor = thisClass.getConstructor(parameters);
			sqlObject = constructor.newInstance(values);
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		return (SqlDataType) sqlObject;
	}

	/**
	 * Sets the sqlSize attribute of the DBTableAttribute object
	 *
	 * @param newSize  The new sqlSize value
	 */
	public void setSqlSize(int newSize)
	{
		if (newSize != sqlSize)
		{
			int oldSize = this.sqlSize;
			this.sqlSize = newSize;
			firePropertyChange("sqlSize", oldSize, newSize);
		}
	}

	/**
	 * Get the sqlSize attribute of the DBTableAttribute object
	 *
	 * @return   The sqlSize value
	 */
	public int getSqlSize()
	{
		return this.sqlSize;
	}

	/**
	 * Sets the sqlScale attribute of the DBTableAttribute object
	 *
	 * @param newScale  The new sqlScale value
	 */
	public void setSqlScale(int newScale)
	{
		if (newScale != sqlScale)
		{
			int oldScale = this.sqlScale;
			this.sqlScale = newScale;
			firePropertyChange("sqlScale", oldScale, newScale);
		}
	}

	/**
	 * Get the sqlScale attribute of the DBTableAttribute object
	 *
	 * @return   The sqlScale value
	 */
	public int getSqlScale()
	{
		return this.sqlScale;
	}
	
	private String description = "";
	
	public String getDescription()
	{
		return this.description;
	}
	
	public void setDescription(String newDescription)
	{
		if (!description.equals(newDescription))
		{
			String oldDescription = this.description;
			this.description = newDescription;
			firePropertyChange("description", oldDescription, newDescription);
		}
	}

	/**
	 * Sets the primaryKeyValue attribute of the DBTableAttribute object
	 *
	 * @param newValue  The new primaryKeyValue value
	 */
	public void setPrimaryKeyValue(boolean newValue)
	{
		if (newValue != primaryKeyValue)
		{
			boolean oldValue = this.primaryKeyValue;
			this.primaryKeyValue = newValue;
			firePropertyChange("primaryKeyValue", oldValue, newValue);
		}
	}

	/**
	 * Get the primaryKeyValue attribute of the DBTableAttribute object
	 *
	 * @return   The primaryKeyValue value
	 */
	public boolean getPrimaryKeyValue()
	{
		return this.primaryKeyValue;
	}

	/**
	 * Sets the notNullValue attribute of the DBTableAttribute object
	 *
	 * @param newValue  The new notNullValue value
	 */
	public void setNotNullValue(boolean newValue)
	{
		if (newValue != notNullValue)
		{
			boolean oldValue = this.notNullValue;
			this.notNullValue = newValue;
			firePropertyChange("notNullValue", oldValue, newValue);
		}
	}

	/**
	 * Get the notNullValue attribute of the DBTableAttribute object
	 *
	 * @return   The notNullValue value
	 */
	public boolean getNotNullValue()
	{
		return this.notNullValue;
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	public void removeYou()
	{
		Iterator iter = iteratorOfRevUniques();
		while (iter.hasNext())
		{
			DBUnique uni = (DBUnique) iter.next();
			uni.removeYou();
		}
		iter = iteratorOfRevViews();
		while (iter.hasNext())
		{
			DBView view = (DBView) iter.next();
			view.removeYou();
		}
		iter = iteratorOfJunctions();
		while (iter.hasNext())
		{
			DBTableAttributeJunction junc =
				(DBTableAttributeJunction) iter.next();
			DBJunctionPair pair = junc.getPair();
			pair.removeYou();
		}
		DBTable tmpTable = getParent();
		if (tmpTable != null)
		{
			setParent(null);
		} // if
		super.removeYou();
	}

	/**
	 * Get the text attribute of the DBTableAttribute object
	 *
	 * @return   The text value
	 */
	public String getText()
	{
		return this.getName();
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @return   No description provided
	 */
	public String toString()
	{
		return this.getText();
	}

	/**
	 * <pre>
	 *          +-----------+ 1              1
	 * DBTable  | getName() +------------------ DBTableAttribute
	 *          +-----------+ parent     attrs
	 * </pre>
	 */
	private DBTable parent;

	/**
	 * Sets the parent attribute of the DBTableAttribute object
	 *
	 * @param obj  The new parent value
	 * @return     No description provided
	 */
	public boolean setParent(DBTable obj)
	{
		boolean changed = false;

		if (this.parent != obj)
		{
			DBTable oldValue = this.parent;
			if (this.parent != null)
			{
				this.parent = null;
				oldValue.removeFromAttributes(this);
			}
			this.parent = obj;
			if (obj != null)
			{
				obj.addToAttributes(this);
			}
			changed = true;

			// side effects

			firePropertyChange("parent", oldValue, obj);
		}

		return changed;
	}

	/**
	 * Get the parent attribute of the DBTable object
	 *
	 * @return   The parent value
	 */
	public DBTable getParent()
	{
		return parent;
	}

	/**
	 * <pre>
	 *             0..n   revUniques    0..1
	 * DBUnique ---------------------- DBTableAttribute
	 *             revUnique         attribute
	 * </pre>
	 */
	private FPropHashSet revUniques;

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @return   No description provided
	 */
	public int sizeOfRevUniques()
	{
		return ((this.revUniques == null) ? 0 : this.revUniques.size());
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param value  No description provided
	 * @return       No description provided
	 */
	public boolean removeFromRevUniques(DBUnique value)
	{
		/*
		 *  id=id397   # no Name
		 */
		boolean changed = false;
		if ((this.revUniques != null) && (value != null))
		{
			changed = this.revUniques.remove(value);
			if(this.sizeOfRevUniques() < 1)
			{
				this.refreshLabel();
			}
		}
		return changed;
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	public void removeAllFromRevUniques()
	{
		/*
		 *  id=id356   # no Name
		 */
		DBUnique tmpValue;
		Iterator iter = this.iteratorOfRevUniques();
		while (iter.hasNext())
		{
			tmpValue = (DBUnique) iter.next();
			this.removeFromRevUniques(tmpValue);
		}
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @return   No description provided
	 */
	public Iterator iteratorOfRevUniques()
	{
		/*
		 *  id=id365   # no Name
		 */
		return (
			(this.revUniques == null)
				? FEmptyIterator.get()
				: this.revUniques.iterator());
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param value  No description provided
	 * @return       No description provided
	 */
	public boolean hasInRevUniques(DBUnique value)
	{
		/*
		 *  id=id381   # no Name
		 */
		return (
			(this.revUniques != null)
				&& (value != null)
				&& this.revUniques.contains(value));
	}

	/**
	 * Access method for an one to n association.
	 *
	 * @param value  The object added.
	 * @return       No description provided
	 */
	public boolean addToRevUniques(DBUnique value)
	{
		/*
		 *  id=id389   # no Name
		 */
		boolean changed = false;
		if (value != null)
		{
			if (this.revUniques == null)
			{
				this.revUniques = new FPropHashSet(this, "revUniques");
				// or FTreeSet () or FLinkedList ()
			}
			changed = this.revUniques.add(value);
			if(this.sizeOfRevUniques() < 2)
			{
				this.refreshLabel();
			}
		}
		return changed;
	}

	/**
	 * <pre>
	 *                   0..n   junctions   0..1
	 * DBTableAttributeJunction ---------------------- DBTableAttribute
	 *                  junctions         tableAttribute
	 * </pre>
	 */
	private FPropHashSet junctions;

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @return   No description provided
	 */
	public int sizeOfJunctions()
	{
		return ((this.junctions == null) ? 0 : this.junctions.size());
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param value  No description provided
	 * @return       No description provided
	 */
	public boolean removeFromJunctions(DBTableAttributeJunction value)
	{
		boolean changed = false;
		if ((this.junctions != null) && (value != null))
		{
			changed = this.junctions.remove(value);
			if(this.sizeOfRevUniques() < 1)
			{
				this.refreshLabel();
			}
		}
		return changed;
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	public void removeAllFromJunctions()
	{
		DBTableAttributeJunction tmpValue;
		Iterator iter = this.iteratorOfJunctions();
		while (iter.hasNext())
		{
			tmpValue = (DBTableAttributeJunction) iter.next();
			this.removeFromJunctions(tmpValue);
			tmpValue.removeYou();
		}
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @return   No description provided
	 */
	public Iterator iteratorOfJunctions()
	{
		return (
			(this.junctions == null)
				? FEmptyIterator.get()
				: this.junctions.iterator());
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param value  No description provided
	 * @return       No description provided
	 */
	public boolean hasInJunctions(DBTableAttributeJunction value)
	{
		return (
			(this.junctions != null)
				&& (value != null)
				&& this.junctions.contains(value));
	}

	/**
	 * Access method for an one to n association.
	 *
	 * @param value  The object added.
	 * @return       No description provided
	 */
	public boolean addToJunctions(DBTableAttributeJunction value)
	{
		boolean changed = false;
		if (value != null)
		{
			if (this.junctions == null)
			{
				this.junctions = new FPropHashSet(this, "junctions");
				// or FTreeSet () or FLinkedList ()
			}
			changed = this.junctions.add(value);
			if(this.sizeOfJunctions() < 2)
			{
				this.refreshLabel();
			}
		}
		return changed;
	}

	public static final int exampleCount = 5;

	private FLinkedList examples;

	public int sizeOfExamples()
	{
		return ((this.examples == null) ? 0 : this.examples.size());
	}

	public boolean removeFromExamples(String value)
	{
		boolean changed = false;
		if ((this.examples != null) && (value != null))
		{
			changed = this.examples.remove(value);
		}
		return changed;
	}

	public void removeAllFromExamples()
	{
		String tmpValue;
		Iterator iter = this.iteratorOfExamples();
		while (iter.hasNext())
		{
			tmpValue = (String) iter.next();
			this.removeFromExamples(tmpValue);
		}
	}

	public Iterator iteratorOfExamples()
	{
		return (
			(this.examples == null)
				? FEmptyIterator.get()
				: this.examples.iterator());
	}

	public boolean hasInExamples(String value)
	{
		return (
			(this.examples != null)
				&& (value != null)
				&& this.examples.contains(value));
	}

	public boolean addToExamples(String value)
	{
		boolean changed = false;
		if (value != null && sizeOfExamples() < exampleCount)
		{
			if (this.examples == null)
			{
				this.examples = new FLinkedList();
				// or FTreeSet () or FLinkedList ()
			}
			changed = this.examples.add(value);
		}
		return changed;
	}

	public boolean setExample(String value, int index)
	{
		boolean changed = false;
		if (value != null && index > -1 && index < exampleCount)
		{
			if (this.examples == null)
			{
				this.examples = new FLinkedList();
				// or FTreeSet () or FLinkedList ()
			}
			if (index > examples.size() - 1)
			{
				for (int i = examples.size(); i < index; i++)
				{
					examples.add("");
				}
				examples.add(value);
			} else
			{
				examples.set(index, value);
			}
			changed = true;
		}
		return changed;
	}

	public String getExample(int index)
	{
		if (index < -1 || index > exampleCount)
		{
			return null;
		}
		if (this.examples == null || index > this.examples.size() - 1)
		{
			return "";
		}
		return (String) this.examples.get(index);
	}

	/**
	 * 
	 * <pre>
	 *             0..n   revViews   0..1
	 * DBView ---------------------- DBTableAttribute
	 *             revViews         attribute
	 * </pre>
	 */
	private FPropHashSet revViews;

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @return   No description provided
	 */
	public int sizeOfRevViews()
	{
		return ((this.revViews == null) ? 0 : this.revViews.size());
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param value  No description provided
	 * @return       No description provided
	 */
	public boolean removeFromRevViews(DBView value)
	{
		boolean changed = false;
		if ((this.revViews != null) && (value != null))
		{
			changed = this.revViews.remove(value);
		}
		return changed;
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	public void removeAllFromRevViews()
	{
		DBView tmpValue;
		Iterator iter = this.iteratorOfRevViews();
		while (iter.hasNext())
		{
			tmpValue = (DBView) iter.next();
			this.removeFromRevViews(tmpValue);
		}
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @return   No description provided
	 */
	public Iterator iteratorOfRevViews()
	{
		return (
			(this.revViews == null)
				? FEmptyIterator.get()
				: this.revViews.iterator());
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param value  No description provided
	 * @return       No description provided
	 */
	public boolean hasInRevViews(DBView value)
	{
		return (
			(this.revViews != null)
				&& (value != null)
				&& this.revViews.contains(value));
	}

	/**
	 * Access method for an one to n association.
	 *
	 * @param value  The object added.
	 * @return       No description provided
	 */
	public boolean addToRevViews(DBView value)
	{
		boolean changed = false;
		if (value != null)
		{
			if (this.revViews == null)
			{
				this.revViews = new FPropHashSet(this, "revViews");
				// or FTreeSet () or FLinkedList ()
			}
			changed = this.revViews.add(value);
		}
		return changed;
	}
}

/*
 * $Log: DBTableAttribute.java,v $
 * Revision 1.3  2003/10/07 07:21:53  ariseppi
 * misc. corrections
 *
 */
