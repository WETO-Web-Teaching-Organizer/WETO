/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.cs.sqldatatypes;

import fi.uta.cs.sqldatamodel.InvalidValueException;

/**
 * Abstract base class for SQL data types.
 * 
 * Concrete subclasses must implement, in addition to the abstract methods:
 *  - equals
 *  - clone (as a public method)
 *  - toString
 *  - fromString (i.e., setting the value from the given string)
 *  - setValue and getValue in compliance with JavaBeans property API
 *  - jdbcSetValue and jdbcGetValue for value manipulation using JDBC
 * 
 * Concrete subclasses may optionally implement:
 *  - setValueUnchecked to set the attribute value without verifying
 * 		the validity of the new value
 * 
 * JavaBeans property and JDBC property may have different types.
 * 
 * Methods setValue and getValue must implement pass-by-copy, unless
 * the parameter/return value type is immutable by nature.
 * 
 * In addition to the contract imposed by java.lang.Object,
 * subclasses of SqlDataType must implement equals method with
 * the following checks:
 *  - An object is considered to be "of compatible type" only
 *    if 1) it has the same type or 2) both the objects share the
 *    same base class and neither of them adds any new attributes.
 *  - An object with non-null attribute value must return true
 *    if compared to another object (of a compatible type) with
 *    the equal attribute value.
 *  - An object with null attribute value must return true 
 *    if compared to another object (of a compatible type) with 
 * 	  null attribute value.
 *  - prime and nullAllowed attributes must not be used
 *    in comparison (i.e., the comparison is based on 
 *    values only).
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:49 $
 * @version   $Revision: $
 */
public abstract class SqlDataType implements Cloneable {
	/**
     * Attribute indicating whether this field is a part of primary key.
     * Default to false.
     */
	private boolean prime;
   
	/**
	 * Attribute indicating whether this field can have null value.
	 * Default to true.
	 */
	private boolean nullAllowed;

	/**
	 * Default constructor for class SqlDataType.
	 */
	public SqlDataType() {
		prime = false;
		nullAllowed = true;
	}

	/**
     * Sets the prime attribute of the SqlDataType object.
     *
     * @param prime The new prime value. If true, also implies
     * 	that nullAllowed is false. If false, nullAllowed
     *  attribute remains unchanged.
     */
	public void setPrime( boolean prime ) {
		if( prime ) {
			this.prime = true;
			this.nullAllowed = false;
		} else {
			this.prime = false;
		}
	}

	/**
     * Get the prime attribute of the SqlDataType object.
     *
     * @return The prime attribute value.
     */
	public boolean isPrime()
	{
		return prime;
	}
	
	/**
	 * Sets the nullAllowed attribute of the SqlDataType object.
	 * 
	 * @param nullAllowed The new value for nullAllowed attribute.
	 */
	public void setNullAllowed( boolean nullAllowed ) {
		this.nullAllowed = nullAllowed;
	}
	
	/**
	 * Gets the nullAllowed attribute of the SqlDataType object.
	 * 
	 * @return The nullAllowed attribute value.
	 */
	public boolean isNullAllowed() {
		return nullAllowed;
	}
	
	/**
	 * Checks whether the SqlDataType object value is valid.
	 * 
	 * @return true if the content is valid (e.g., the value of
	 * 	an object constrained to be non-null is really non-null),
	 * 	false otherwise.
	 */
	public abstract boolean isValid();
	
	/**
	 * Sets the value of the object from the given string.
	 * 
	 * Concrete implementation should implement this method so
	 * that it is as close to the inverse operation of toString
	 * as possible.
	 * 
	 * @param str New value of the object as a string.
	 * 
	 * @throws InvalidValueException if the value is invalid,
	 * 	and therefore could not be set.
	 * 
	 * Note that the method may also throw a runtime exception
	 * (most likely IllegalArgumentException) if the given
	 * string can not be converted to the correct type.
	 * The method may, but does not necessarily, catch
	 * such an exception and throw an InvalidValueException
	 * instead.
	 */
	public abstract void fromString( String str ) throws InvalidValueException;
	
	/**
	 * Returns a sample of the longest string that should be
	 * enough to store the value of this type.
	 * 
	 * The length of the string may depend of, e.g., size and
	 * scale parameters, if any are defined for the particular type.
	 * 
	 * @return Sample of the longest string for this type. The
	 * 	content of the string does not necessarily reflect the
	 *  current value. 
	 */
	public abstract String getLongestString();
}

/*
 * $Log: SqlDataType.java,v $
 * Revision 1.2  2003/10/07 07:21:49  ariseppi
 * misc. corrections
 *
 */

// End of file.
