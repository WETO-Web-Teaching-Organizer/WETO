/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this added code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.gui;

import java.awt.Cursor;
import java.awt.event.ActionEvent;
import java.util.Enumeration;
import java.util.Iterator;

import javax.swing.JFrame;

import de.uni_paderborn.fujaba.asg.ASGElement;
import de.uni_paderborn.fujaba.gui.CMAFocusListener;
import de.uni_paderborn.fujaba.gui.PEColumn;
import de.uni_paderborn.fujaba.gui.PEEditPanel;
import de.uni_paderborn.fujaba.gui.PETextField;
import de.uni_paderborn.fujaba.uml.UMLProject;
import de.upb.tools.fca.FLinkedList;
import fi.uta.dbschema.metamodel.DBForeignKey;
import fi.uta.dbschema.metamodel.DBJunctionPair;
import fi.uta.dbschema.metamodel.DBQuery;
import fi.uta.dbschema.metamodel.DBSchema;
import fi.uta.dbschema.metamodel.DBTable;
import fi.uta.dbschema.metamodel.DBTableAttribute;
import fi.uta.dbschema.metamodel.DBTableAttributeJunction;
import fi.uta.dbschema.metamodel.DBTableJoin;
import fi.uta.dbschema.metamodel.DBTableJunction;


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:51 $
 * @version   $Revision: 1.3 $
 */
public class PEDBQuery extends DBPropertyEditor
{
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PETextField queryName;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PETextField packageName;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PETextArea whereClause;

   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBTableSelection tableSelection;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBTableJoinSelection tableJoinSelection;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBQuerySelection querySelection;

   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   FLinkedList addQueries = new FLinkedList();
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   FLinkedList delQueries = new FLinkedList();

   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   FLinkedList addJoins = new FLinkedList();
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   FLinkedList delJoins = new FLinkedList();


   /**
    * Constructor for class PEDBQuery
    *
    * @param frame  No description provided
    * @param title  No description provided
    * @param modal  No description provided
    */
   public PEDBQuery (JFrame frame, String title, boolean modal)
   {
      super (frame);
      setModal (modal);
      setTitle (title);
      try
      {
         pack();
         this.setTitle ("Query Editor");
      }
      catch (Exception e)
      {
         e.printStackTrace();
      }
      initPE();

      addFocusListener (new CMAFocusListener (queryName));
   }


   /**
    * Constructor for class PEDBQuery
    *
    * @param frame  No description provided
    */
   public PEDBQuery (JFrame frame)
   {
      this (frame, "", false);
   }


   /**
    * Constructor for class PEDBQuery
    *
    * @param frame  No description provided
    * @param modal  No description provided
    */
   public PEDBQuery (JFrame frame, boolean modal)
   {
      this (frame, "", modal);
   }


   /**
    * Constructor for class PEDBQuery
    *
    * @param frame  No description provided
    * @param title  No description provided
    */
   public PEDBQuery (JFrame frame, String title)
   {
      this (frame, title, false);
   }


   /**
    * Sets the attributeName attribute of the PEDBQuery object
    *
    * @param name  The new queryName value
    */
   public void setQueryName (String name)
   {
      queryName.setText (name);
   }


   /**
    * Sets the packageName attribute of the PEDBQuery object
    *
    * @param name  The new packageName value
    */
   public void setPackageName (String name)
   {
      packageName.setText (name);
   }


   /**
    * Sets the whereClause attribute of the PEDBQuery object
    *
    * @param name  The new whereClause value
    */
   public void setWhereClause (String name)
   {
      whereClause.setText (name);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param panel  No description provided
    */
   protected void additionalProperties (PEEditPanel panel)
   {
      queryName = new PETextField (this, "Query Name");
      packageName = new PETextField (this, "Package Name");
      whereClause = new PETextArea (this, "Where Clause");

      tableSelection = new PEDBTableSelection (this);
      tableJoinSelection = new PEDBTableJoinSelection (this);
      querySelection = new PEDBQuerySelection (this);

      queryName.setStatus ("Enter the name of the query");
      packageName.setStatus ("Enter the name of the package");
      whereClause.setStatus ("Enter the where clause of the query");

      tableJoinSelection.setAddListener (new PEDBQuery_addJoinButton_actionAdapter (this));
      tableJoinSelection.setRemoveListener (new PEDBQuery_removeJoinButton_actionAdapter (this));
      tableJoinSelection.setModifyListener (new PEDBQuery_modifyJoinButton_actionAdapter (this));

      querySelection.setAddListener (new PEDBQuery_addQueryButton_actionAdapter (this));
      querySelection.setRemoveListener (new PEDBQuery_removeQueryButton_actionAdapter (this));
      querySelection.setModifyListener (new PEDBQuery_modifyQueryButton_actionAdapter (this));

      PEColumn column = new PEColumn (this);

      column.add (queryName);
      column.add (packageName);
      column.add (whereClause);

      column.add (tableSelection);
      column.add (tableJoinSelection);
      column.add (querySelection);

      panel.add (column);
   }


   /**
    * Access method for an one to n association.
    *
    * @param e  The object added.
    */
   void addJoinButton_actionPerformed (ActionEvent e)
   {
      int[] firstSel = tableSelection.getLeft().getSelectedIndices();
      int[] secondSel = tableSelection.getRight().getSelectedIndices();
      if ( (firstSel.length == 1) &&  (secondSel.length == 1) &&  (firstSel[0] != secondSel[0]))
      {
         DBTableJoin newJoin = new DBTableJoin();

         DBTable firstTable = tableSelection.getFirstTable();
         DBTable secondTable = tableSelection.getSecondTable();

         DBTableJunction firstJunc = new DBTableJunction (firstTable);
         DBTableJunction secondJunc = new DBTableJunction (secondTable);

         newJoin.setFirstJunction (firstJunc);
         newJoin.setSecondJunction (secondJunc);

         addJoins.add (newJoin);
         tableJoinSelection.addToList (newJoin);

         String whereClause = this.getWhereClause();
         String firstTableName = firstTable.getName();
         String secondTableName = secondTable.getName();

//         Pattern pat = Pattern.compile("(.*)" + firstTableName + " *= *" + secondTableName + "")

         DBForeignKey key = null;

         Iterator iter = firstTable.iteratorOfForeignKeys();
         while (iter.hasNext())
         {
            key = (DBForeignKey) iter.next();
            DBTable table = key.getRevTable();
            if (table == secondTable)
            {
               while (iter.hasNext())
               {
                  iter.next();
               }
            }
            else
            {
               key = null;
            }
         }

         if (key == null)
         {
            Iterator iter2 = firstTable.iteratorOfRevForeignKeys();
            while (iter2.hasNext())
            {
               key = (DBForeignKey) iter2.next();
               DBTable table = key.getOriginalTable();
               if (table == secondTable)
               {
                  while (iter2.hasNext())
                  {
                     iter2.next();
                  }
               }
               else
               {
                  key = null;
               }
            }
         }
         StringBuffer buf = new StringBuffer();
         if (key != null)
         {
            if (!whereClause.equals (""))
            {
               buf.append (" AND ");
            }
            buf.append ("(");
            Iterator iter2 = key.iteratorOfJunctionPairs();
            while (iter2.hasNext())
            {
               DBJunctionPair pair = (DBJunctionPair) iter2.next();
               DBTableAttributeJunction origJunc = pair.getOriginalJunction();
               DBTableAttribute origAttr = origJunc.getTarget();
               DBTableAttributeJunction revJunc = pair.getRevJunction();
               DBTableAttribute revAttr = revJunc.getTarget();
               buf.append (firstTableName + "." + origAttr.getName() + " = " + secondTableName + "." + revAttr.getName());
               if (iter2.hasNext())
               {
                  buf.append (" AND ");
               }
            }
            buf.append (")");
         }

         whereClause += buf.toString();

         setWhereClause (whereClause);
      }
   }


   /**
    * Access method for an one to n association.
    *
    * @param e  The object added.
    */
   void addQueryButton_actionPerformed (ActionEvent e)
   {
      addJoins.clear();
      delJoins.clear();
      if (tableJoinSelection.hasElements())
      {
         DBQuery newQuery = new DBQuery (getQueryName());
         newQuery.setJavaPackage (getPackageName());
         newQuery.setWhereClause (getWhereClause());

         Enumeration enum = tableJoinSelection.getListList();
         while (enum.hasMoreElements())
         {
            PEDBItem item = (PEDBItem) enum.nextElement();
            DBTableJoin pair = (DBTableJoin) item.getIncrement();
            newQuery.addToJoins (pair);
         }

         addQueries.add (newQuery);
         querySelection.addToList (newQuery);

         tableJoinSelection.clearList();
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   protected void removeJoinButton_actionPerformed (ActionEvent e)
   {
      ASGElement incr = tableJoinSelection.getListSelectedIncr();
      if (incr != null)
      {
         /*
          *  if (incr instanceof DBJunctionPair)
          *  {
          *  DBJunctionPair pair = (DBJunctionPair) incr;
          *  }
          */
         addJoins.remove (incr);
         delJoins.add (incr);
         tableJoinSelection.removeFromList (incr);

         DBTableJoin join = (DBTableJoin) incr;

         DBTableJunction firstJunc = join.getFirstJunction();
         DBTableJunction secondJunc = join.getSecondJunction();

         DBTable firstTable = (DBTable) firstJunc.getTarget();
         DBTable secondTable = (DBTable) secondJunc.getTarget();

         String whereClause = this.getWhereClause();
         String firstTableName = firstTable.getName();
         String secondTableName = secondTable.getName();

//         Pattern pat = Pattern.compile("(.*)" + firstTableName + " *= *" + secondTableName + "")

         DBForeignKey key = null;

         Iterator iter = firstTable.iteratorOfForeignKeys();
         while (iter.hasNext())
         {
            key = (DBForeignKey) iter.next();
            DBTable table = key.getRevTable();
            if (table == secondTable)
            {
               while (iter.hasNext())
               {
                  iter.next();
               }
            }
            else
            {
               key = null;
            }
         }

         if (key == null)
         {
            Iterator iter2 = firstTable.iteratorOfRevForeignKeys();
            while (iter2.hasNext())
            {
               key = (DBForeignKey) iter2.next();
               DBTable table = key.getOriginalTable();
               if (table == secondTable)
               {
                  while (iter2.hasNext())
                  {
                     iter2.next();
                  }
               }
               else
               {
                  key = null;
               }
            }
         }
         StringBuffer buf = new StringBuffer();
         if (key != null)
         {
            buf.append (" AND (");
            Iterator iter2 = key.iteratorOfJunctionPairs();
            while (iter2.hasNext())
            {
               DBJunctionPair pair = (DBJunctionPair) iter2.next();
               DBTableAttributeJunction origJunc = pair.getOriginalJunction();
               DBTableAttribute origAttr = origJunc.getTarget();
               DBTableAttributeJunction revJunc = pair.getRevJunction();
               DBTableAttribute revAttr = revJunc.getTarget();
               buf.append (firstTableName + "." + origAttr.getName() + " = " + secondTableName + "." + revAttr.getName());
               if (iter2.hasNext())
               {
                  buf.append (" AND ");
               }
            }
            buf.append (")");
         }
         else
         {
            return;
         }
         int startInd = whereClause.indexOf (buf.toString());
         if (startInd == -1)
         {
            buf.delete (0, 5);
            startInd = whereClause.indexOf (buf.toString());
         }
         if (startInd != -1)
         {
            String removeString = buf.toString();
            int length = removeString.length();
            String newWhere = whereClause.substring (0, startInd);
            int secondStart = startInd + length;
            if (whereClause.length() <= secondStart)
            {
               newWhere += whereClause.substring (startInd + length);
            }
            this.setWhereClause (newWhere);
         }
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   protected void removeQueryButton_actionPerformed (ActionEvent e)
   {
      addJoins.clear();
      delJoins.clear();
      ASGElement incr = querySelection.getListSelectedIncr();
      if (incr != null)
      {
         addQueries.remove (incr);
         querySelection.removeFromList (incr);
         delQueries.add (incr);
         tableJoinSelection.clearList();
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   void modifyQueryButton_actionPerformed (ActionEvent e)
   {
      ASGElement oldIncr = querySelection.getListSelectedIncr();
      if (oldIncr != null && oldIncr instanceof DBQuery)
      {
         // Fix me: The new editor should make it better handling modified items.
         DBQuery curQuery = (DBQuery) oldIncr;

         DBQuery newQuery = new DBQuery();
         Iterator i = curQuery.iteratorOfJoins();
         while (i.hasNext())
         {
            DBTableJoin join = (DBTableJoin) i.next();
            if (!delJoins.contains (join))
            {
               DBTableJunction firstJunc = join.getFirstJunction();
               DBTable firstTable = (DBTable) firstJunc.getTarget();
               DBTableJunction secondJunc = join.getSecondJunction();
               DBTable secondTable = (DBTable) secondJunc.getTarget();

               DBTableJoin newJoin = new DBTableJoin();
               firstJunc = new DBTableJunction (firstTable);
               secondJunc = new DBTableJunction (secondTable);
               newJoin.setFirstJunction (firstJunc);
               newJoin.setSecondJunction (secondJunc);

               newQuery.addToJoins (newJoin);
            }
         }
         delJoins.clear();

         DBTableJoin join = null;

         Iterator iter = addJoins.iterator();
         while (iter.hasNext())
         {
            join = (DBTableJoin) iter.next();
            newQuery.addToJoins (join);
         }
         addJoins.clear();

         newQuery.setName (this.getQueryName());
         newQuery.setJavaPackage (this.getPackageName());
         newQuery.setWhereClause (this.getWhereClause());

         delQueries.add (curQuery);

         Enumeration enum = querySelection.getListList();
         while (enum.hasMoreElements())
         {
            PEDBItem item = (PEDBItem) enum.nextElement();

            ASGElement elem = item.getIncrement();

            querySelection.removeFromList (elem);
            if (elem != curQuery)
            {
               querySelection.addToList (elem);
            }
            else
            {
               querySelection.addToList (newQuery);
            }
         }

         addQueries.add (newQuery);
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   void modifyJoinButton_actionPerformed (ActionEvent e)
   {
      int[] firstSel = tableSelection.getLeft().getSelectedIndices();
      int[] secondSel = tableSelection.getRight().getSelectedIndices();
      if ( (firstSel.length == 1) &&  (secondSel.length == 1) &&  (firstSel[0] != secondSel[0]))
      {
         DBTableJoin join = (DBTableJoin) tableJoinSelection.getListSelectedIncr();
         DBTableJoin newJoin = new DBTableJoin();
         DBTableJunction junc = new DBTableJunction (tableSelection.getFirstTable());
         newJoin.setFirstJunction (junc);
         junc = new DBTableJunction (tableSelection.getSecondTable());
         newJoin.setSecondJunction (junc);

         delJoins.add (join);
         addJoins.remove (join);
         addJoins.add (newJoin);

         tableJoinSelection.removeFromList (join);
         tableJoinSelection.addToList (newJoin);
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void unparse()
   {
      if (getIncrement() instanceof DBSchema)
      {
         DBSchema schema = (DBSchema) getIncrement();
         querySelection.setIncrement (schema);
         tableSelection.fillLeftList();
         tableSelection.fillRightList();
         querySelection.fillList();
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected void parse()
   {
      DBSchema schema = (DBSchema) UMLProject.get().getCurrentDiagram();

      DBQuery query = null;

      Iterator iter = addQueries.iterator();
      while (iter.hasNext())
      {
         query = (DBQuery) iter.next();
         schema.addToItems (query);
      }
      addQueries.clear();

      iter = delQueries.iterator();
      while (iter.hasNext())
      {
         query = (DBQuery) iter.next();
		schema.removeFromItems (query);

         Iterator iter2 = query.iteratorOfJoins();
         while (iter2.hasNext())
         {
            DBTableJoin join = (DBTableJoin) iter2.next();
            schema.removeFromItems (join);
            join.removeYou();
         }

         query.removeYou();
      }
      delQueries.clear();
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected void cancel()
   {
      setVisible (false);
      dispose();
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void buttonOK_actionPerformed (ActionEvent e)
   {
//      super.buttonOK_actionPerformed (e);
      if (getFrame() != null)
      {
         getFrame().setCursor (Cursor.getPredefinedCursor (Cursor.WAIT_CURSOR));
      } // if

      try
      {
         setVisible (false);
         parse();
         UMLProject.get().refreshDisplay();
      }
      finally
      {
         if (getFrame() != null)
         {
            getFrame().setCursor (Cursor.getPredefinedCursor (Cursor.DEFAULT_CURSOR));
         }
      }
   }


   /**
    * Sets the increment attribute of the PEDBQuery object
    *
    * @param incr  The new increment value
    */
   public void setIncrement (ASGElement incr)
   {
      super.setIncrement (incr);
      if (getSchemaIncrement() != null)
      {
         setTitle ("Query Editor");
      }
   }


   /**
    * Get the queryName attribute of the PEDBQuery object
    *
    * @return   The queryName value
    */
   public String getQueryName()
   {
      return queryName.getText();
   }


   /**
    * Get the packageName attribute of the PEDBQuery object
    *
    * @return   The queryName value
    */
   public String getPackageName()
   {
      return packageName.getText();
   }


   /**
    * Get the packageName attribute of the PEDBQuery object
    *
    * @return   The queryName value
    */
   public String getWhereClause()
   {
      return whereClause.getText();
   }


   /**
    * Set the tableJoin attribute of the PEDBQuery object
    *
    * @param join  The new tableJoin value
    */
   public void setTableJoin (DBTableJoin join)
   {
      if (join != null)
      {
         DBTableJunction firstJunc = join.getFirstJunction();
         DBTable firstTable = (DBTable) firstJunc.getTarget();
         DBTableJunction secondJunc = join.getSecondJunction();
         DBTable secondTable = (DBTable) secondJunc.getTarget();
         tableSelection.setFirstTable (firstTable);
         tableSelection.setSecondTable (secondTable);
      }
   }


   /**
    * Get the tableJoin attribute of the PEDBQuery object
    *
    * @return   The tableJoin value
    */
   public DBTableJoin getTableJoin()
   {
      return tableJoinSelection.getJoin();
   }


   /**
    * Get the query attribute of the PEDBQuery object
    *
    * @param query  The new query value
    */
   public void setQuery (DBQuery query)
   {
      tableJoinSelection.fillList();
      setQueryName (query.getName());
      setPackageName (query.getJavaPackage());
      setWhereClause (query.getWhereClause());
      addJoins.clear();
      delJoins.clear();
   }


   /**
    * Get the query attribute of the PEDBQuery object
    *
    * @param query  The new querySelection value
    */
   public void setQuerySelection (DBQuery query)
   {
      querySelection.getList().selectIncrement (query);
   }


   /**
    * Get the query attribute of the PEDBQuery object
    *
    * @return   The query value
    */
   public DBQuery getQuery()
   {
      return querySelection.getQuery();
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:51 $
 * @version   $Revision: 1.3 $
 */
class PEDBQuery_addJoinButton_actionAdapter implements java.awt.event.ActionListener
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBQuery adaptee;


   /**
    * Constructor for class PEDBQuery_addJoinButton_actionAdapter
    *
    * @param adaptee  No description provided
    */
   PEDBQuery_addJoinButton_actionAdapter (PEDBQuery adaptee)
   {
      this.adaptee = adaptee;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void actionPerformed (ActionEvent e)
   {
      adaptee.addJoinButton_actionPerformed (e);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:51 $
 * @version   $Revision: 1.3 $
 */
class PEDBQuery_addQueryButton_actionAdapter implements java.awt.event.ActionListener
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBQuery adaptee;


   /**
    * Constructor for class PEDBQuery_addQueryButton_actionAdapter
    *
    * @param adaptee  No description provided
    */
   PEDBQuery_addQueryButton_actionAdapter (PEDBQuery adaptee)
   {
      this.adaptee = adaptee;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void actionPerformed (ActionEvent e)
   {
      adaptee.addQueryButton_actionPerformed (e);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:51 $
 * @version   $Revision: 1.3 $
 */
class PEDBQuery_removeJoinButton_actionAdapter implements java.awt.event.ActionListener
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBQuery adaptee;


   /**
    * Constructor for class PEDBQuery_removeJoinButton_actionAdapter
    *
    * @param adaptee  No description provided
    */
   PEDBQuery_removeJoinButton_actionAdapter (PEDBQuery adaptee)
   {
      this.adaptee = adaptee;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void actionPerformed (ActionEvent e)
   {
      adaptee.removeJoinButton_actionPerformed (e);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:51 $
 * @version   $Revision: 1.3 $
 */
class PEDBQuery_removeQueryButton_actionAdapter implements java.awt.event.ActionListener
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBQuery adaptee;


   /**
    * Constructor for class PEDBQuery_removeQueryButton_actionAdapter
    *
    * @param adaptee  No description provided
    */
   PEDBQuery_removeQueryButton_actionAdapter (PEDBQuery adaptee)
   {
      this.adaptee = adaptee;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void actionPerformed (ActionEvent e)
   {
      adaptee.removeQueryButton_actionPerformed (e);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:51 $
 * @version   $Revision: 1.3 $
 */
class PEDBQuery_modifyJoinButton_actionAdapter implements java.awt.event.ActionListener
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBQuery adaptee;


   /**
    * Constructor for class PEDBQuery_modifyJoinButton_actionAdapter
    *
    * @param adaptee  No description provided
    */
   PEDBQuery_modifyJoinButton_actionAdapter (PEDBQuery adaptee)
   {
      this.adaptee = adaptee;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void actionPerformed (ActionEvent e)
   {
      adaptee.modifyJoinButton_actionPerformed (e);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:51 $
 * @version   $Revision: 1.3 $
 */
class PEDBQuery_modifyQueryButton_actionAdapter implements java.awt.event.ActionListener
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBQuery adaptee;


   /**
    * Constructor for class PEDBQuery_modifyQueryButton_actionAdapter
    *
    * @param adaptee  No description provided
    */
   PEDBQuery_modifyQueryButton_actionAdapter (PEDBQuery adaptee)
   {
      this.adaptee = adaptee;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void actionPerformed (ActionEvent e)
   {
      adaptee.modifyQueryButton_actionPerformed (e);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:51 $
 * @version   $Revision: 1.3 $
 */
class PEDBTableSelection extends PEDoubleListSelection
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private PEDBQuery queryEditor;


   /**
    * Constructor for class PETableSelection
    *
    * @param parent  No description provided
    */
   PEDBTableSelection (DBPropertyEditor parent)
   {
      super (parent);
//      getLeft().setHeader ("");
//      getRight().setHeader ("");
      queryEditor = (PEDBQuery) parent;
      fillLeftList();
      fillRightList();
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void fillLeftList()
   {
      clearLeft();
      DBSchema schema = (DBSchema) UMLProject.get().getCurrentDiagram();
      Iterator iter = schema.iteratorOfItems();
      while (iter.hasNext())
      {
         Object obj = iter.next();
         if (obj instanceof DBTable)
         {
            addToLeft ((DBTable) obj);
         }
      }
   }


   /**
    * Get the firstTable attribute of the PEDBTableSelection object
    *
    * @return   The firstTable value
    */
   public DBTable getFirstTable()
   {
      DBTable table = (DBTable) left.getList().getSelectedIncrement();
      return table;
   }


   /**
    * Sets the firstTable attribute of the PEDBTableSelection object
    *
    * @param table  The new firstTable value
    */
   public void setFirstTable (DBTable table)
   {
      left.selectIncrement (table);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void fillRightList()
   {
      clearRight();
      DBSchema schema = (DBSchema) UMLProject.get().getCurrentDiagram();
      Iterator iter = schema.iteratorOfItems();
      while (iter.hasNext())
      {
         Object obj = iter.next();
         if (obj instanceof DBTable)
         {
            addToRight ((DBTable) obj);
         }
      }
   }


   /**
    * Get the secondTable attribute of the PEDBTableSelection object
    *
    * @return   The secondTable value
    */
   public DBTable getSecondTable()
   {
      DBTable table = (DBTable) right.getList().getSelectedIncrement();
      return table;
   }


   /**
    * Sets the secondTable attribute of the PEDBTableSelection object
    *
    * @param table  The new secondTable value
    */
   public void setSecondTable (DBTable table)
   {
      right.selectIncrement (table);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:51 $
 * @version   $Revision: 1.3 $
 */
class PEDBTableJoinSelection extends PESingleSelection
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private PEDBQuery queryEditor;


   /**
    * Constructor for class PEDBTableJoinSelection
    *
    * @param parent  No description provided
    */
   public PEDBTableJoinSelection (DBPropertyEditor parent)
   {
      super (parent);
      getList().setHeader ("Table joins");
      queryEditor = (PEDBQuery) parent;
   }


   /**
    * Get the join attribute of the PEDBTableJoinSelection object
    *
    * @return   The join value
    */
   public DBTableJoin getJoin()
   {
      DBTableJoin join = (DBTableJoin) list.getList().getSelectedIncrement();
      return join;
   }


   /**
    * Sets the join attribute of the PEDBTableJoinSelection object
    *
    * @param join  The new join value
    */
   public void setJoin (DBTableJoin join)
   {
      Iterator iter = getList().getList().iterator();
      boolean valueSet = false;
      while (!valueSet && iter.hasNext())
      {
         PEDBItem item = (PEDBItem) iter.next();
         DBTableJoin curJoin = (DBTableJoin) item.getIncrement();
         if (curJoin == join)
         {
            list.getList().setSelectedValue (item, true);
            valueSet = true;
         }
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected void listSelectionChanged()
   {
      ASGElement incr = list.getSelectedIncrement();
      if (incr instanceof DBTableJoin)
      {
         DBTableJoin join = (DBTableJoin) incr;
         queryEditor.setTableJoin (join);
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void fillList()
   {
      clearList();
      DBQuery query = queryEditor.getQuery();
      if (query == null)
      {
         return;
      }
      Iterator iter = query.iteratorOfJoins();
      while (iter.hasNext())
      {
         Object obj = iter.next();
         if (obj instanceof DBTableJoin)
         {
            list.add ((DBTableJoin) obj);
         }
      }
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:51 $
 * @version   $Revision: 1.3 $
 */
class PEDBQuerySelection extends PESingleSelection
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private PEDBQuery queryEditor;


   /**
    * Constructor for class PEDBTableJoinSelection
    *
    * @param parent  No description provided
    */
   PEDBQuerySelection (DBPropertyEditor parent)
   {
      super (parent);
      getList().setHeader ("Queries");
      queryEditor = (PEDBQuery) parent;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @return   The query value
    */
   public DBQuery getQuery()
   {
      ASGElement incr = list.getSelectedIncrement();
      if (incr instanceof DBQuery)
      {
         return (DBQuery) incr;
      }
      return null;
   }


   /**
    * Sets the query attribute of the PEDBQuerySelection object
    *
    * @param query  The new query value
    */
   public void setQuery (DBQuery query)
   {
      Iterator iter = getList().getList().iterator();
      boolean valueSet = false;
      while (!valueSet && iter.hasNext())
      {
         PEDBItem item = (PEDBItem) iter.next();
         DBQuery curQuery = (DBQuery) item.getIncrement();
         if (curQuery == query)
         {
            list.getList().setSelectedValue (item, true);
            valueSet = true;
         }
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected void listSelectionChanged()
   {
      ASGElement incr = list.getSelectedIncrement();
      if (incr instanceof DBQuery)
      {
         DBQuery query = (DBQuery) incr;
         queryEditor.setQuery (query);
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void fillList()
   {
      clearList();
      DBSchema schema = (DBSchema) getIncrement();
      Iterator iter = schema.iteratorOfItems();
      while (iter.hasNext())
      {
         Object obj = iter.next();
         if (obj instanceof DBQuery)
         {
            DBQuery query = (DBQuery) obj;
            list.add (query);
         }
      }
   }
}

/*
 * $Log: PEDBQuery.java,v $
 * Revision 1.3  2003/10/07 07:21:51  ariseppi
 * misc. corrections
 *
 */
