/*
 * Created on Nov 25, 2004
 *
 */
package fi.uta.cs.dbswtool;

import java.util.HashMap;
import java.util.Vector;

/**
 * @author csvera
 *
 */
public class JavaClassWriter implements RelAndQueryConstants {
	
	public JavaClassWriter( StringBuffer outputBuffer,
		String className ) {
		this.sb = outputBuffer;
		this.className = className;
	}
	
	public void WriteEmptyLine() {
		sb.append(endLine);
	}
	
	public void WritePackage( String pkg ) {
		if (!pkg.equals(""))
		{
			sb.append(
				javaPackageString
				+ " "
				+ pkg
				+ semicolon
				+ endLine );
		}
	}
	
	public void WriteDbImportsWithoutTypes() {
		sb.append(javaImportSqlString + endLine);
		sb.append(javaImportIteratorString + endLine);
		sb.append(javaImportSqlDatamodelString + endLine);
	}
	
	public void WriteDbImports() {
		WriteDbImportsWithoutTypes();
		sb.append(javaImportSqlDatatypesString + endLine);
	}
	
	public void WriteImport( String importedClass ) {
		sb.append("import " + importedClass + ";" + endLine );
	}
	
	public void WriteClass( String inheritance ) {
		sb.append( "public class "
			+ className
			+ " "
			+ inheritance
			+ " "
			+ openCurly
			+ endLine );
	}
	
	public void WritePrivateProperty( String type, String name ) {
		sb.append(
			tabString
			+ javaPrivateString
			+ " "
			+ type
			+ " "
			+ name
			+ semicolon
			+ endLine);
	}
	
	public void WriteDbConstructor( AttributeVector av,
		NameVector primaryKey, HashMap tempNames ) {
		sb.append( tabString
			+ javaPublicString
			+ " "
			+ className
			+ openParenthesis);
		sb.append(closeParenthesis + " " + openCurly + endLine);
		
		sb.append(tab2String
			+ "super();" + endLine);
		
		for (int j = 0; j < av.size(); j++) {
			// Constructor assignments
			Attribute a = av.getAttribute(j);
				
			String attrDesc = a.getDescription();
			if(!attrDesc.equals("")) {
				attrDesc = attrDesc.replaceAll("\\n", "\n" + tabString + "// ");
				sb.append(tabString
					+ "// " 
					+ attrDesc
					+ endLine);
			}
				
			sb.append(tab2String
				+ a.getRole() + javaDbAttributeSuffix
				+ " "
				+ javaAssignString
				+ " "
				+ "new "
				+ a.getJavaType()
				+ openParenthesis);
			if (a.getJavaType().equals("SqlChar")) {
				sb.append(a.getJavaTypeLength() + ", null");
			}
			if (a.getJavaType().equals("SqlVarchar")) {
				sb.append(a.getJavaTypeLength() + ", null");
			}
			if (a.getJavaType().equals("SqlLongvarchar")) {
				sb.append(a.getJavaTypeLength() + ", null");
			}
			if (a.getJavaType().equals("SqlDecimal")) {
				sb.append(
					a.getJavaTypeLength()
					+ comma
					+ " "
					+ a.getJavaTypeScale()
					+ ", null");
			}
			sb.append(closeParenthesis + semicolon + endLine);

			if( primaryKey!=null ) {
				if(primaryKey.nameExists(a.getRole())) {
					sb.append(tab2String
						+ tempNames.get(a.getRole())
						+ " "
						+ javaAssignString
						+ " "
						+ "new "
						+ a.getJavaType()
						+ openParenthesis);
					if (a.getJavaType().equals("SqlChar")) {
						sb.append(a.getJavaTypeLength() + ", null");
					}
					if (a.getJavaType().equals("SqlVarchar")) {
						sb.append(a.getJavaTypeLength() + ", null");
					}
					if (a.getJavaType().equals("SqlLongvarchar")) {
						sb.append(a.getJavaTypeLength() + ", null");
					}
					if (a.getJavaType().equals("SqlDecimal")) {
						sb.append(
							a.getJavaTypeLength()
							+ comma
							+ " "
							+ a.getJavaTypeScale()
							+ ", null");
					}
					sb.append(closeParenthesis + semicolon + endLine);
				}
			}
		}
		if( primaryKey != null ) {
		    // Create setPrime() - method calls
			Vector primeAttrNameVector = primaryKey.getVector();
			for (int p = 0; p < primeAttrNameVector.size(); p++) {
				String primeAttrName =
					(String) primeAttrNameVector.elementAt(p);
				sb.append( tab2String 
					+ primeAttrName + javaDbAttributeSuffix 
					+ ".setPrime(true);" + endLine);
			}
		}
		sb.append(tabString + closeCurly + endLine);
	}
	
	public void WritePlainConstructor() {
		sb.append( tabString
			+ javaPublicString
			+ " "
			+ className
			+ "() {"
			+ endLine);
		sb.append(
			tab2String + "super();" + endLine 
			+ tabString + closeCurly + endLine );
	}
	
	public void WriteSetFromResultSet( AttributeVector av,
		NameVector primaryKey, HashMap tempNames ) {
		sb.append( tabString
			+ "public void setFromResultSet(ResultSet resultSet, int baseIndex) throws SQLException, InvalidValueException {"
			+ endLine);
		for (int j = 0; j < av.size(); j++) {
			Attribute a = av.getAttribute(j);
			sb.append(tab2String 
				+ a.getRole() + javaDbAttributeSuffix
				+ ".jdbcSetValue( "
				+ "(" + a.getJdbcType() + ") "
				+ "resultSet.getObject(baseIndex+" + (j+1) + ") "
				+ ");" + endLine);
			if( primaryKey != null  ) {
				if(primaryKey.nameExists(a.getRole())) {
					sb.append(tab2String
						+ tempNames.get(a.getRole()) + ".jdbcSetValue("
					    + a.getRole() + javaDbAttributeSuffix + ".jdbcGetValue());"
					    + endLine );
				}
		    }
		}
		sb.append(tabString + "}" + endLine);
	}
	
	public void WriteDbToString( String name, AttributeVector av ) {
		sb.append( tabString
			+ javaPublicString
			+ " String toString() {"
			+ endLine);
		sb.append(tab2String + "StringBuffer sb = new StringBuffer();\n");
		sb.append(tab2String
			+ "sb.append(\""
			+ name
			+ "\\n\");"
			+ endLine);
		for (int l = 0; l < av.size(); l++) { 
			Attribute a = av.getAttribute(l);
			sb.append(
				tab2String
				+ "sb.append(\""
				+ a.getRole()
				+ ":\" +  "
				+ a.getRole() + javaDbAttributeSuffix
				+ ".toString() + \"\\n\");"
				+ endLine);
			}
		sb.append(tab2String + "sb.append(\"\\n\");" + endLine);
		sb.append(tab2String + "return(sb.toString());" + endLine);
		sb.append(tabString + closeCurly + endLine);
	}
	
	public void WriteDbEquals( AttributeVector av ) {
		sb.append( tabString
			+ javaPublicString
			+ " boolean equals( Object obj ) {" + endLine
			+ tab2String
			+ "if( obj == null ) return false;" + endLine 
			+ tab2String
			+ "if( !(obj instanceof " + className + ") ) return false;" + endLine 
			+ tab2String
			+ className + " dbObj = (" + className + ")obj;" + endLine );
		for (int j = 0; j < av.size(); j++) {
			Attribute a = av.getAttribute(j);
			sb.append(tab2String 
				+ "if( !" + a.getRole() + javaDbAttributeSuffix 
				+ ".equals( dbObj." + a.getRole() + javaDbAttributeSuffix + " ) ) return false;"
				+ endLine);
		}
		sb.append(tab2String 
			+ "return true;" + endLine 
			+ tabString + "}" + endLine);
	}
	
	public void WriteClone() {
		sb.append( tabString 
			+ "public Object clone() throws CloneNotSupportedException " 
			+ openCurly + endLine);
		sb.append(tab2String + "return super.clone();" + endLine);
		sb.append(tabString + closeCurly + endLine);
	}
	
	public void WriteGetter( String type, String property ) {
		String capName =
			property.substring(0, 1).toUpperCase() + 
			property.substring(1, property.length());
		sb.append( tabString
			+ javaPublicString
			+ " " + type + " "
			+ "get" + capName
			+ openParenthesis
			+ closeParenthesis
			+ " "
			+ openCurly
			+ endLine
			+ tab2String
			+ "return "
			+ property + ";"
			+ endLine
			+ tabString
			+ closeCurly
			+ endLine );
	}
	
	public void WriteBeanGetter( String beanType, String beanProperty ) {
		String capName =
			beanProperty.substring(0, 1).toUpperCase() 
			+ beanProperty.substring(1, beanProperty.length());
		sb.append( tabString
			+ javaPublicString
			+ " " + beanType + " "
			+ "get" + capName 
			+ openParenthesis
			+ closeParenthesis
			+ " "
			+ openCurly
			+ endLine
			+ tab2String
			+ "return get"
			+ capName + javaDbAttributeSuffix + "().getValue();"
			+ endLine
			+ tabString
			+ closeCurly
			+ endLine );
	}
	
	public void WriteBeanSetter( String beanType, String beanProperty ) {
		String capName =
			beanProperty.substring(0, 1).toUpperCase() 
			+ beanProperty.substring(1, beanProperty.length());
		sb.append( tabString
			+ javaPublicString
			+ " void "
			+ "set" + capName 
			+ "( "
			+ beanType + " newValue "
			+ ") throws InvalidValueException "
			+ openCurly
			+ endLine
			+ tab2String
			+ "get"
			+ capName + javaDbAttributeSuffix + "().setValue( newValue );"
			+ endLine
			+ tabString
			+ closeCurly
			+ endLine );
	}
	
	public void WriteDbInsert( String table, AttributeVector av ) {
		sb.append( tabString
			+ "public void insert(Connection con) throws SQLException, ObjectNotValidException {" + endLine );
		for (int j = 0; j < av.size(); j++) {
			Attribute a = av.getAttribute(j);
			sb.append(tab2String
				+ "if( !" + a.getRole() + javaDbAttributeSuffix
				+ ".isValid() ) "
				+ "throw new ObjectNotValidException(\"" + a.getRole() + "\");" + endLine );
		}
		sb.append(tab2String
			+ "String prepareString = \"insert into "
			+ table + " values(?");
		for (int j = 1; j < av.size(); j++) {
			sb.append(comma + questionMark);
		}
		sb.append(");\";" + endLine);
		sb.append(tab2String
			+ "PreparedStatement ps = con.prepareStatement(prepareString);" + endLine );
		for (int j = 0; j < av.size(); j++) {
			Attribute a = av.getAttribute(j);
			sb.append(tab2String
				+ "ps.setObject(" + (j+1) + ", "
				+ a.getRole() + javaDbAttributeSuffix + ".jdbcGetValue());" + endLine );
		}
		sb.append(tab2String
			+ "int rows = ps.executeUpdate();" + endLine
			+ tab2String 
			+ "ps.close();" + endLine
			+ tab2String
			+ "if( rows != 1 ) throw new SQLException(\"Insert did not return 1 row\");" + endLine 
			+ tabString
			+ "}" + endLine );
	}
	
	public void WriteDbUpdate( String table, AttributeVector av,
		NameVector primaryKey, HashMap tempNames ) {
		sb.append( tabString
			+ "public void update(Connection con) " 
			+ "throws SQLException, ObjectNotValidException, NoSuchItemException {"
			+ endLine );
		for (int j = 0; j < av.size(); j++) {
			Attribute a = av.getAttribute(j);
			sb.append(tab2String
				+ "if( !" + a.getRole() + javaDbAttributeSuffix
				+ ".isValid() ) "
				+ "throw new ObjectNotValidException(\"" + a.getRole() + "\");" + endLine );
		}
		sb.append(tab2String
			+ "String prepareString = \"update "
			+ table + " set ");
		boolean first = true;
		for (int j = 0; j < av.size(); j++)
		{
			Attribute a = av.getAttribute(j);
			if (first) {
				first = false;
			} else {
				sb.append(", ");
			}
			sb.append(a.getRole() + " = ?");
		}
		sb.append(" where ");
		boolean firstKey = true;
		for (int j = 0; j < av.size(); j++) {
			Attribute a = av.getAttribute(j);
			if (primaryKey.nameExists(a.getRole()))
			{
				if (firstKey) {
					firstKey = false;
				} else {
					sb.append(" AND ");
				}
				sb.append(a.getRole() + " = ?");
			}
		}
		sb.append("\";" + endLine);
		sb.append(tab2String
			+ "PreparedStatement ps = con.prepareStatement(prepareString);" + endLine );
		int orderNo = 0;
		for (int j = 0; j < av.size(); j++) {
			orderNo++;
			Attribute a = av.getAttribute(j);
			sb.append(tab2String
				+ "ps.setObject(" + orderNo + ", "
				+ a.getRole() + javaDbAttributeSuffix + ".jdbcGetValue());" + endLine );
		}
		for (int j = 0; j < av.size(); j++) {
			Attribute a = av.getAttribute(j);
			if (primaryKey.nameExists(a.getRole())) {
				orderNo++;
				sb.append(tab2String 
					+ "ps.setObject(" + orderNo + ", "
					+ tempNames.get(a.getRole()) + ".jdbcGetValue());" + endLine );
			}
		}
		sb.append(tab2String
			+ "int rows = ps.executeUpdate();" + endLine
			+ tab2String 
			+ "ps.close();" + endLine );
		
		sb.append(tab2String
			+ "try {" + endLine );
		for (int j = 0; j < av.size(); j++) {
		    Attribute a = av.getAttribute(j);
		    if(primaryKey.nameExists(a.getRole())) {
		    	sb.append(tab3String
	    			+ tempNames.get(a.getRole()) + ".jdbcSetValue("
					+ a.getRole() + javaDbAttributeSuffix + ".jdbcGetValue());"
					+ endLine );
		    }
		}
		sb.append(tab2String
			+ "} catch( InvalidValueException e ) {" + endLine + tab3String
			+ "// Ignored (isValid already called)" + endLine + tab2String
			+ "}" + endLine );
		
		sb.append(tab2String
			+ "if( rows != 1 ) throw new NoSuchItemException();" + endLine 
			+ tabString
			+ "}" + endLine );
	}
	
	public void WriteDbDelete( String table, AttributeVector av,
		NameVector primaryKey, HashMap tempNames ) {
		sb.append( tabString
			+ "public void delete(Connection con) " 
			+ "throws SQLException, TooManyItemsException, NoSuchItemException {"
			+ endLine );
		sb.append(tab2String
			+ "String prepareString = \"delete from "
			+ table + " where ");
		boolean firstKey = true;
		for (int j = 0; j < av.size(); j++) {
			Attribute a = av.getAttribute(j);
			boolean useThis = false;
			if( primaryKey == null ) {
				useThis = true;
			} else {
				if( primaryKey.nameExists(a.getRole())) {
					useThis = true;
				}
			}
			if( useThis ) {
				if (firstKey) {
					firstKey = false;
				} else {
					sb.append(" AND ");
				}
				sb.append(a.getRole() + " = ?");
			}
		}
		sb.append("\";" + endLine);
		sb.append(tab2String
			+ "PreparedStatement ps = con.prepareStatement(prepareString);" + endLine );
		int orderNo = 0;
		for (int j = 0; j < av.size(); j++) {
			Attribute a = av.getAttribute(j);
			boolean useThis = false;
			String keyVar = "";
			if( primaryKey == null ) {
				useThis = true;
				keyVar = a.getRole() + javaDbAttributeSuffix;
			} else {
				if( primaryKey.nameExists(a.getRole())) {
					useThis = true;
					keyVar = tempNames.get(a.getRole()).toString();
				}
			}
			if( useThis ) {
				orderNo++;
				sb.append(tab2String 
					+ "ps.setObject(" + orderNo + ", "
					+ keyVar + ".jdbcGetValue());" + endLine );
			}
		}
		sb.append(tab2String
			+ "int rows = ps.executeUpdate();" + endLine
			+ tab2String
			+ "ps.close();" + endLine
			+ tab2String
			+ "if( rows > 1 ) throw new TooManyItemsException();" + endLine
				+ tab2String
			+ "if( rows < 1 ) throw new NoSuchItemException();" + endLine 
			+ tabString
			+ "}" + endLine );
	}
	
	public void WriteDbSelect( String table, AttributeVector av,
		NameVector primaryKey) {
		sb.append( tabString
			+ "public void select(Connection con) " 
			+ "throws SQLException, InvalidValueException, NoSuchItemException {"
			+ endLine );
		sb.append(tab2String
			+ "String prepareString = \"select * from "
			+ table + " where ");
		boolean firstKey = true;
		for (int j = 0; j < av.size(); j++) {
			Attribute a = av.getAttribute(j);
			boolean useThis = false;
			if( primaryKey == null ) {
				useThis = true;
			} else {
				if( primaryKey.nameExists(a.getRole())) {
					useThis = true;
				}
			}
			if( useThis ) {
				if (firstKey) {
					firstKey = false;
				} else {
					sb.append(" AND ");
				}
				sb.append(a.getRole() + " = ?");
			}
		}
		sb.append("\";" + endLine);
		sb.append(tab2String
			+ "PreparedStatement ps = con.prepareStatement(prepareString);" + endLine );
		int orderNo = 0;
		for (int j = 0; j < av.size(); j++)
		{
			Attribute a = av.getAttribute(j);
			boolean useThis = false;
			if( primaryKey == null ) {
				useThis = true;
			} else {
				if( primaryKey.nameExists(a.getRole())) {
					useThis = true;
				}
			}
			if( useThis ) {
				orderNo++;
				sb.append(tab2String 
					+ "ps.setObject(" + orderNo + ", "
					+ a.getRole() + javaDbAttributeSuffix + ".jdbcGetValue());" + endLine );
			}
		}
		sb.append(tab2String
			+ "ResultSet rs = ps.executeQuery();" + endLine
			+ tab2String
			+ "if (rs.next()) {" + endLine
			+ tab3String
			+ "setFromResultSet(rs,0);" + endLine
			+ tab3String
			+ "rs.close();" + endLine 
			+ tab3String
			+ "ps.close();" + endLine
			+ tab2String
			+ "} else {" + endLine
			+ tab3String
			+ "rs.close();" + endLine
			+ tab3String
			+ "ps.close();" + endLine
			+ tab3String
			+ "throw new NoSuchItemException();" + endLine
			+ tab2String
			+ "}" + endLine
			+ tabString
			+ "}" + endLine );
	}
	
	public void WriteDbSelectionIterator( String table,
		String elementClass ) {
		sb.append( tabString
			+ "public static Iterator selectionIterator( Connection con, String whereClause ) " 
			+ "throws SQLException {"
			+ endLine );
		sb.append(tab2String
			+ "String prepareString;" + endLine
			+ tab2String
			+ "if( whereClause.equals(\"\") )" + endLine
			+ tab3String
			+ "prepareString = \"select * from "
			+ table + "\";" + endLine
			+ tab2String
			+ "else" + endLine
			+ tab3String
			+ "prepareString = \"select * from "
			+ table + " where \" + whereClause;" + endLine
			+ tab2String
			+ "PreparedStatement ps = con.prepareStatement(prepareString);" + endLine
			+ tab2String
			+ "return new SqlSelectionIterator( ps, " 
			+ elementClass
			+ ".class );" + endLine
			+ tabString
			+ "}"
			+ endLine );
	}
	
	public void WriteClassEndAndFooter() {
		sb.append(closeCurly + endLine
			+ endLine
			+ "// End of file." + endLine );
	}
	
	public void WriteClassJavaDocBegin() {
		sb.append( "/**" + endLine );
	}
	
	public void WriteClassJavaDocLine( String comment ) {
		if( !comment.equals("")) {
			comment = comment.replaceAll(
				"\\n", endLine + " * " );
		}
		sb.append( " * " + comment + endLine );
	}
	
	public void WriteClassJavaDocEnd() {
		sb.append( " */" + endLine );
	}
	
	public void WriteJavaDocBegin() {
		sb.append(tabString
			+ "/**" + endLine );
	}
	
	public void WriteJavaDocLine( String comment ) {
		if( !comment.equals("")) {
			comment = comment.replaceAll(
				"\\n", endLine + tabString + " * " );
		}
		sb.append(tabString
			+ " * " + comment + endLine );
	}
	
	public void WriteJavaDocEnd() {
		sb.append(tabString
			+ " */" + endLine );
	}
	
	private StringBuffer sb;
	private String className; 
}
