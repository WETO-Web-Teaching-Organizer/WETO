/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.cs.dbswtool;

import java.util.Vector;

/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:48 $
 * @version   $Revision: 1.2 $
 */
public class Relation
{
	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	private String name;
	
	private String description;
	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	private String packageName; // Java package for the generated files
	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	private AttributeVector attributeVector;
	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	private NameVector primaryKey;
	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	private Vector uniqueVector; // This is for unique namevectors here.
	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	private Vector foreignKeyVector;

	private Vector exampleVector;

	/**
	 * Constructor for class Relation
	 */
	public Relation()
	{
		name = "";
		description = "";
		packageName = "";
		attributeVector = new AttributeVector();
		primaryKey = new NameVector();
		uniqueVector = new Vector();
		foreignKeyVector = new Vector();
		exampleVector = new Vector();
	}

	/**
	 * Sets the name attribute of the Relation object
	 *
	 * @param name  The new name value
	 */
	public void setName(String name)
	{
		this.name = name;
	}

	/**
	 * Get the name attribute of the Relation object
	 *
	 * @return   The name value
	 */
	public String getName()
	{
		return name;
	}
	
	public void setDescription(String description)
	{
		this.description = description;
	}
	
	public String getDescription()
	{
		return description;
	}

	/**
	 * Sets the package attribute of the Relation object
	 *
	 * @param packageName  The new package value
	 */
	public void setPackage(String packageName)
	{
		this.packageName = packageName;
	}

	/**
	 * Get the package attribute of the Relation object
	 *
	 * @return   The package value
	 */
	public String getPackage()
	{
		return packageName;
	}

	/**
	 * Get the attributeVector attribute of the Relation object
	 *
	 * @return   The attributeVector value
	 */
	public AttributeVector getAttributeVector()
	{
		return attributeVector;
	}

	/**
	 * Get the primaryKey attribute of the Relation object
	 *
	 * @return   The primaryKey value
	 */
	public NameVector getPrimaryKey()
	{
		return primaryKey;
	}

	/**
	 * Sets the primaryKey attribute of the Relation object
	 *
	 * @param primaryKey  The new primaryKey value
	 */
	public void setPrimaryKey(NameVector primaryKey)
	{
		this.primaryKey = primaryKey;
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param name  No description provided
	 * @return      No description provided
	 */
	public boolean attributeNameExists(String name)
	{
		if (attributeVector.getAttribute(name) == null)
		{
			return false;
		} else
		{
			return true;
		}
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param role  No description provided
	 * @return      No description provided
	 */
	public boolean attributeRoleExists(String role)
	{
		if (attributeVector.getAttributeByRole(role) == null)
		{
			return false;
		} else
		{
			return true;
		}
	}

	/**
	 * Get the uniqueVector attribute of the Relation object
	 *
	 * @return   The uniqueVector value
	 */
	public Vector getUniqueVector()
	{
		return uniqueVector;
	}

	/**
	 * Access method for an one to n association.
	 *
	 * @param unique  The object added.
	 */
	public void addUnique(NameVector unique)
	{
		uniqueVector.add(unique);
	}

	/**
	 * Get the foreignKeyVector attribute of the Relation object
	 *
	 * @return   The foreignKeyVector value
	 */
	public Vector getForeignKeyVector()
	{
		return foreignKeyVector;
	}

	/**
	 * Access method for an one to n association.
	 *
	 * @param foreignKey  The object added.
	 */
	public void addForeignKey(ForeignKey foreignKey)
	{
		foreignKeyVector.add(foreignKey);
	}

	/**
		* Get the exampleVector attribute of the Relation object
		*
		* @return   The foreignKeyVector value
		*/
	public Vector getExampleVector()
	{
		return exampleVector;
	}

	/**
		* Access method for an one to n association.
		*
		* @param foreignKey  The object added.
		*/
	public void addExample(String[] example)
	{
		exampleVector.add(example);
	}

	/**
	 * Access method for an one to n association.
	 *
	 * @param newAttribute  The object added.
	 */
	public void addAttribute(Attribute newAttribute)
	{
		attributeVector.addAttribute(newAttribute);
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	public void output()
	{
		System.out.println("Relation " + name);
		attributeVector.output();
	}

	public boolean isUnique(NameVector names)
	{
		NameVector primary = this.getPrimaryKey();
		Vector nameVector = names.getVector();
		if (names.size() == primary.size())
		{
			for (int i = 0; i < nameVector.size(); i++)
			{
				if (!primary.nameExists((String) nameVector.get(i)))
				{
					i = nameVector.size();
				} else if (i + 1 == nameVector.size())
				{
					return true;
				}
			}
		}
		Vector uniques = this.getUniqueVector();
		for (int i = 0; i < uniques.size(); i++)
		{
			NameVector unique = (NameVector) uniques.get(i);
			if (names.size() == unique.size())
			{
				for (int i2 = 0; i2 < nameVector.size(); i2++)
				{
					if (!unique.nameExists((String) nameVector.get(i2)))
					{
						i2 = nameVector.size();
					} else if (i2 + 1 == nameVector.size())
					{
						return true;
					}
				}
			}
		}
		return false;
	}

}

/*
 * $Log: Relation.java,v $
 * Revision 1.2  2003/10/07 07:21:48  ariseppi
 * misc. corrections
 *
 */
