package fi.uta.cs.sqldatamodel;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Parent class for objects that can have their values set from a given
 * ResultSet.
 * 
 * Database-originating objects should extend this class.
 */
public abstract class SqlAssignableObject {
	
	/**
	 * Default constructor.
	 */
	public SqlAssignableObject() {
	}
	
	/**
	 * Abstract method that sets the values of the object from a given
	 * ResultSet.
	 * 
	 * Inherited classes must implement this method to perform the concrete
	 * assignment.
	 * 
	 * @param resultSet ResultSet to be used to set values.
	 * 
	 * @param baseIndex Base index of the objects used from the ResultSet (exclusive).
	 * 
	 * @throws SQLException If given ResultSet can not be read, or is incompatible.
	 * @throws InvalidValueException If the value in ResultSet is not compatible
	 * 	with the data object constraints.
	 */
	public abstract void setFromResultSet( ResultSet resultSet, int baseIndex ) throws SQLException, InvalidValueException;
}
