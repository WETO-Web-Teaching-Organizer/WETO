/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.actions;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import javax.swing.AbstractAction;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JViewport;

import de.uni_paderborn.fujaba.app.FrameMain;
import de.uni_paderborn.fujaba.asg.ASGElement;
import de.uni_paderborn.fujaba.fsa.FSAObject;
import de.uni_paderborn.fujaba.fsa.SelectionManager;
import de.uni_paderborn.fujaba.fsa.unparse.FSAInterface;
import de.uni_paderborn.fujaba.uml.UMLProject;
import fi.uta.dbschema.metamodel.DBNodeInterface;
import fi.uta.dbschema.metamodel.DBSchema;


/**
 * @author
 * @created   $Date: 2003/10/07 07:21:50 $
 * @version   $Revision: 1.6 $
 */
public class FindDBTableAction extends AbstractAction
{

   /*
    *  (non-Javadoc)
    *  @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
    */
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param event  No description provided
    */
   public void actionPerformed (ActionEvent event)
   {
      ASGElement element = UMLProject.get().getCurrentDiagram();
      if (! (element instanceof DBSchema))
      {
         return;
      }
      DBSchema schema = (DBSchema) element;

      Iterator iter = schema.iteratorOfItems();

      final JComboBox combo = new JComboBox();

      HashMap tables = new HashMap();

      ArrayList tableList = new ArrayList();

      while (iter.hasNext())
      {
         Object obj = iter.next();
         if (obj instanceof DBNodeInterface)
         {
            tables.put (obj.toString(), obj);
         }
      }

      Set keySet = tables.keySet();

      Object[] tableArray = keySet.toArray();
      Arrays.sort (tableArray);
      for (int i = 0; i < tableArray.length; i++)
      {
         combo.addItem (tables.get (tableArray[i]));
      }

      combo.setEditable (true);

      int option = JOptionPane.showConfirmDialog (FrameMain.get(), combo, "Find table/view", JOptionPane.OK_CANCEL_OPTION);

      if (option == JOptionPane.CANCEL_OPTION)
      {
         return;
      }

      DBNodeInterface table = null;

      Object selectedObj = combo.getSelectedItem();

      if (selectedObj == null)
      {
         return;
      }

      if (selectedObj instanceof DBNodeInterface)
      {
         table = (DBNodeInterface) selectedObj;
      }
      else
      {
         table = (DBNodeInterface) tables.get (selectedObj);
      }

      if (table == null)
      {
         JOptionPane.showMessageDialog (FrameMain.get(), "Table/view " + selectedObj + " was not found.", "Table/view not found", JOptionPane.ERROR_MESSAGE);
         return;
      }

      FSAInterface iFace = table.getFSAInterface();
      FSAObject fsaObj = iFace.getFirstFromFsaObjects();
      JComponent comp = fsaObj.getJComponent();
      SelectionManager selMan = SelectionManager.get();
      selMan.clear();
      selMan.setSelected (comp, true);
      selMan.setFocused (comp, true);
      Container parent = comp.getParent();
      if (parent != null && parent instanceof JLayeredPane)
      {
         JLayeredPane pane = (JLayeredPane) parent;
         pane.moveToFront (comp);
         Container cont = parent.getParent();
         Container vport = cont.getParent();
         JViewport viewport = (JViewport) vport;

         viewport.setViewPosition (comp.getLocation());
      }
   }
}

/*
 * $Log: FindDBTableAction.java,v $
 * Revision 1.6  2003/10/07 07:21:50  ariseppi
 * misc. corrections
 *
 */
