/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.cs.sqldatatypes;

import fi.uta.cs.sqldatamodel.InvalidValueException;
import fi.uta.cs.sqldatamodel.NullNotAllowedException;

/**
 * Concrete implementation of integer SQL data type.
 * 
 * Value data type is java.lang.Integer.
 * JDBC data type is java.lang.Integer.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:49 $
 * @version   $Revision: $
 */
public class SqlInteger extends SqlDataType {
	/**
	 * Value attribute.
	 */
	private Integer value;

	/**
	 * Default constructor for class SqlInteger.
	 */
	public SqlInteger() {
		super();
		value = null;
	}
	
	/**
	 * Initializing constructor for Fujaba.
	 * 
	 * @param value Initial value as its string representation.
	 *  If an invalid value is given, the result is undefined
	 *  (a runtime exception may be thrown).
	 */
	public SqlInteger( String value )
	{
		this();
		try {
			fromString( value );
		} catch( InvalidValueException e ) {
			// Ignored
		}
	}

//	======================================================================
//	Bean property methods
//	======================================================================
	
	/**
	 * Gets the value.
	 * 
	 * @return The current value. Passed by copy.
	 */
	public Integer getValue() {
		if( value == null ) return null;
		return new Integer( value.intValue() );
	}
	
	/**
	 * Sets the value.
	 * 
	 * @param value New value, passed by copy.
	 * 
	 * @throws NullNotAllowedException if a null-value is given, but
	 * 	not allowed.
	 */
	public void setValue( Integer value ) throws NullNotAllowedException {
		if( value==null && !isNullAllowed() ) 
			throw new NullNotAllowedException();
		setValueUnchecked( value );
	}
	
	/**
	 * Sets the value without performing any checks.
	 * 
	 * @param value New value, passed by copy.
	 */
	public void setValueUnchecked( Integer value ) {
		if( value == null ) {
			this.value = null;
		} else {
			this.value = new Integer( value.intValue() );
		}
	}
	
//	======================================================================
//	JDBC property methods
//	======================================================================
	
	/**
	 * Gets the value as the type used with JDBC.
	 * 
	 * @return The current value.
	 */
	public Integer jdbcGetValue() {
		return getValue();
	}
	
	/**
	 * Sets the value as the type used with JDBC.
	 * 
	 * @param value New value.
	 *
	 * @throws NullNotAllowedException if a null-value is given, but
	 * 	not allowed.
	 */
	public void jdbcSetValue( Integer value ) throws NullNotAllowedException {
		setValue( value );
	}
	
//	======================================================================
//	SqlDataType methods	
//	======================================================================

	public String toString() {
		if( value == null ) return "";
		return value.toString();
	}
	
	public void fromString( String str ) throws NullNotAllowedException {
		Integer newValue = null;
		if( str!=null ) {
			if( str.length()>0 ) {
				newValue = Integer.valueOf( str );
			}
		}
		setValue( newValue );
	}

	public boolean isValid() {
		if( (value==null) && (!isNullAllowed()) ) return false;
		return true;
	}

	public boolean equals(Object obj) {
		if( !(obj instanceof SqlInteger) ) return false;
		SqlInteger intObj = (SqlInteger)obj;
		
		if( value==null || intObj.value==null ) {
			if( value==null && intObj.value==null ) return true;
			return false;
		}
		
		return value.equals( intObj.value );
	}

	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	
	public String getLongestString() {
		return String.valueOf(Integer.MIN_VALUE);
	}
}

/*
 * $Log: SqlInteger.java,v $
 * Revision 1.2  2003/10/07 07:21:49  ariseppi
 * misc. corrections
 *
 */

// End of file.
