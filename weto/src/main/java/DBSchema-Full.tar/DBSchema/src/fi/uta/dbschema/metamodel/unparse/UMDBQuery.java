/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.metamodel.unparse;

import javax.swing.JComponent;

import de.uni_paderborn.fujaba.fsa.FSAObject;
import de.uni_paderborn.fujaba.fsa.FSAPanel;
import de.uni_paderborn.fujaba.fsa.FSASeparatedPanel;
import de.uni_paderborn.fujaba.fsa.FSATextFieldLabel;
import de.uni_paderborn.fujaba.fsa.listener.ArrowMoveListener;
import de.uni_paderborn.fujaba.fsa.listener.AscendDescendMouseHandler;
import de.uni_paderborn.fujaba.fsa.listener.BorderHighlighter;
import de.uni_paderborn.fujaba.fsa.listener.ComponentBorderListener;
import de.uni_paderborn.fujaba.fsa.listener.ComponentCursorListener;
import de.uni_paderborn.fujaba.fsa.listener.DragMouseListener;
import de.uni_paderborn.fujaba.fsa.listener.SelectionListenerHelper;
import de.uni_paderborn.fujaba.fsa.listener.SelectionMouseListener;
import de.uni_paderborn.fujaba.fsa.swing.ColumnRowLayout;
import de.uni_paderborn.fujaba.fsa.swing.border.StateBorder;
import de.uni_paderborn.fujaba.fsa.unparse.AbstractUnparseModule;
import de.uni_paderborn.fujaba.fsa.unparse.LogicUnparseInterface;
import de.uni_paderborn.fujaba.fsa.update.AbstractUpdater;
import fi.uta.dbschema.metamodel.DBQuery;


/**
 * @author
 * @created   $Date: 2003/10/07 07:21:53 $
 * @version   $Revision: 1.2 $
 */
public class UMDBQuery extends AbstractUnparseModule
{
   /**
    * @param parent  No description provided
    * @param incr    No description provided
    * @return        No description provided
    * @see           de.uni_paderborn.fujaba.fsa.unparse.UnparseInterface#create(de.uni_paderborn.fujaba.fsa.FSAObject,
    *      de.uni_paderborn.fujaba.fsa.unparse.LogicUnparseInterface)
    */
   public FSAObject create (FSAObject parent, LogicUnparseInterface incr)
   {
	DBQuery dbTable = (DBQuery) incr;

	// the main component for the class
	FSASeparatedPanel panel = new FSASeparatedPanel (incr, getMainFsaName(), parent.getJComponent());
	panel.setBorder (new StateBorder ());

	JComponent jPanel = panel.getJComponent();
	jPanel.addKeyListener (ArrowMoveListener.get());
	AscendDescendMouseHandler.addMouseInputListener (jPanel, ComponentCursorListener.get());
	AscendDescendMouseHandler.addMouseInputListener (jPanel, ComponentBorderListener.get());
	AscendDescendMouseHandler.addMouseInputListener (jPanel, SelectionMouseListener.get());
	AscendDescendMouseHandler.addMouseInputListener (jPanel, DragMouseListener.get());
	SelectionListenerHelper.addSelectionListener (jPanel, BorderHighlighter.get());
	SelectionListenerHelper.addSelectionListener (jPanel, ArrowMoveListener.get());

	// -------------------------
	// the name field.
	// -------------------------
	FSAPanel namePanel = new FSAPanel (incr, "queryNamePanel", panel.getJComponent());
	namePanel.setLayout (new ColumnRowLayout (0, ColumnRowLayout.COLUMN));

	FSATextFieldLabel tableNameLabel = new FSATextFieldLabel (incr, "name", namePanel.getJComponent());

	// default updater handles text changes
	AbstractUpdater updater = tableNameLabel.createDefaultUpdater();
	tableNameLabel.addToUpdater (updater);

/*	panel.addSeparator();

	// The attributes panel.
	// add the panel to the collapsable components.
	FSACollapsable tmpCollapsable;
	tmpCollapsable = new FSACollapsable (incr, "attributesPanel", panel.getJComponent());
//	  updater = new ClassCompartmentVisibilityUpdater (incr, "attributes");
//	  tmpCollapsable.addToUpdater (updater);
*/
	return panel;
   }
}

/*
 * $Log: UMDBQuery.java,v $
 * Revision 1.2  2003/10/07 07:21:53  ariseppi
 * misc. corrections
 *
 */
