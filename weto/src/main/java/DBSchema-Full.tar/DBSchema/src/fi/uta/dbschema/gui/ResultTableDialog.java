/*
 * Created on 24.6.2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package fi.uta.dbschema.gui;

import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileWriter;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileFilter;

import de.uni_paderborn.fujaba.app.FrameMain;
import de.uni_paderborn.fujaba.gui.PEEditPanel;

/**
 * @author as66033
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ResultTableDialog extends BasicDialog
{
	private BDJTable definitionTable;
	
	private BDButton backButton;
	private BDButton saveButton;
	
	private String[] titles;
	private Object[][] values;
	
	private String query;
	
	public ResultTableDialog(JFrame frame, String title, boolean modal, String[][] result, String[] titles, String query) {
		   super (frame);
		   setModal (modal);
		   setTitle (title);
		   setTable (result, titles);
		   setQuery (query);
		   try
		   {
			  pack();
			  this.setTitle ("Database Query Definition");
		   }
		   catch (Exception e)
		   {
			  e.printStackTrace();
		   }
		   initDialog();
	}
	
	public ResultTableDialog (JFrame frame, String[][] result, String[] titles, String query)
	{
	   this (frame, "", false, result, titles, query);
	}

	public ResultTableDialog (JFrame frame, boolean modal, String[][] result, String[] titles, String query)
	{
	   this (frame, "", modal, result, titles, query);
	}

	public ResultTableDialog (JFrame frame, String title, String[][] result, String[] titles, String query)
	{
	   this (frame, title, false, result, titles, query);
	}

	protected void additionalButtons(BDComponentGroup buttons)
	{
		backButton = new BDButton(this, "Back");
		buttons.add(backButton);
		backButton.setListener(
			new ResultTableDialog_backButton_actionAdapter(this));
		saveButton = new BDButton(this, "Save");
		buttons.add(saveButton);
		saveButton.setListener(
			new ResultTableDialog_saveButton_actionAdapter(this));
	}
	
	protected void additionalContents (PEEditPanel panel)
	{
		definitionTable = new BDJTable(this, "Result", titles, values, null);
		panel.add(definitionTable);
	}
	
	void backButton_actionPerformed(ActionEvent e)
	{
		setVisible(false);
		dispose();
	}
	
	void saveButton_actionPerformed(ActionEvent e)
	{
		JFileChooser chooser = new HtmlSaveChooser();
		chooser.setFileFilter(new HtmlFileFilter());
		int returnVal = chooser.showSaveDialog (FrameMain.get());

		File file = null;

		if (returnVal == JFileChooser.APPROVE_OPTION)
		{
			file = chooser.getSelectedFile();
		}
		else
		{
		   return;
		}

		try {
			FileWriter fw = new FileWriter(file, false);
			String htmlString = "<html>\n"+
				"\t<head>\n" +
				"\t\t<title>Query result</title>\n" +
				"\t</head>\n" +
				"\t<body>\n" +
				"\t\t<h1>Query result</h1>\n" +
				"\t\t<p>Query: " + getQuery().replaceAll("\\n", "<br>\\n") + "</p>\n" +
				definitionTable.getHtml("\t\t") +
				"\t</body>\n" +
				"</html>";
				fw.write(htmlString);
				fw.close();
		} catch(Exception exception) {
			exception.printStackTrace();
		}
	}
	
	public void setTable(String[][] result, String[] titles) {
		values = result;
		this.titles  = titles;
	}
	/**
	 * @return
	 */
	public String getQuery()
	{
		return query;
	}

	/**
	 * @param string
	 */
	public void setQuery(String string)
	{
		query = string;
	}

}

class ResultTableDialog_backButton_actionAdapter
	implements java.awt.event.ActionListener
{
	ResultTableDialog adaptee;

	ResultTableDialog_backButton_actionAdapter(ResultTableDialog adaptee)
	{
		this.adaptee = adaptee;
	}

	public void actionPerformed(ActionEvent e)
	{
		adaptee.backButton_actionPerformed(e);
	}
}

class ResultTableDialog_saveButton_actionAdapter
	implements java.awt.event.ActionListener
{
	ResultTableDialog adaptee;

	ResultTableDialog_saveButton_actionAdapter(ResultTableDialog adaptee)
	{
		this.adaptee = adaptee;
	}

	public void actionPerformed(ActionEvent e)
	{
		adaptee.saveButton_actionPerformed(e);
	}
}

class HtmlFileFilter extends FileFilter
{
   /**
	* No comment provided by developer, please add a comment to ensure improve documentation.
	*
	* @param file  No description provided
	* @return      No description provided
	*/
   public boolean accept (File file)
   {
	  String name = file.getName();
	  if (file.isDirectory() || name.endsWith (".html") || name.endsWith (".htm"))
	  {
		 return true;
	  }
	  return false;
   }


   /**
	* Get the description attribute of the SQLFileFilter object
	*
	* @return   The description value
	*/
   public String getDescription()
   {
	  return "HTML files (.html, .htm)";
   }
}


class HtmlSaveChooser extends JFileChooser {
	public void approveSelection() {
		File file = getSelectedFile();
		if(file.getName().indexOf('.') < 0) {
			file = new File(file.getAbsolutePath() + ".html");
		}
		setSelectedFile(file);
		if(file.exists()) {
			int selection = JOptionPane.showConfirmDialog(FrameMain.get().getFrame(), "Are you sure you want to overwrite file " + file.getName() + "?", "Overwrite file", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
			if(selection != JOptionPane.YES_OPTION) {
				return;
			}
		}
		super.approveSelection();
	}
}