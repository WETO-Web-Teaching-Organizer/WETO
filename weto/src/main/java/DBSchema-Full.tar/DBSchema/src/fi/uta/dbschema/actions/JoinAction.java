/*
 * Created on 26.7.2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package fi.uta.dbschema.actions;

import java.awt.event.ActionEvent;
import java.util.Iterator;

import javax.swing.AbstractAction;
import javax.swing.JOptionPane;

import de.uni_paderborn.fujaba.app.FrameMain;
import de.uni_paderborn.fujaba.uml.UMLProject;
import fi.uta.dbschema.gui.PEDBJoin;
import fi.uta.dbschema.metamodel.DBTable;
import fi.uta.dbschema.metamodel.DBTableAttribute;

/**
 * @author as66033
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class JoinAction extends AbstractAction
{

	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e)
	{
		Object source = e.getSource();
		DBTable firstTable = null;
		DBTable secondTable = null;
		
		if (source instanceof Iterator)
		{
		   Iterator iter = (Iterator) source;
		   if (iter.hasNext())
		   {
		   	  Object tableObject = iter.next();
		   	  if(tableObject instanceof DBTable) 
		   	  {
				firstTable = (DBTable) tableObject;
		   	  } else if(source instanceof DBTableAttribute)
			{
				firstTable = ((DBTableAttribute) source).getParent();
			}
		   	  else {
				JOptionPane.showMessageDialog(
				FrameMain.get().getFrame(),
				"Error: selection include non-table objects.",
				"Unjoinable objects",
				JOptionPane.ERROR_MESSAGE);
		   	  }
		   }
		   if (iter.hasNext())
		   {
			  Object tableObject = iter.next();
			  if(tableObject instanceof DBTable) 
			  {
				secondTable = (DBTable) tableObject;
			  } else if(source instanceof DBTableAttribute)
			{
				secondTable = ((DBTableAttribute) source).getParent();
			}
			  else {
				JOptionPane.showMessageDialog(
				FrameMain.get().getFrame(),
				"Error: selection includes non-table objects.",
				"Unjoinable objects",
				JOptionPane.ERROR_MESSAGE);
			  }
		   }
		   if(iter.hasNext()) {
			JOptionPane.showMessageDialog(
			FrameMain.get().getFrame(),
			"Error: selection has too many object.",
			"Too many objects",
			JOptionPane.ERROR_MESSAGE);
		   }
		}
		else if (source instanceof DBTable)
		{
		   firstTable = (DBTable) source;
		} else if(source instanceof DBTableAttribute)
		{
			firstTable = ((DBTableAttribute) source).getParent();
		}
		else
		{
			JOptionPane.showMessageDialog (FrameMain.get(), "Only tables can be joined.", "Unjoinable objects selected", JOptionPane.ERROR_MESSAGE);
		   return;
		}
		PEDBJoin joinEditor = new PEDBJoin (FrameMain.get().getFrame());
		if(firstTable != null)
		{
			joinEditor.setFirstTableChoise(firstTable);
		}
		if(secondTable != null)
		{
			joinEditor.setSecondTableChoise(secondTable);
		}
		joinEditor.showCentered();

		UMLProject.get().refreshDisplay();
	}
}
