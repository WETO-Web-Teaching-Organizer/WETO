/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this added code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.gui;

import java.awt.Cursor;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;

import javax.swing.JFrame;

import de.uni_paderborn.fujaba.asg.ASGElement;
import de.uni_paderborn.fujaba.gui.PEColumn;
import de.uni_paderborn.fujaba.gui.PEEditPanel;
import de.uni_paderborn.fujaba.uml.UMLProject;
import de.upb.tools.fca.FLinkedList;
import fi.uta.dbschema.metamodel.DBTable;
import fi.uta.dbschema.metamodel.DBTableAttribute;
import fi.uta.dbschema.metamodel.DBUnique;


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.2 $
 */
public class PEDBUnique extends DBPropertyEditor
{

   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBAttrSelection attrSelection;

   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBUniqueAttrSelection uniAttrSelection;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBUniqueSelection uniSelection;

   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   FLinkedList addUniques = new FLinkedList();
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   FLinkedList delUniques = new FLinkedList();


   /**
    * Constructor for class PEDBUnique
    *
    * @param frame  No description provided
    * @param title  No description provided
    * @param modal  No description provided
    */
   public PEDBUnique (JFrame frame, String title, boolean modal)
   {
      super (frame);
      setModal (modal);
      setTitle (title);
      try
      {
         pack();
         this.setTitle ("Unique Constraint Editor");
      }
      catch (Exception e)
      {
         e.printStackTrace();
      }
      initPE();

//      addFocusListener (new CMAFocusListener (attributeName));

      /*
       *  attributeName.addActionListener (
       *  new ActionListener()
       *  {
       *  public void actionPerformed (ActionEvent e)
       *  {
       *  addButton_actionPerformed (e);
       *  }
       *  }
       *  );
       */
   }


   /**
    * Constructor for class PEDBUnique
    *
    * @param frame  No description provided
    */
   public PEDBUnique (JFrame frame)
   {
      this (frame, "", false);
   }


   /**
    * Constructor for class PEDBUnique
    *
    * @param frame  No description provided
    * @param modal  No description provided
    */
   public PEDBUnique (JFrame frame, boolean modal)
   {
      this (frame, "", modal);
   }


   /**
    * Constructor for class PEDBUnique
    *
    * @param frame  No description provided
    * @param title  No description provided
    */
   public PEDBUnique (JFrame frame, String title)
   {
      this (frame, title, false);
   }


   /**
    * Sets the uniAttrSelection attribute of the PEDBUnique object
    *
    * @param uni  The new uniAttrSelection value
    */
   public void setUniAttrSelection (DBUnique uni)
   {
      uniAttrSelection.clearList();
      Iterator i = uni.iteratorOfAttributes();
      DBTableAttribute attr;
      while (i.hasNext())
      {
         attr = (DBTableAttribute) i.next();
         uniAttrSelection.addToList (attr);
      }
      if (uniAttrSelection.hasElements())
      {
         uniAttrSelection.setSelectedIndex (0);
      }
   }


   /**
    * Returns the selected unique attribute of the PEDBUnique object
    *
    * @return   The unique value
    */
   public DBUnique getUnique()
   {
      return (DBUnique) uniSelection.getListSelectedIncr();
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param panel  No description provided
    */
   protected void additionalProperties (PEEditPanel panel)
   {
      attrSelection = new PEDBAttrSelection (this);
      uniAttrSelection = new PEDBUniqueAttrSelection (this);
      uniSelection = new PEDBUniqueSelection (this);

      uniAttrSelection.setAddListener (new PEDBUnique_addAttrButton_actionAdapter (this));
      uniAttrSelection.setRemoveListener (new PEDBUnique_removeAttrButton_actionAdapter (this));
      uniAttrSelection.setModifyListener (new PEDBUnique_modifyAttrButton_actionAdapter (this));

      uniSelection.setAddListener (new PEDBUnique_addUniButton_actionAdapter (this));
      uniSelection.setRemoveListener (new PEDBUnique_removeUniButton_actionAdapter (this));
      uniSelection.setModifyListener (new PEDBUnique_modifyUniButton_actionAdapter (this));

      PEColumn column = new PEColumn (this);

      column.add (attrSelection);
      column.add (uniAttrSelection);
      column.add (uniSelection);

      panel.add (column);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void unparse()
   {
      if (getIncrement() instanceof DBTable)
      {
         DBTable selectedTable = (DBTable) getIncrement();
//         attrSelection.setIncrement (selectedTable);
//         uniAttrSelection.setIncrement (selectedTable);
         uniSelection.setIncrement (selectedTable);
         uniAttrSelection.fillList();
         attrSelection.fillList();
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected void parse()
   {
      ASGElement incr = getIncrement();

      if (incr instanceof DBTable)
      {
         DBUnique uni = null;

         Iterator iter = addUniques.iterator();
         while (iter.hasNext())
         {
            uni = (DBUnique) iter.next();
            uni.setParent ((DBTable) incr);
         }
         addUniques.clear();

         iter = delUniques.iterator();
         while (iter.hasNext())
         {
            uni = (DBUnique) iter.next();

            uni.removeYou();
         }
         delUniques.clear();
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected void cancel()
   {
      addUniques.clear();
      delUniques.clear();
      setVisible (false);
      dispose();
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void buttonOK_actionPerformed (ActionEvent e)
   {
//      super.buttonOK_actionPerformed (e);
      if (getFrame() != null)
      {
         getFrame().setCursor (Cursor.getPredefinedCursor (Cursor.WAIT_CURSOR));
      } // if

      try
      {
         setVisible (false);
         parse();
         UMLProject.get().refreshDisplay();
      }
      finally
      {
         if (getFrame() != null)
         {
            getFrame().setCursor (Cursor.getPredefinedCursor (Cursor.DEFAULT_CURSOR));
         }
      }
   }


   /**
    * Access method for an one to n association.
    *
    * @param e  The object added.
    */

   void addAttrButton_actionPerformed (ActionEvent e)
   {
      if (attrSelection.getSelectedIndex() != -1)
      {
         DBTableAttribute newAttr = (DBTableAttribute) attrSelection.getListSelectedIncr();

         uniAttrSelection.addToList (newAttr);
      }
   }


   /**
    * Access method for an one to n association.
    *
    * @param e  The object added.
    */

   void addUniButton_actionPerformed (ActionEvent e)
   {
      if (uniAttrSelection.hasElements())
      {
         DBUnique newUnique = new DBUnique();

         Enumeration enum = uniAttrSelection.getListList();
         while (enum.hasMoreElements())
         {
            PEDBItem item = (PEDBItem) enum.nextElement();
            DBTableAttribute attr = (DBTableAttribute) item.getIncrement();
            attr.addToRevUniques (newUnique);
            newUnique.addToAttributes (attr);
         }

         addUniques.add (newUnique);
         uniSelection.addToList (newUnique);

         uniAttrSelection.clearList();
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   protected void removeAttrButton_actionPerformed (ActionEvent e)
   {
      ASGElement incr = uniAttrSelection.getListSelectedIncr();
      if (incr != null)
      {
         /*
          *  if (incr instanceof DBAttributePair)
          *  {
          *  DBAttributePair pair = (DBAttributePair) incr;
          *  }
          */
         uniAttrSelection.removeFromList (incr);
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   protected void removeUniButton_actionPerformed (ActionEvent e)
   {
      ASGElement incr = uniSelection.getListSelectedIncr();
      if (incr != null)
      {
         /*
          *  if (incr instanceof DBAttributePair)
          *  {
          *  DBAttributePair pair = (DBAttributePair) incr;
          *  }
          */
         addUniques.remove (incr);
         uniSelection.removeFromList (incr);
         delUniques.add (incr);
         uniAttrSelection.clearList();
      }
   }


   /**
    * Sets the increment attribute of the PEDBUnique object
    *
    * @param incr  The new increment value
    */
   public void setIncrement (ASGElement incr)
   {
      if (incr instanceof DBUnique)
      {
         super.setIncrement ( ((DBUnique) incr).getParent());
         uniSelection.getList().selectIncrement (incr);
      }
      else
      {
         super.setIncrement (incr);
      }
      if (getTableIncrement() != null)
      {
         setTitle ("Unique Editor: " + getTableIncrement().getName());
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   void modifyUniButton_actionPerformed (ActionEvent e)
   {
      ASGElement oldIncr = uniSelection.getListSelectedIncr();
      if (oldIncr != null && oldIncr instanceof DBUnique)
      {
         // Fix me: The new editor should make it better handling modified items.
         DBUnique curUni = (DBUnique) oldIncr;

         DBUnique oldUni = new DBUnique();
         Iterator i = curUni.iteratorOfAttributes();
         while (i.hasNext())
         {
            oldUni.addToAttributes ((DBTableAttribute) i.next());
         }

         curUni.removeAllFromAttributes();
         Enumeration enum = uniAttrSelection.getListList();

         while (enum.hasMoreElements())
         {
            PEDBItem item = (PEDBItem) enum.nextElement();
            DBTableAttribute attr = (DBTableAttribute) item.getIncrement();
            curUni.addToAttributes (attr);
         }

         uniSelection.removeFromList (curUni);
         uniSelection.addToList (curUni);
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   void modifyAttrButton_actionPerformed (ActionEvent e)
   {
      if ( (attrSelection.getSelectedIndex() != -1) &&  (uniAttrSelection.getListSelectedIncr() != null))
      {
         DBTableAttribute attr = (DBTableAttribute) uniAttrSelection.getListSelectedIncr();
         int index = uniAttrSelection.getSelectedIndex();
         uniAttrSelection.removeFromList (attr);
         attr = (DBTableAttribute) attrSelection.getListSelectedIncr();
         ArrayList list = new ArrayList();
         Enumeration enum = uniAttrSelection.getListList();
         while (enum.hasMoreElements())
         {
            PEDBItem item = (PEDBItem) enum.nextElement();
            list.add (item);
         }
         for (int i = 0; i < list.size(); i++)
         {
            if (i == index)
            {
               uniAttrSelection.addToList (attr);
            }
            PEDBItem item = (PEDBItem) list.get (i);
            ASGElement elem = (ASGElement) item.getIncrement();
            uniAttrSelection.removeFromList (elem);
            uniAttrSelection.addToList (elem);
         }
         if (index == list.size())
         {
            uniAttrSelection.addToList (attr);
         }
      }
   }


   /**
    * Sets the attrSelection attribute of the PEDBUnique object
    *
    * @param attr  The new attrSelection value
    */
   public void setAttrSelection (DBTableAttribute attr)
   {
      attrSelection.setListSelectedIncr (attr);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.2 $
 */
class PEDBUnique_addAttrButton_actionAdapter implements java.awt.event.ActionListener
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBUnique adaptee;


   /**
    * Constructor for class PEDBUnique_addAttrButton_actionAdapter
    *
    * @param adaptee  No description provided
    */
   PEDBUnique_addAttrButton_actionAdapter (PEDBUnique adaptee)
   {
      this.adaptee = adaptee;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void actionPerformed (ActionEvent e)
   {
      adaptee.addAttrButton_actionPerformed (e);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.2 $
 */
class PEDBUnique_addUniButton_actionAdapter implements java.awt.event.ActionListener
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBUnique adaptee;


   /**
    * Constructor for class PEDBUnique_addUniButton_actionAdapter
    *
    * @param adaptee  No description provided
    */
   PEDBUnique_addUniButton_actionAdapter (PEDBUnique adaptee)
   {
      this.adaptee = adaptee;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void actionPerformed (ActionEvent e)
   {
      adaptee.addUniButton_actionPerformed (e);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.2 $
 */
class PEDBUnique_removeAttrButton_actionAdapter implements java.awt.event.ActionListener
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBUnique adaptee;


   /**
    * Constructor for class PEDBUnique_removeAttrButton_actionAdapter
    *
    * @param adaptee  No description provided
    */
   PEDBUnique_removeAttrButton_actionAdapter (PEDBUnique adaptee)
   {
      this.adaptee = adaptee;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void actionPerformed (ActionEvent e)
   {
      adaptee.removeAttrButton_actionPerformed (e);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.2 $
 */
class PEDBUnique_removeUniButton_actionAdapter implements java.awt.event.ActionListener
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBUnique adaptee;


   /**
    * Constructor for class PEDBUnique_removeUniButton_actionAdapter
    *
    * @param adaptee  No description provided
    */
   PEDBUnique_removeUniButton_actionAdapter (PEDBUnique adaptee)
   {
      this.adaptee = adaptee;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void actionPerformed (ActionEvent e)
   {
      adaptee.removeUniButton_actionPerformed (e);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.2 $
 */
class PEDBUnique_modifyAttrButton_actionAdapter implements java.awt.event.ActionListener
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBUnique adaptee;


   /**
    * Constructor for class PEDBUnique_modifyAttrButton_actionAdapter
    *
    * @param adaptee  No description provided
    */
   PEDBUnique_modifyAttrButton_actionAdapter (PEDBUnique adaptee)
   {
      this.adaptee = adaptee;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void actionPerformed (ActionEvent e)
   {
      adaptee.modifyAttrButton_actionPerformed (e);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.2 $
 */
class PEDBUnique_modifyUniButton_actionAdapter implements java.awt.event.ActionListener
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBUnique adaptee;


   /**
    * Constructor for class PEDBUnique_modifyUniButton_actionAdapter
    *
    * @param adaptee  No description provided
    */
   PEDBUnique_modifyUniButton_actionAdapter (PEDBUnique adaptee)
   {
      this.adaptee = adaptee;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void actionPerformed (ActionEvent e)
   {
      adaptee.modifyUniButton_actionPerformed (e);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.2 $
 */
class PEDBUniqueSelection extends PESingleSelection
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private PEDBUnique uniEditor;


   /**
    * Constructor for class PEDBUniqueSelection
    *
    * @param parent  No description provided
    */
   PEDBUniqueSelection (DBPropertyEditor parent)
   {
      super (parent);
      getList().setHeader ("Unique Constraints");
      uniEditor = (PEDBUnique) parent;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected void listSelectionChanged()
   {
      ASGElement incr = list.getSelectedIncrement();
      if (incr instanceof DBUnique)
      {
         DBUnique uni = (DBUnique) incr;
         uniEditor.setUniAttrSelection (uni);
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void fillList()
   {
      clearList();
      ASGElement incr = getIncrement();
      if (incr instanceof DBTable)
      {
         Iterator iter =  ((DBTable) incr).iteratorOfUniques();
         DBUnique uni;
         while (iter.hasNext())
         {
            uni = (DBUnique) iter.next();
            if (uni != null)
            {
               addToList (uni);
            }
         }
      }
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.2 $
 */
class PEDBUniqueAttrSelection extends PESingleSelection
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private PEDBUnique uniEditor;


   /**
    * Constructor for class PEDBForKeyAttrSelection
    *
    * @param parent  No description provided
    */
   PEDBUniqueAttrSelection (DBPropertyEditor parent)
   {
      super (parent);
      getList().setHeader ("Unique Constraint Attributes");
      uniEditor = (PEDBUnique) parent;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected void listSelectionChanged()
   {
      ASGElement incr = list.getSelectedIncrement();
      if (incr instanceof DBTableAttribute)
      {
         DBTableAttribute attr = (DBTableAttribute) incr;
         uniEditor.setAttrSelection (attr);
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void fillList()
   {
      clearList();
      DBUnique uni = uniEditor.getUnique();
      if (uni != null)
      {
         Iterator iter = uni.iteratorOfAttributes();
         DBTableAttribute attr;
         while (iter.hasNext())
         {
            attr = (DBTableAttribute) iter.next();
            if (attr != null)
            {
               addToList (attr);
            }
         }
      }
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.2 $
 */
class PEDBAttrSelection extends PEListSelection
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBUnique uniEditor;


   /**
    * Constructor for class PEDBAttrSelection
    *
    * @param parent  No description provided
    */
   PEDBAttrSelection (DBPropertyEditor parent)
   {
      super (parent);
      getList().setHeader ("Table Attributes");
      uniEditor = (PEDBUnique) parent;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void fillList()
   {
      clearList();
      ASGElement incr = uniEditor.getIncrement();

      if (incr instanceof DBTable)
      {
         DBTable table = (DBTable) incr;
         if (table != null)
         {
            Iterator iter = table.iteratorOfAttributes();
            DBTableAttribute attr;
            while (iter.hasNext())
            {
               attr = (DBTableAttribute) iter.next();
               if (attr != null)
               {
                  addToList (attr);
               }
            }
         }
      }
   }
}

/*
 * $Log: PEDBUnique.java,v $
 * Revision 1.2  2003/10/07 07:21:52  ariseppi
 * misc. corrections
 *
 */
