/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.cs.dbswtool;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StreamTokenizer;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:48 $
 * @version   $Revision: 1.3 $
 */
public class RelationVector implements RelAndQueryConstants, RelationStore
{
	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	private Vector relationVector;

	/**
	 * Constructor for class RelationVector
	 */
	public RelationVector()
	{
		relationVector = new Vector();
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	public void output()
	{
		System.out.println("RelationVector with size " + relationVector.size());
		for (int i = 0; i < relationVector.size(); i++)
		{
			Relation r = (Relation) relationVector.elementAt(i);
			r.output();
		}
	}

	/**
	 * Get the relation attribute of the RelationVector object
	 *
	 * @param name  No description provided
	 * @return      The relation value
	 */
	public Relation getRelation(String name)
	{
		Relation rFound = null;
		int i = 0;
		while ((i < relationVector.size()) && (rFound == null))
		{
			Relation r = (Relation) relationVector.elementAt(i);
			i++;
			if (name.equals(r.getName()))
			{
				rFound = r;
			}
		}
		return rFound;
	}

	/**
	 * Access method for an one to n association.
	 *
	 * @param newRelation  The object added.
	 */
	public void addRelation(Relation newRelation)
	{
		//	output();
		if (getRelation(newRelation.getName()) == null)
		{
			relationVector.add(newRelation);
		}
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param projectdir  No description provided
	 * @return            No description provided
	 */
	public int writeSQLFiles(String projectdir)
	{
		return writeSQLFiles(projectdir, 0);
	}

	public int writeSQLFiles(String projectdir, int database)
	{
		File sqlDir = new File(projectdir + "/" + sqlString);
		sqlDir.mkdir();
		try
		{
			File allFile =
				new File(
					projectdir
						+ slashChar
						+ sqlString
						+ slashChar
						+ "all"
						+ period
						+ sqlString);
			FileWriter allWriter = new FileWriter(allFile);
			for (int i = 0; i < relationVector.size(); i++)
			{
				Relation r = (Relation) relationVector.elementAt(i);
				// Write the contents of output to a file using a FileWriter
				File outFile =
					new File(
						projectdir
							+ slashChar
							+ sqlString
							+ slashChar
							+ r.getName()
							+ period
							+ sqlString);
				FileWriter writer = new FileWriter(outFile);
				String fileString = getSQLString(i, database).toString();
				writer.write(fileString);
				allWriter.write(fileString);
				writer.close();

			} // Write the contents of output to a file using a FileWriter
			allWriter.close();
		} catch (Exception e)
		{
			System.out.println(e);
		}
		return 0;
	}

	public String getSQLString(int database)
	{
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < relationVector.size(); i++)
		{
			sb.append(getSQLString(i, database));
		}
		return sb.toString();
	}

	public StringBuffer getSQLString(int vectorIndex, int database)
	{
		StringBuffer sb = new StringBuffer();
		if (vectorIndex < 0 || vectorIndex >= relationVector.size())
		{
			return null;
		}
		Relation r = (Relation) relationVector.elementAt(vectorIndex);
		sb.append(sqlDropTableString + " ");
		if (database == RelAndQueryConstants.mySql)
		{
			sb.append("if exists ");
		}
		sb.append(r.getName() + " ");
		if (database == RelAndQueryConstants.hsqldb)
		{
			sb.append("if exists");
		} else
		{
			sb.append("cascade");
		}
		sb.append(semicolon + endLine);
		sb.append(
			sqlCreateTableString
				+ " "
				+ r.getName()
				+ openParenthesis
				+ endLine);
		AttributeVector av = r.getAttributeVector();
		boolean[] strings = new boolean[av.size()];
		for (int j = 0; j < av.size(); j++)
		{
			Attribute a = av.getAttribute(j);
			String type = a.getSQLType();
			if(database == RelAndQueryConstants.hsqldb)
			{
				int indexOfOpenParenthesis = type.indexOf('(');
				if(indexOfOpenParenthesis > 0)
				{
					type = type.substring(0, indexOfOpenParenthesis);
				}
			}
			sb.append(a.getRole() + " " + type);
			if (a.getNotNull().booleanValue() == true)
			{
				sb.append(" " + sqlNotNullString);
			}
			sb.append(comma + endLine);
			strings[j] = a.getStringType().booleanValue();
		}
		sb.append(sqlPrimaryKeyString + " " + openParenthesis);
		NameVector primaryKey = r.getPrimaryKey();
		sb.append(primaryKey.commaList());
		sb.append(closeParenthesis);
		Vector uniqueVector = r.getUniqueVector();
		for (int k = 0; k < uniqueVector.size(); k++)
		{
			sb.append(
				comma + endLine + sqlUniqueString + " " + openParenthesis);
			NameVector unique = (NameVector) uniqueVector.elementAt(k);
			sb.append(unique.commaList());
			sb.append(closeParenthesis);
		}
		Vector foreignKeyVector = r.getForeignKeyVector();
		for (int k = 0; k < foreignKeyVector.size(); k++)
		{
			sb.append(
				comma + endLine + sqlForeignKeyString + " " + openParenthesis);
			ForeignKey foreignKey = (ForeignKey) foreignKeyVector.elementAt(k);
			NameVector ownAttributes = foreignKey.getOwnAttributes();
			String refTable = foreignKey.getReferredTable();
			NameVector refAttributes = foreignKey.getReferredAttributes();
			sb.append(
				ownAttributes.commaList()
					+ closeParenthesis
					+ " "
					+ sqlReferencesString
					+ " "
					+ refTable
					+ openParenthesis
					+ refAttributes.commaList()
					+ closeParenthesis);
		}
		sb.append(closeParenthesis + semicolon + endLine);
		Vector exampleVector = r.getExampleVector();

		for (int j = 0; j < exampleVector.size(); j++)
		{
			sb.append(
				sqlInsertString + r.getName() + " " + sqlValuesString + " (");
			String[] example = (String[]) exampleVector.get(j);
			for (int k = 0; k < example.length; k++)
			{
				if (!example[k].equals("null") && strings[k])
				{
					sb.append("\'");
				}
				sb.append(example[k]);
				if (!example[k].equals("null") && strings[k])
				{
					sb.append("\'");
				}
				if (k < example.length - 1)
				{
					sb.append(", ");
				}
			}
			sb.append(");" + endLine);
		}
		return sb;
	}

	public String[] getSQLStrings(int vectorIndex)
	{
		return getSQLStrings(vectorIndex, RelAndQueryConstants.generic);
	}

	public String[] getSQLStrings(int vectorIndex, int database)
	{
		StringBuffer sb = new StringBuffer();
		if (vectorIndex < 0 || vectorIndex >= relationVector.size())
		{
			return null;
		}
		Relation r = (Relation) relationVector.elementAt(vectorIndex);
		String[] stringArray = new String[2 + r.getExampleVector().size()];
		int arrayIndex = 0;
		sb.append(sqlDropTableString + " ");
		if (database == RelAndQueryConstants.mySql)
		{
			sb.append("if exists ");
		}
		sb.append(r.getName() + " ");
		if (database == RelAndQueryConstants.hsqldb)
		{
			sb.append("if exists");
		} else
		{
			sb.append("cascade");
		}
		sb.append(semicolon + endLine);
		stringArray[arrayIndex] = sb.toString();
		arrayIndex++;
		sb.setLength(0);
		sb.append("create table " + r.getName() + openParenthesis);
		AttributeVector av = r.getAttributeVector();
		boolean[] strings = new boolean[av.size()];
		for (int j = 0; j < av.size(); j++)
		{
			Attribute a = av.getAttribute(j);
			String type = a.getSQLType();
			if(database == RelAndQueryConstants.hsqldb)
			{
				int indexOfOpenParenthesis = type.indexOf('(');
				if(indexOfOpenParenthesis > 0)
				{
					type = type.substring(0, indexOfOpenParenthesis);
				}
			}
			sb.append(a.getRole() + " " + type);
			if (a.getNotNull().booleanValue() == true)
			{	
				sb.append(" " + sqlNotNullString);
			}
			sb.append(comma);
			strings[j] = a.getStringType().booleanValue();
		}
		sb.append(sqlPrimaryKeyString + " " + openParenthesis);
		NameVector primaryKey = r.getPrimaryKey();
		sb.append(primaryKey.commaList());
		sb.append(closeParenthesis);
		Vector uniqueVector = r.getUniqueVector();
		for (int k = 0; k < uniqueVector.size(); k++)
		{
			sb.append(comma + sqlUniqueString + " " + openParenthesis);
			NameVector unique = (NameVector) uniqueVector.elementAt(k);
			sb.append(unique.commaList());
			sb.append(closeParenthesis);
		}
		Vector foreignKeyVector = r.getForeignKeyVector();
		for (int k = 0; k < foreignKeyVector.size(); k++)
		{
			sb.append(comma + sqlForeignKeyString + " " + openParenthesis);
			ForeignKey foreignKey = (ForeignKey) foreignKeyVector.elementAt(k);
			NameVector ownAttributes = foreignKey.getOwnAttributes();
			String refTable = foreignKey.getReferredTable();
			NameVector refAttributes = foreignKey.getReferredAttributes();
			sb.append(
				ownAttributes.commaList()
					+ closeParenthesis
					+ " "
					+ sqlReferencesString
					+ " "
					+ refTable
					+ openParenthesis
					+ refAttributes.commaList()
					+ closeParenthesis);
		}
		sb.append(closeParenthesis);

		stringArray[arrayIndex] = sb.toString();
		arrayIndex++;
		sb.setLength(0);

		Vector exampleVector = r.getExampleVector();

		for (int j = 0; j < exampleVector.size(); j++)
		{
			sb.append(
				sqlInsertString
					+ r.getName()
					+ " "
					+ endLine
					+ sqlValuesString
					+ " (");
			String[] example = (String[]) exampleVector.get(j);
			for (int k = 0; k < example.length; k++)
			{
				if (!example[k].equals("null") && strings[k])
				{
					sb.append("\'");
				}
				sb.append(example[k]);
				if (!example[k].equals("null") && strings[k])
				{
					sb.append("\'");
				}
				if (k < example.length - 1)
				{
					sb.append(", ");
				}
			}
			sb.append(");");
			stringArray[arrayIndex] = sb.toString();
			arrayIndex++;
			sb.setLength(0);
		}
		return stringArray;
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param projectdir  No description provided
	 * @return            No description provided
	 */
	public int writeHtmlFile(String projectdir)
	{
		//	String filename = attributeHtmlFileName;
		StringBuffer sb = new StringBuffer();
		sb.append(htmlFileHeader1);
		sb.append(htmlFileHeader2);
		sb.append(htmlFileHeader3);
		sb.append(htmlFileHeader4);

		// First write an index table of all relation names
		sb.append(beginHtmlTable);
		sb.append(beginHtmlTableRow + endLine);
		sb.append(
			beginHtmlTableColumn
				+ " "
				+ relationNameHtmlString
				+ " "
				+ endHtmlTableColumn
				+ endLine);
		sb.append(endHtmlTableRow + endLine);
		for (int i = 0; i < relationVector.size(); i++)
		{
			Relation r = (Relation) relationVector.elementAt(i);
			sb.append(beginHtmlTableRow + endLine);
			sb.append(
				beginHtmlTableColumn
					+ " "
					+ beginHtmlHref
					+ r.getName()
					+ endHtmlHref
					+ " "
					+ r.getName().toUpperCase()
					+ " "
					+ endHtmlA
					+ endHtmlTableColumn
					+ endLine);
			sb.append(endHtmlTableRow + endLine);
		}
		sb.append(endHtmlTable);
		sb.append(htmlParagraph);

		// Then a table for each relation
		for (int i = 0; i < relationVector.size(); i++)
		{ // First the header
			sb.append(htmlParagraph);
			sb.append(htmlParagraph);
			Relation r = (Relation) relationVector.elementAt(i);
			sb.append(
				beginHtmlTarget
					+ r.getName()
					+ endHtmlTarget
					+ " "
					+ htmlBeginBold
					+ r.getName().toUpperCase()
					+ htmlEndBold
					+ endLine);
			sb.append("<p><b>Description</b>: " + r.getDescription() + endLine);
			sb.append(beginHtmlTable);
			sb.append(beginHtmlTableRow + endLine);
			sb.append(
				beginHtmlTableColumn
					+ " "
					+ roleHtmlString
					+ " "
					+ endHtmlTableColumn
					+ endLine);
			sb.append(
				beginHtmlTableColumn
					+ " "
					+ notNullHtmlString
					+ " "
					+ endHtmlTableColumn
					+ endLine);
			sb.append(
				beginHtmlTableColumn
					+ " "
					+ baseAttributeHtmlString
					+ " "
					+ endHtmlTableColumn
					+ endLine);
			sb.append(
				beginHtmlTableColumn
					+ " "
					+ sqlHtmlString
					+ " "
					+ endHtmlTableColumn
					+ endLine);
			sb.append(
				beginHtmlTableColumn
					+ " "
					+ javaHtmlString
					+ " "
					+ endHtmlTableColumn
					+ endLine);
			sb.append(
				beginHtmlTableColumn
					+ " <b>Description</b> "
					+ endHtmlTableColumn
					+ endLine);
			sb.append(endHtmlTableRow + endLine);

			AttributeVector av = r.getAttributeVector();
			for (int j = 0; j < av.size(); j++)
			{ // Then the table rows, one for each attribute
				Attribute a = av.getAttribute(j);

				sb.append(beginHtmlTableRow + endLine);
				sb.append(
					beginHtmlTableColumn
						+ " "
						+ a.getRole()
						+ " "
						+ endHtmlTableColumn
						+ endLine);
				sb.append(
					beginHtmlTableColumn
						+ " "
						+ a.getNotNull().toString()
						+ " "
						+ endHtmlTableColumn
						+ endLine);
				// sb.append(beginHtmlTableColumn + " " + a.getPrimaryKeyPart().toString() + " " + endHtmlTableColumn + endLine);
				sb.append(
					beginHtmlTableColumn
						+ " "
						+ a.getName()
						+ " "
						+ endHtmlTableColumn
						+ endLine);
				sb.append(
					beginHtmlTableColumn
						+ " "
						+ a.getSQLType()
						+ " "
						+ endHtmlTableColumn
						+ endLine);
				sb.append(
					beginHtmlTableColumn
						+ " "
						+ a.getJavaType()
						+ " "
						+ endHtmlTableColumn
						+ endLine);
				sb.append(
					beginHtmlTableColumn
						+ " "
						+ a.getDescription()
						+ " "
						+ endHtmlTableColumn
						+ endLine);
				sb.append(endHtmlTableRow + endLine);
			}
			sb.append(endHtmlTable + endLine);

			NameStore primaryKey = r.getPrimaryKey();
			// After the table, add primary key information
			sb.append(
				htmlBeginPrimaryKeyString
					+ " "
					+ primaryKey.commaList()
					+ " "
					+ htmlEndPrimaryKeyString
					+ endLine);

			Vector uniqueVector = r.getUniqueVector();
			// Then the unique statements
			for (int u = 0; u < uniqueVector.size(); u++)
			{
				NameStore unique = (NameStore) uniqueVector.elementAt(u);
				sb.append(
					htmlLineBreak
						+ htmlBeginUniqueString
						+ " "
						+ unique.commaList()
						+ " "
						+ htmlEndUniqueString
						+ endLine);
			}

			Vector foreignKeyVector = r.getForeignKeyVector();
			// Then the foreign key statements
			for (int k = 0; k < foreignKeyVector.size(); k++)
			{
				ForeignKey foreignKey =
					(ForeignKey) foreignKeyVector.elementAt(k);
				NameVector ownAttributes = foreignKey.getOwnAttributes();
				String refTable = foreignKey.getReferredTable();
				NameVector refAttributes = foreignKey.getReferredAttributes();

				sb.append(
					htmlLineBreak
						+ htmlBeginForeignKeyString
						+ " "
						+ ownAttributes.commaList()
						+ " "
						+ htmlReferencesString
						+ refTable
						+ openParenthesis
						+ refAttributes.commaList()
						+ htmlEndForeignKeyString
						+ endLine);
			}
		}

		sb.append(endHtmlFile);

		try
		{ // Write the contents of output to a file using a FileWriter
			File outFile =
				new File(projectdir + slashChar + relationHtmlFileName);
			FileWriter writer = new FileWriter(outFile);
			writer.write(sb.toString());
			writer.close();
		} catch (Exception e)
		{
			System.out.println(e);
		}
		return 0;
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param projectdir  No description provided
	 * @return            No description provided
	 */
	public int writeJavaFiles(String projectdir)
	{
		File javaDir = new File(projectdir + slashChar + javaString);
		javaDir.mkdir();
		writeDbClassFiles(projectdir);
		writeBeanClassFiles(projectdir);
		writeMainClassFiles(projectdir);
		return 0;
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param projectdir  No description provided
	 * @param filename    No description provided
	 * @param as          No description provided
	 * @return            No description provided
	 */
	public int readRelationFile(
		String projectdir,
		String filename,
		AttributeVector as)
	{

		String relationName = "";
		String packageName = "";
		String attributeName = "";
		String attributeRole = "";
		Boolean attributePrimaryKeyPart = new Boolean(false);
		Boolean attributeNotNull = new Boolean(false);

		// as.output();

		try
		{

			// Open the file, do the technicalities to get StreamTokenizer
			FileInputStream fis =
				new FileInputStream(projectdir + slashChar + filename);

			InputStreamReader isr = new InputStreamReader(fis);
			BufferedReader br = new BufferedReader(isr);
			StreamTokenizer st = new StreamTokenizer(br);
			st.slashSlashComments(false);
			st.wordChars('_', '_');
			// st.wordChars('[','[');
			// st.wordChars(']',']');
			st.ordinaryChars('0', '9');
			st.wordChars('0', '9');
			st.ordinaryChar(')');
			st.whitespaceChars('(', '(');
			st.whitespaceChars(',', ',');

			int nextType = expectingRelationString;

			while (st.nextToken() != StreamTokenizer.TT_EOF)
			{
				if (st.ttype != StreamTokenizer.TT_WORD)
				{
					System.out.println(
						"Expecting a string, got " + st.toString());
				} else
				{
					if (!st.sval.equals(relationString))
					{
						System.out.println(
							"Expexting '"
								+ relationString
								+ "', got: "
								+ st.toString());
					} else
					{ // A relation coming up, let's read it:
						nextType = expectingRelationName;
						Relation r = new Relation();
						while ((st.nextToken() != StreamTokenizer.TT_EOF)
							&& (nextType != expectingRelationString))
						{
							if (st.ttype != StreamTokenizer.TT_WORD)
							{
								System.out.println(
									"Expecting a string, got " + st.toString());
							} else
							{
								switch (nextType)
								{
									case expectingRelationName :
										// System.out.println("Got relation name " + st.sval);
										relationName = st.sval.toLowerCase();
										r.setName(relationName);
										nextType = expectingPackageString;
										break;
									case expectingPackageString :
										if (st.sval.equals(packageString))
										{
											nextType = expectingPackageName;
										} else
										{
											System.out.println(
												"I was expecting "
													+ packageString
													+ ", but I got "
													+ st.toString());
										}
										break;
									case expectingPackageName :
										packageName = st.sval.toLowerCase();
										r.setPackage(packageName);
										nextType = expectingAttributeString;
										break;
									case expectingAttributeString :
										if (st.sval.equals(attributeString))
										{
											nextType = expectingAttributeRole;
										} else if (
											st.sval.equals(endRelationString))
										{
											st.pushBack();
											nextType = expectingRelationString;
										} else if (
											st.sval.equals(primaryKeyString))
										{
											nextType = expectingPrimaryKey;
										} else if (
											st.sval.equals(uniqueString))
										{
											nextType = expectingUnique;
										} else if (
											st.sval.equals(foreignKeyString))
										{
											nextType = expectingForeignKey;
										} else
										{
											System.out.println(
												"Expexting '"
													+ attributeString
													+ "' or '"
													+ endRelationString
													+ "', got: "
													+ st.toString());
										}
										break;
									case expectingAttributeRole :
										// System.out.println("Got attribute role " + st.sval);
										attributeRole = st.sval.toLowerCase();
										nextType = expectingNotNull;
										break;
									case expectingNotNull :
										// System.out.println("Got notNull " + st.sval);
										attributeNotNull = new Boolean(st.sval);
										nextType = expectingAttributeName;
										break;
									case expectingAttributeName :
										// System.out.println("Got attribute name " + st.sval);
										attributeName = st.sval.toLowerCase();
										nextType = expectingAttributeString;
										Attribute a =
											as.getAttribute(attributeName);
										if (a != null)
										{
											Attribute a2 =
												new Attribute(
													a.getName(),
													a.getSQLType(),
													a.getJavaType(),
													a.getStringType());
											a2.setDescription(a.getDescription());
											a2.setNotNull(attributeNotNull);
											a2.setJavaTypeLength(
												a.getJavaTypeLength());
											a2.setJavaTypeScale(
												a.getJavaTypeScale());
											// a2.output();
											// System.out.println("It was a real attribute!");
											r.addAttribute(a2);
										} else
										{
											System.out.println(
												"Unknown attribute "
													+ attributeName
													+ " in relation "
													+ r.getName());
										}
										break;
									case expectingPrimaryKey : // we always come here from
										// case expectingAttributeString
										NameVector primaryKey =
											new NameVector();
										try
										{
											do
											{
												//System.out.println("Primary key for relation " + r.getName() +
												//	       " and I just read " + st.toString());
												String name =
													st.sval.toLowerCase();
												if (st.ttype
													!= closeParenthesisChar)
												{
													if ((!primaryKey
														.nameExists(name))
														&& (r
															.attributeRoleExists(name)))
													{
														primaryKey.addName(
															name);
													} else
													{
														System.out.println(
															"Primary key statement attribute "
																+ st.sval
																+ " not found for relation "
																+ r.getName()
																+ ", got:"
																+ st.toString());
													}
												}
												st.nextToken();
											} while (
												st.ttype
													!= closeParenthesisChar);
											r.setPrimaryKey(primaryKey);
										} catch (Exception e)
										{
											System.out.println(
												"Error reading primary key for relation "
													+ r.getName());
										}
										nextType = expectingAttributeString;
										break;
									case expectingUnique : // we always come here from
										// case expectingAttributeString
										NameVector unique = new NameVector();
										try
										{
											do
											{
												String name =
													st.sval.toLowerCase();
												if (st.ttype
													!= closeParenthesisChar)
												{
													if (!unique
														.nameExists(name)
														&& (r
															.attributeRoleExists(name)))
													{
														unique.addName(name);
													} else
													{
														System.out.println(
															"Unique statement attribute "
																+ st.sval
																+ " not found for relation "
																+ r.getName()
																+ ", got:"
																+ st.toString());
													}
												}
												st.nextToken();
											} while (
												st.ttype
													!= closeParenthesisChar);
											r.addUnique(unique);
										} catch (Exception e)
										{
											System.out.println(
												"Error reading a unique statement"
													+ " for relation "
													+ r.getName());
										}
										nextType = expectingAttributeString;
										break;
									case expectingForeignKey : // we always come here from
										// case expectingAttributeString
										NameVector ownAttributes =
											new NameVector();
										String referredTable = "";
										NameVector referredAttributes =
											new NameVector();
										try
										{
											do
											{
												String name =
													st.sval.toLowerCase();
												if (st.ttype
													!= closeParenthesisChar)
												{
													if (!ownAttributes
														.nameExists(name)
														&& (r
															.attributeRoleExists(name)))
													{
														ownAttributes.addName(
															name);
													} else
													{
														System.out.println(
															"Foreign key statement attribute "
																+ st.sval
																+ " not found for relation "
																+ r.getName()
																+ ", got:"
																+ st.toString());
													}
												}
												st.nextToken();
											} while (
												st.ttype
													!= closeParenthesisChar);
											st.nextToken();
											referredTable =
												st.sval.toLowerCase();
											st.nextToken();
											do
											{
												String name =
													st.sval.toLowerCase();
												if (st.ttype
													!= closeParenthesisChar)
												{
													if (!referredAttributes
														.nameExists(name))
													{
														referredAttributes
															.addName(
															name);
													} else
													{
														System.out.println(
															"Foreign key statement attribute "
																+ st.sval
																+ " not found for relation "
																+ r.getName()
																+ ", got:"
																+ st.toString());
													}
												}
												st.nextToken();
											} while (
												st.ttype
													!= closeParenthesisChar);

											ForeignKey foreignKey =
												new ForeignKey();
											foreignKey.setOwnAttributes(
												ownAttributes);
											foreignKey.setReferredTable(
												referredTable);
											foreignKey.setReferredAttributes(
												referredAttributes);

											r.addForeignKey(foreignKey);
										} catch (Exception e)
										{
											System.out.println(
												"Error reading a foreign key statement"
													+ " for relation "
													+ r.getName());
										}
										nextType = expectingAttributeString;
										break;
									default :
										break;
								} // end switch
							} // end of "getting a string" else
						} // end while - done reading a relation
						addRelation(r);
					} // end of "getting a relation" else
				}
			}
			return relationFileReadOk;
		} catch (IOException e)
		{
			System.out.println(e);
			return relationFileReadFailed;
		}
	}


	public int size()
	{
		return relationVector.size();
	}

	public void sort()
	{
		Vector newVector = new Vector();
		HashMap hm = new HashMap();
		HashMap allRels = new HashMap();
		HashMap missingRels = new HashMap();
		for (int i = 0; i < relationVector.size(); i++)
		{
			Relation rel = (Relation) relationVector.get(i);
			allRels.put(rel.getName(), Boolean.TRUE);
			Vector foreignKeys = rel.getForeignKeyVector();
			boolean add = true;
			for (int i2 = 0; i2 < foreignKeys.size(); i2++)
			{
				ForeignKey fk = (ForeignKey) foreignKeys.get(i2);
				if (!hm.containsKey(fk.getReferredTable()))
				{
					missingRels.put(fk.getReferredTable(), Boolean.TRUE);
					add = false;
				}
			}
			if (add)
			{
				newVector.add(rel);
				relationVector.remove(rel);
				i--;
				hm.put(rel.getName(), Boolean.TRUE);
				missingRels.remove(rel.getName());
			}
		}
		Iterator iter = missingRels.keySet().iterator();
		while (iter.hasNext())
		{
			Object relName = iter.next();
			if (!allRels.containsKey(relName))
			{
				hm.put(relName, Boolean.TRUE);
			}
		}
		while (relationVector.size() > 0)
		{
			for (int i = 0; i < relationVector.size(); i++)
			{
				Relation rel = (Relation) relationVector.get(i);
				Vector foreignKeys = rel.getForeignKeyVector();
				boolean add = true;
				for (int i2 = 0; i2 < foreignKeys.size(); i2++)
				{
					ForeignKey fk = (ForeignKey) foreignKeys.get(i2);
					if (!hm.containsKey(fk.getReferredTable()))
					{
						i2 = foreignKeys.size();
						add = false;
					}
				}
				if (add)
				{
					newVector.add(rel);
					relationVector.remove(rel);
					i--;
					hm.put(rel.getName(), Boolean.TRUE);
				}
			}
		}
		relationVector = newVector;
	}
	
//  ------------------------------------------------------------
//  Class file output
//  ------------------------------------------------------------
	
	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param projectdir  No description provided
	 * @return            No description provided
	 */
    private int writeDbClassFiles(String projectdir) {
		for (int i = 0; i < relationVector.size(); i++) {
			StringBuffer sb = new StringBuffer();
			Relation r = (Relation) relationVector.elementAt(i);
			AttributeVector av = r.getAttributeVector();
			NameVector primaryKey = r.getPrimaryKey();
			String className = javaDbPrefix
					+ r.getName().substring(0, 1).toUpperCase()
					+ r.getName().substring(1, r.getName().length());
			JavaClassWriter jcw = new JavaClassWriter(sb, className);

			// Package
			jcw.WritePackage(r.getPackage());

			// Imports
			jcw.WriteEmptyLine();
			jcw.WriteDbImports();

			// Class
			jcw.WriteEmptyLine();
			jcw.WriteClassJavaDocBegin();
			jcw.WriteClassJavaDocLine( "Generated database access class for table " + r.getName() + "." );
			jcw.WriteClassJavaDocLine( r.getDescription() );
			jcw.WriteClassJavaDocEnd();
			jcw.WriteClass(javaDbClassInheritance);

			// Attributes
			HashMap tempNames = new HashMap();
			for (int j = 0; j < av.size(); j++) { 
				Attribute a = av.getAttribute(j);
				jcw.WritePrivateProperty( a.getJavaType(),
						a.getRole() + javaDbAttributeSuffix );
				if (primaryKey.nameExists(a.getRole()))
				{
				    String name = a.getRole();
				    while(av.getAttributeByRole(name) != null || tempNames.containsValue(name))
				    {
				        name += "KC";
				    }
					jcw.WritePrivateProperty( a.getJavaType(),
						name );
					tempNames.put(a.getRole(), name);
				}
			}
			
			// Constructor
			jcw.WriteEmptyLine();
			jcw.WriteJavaDocBegin();
			jcw.WriteJavaDocLine( "Default constructor." );
			jcw.WriteJavaDocEnd();
			jcw.WriteDbConstructor( av, primaryKey, tempNames );
			
			// setFromResultSet
			jcw.WriteEmptyLine();
			jcw.WriteJavaDocBegin();
			jcw.WriteJavaDocLine("Updates the data from the given ResultSet object." );
			jcw.WriteJavaDocLine("@param resultSet ResultSet object containing the data.");
			jcw.WriteJavaDocLine("@param baseIndex Base index of the columns in the ResultSet (exclusive).");
			jcw.WriteJavaDocLine("@throws SQLException if the JDBC operation fails.");
			jcw.WriteJavaDocLine("@throws InvalidValueException if the attributes are invalid.");
			jcw.WriteJavaDocEnd();
			jcw.WriteSetFromResultSet( av, primaryKey, tempNames );
			
			// toString
			jcw.WriteEmptyLine();
			jcw.WriteDbToString( r.getName(), av );
			
			// equals
			jcw.WriteEmptyLine();
			jcw.WriteDbEquals( av );
			
			// clone
			jcw.WriteEmptyLine();
			jcw.WriteClone();

			// Getters
			for (int j = 0; j < av.size(); j++)
			{
				Attribute a = av.getAttribute(j);
				jcw.WriteEmptyLine();
				jcw.WriteJavaDocBegin();
				jcw.WriteJavaDocLine("Gets the raw data object for " + a.getRole() + " attribute.");
				jcw.WriteJavaDocLine("@return Data object as " + a.getJavaType() + "." );
				jcw.WriteJavaDocEnd();
				jcw.WriteGetter( a.getJavaType(),
					a.getRole() + javaDbAttributeSuffix );
			}
			
			// insert
			jcw.WriteEmptyLine();
			jcw.WriteJavaDocBegin();
			jcw.WriteJavaDocLine("Inserts this object to the database table " + r.getName() + ".");
			jcw.WriteJavaDocLine("@param con Open and active connection to the database.");
			jcw.WriteJavaDocLine("@throws SQLException if the JDBC operation fails.");
			jcw.WriteJavaDocLine("@throws ObjectNotValidException if the attributes are invalid.");
			jcw.WriteJavaDocEnd();
			jcw.WriteDbInsert( r.getName(), av );
			
			// update
			jcw.WriteEmptyLine();
			jcw.WriteJavaDocBegin();
			jcw.WriteJavaDocLine("Updates the row of this object in the database table " + r.getName() + ".");
			jcw.WriteJavaDocLine("The row is identified by the primary key attribute(s).");
			jcw.WriteJavaDocLine("@param con Open and active connection to the database.");
			jcw.WriteJavaDocLine("@throws SQLException if the JDBC operation fails.");
			jcw.WriteJavaDocLine("@throws ObjectNotValidException if the attributes are invalid.");
			jcw.WriteJavaDocLine("@throws NoSuchItemException if the row to be updated does not exist or is not unique.");
			jcw.WriteJavaDocEnd();
			jcw.WriteDbUpdate( r.getName(), av, primaryKey, tempNames );			
			
			// delete
			jcw.WriteEmptyLine();
			jcw.WriteJavaDocBegin();
			jcw.WriteJavaDocLine("Deletes the row of this object from the database table " + r.getName() + ".");
			jcw.WriteJavaDocLine("The row is identified by the primary key attribute(s).");
			jcw.WriteJavaDocLine("@param con Open and active connection to the database.");
			jcw.WriteJavaDocLine("@throws SQLException if the JDBC operation fails.");
			jcw.WriteJavaDocLine("@throws TooManyItemsException if the row to be deleted is not unique.");
			jcw.WriteJavaDocLine("@throws NoSuchItemException if the row to be deleted does not exist.");
			jcw.WriteJavaDocEnd();
			jcw.WriteDbDelete( r.getName(), av, primaryKey, tempNames );
			
			// select
			jcw.WriteEmptyLine();
			jcw.WriteJavaDocBegin();
			jcw.WriteJavaDocLine("Selects the row of this object from the database table " + r.getName() 
				+ " and updates the attributes accordingly.");
			jcw.WriteJavaDocLine("The row is identified by the primary key attribute(s).");
			jcw.WriteJavaDocLine("@param con Open and active connection to the database.");
			jcw.WriteJavaDocLine("@throws SQLException if the JDBC operation fails.");
			jcw.WriteJavaDocLine("@throws InvalidValueException if the attributes are invalid.");
			jcw.WriteJavaDocLine("@throws NoSuchItemException if the row to be selected does not exist or is not unique.");
			jcw.WriteJavaDocEnd();
			jcw.WriteDbSelect( r.getName(), av, primaryKey );
			
			// selectionIterator
			String elementClass = 
			    r.getName().substring(0, 1).toUpperCase()
				+ r.getName().substring(1, r.getName().length());
			jcw.WriteEmptyLine();
			jcw.WriteJavaDocBegin();
			jcw.WriteJavaDocLine("Constructs and returns a selection iterator for rows in database table " + r.getName() + ".\n"); 
			jcw.WriteJavaDocLine("@param con Open and active connection to the database.");	
			jcw.WriteJavaDocLine("@param whereClause Optional where clause. If null is given, all the rows are selected.\n");
			jcw.WriteJavaDocLine("@return Newly constructed iterator that returns objects of type " + elementClass 
				+ ". The iterator is closed when hasNext() returns false or the iterator is finalized.\n" );
			jcw.WriteJavaDocLine("@throws SQLException if the JDBC operation fails.\n");
			jcw.WriteJavaDocLine("Note that the iterator may throw SqlSelectionIteratorException (which is a runtime exception) when its methods are called.");
			jcw.WriteJavaDocEnd();
			jcw.WriteDbSelectionIterator( r.getName(), elementClass );
			
			// Footer
			jcw.WriteClassEndAndFooter();

			try { 
				// Write the contents of output to a file using a FileWriter
				File outDir = new File( projectdir
					+ slashChar
					+ javaString
					+ slashChar
					+ r.getPackage());
				outDir.mkdir();
				File outFile = new File( projectdir
					+ slashChar
					+ javaString
					+ slashChar
					+ r.getPackage()
					+ slashChar
					+ className
					+ period
					+ javaString);
				FileWriter writer = new FileWriter(outFile);
				writer.write(sb.toString());
				writer.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
		return 0;
	}	

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param projectdir  No description provided
	 * @return            No description provided
	 */
	private int writeBeanClassFiles(String projectdir)
	{
		for (int i = 0; i < relationVector.size(); i++)
		{ 
			StringBuffer sb = new StringBuffer();
			Relation r = (Relation) relationVector.elementAt(i);
			AttributeVector av = r.getAttributeVector();
			NameVector primaryKey = r.getPrimaryKey();
			String className =
				javaBeanPrefix
					+ r.getName().substring(0, 1).toUpperCase()
					+ r.getName().substring(1, r.getName().length());
			JavaClassWriter jcw = new JavaClassWriter(sb, className);
			
			// Package
			jcw.WritePackage( r.getPackage() );
			
			// Imports
			jcw.WriteEmptyLine();
			sb.append( javaImportSqlDatamodelString + endLine);
			
			// Class
			jcw.WriteEmptyLine();
			jcw.WriteClassJavaDocBegin();
			jcw.WriteClassJavaDocLine("Generated bean class for " + r.getName() + ".");
			jcw.WriteClassJavaDocLine("This class extends the database access class by adding bean property getters and setters.");
			jcw.WriteClassJavaDocEnd();
			jcw.WriteClass( "extends " 
				+ javaDbPrefix 
				+ r.getName().substring(0, 1).toUpperCase()
				+ r.getName().substring(1, r.getName().length()) );

			// Constructor
			jcw.WriteEmptyLine();
			jcw.WriteJavaDocBegin();
			jcw.WriteJavaDocLine("Default constructor.");
			jcw.WriteJavaDocEnd();
			jcw.WritePlainConstructor();
			
			// Getters and setters
			for (int j = 0; j < av.size(); j++)
			{
				Attribute a = av.getAttribute(j);
				
				jcw.WriteEmptyLine();
				jcw.WriteJavaDocBegin();
				jcw.WriteJavaDocLine("Gets the value of the property " + a.getRole() + ".");
				jcw.WriteJavaDocLine("@return Value as " + a.getBeanType() + ".");
				jcw.WriteJavaDocEnd();
				jcw.WriteBeanGetter(a.getBeanType(), a.getRole() );
				
				jcw.WriteEmptyLine();
				jcw.WriteJavaDocBegin();
				jcw.WriteJavaDocLine("Sets the value of the property " + a.getRole() + ".");
				jcw.WriteJavaDocLine("@param newValue New value as " + a.getBeanType() + ".");
				jcw.WriteJavaDocLine("@throws InvalidValueException if the new value is not valid.");
				jcw.WriteJavaDocEnd();
				jcw.WriteBeanSetter(a.getBeanType(), a.getRole() );
			}
			
			// Footer
			jcw.WriteClassEndAndFooter();

			try { 
				// Write the contents of output to a file using a FileWriter
				File outDir = new File( projectdir
					+ slashChar
					+ javaString
					+ slashChar
					+ r.getPackage());
				outDir.mkdir();
				File outFile = new File( projectdir
					+ slashChar
					+ javaString
					+ slashChar
					+ r.getPackage()
					+ slashChar
					+ className
					+ period
					+ javaString);
				FileWriter writer = new FileWriter(outFile);
				writer.write(sb.toString());
				writer.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
		return 0;
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param projectdir  No description provided
	 * @return            No description provided
	 */
	private int writeMainClassFiles(String projectdir) {
		for (int i = 0; i < relationVector.size(); i++) { 
			StringBuffer sb = new StringBuffer();
			Relation r = (Relation) relationVector.elementAt(i);
			String className =
				r.getName().substring(0, 1).toUpperCase()
				+ r.getName().substring(1, r.getName().length());
			JavaClassWriter jcw = new JavaClassWriter(sb, className);
			
			// Package
			jcw.WritePackage( r.getPackage() );
			
			// Class
			String extendsClassName =
				javaBeanPrefix + className;
			jcw.WriteEmptyLine();
			jcw.WriteClassJavaDocBegin();
			jcw.WriteClassJavaDocLine("Skeleton class for application-specific functionality.");
			jcw.WriteClassJavaDocEnd();
			jcw.WriteClass("extends " + extendsClassName);
			
			// Constructor
			jcw.WriteEmptyLine();
			jcw.WriteJavaDocBegin();
			jcw.WriteJavaDocLine("Default constructor.");
			jcw.WriteJavaDocEnd();
			jcw.WritePlainConstructor();
			
			// Insertion comment
			jcw.WriteEmptyLine();
			sb.append( tabString + "// @todo Insert your additional attributes and methods here." + endLine );
			jcw.WriteEmptyLine();
			
			// Footer
			jcw.WriteClassEndAndFooter();

			try { 
				// Write the contents of output to a file using a FileWriter
				File outDir = new File( projectdir
					+ slashChar
					+ javaString
					+ slashChar
					+ r.getPackage());
				outDir.mkdir();
				File outFile = new File( projectdir
					+ slashChar
					+ javaString
					+ slashChar
					+ r.getPackage()
					+ slashChar
					+ className
					+ period
					+ javaString);
				FileWriter writer = new FileWriter(outFile);
				writer.write(sb.toString());
				writer.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
		return 0;
	}
}

/*
 * $Log: RelationVector.java,v $
 * Revision 1.3  2003/10/07 07:21:48  ariseppi
 * misc. corrections
 *
 */
