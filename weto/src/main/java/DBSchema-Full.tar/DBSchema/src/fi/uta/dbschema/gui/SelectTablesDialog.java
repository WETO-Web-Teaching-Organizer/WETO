/*
 * Created on 22.6.2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package fi.uta.dbschema.gui;

import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

import de.uni_paderborn.fujaba.asg.ASGElement;
import de.uni_paderborn.fujaba.gui.PEEditPanel;
import fi.uta.dbschema.metamodel.DBForeignKey;
import fi.uta.dbschema.metamodel.DBJunctionPair;
import fi.uta.dbschema.metamodel.DBSchema;
import fi.uta.dbschema.metamodel.DBSchemaItem;
import fi.uta.dbschema.metamodel.DBTable;
import fi.uta.dbschema.metamodel.DBTableAttribute;
import fi.uta.dbschema.metamodel.DBTableAttributeJunction;
import fi.uta.dbschema.metamodel.DBTableInterface;

/**
 * @author as66033
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class SelectTablesDialog extends BasicDialog
{
	private TableSelection selection;

	private BDButton editButton;

	public SelectTablesDialog(JFrame frame, String title, boolean modal)
	{
		super(frame);
		setModal(modal);
		setTitle(title);
		try
		{
			pack();
			this.setTitle("Database Query");
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		initDialog();
	}

	public SelectTablesDialog(JFrame frame)
	{
		this(frame, "", false);
	}

	public SelectTablesDialog(JFrame frame, boolean modal)
	{
		this(frame, "", modal);
	}

	public SelectTablesDialog(JFrame frame, String title)
	{
		this(frame, title, false);
	}

	protected void additionalContents(PEEditPanel panel)
	{
		selection = new TableSelection(this);

		panel.add(selection);
	}

	protected void additionalButtons(BDComponentGroup buttons)
	{
		editButton = new BDButton(this, "Edit Attributes");
		buttons.add(editButton);
		editButton.setListener(
			new SelectTablesDialog_editButton_actionAdapter(this));
		setOkToCancel();
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param e  No description provided
	 */
	void buttonOK_actionPerformed(ActionEvent e)
	{
		setVisible(false);
		dispose();
	}

	void editButton_actionPerformed(ActionEvent e)
	{
		int[] selected = selection.getList().getList().getSelectedElements();
		ArrayList attributes = new ArrayList();
		ArrayList tables = new ArrayList();
		HashMap foreignAttributes = new HashMap();
		boolean tableQuery = true;
		DBTableInterface view = null;
		for (int i = 0; i < selected.length; i++)
		{
			PEDBItem item =
				(PEDBItem) selection.getList().getList().getItemByIndex(
					selected[i]);
			DBTableInterface table = (DBTableInterface) item.getIncrement();
			if (table instanceof DBTable)
			{
				tables.add(table);
			} else
			{
				if (selected.length > 1)
				{
					JOptionPane.showMessageDialog(
						getFrame(),
						"Error: Selection contains a view and has more than one items selected.",
						"Multiple views not allowed",
						JOptionPane.ERROR_MESSAGE);
					return;
				}
				view = table;
				tableQuery = false;
			}
			Iterator iter2 = table.iteratorOfAttributes();
			while (iter2.hasNext())
			{
				Object attributeObject = iter2.next();
				if (attributeObject instanceof DBTableAttribute)
				{
					DBTableAttribute attr = (DBTableAttribute) attributeObject;
					Iterator iter3 = attr.iteratorOfJunctions();
					boolean found = false;
					while (iter3.hasNext() && !found)
					{
						DBTableAttributeJunction junc =
							(DBTableAttributeJunction) iter3.next();
						DBJunctionPair pair = junc.getPair();
						DBTableAttributeJunction otherJunc = null;
						if (pair.getOriginalJunction() == junc)
						{
							otherJunc = pair.getRevJunction();
						} else
						{
							otherJunc = pair.getOriginalJunction();
						}
						DBTableAttribute otherAttr = otherJunc.getTarget();
						if (tables.contains(otherAttr.getParent()))
						{
							if (attributes.contains(otherAttr))
							{
								attributes.remove(otherAttr);
								Object[] attrArray =
									{ otherAttr, attr.getParent().getName()};
								attributes.add(attrArray);
								foreignAttributes.put(attr, attrArray);
								foreignAttributes.put(otherAttr, attrArray);
							} else
							{
								Object[] attrArray =
									(Object[]) foreignAttributes.get(otherAttr);
								attrArray[1] =
									attrArray[1].toString()
										+ ", "
										+ attr.getParent().getName();
								foreignAttributes.put(attr, attrArray);
							}
							found = true;
						}
					}
					if (!found)
					{
						attributes.add(attributeObject);
					}
				} else
				{
					attributes.add(attributeObject);
				}
			}
		}
		String[] tableArray = null;
		StringBuffer sb = new StringBuffer();
		if (tableQuery)
		{
			ArrayList tablesTemp = (ArrayList) tables.clone();
			wheres = new ArrayList();
			addTables = new ArrayList();
			visited = new ArrayList();
			DBTable table = (DBTable) tables.remove(0);
			addWheres(table, tables, new ArrayList(), new ArrayList());
			Iterator iter = wheres.iterator();
			int ind = 0;
			while (iter.hasNext())
			{
				sb.append(iter.next());
				if (ind < wheres.size() - 1)
				{
					sb.append(" AND ");
				}
				ind++;
			}

			iter = addTables.iterator();
			while (iter.hasNext())
			{
				Object addTable = iter.next();
				if (!tablesTemp.contains(addTable))
				{
					tablesTemp.add(addTable);
				}
			}

			tableArray = new String[tablesTemp.size()];
			for (int i = 0; i < tablesTemp.size(); i++)
			{
				tableArray[i] = ((DBSchemaItem) tablesTemp.get(i)).getName();
			}
		} else
		{
			tableArray = new String[1];
			tableArray[0] = view.getName();
		}
		DefineQueryDialog queryDialog =
			new DefineQueryDialog(this.getFrame(), attributes, tableArray);
		queryDialog.setWhereClause(sb.toString());
		queryDialog.showCentered();
	}

	public void setIncrement(ASGElement e)
	{
		super.setIncrement(e);
		selection.fillList();
	}

	private ArrayList wheres;
	private ArrayList addTables;
	private ArrayList visited;

	private void addWheres(
		DBTable currentTable,
		ArrayList tables,
		ArrayList wherePath,
		ArrayList tablePath)
	{
		visited.add(currentTable);
		if (tables.size() > 0)
		{
			Iterator iter = currentTable.iteratorOfForeignKeys();
			while (iter.hasNext())
			{
				DBForeignKey key = (DBForeignKey) iter.next();
				if (!visited.contains(key.getRevTable()))
				{
					wherePath.add(key.getWhereClause());
					tablePath.add(key.getRevTable());
					if (tables.contains(key.getRevTable()))
					{
						Iterator iter2 = wherePath.iterator();
						while (iter2.hasNext())
						{
							Object whereClause = iter2.next();
							if (!wheres.contains(whereClause))
							{
								wheres.add(whereClause);
							}
						}
						iter2 = tablePath.iterator();
						while (iter2.hasNext())
						{
							Object table = iter2.next();
							if (!addTables.contains(table))
							{
								addTables.add(table);
							}
						}
						tables.remove(key.getRevTable());
					}
					addWheres(key.getRevTable(), tables, wherePath, tablePath);
					wherePath.remove(wherePath.size() - 1);
					tablePath.remove(tablePath.size() - 1);
				}
			}
			iter = currentTable.iteratorOfRevForeignKeys();
			while (iter.hasNext())
			{
				DBForeignKey key = (DBForeignKey) iter.next();
				if (!visited.contains(key.getOriginalTable()))
				{
					wherePath.add(key.getWhereClause());
					tablePath.add(key.getOriginalTable());
					if (tables.contains(key.getOriginalTable()))
					{
						Iterator iter2 = wherePath.iterator();
						while (iter2.hasNext())
						{
							Object whereClause = iter2.next();
							if (!wheres.contains(whereClause))
							{
								wheres.add(whereClause);
							}
						}
						iter2 = tablePath.iterator();
						while (iter2.hasNext())
						{
							Object table = iter2.next();
							if (!addTables.contains(table))
							{
								addTables.add(table);
							}
						}
						tables.remove(key.getOriginalTable());
					}
					addWheres(
						key.getOriginalTable(),
						tables,
						wherePath,
						tablePath);
					wherePath.remove(wherePath.size() - 1);
					tablePath.remove(tablePath.size() - 1);
				}
			}
		}
	}
}

class SelectTablesDialog_editButton_actionAdapter
	implements java.awt.event.ActionListener
{
	SelectTablesDialog adaptee;

	SelectTablesDialog_editButton_actionAdapter(SelectTablesDialog adaptee)
	{
		this.adaptee = adaptee;
	}

	public void actionPerformed(ActionEvent e)
	{
		adaptee.editButton_actionPerformed(e);
	}
}

class TableSelection extends BDListSelection
{
	SelectTablesDialog dialog = null;

	TableSelection(SelectTablesDialog parent)
	{
		super(parent);
		getList().setHeader("Tables");
		this.getList().getList().setSelectionMode(
			ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		dialog = parent;
	}

	public void fillList()
	{
		clearList();
		ASGElement incr = dialog.getIncrement();

		if (incr == null)
		{
			return;
		}

		if (incr instanceof DBSchema)
		{
			DBSchema schema = (DBSchema) incr;
			if (schema != null)
			{
				Iterator iter = schema.iteratorOfItems();
				while (iter.hasNext())
				{
					Object obj = iter.next();
					DBSchemaItem table;
					if (obj instanceof DBTableInterface)
					{
						table = (DBSchemaItem) obj;
						addToList(table, table.getName());
					}
				}
			}
		}
	}
}