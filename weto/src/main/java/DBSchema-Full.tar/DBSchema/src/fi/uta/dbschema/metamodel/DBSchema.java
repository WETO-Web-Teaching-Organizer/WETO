/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.metamodel;

import java.util.Iterator;
import java.util.Map;

import de.uni_paderborn.fujaba.asg.ASGDiagram;
import de.upb.tools.fca.FEmptyIterator;
import de.upb.tools.fca.FLinkedList;

/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:53 $
 * @version   $Revision: 1.2 $
 */
public class DBSchema extends ASGDiagram
{

	/**
	 * Constructor for class DBSchema
	 */
	public DBSchema()
	{
		super();
	}

	/**
	 * Constructor for class DBSchema
	 *
	 * @param n  No description provided
	 */
	public DBSchema(String n)
	{
		this();
		setName(n);
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	private String name = "Database Schema";

	/**
	 * Sets the name attribute of the DBSchema object
	 *
	 * @param newName  The new name value
	 */
	public void setName(String newName)
	{
		if (!name.equals(newName))
		{
			String oldName = this.name;
			this.name = newName;
			firePropertyChange("name", oldName, newName);
		}
	}

	/**
	 * Get the name attribute of the DBSchema object
	 *
	 * @return   The name value
	 */
	public String getName()
	{
		return this.name;
	}

	/**
	 * @return   The elementKey value
	 * @see      de.uni_paderborn.fujaba.asg.ASGDiagram#getElementKey()
	 */
	protected String getElementKey()
	{
		return "items";
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @return   No description provided
	 */
	public int sizeOfItems()
	{
		return sizeOfElements();
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param item  No description provided
	 * @return      No description provided
	 */
	public boolean hasInItems(DBSchemaItem item)
	{
		return hasInElements(item);
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @return   No description provided
	 */
	public Iterator iteratorOfItems()
	{
		return iteratorOfElements();
	}

	/**
	 * Access method for an one to n association.
	 *
	 * @param item  The object added.
	 * @return      No description provided
	 */
	public boolean addToItems(DBSchemaItem item)
	{
		return addToElements(item);
	}

	/**
	 * @param entry  The object added.
	 */
	protected void addToItems(Map.Entry entry)
	{
		addToElements(entry);
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param item  No description provided
	 * @return      No description provided
	 */
	public boolean removeFromItems(DBSchemaItem item)
	{
		return removeFromElements(item);
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	public void removeAllFromItems()
	{
		Iterator iter = iteratorOfItems();
		while (iter.hasNext())
		{
			removeFromItems((DBSchemaItem) iter.next());
		}
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @return   No description provided
	 */
	public String toString()
	{
		return name;
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	public void removeYou()
	{
		removeAllFromItems();
		super.removeYou();
	}

	private FLinkedList defaultDatabaseConnection;

	public int sizeOfDefaultDatabaseConnection()
	{
		return ((this.defaultDatabaseConnection == null) ? 0 : this.defaultDatabaseConnection.size());
	}

	public boolean removeFromDefaultDatabaseConnection(String value)
	{
		boolean changed = false;
		if ((this.defaultDatabaseConnection != null) && (value != null))
		{
			changed = this.defaultDatabaseConnection.remove(value);
		}
		return changed;
	}

	public void removeAllFromDefaultDatabaseConnection()
	{
		String tmpValue;
		Iterator iter = this.iteratorOfDefaultDatabaseConnection();
		while (iter.hasNext())
		{
			tmpValue = (String) iter.next();
			this.removeFromDefaultDatabaseConnection(tmpValue);
		}
	}

	public Iterator iteratorOfDefaultDatabaseConnection()
	{
		return (
			(this.defaultDatabaseConnection == null)
				? FEmptyIterator.get()
				: this.defaultDatabaseConnection.iterator());
	}

	public boolean hasInDefaultDatabaseConnection(String value)
	{
		return (
			(this.defaultDatabaseConnection != null)
				&& (value != null)
				&& this.defaultDatabaseConnection.contains(value));
	}

	public boolean addToDefaultDatabaseConnection(String value)
	{
		boolean changed = false;
		if (value != null)
		{
			if (this.defaultDatabaseConnection == null)
			{
				this.defaultDatabaseConnection = new FLinkedList();
				// or FTreeSet () or FLinkedList ()
			}
			changed = this.defaultDatabaseConnection.add(value);
		}
		return changed;
	}
	
	/**
	 * @return
	 */
	public String[] getDefaultDatabaseConnection()
	{
		if(defaultDatabaseConnection == null)
		{
			return null;
		}
		String[] parameters = new String[defaultDatabaseConnection.size()];
		Iterator iter = defaultDatabaseConnection.iterator();
		int i = 0;
		while(iter.hasNext())
		{
			parameters[i] = (String) iter.next();
			i++;
		}
		return parameters;
	}

	/**
	 * @param strings
	 */
	public void setDefaultDatabaseConnection(String[] strings)
	{
		if(defaultDatabaseConnection == null)
		{
			defaultDatabaseConnection= new FLinkedList();
		}
		defaultDatabaseConnection.clear();
		for(int i = 0; i < strings.length; i++)
		{
			defaultDatabaseConnection.add(strings[i]);
		}
	}
}

/*
 * $Log: DBSchema.java,v $
 * Revision 1.2  2003/10/07 07:21:53  ariseppi
 * misc. corrections
 *
 */
