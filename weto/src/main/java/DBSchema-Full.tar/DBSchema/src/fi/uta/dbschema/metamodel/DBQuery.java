/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.metamodel;

import java.util.Iterator;

import de.uni_paderborn.fujaba.asg.ASGDiagram;
import de.uni_paderborn.fujaba.uml.UMLProject;
import de.upb.tools.fca.FEmptyIterator;
import de.upb.tools.fca.FPropHashSet;


/**
 * DBQuery contains indentification information about the query (name and package) and list
 * of tables and attributes involved and the where constraint. Notice that attribute pairs
 * and tables are independent lists and both have to be managed.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/09/02 10:17:05 $
 * @version   $Revision: 1.2 $
 */

public class DBQuery
    extends DBSchemaItem
    implements DBNodeInterface
{
   /**
    * Constructor for class DBQuery
    */
   public DBQuery()
   {
      super();
      setName ("Query");
   }


   /**
    * Constructor for class DBQuery
    *
    * @param name  No description provided
    */
   public DBQuery (String name)
   {
      super();
      setName (name);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private String name = "";


   /**
    * Sets the name attribute of the DBQuery object
    *
    * @param newName  The new name value
    */
   public void setName (String newName)
   {
      if (!name.equals (newName))
      {
         String oldName = this.name;
         this.name = newName;
         firePropertyChange ("name", oldName, newName);
      }
   }


   /**
    * Get the name attribute of the DBQuery object
    *
    * @return   The name value
    */
   public String getName()
   {
      return this.name;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private String javaPackage = "";


   /**
    * Sets the javaPackage attribute of the DBQuery object
    *
    * @param newPackage  The new javaPackage value
    */
   public void setJavaPackage (String newPackage)
   {
      if (!javaPackage.equals (newPackage))
      {
         String oldPackage = this.javaPackage;
         this.javaPackage = newPackage;
         firePropertyChange ("javaPackage", oldPackage, newPackage);
      }
   }


   /**
    * Get the javaPackage attribute of the DBQuery object
    *
    * @return   The javaPackage value
    */
   public String getJavaPackage()
   {
      return this.javaPackage;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private String whereClause = "";


   /**
    * Sets the whereClause attribute of the DBQuery object
    *
    * @param newClause  The new whereClause value
    */
   public void setWhereClause (String newClause)
   {
      if (!whereClause.equals (newClause))
      {
         String oldClause = this.whereClause;
         this.whereClause = newClause;
         firePropertyChange ("whereClause", oldClause, newClause);
      }
   }


   /**
    * Get the whereClause attribute of the DBQuery object
    *
    * @return   The whereClause value
    */
   public String getWhereClause()
   {
      return this.whereClause;
   }


   /**
    * Get the text attribute of the DBQuery object
    *
    * @return   The text value
    */
   public String getText()
   {
      StringBuffer sb = new StringBuffer();
      sb.append (this.getName());
      sb.append (": ");
      Iterator iter = iteratorOfJoins();
      if (iter.hasNext())
      {
         DBTableJoin join = (DBTableJoin) iter.next();
         sb.append (join.getText());
      }
      if (iter.hasNext())
      {
         sb.append ("... (");
         sb.append (sizeOfJoins());
         sb.append (" pairs)");
      }
      return sb.toString();
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @return   No description provided
    */
   public String toString()
   {
      return this.getName();
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void removeYou()
   {
      Iterator iter = iteratorOfTables();
      while (iter.hasNext())
      {
         DBTable tmpTable = (DBTable) iter.next();
         tmpTable.removeFromRevQueries (this);
         removeFromTables (tmpTable);
      }
      removeAllFromJoins();
      super.removeYou();
   }


   /**
    * <pre>
    *             0..n   joins   0..1
    * DBTableJoin ---------------------- DBQuery
    *             joins         query
    * </pre>
    */
   private FPropHashSet joins = new FPropHashSet (this, "joins");


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @return   No description provided
    */
   public int sizeOfJoins()
   {
      return  ( (this.joins == null)
         ? 0
         : this.joins.size());
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param value  No description provided
    * @return       No description provided
    */
   public boolean removeFromJoins (DBTableJoin value)
   {
      boolean changed = false;
      if ( (this.joins != null) &&  (value != null))
      {
         changed = this.joins.remove (value);
         if (changed)
         {
            DBTable first = (DBTable) value.getFirstJunction().getTarget();
            DBTable second = (DBTable) value.getSecondJunction().getTarget();
            boolean foundFirst = false;
            boolean foundSecond = false;
            Iterator iter = iteratorOfJoins();
            while ( (!foundFirst || !foundSecond) && iter.hasNext())
            {
               DBTable firstComp = (DBTable) value.getFirstJunction().getTarget();
               DBTable secondComp = (DBTable) value.getSecondJunction().getTarget();
               if (firstComp == first || secondComp == first)
               {
                  foundFirst = true;
               }
               if (firstComp == second || secondComp == second)
               {
                  foundSecond = true;
               }
            }
            if (!foundFirst)
            {
               removeFromTables (first);
            }
            if (!foundSecond)
            {
               removeFromTables (second);
            }
            value.removeYou();
         }
      }
      return changed;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void removeAllFromJoins()
   {
      DBTableJoin tmpValue;
      Iterator iter = this.iteratorOfJoins();
      while (iter.hasNext())
      {
         tmpValue = (DBTableJoin) iter.next();
         this.removeFromJoins (tmpValue);
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @return   No description provided
    */
   public Iterator iteratorOfJoins()
   {
      return  ( (this.joins == null)
         ? FEmptyIterator.get()
         : this.joins.iterator());
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param value  No description provided
    * @return       No description provided
    */
   public boolean hasInJoins (DBTableJoin value)
   {
      return  ( (this.joins != null) &&
          (value != null) &&
         this.joins.contains (value));
   }


   /**
    * Access method for an one to n association.
    *
    * @param value  The object added.
    * @return       No description provided
    */
   public boolean addToJoins (DBTableJoin value)
   {
      boolean changed = false;
      if (value != null)
      {
         value.setParent (this);
         if (this.joins == null)
         {
            this.joins = new FPropHashSet (this, "joins"); // or FTreeSet () or FLinkedList ()
         }
         changed = this.joins.add (value);
         if (changed)
         {
            DBTable first = (DBTable) value.getFirstJunction().getTarget();
            DBTable second = (DBTable) value.getSecondJunction().getTarget();
            if (!hasInTables (first))
            {
               addToTables (first);
            }
            if (!hasInTables (second))
            {
               addToTables (second);
            }
         }
      }
      return changed;
   }


   /**
    * <pre>
    *             0..n   tables   0..1
    * DBTable ---------------------- DBQuery
    *             tables         query
    * </pre>
    */
   private FPropHashSet tables;


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @return   No description provided
    */
   public int sizeOfTables()
   {
      return  ( (this.tables == null)
         ? 0
         : this.tables.size());
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param value  No description provided
    * @return       No description provided
    */
   public boolean removeFromTables (DBTable value)
   {
      boolean changed = false;
      if ( (this.tables != null) &&  (value != null))
      {
         changed = this.tables.remove (value);
         if (changed)
         {
            value.removeFromRevQueries (this);
            Iterator iter = iteratorOfJunctions();
            while(iter.hasNext()) {
            	DBTableJunction queryJunc = (DBTableJunction) iter.next();
            	DBTableJoin join = queryJunc.getJoin();
            	DBTableJunction tableJunction = join.getSecondJunction();
            	DBTable table = (DBTable) tableJunction.getTarget();
            	if(table == value) {
            		join.removeYou();
            	}
            }
         }
      }
      return changed;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void removeAllFromTables()
   {
      DBTable tmpValue;
      Iterator iter = this.iteratorOfTables();
      while (iter.hasNext())
      {
         tmpValue = (DBTable) iter.next();
         this.removeFromTables (tmpValue);
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @return   No description provided
    */
   public Iterator iteratorOfTables()
   {
      return  ( (this.tables == null)
         ? FEmptyIterator.get()
         : this.tables.iterator());
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param value  No description provided
    * @return       No description provided
    */
   public boolean hasInTables (DBTable value)
   {
      return  ( (this.tables != null) &&
          (value != null) &&
         this.tables.contains (value));
   }


   /**
    * Access method for an one to n association.
    *
    * @param value  The object added.
    * @return       No description provided
    */
   public boolean addToTables (DBTable value)
   {
      boolean changed = false;
      if (value != null)
      {
         if (this.tables == null)
         {
            this.tables = new FPropHashSet (this, "tables"); // or FTreeSet () or FLinkedList ()
         }
         changed = this.tables.add (value);
         if (changed)
         {
            value.addToRevQueries (this);
            DBTableJoin join = new DBTableJoin();
            DBTableJunction juncQuery = new DBTableJunction(this);
            join.setFirstJunction(juncQuery);
			DBTableJunction juncTable = new DBTableJunction(value);
			join.setSecondJunction(juncTable);
			ASGDiagram curDiagram = UMLProject.get().getCurrentDiagram();
			if (curDiagram instanceof DBSchema)
			{
				((DBSchema) curDiagram).addToItems (join);
			}
         }
      }
      return changed;
   }

   /**
	* <pre>
	*             0..n   junctions   0..1 
	* DBTableJunction ---------------------- DBQuery
	*             junctions         junction 
	* </pre>
	*/
   private FPropHashSet junctions;

   public int sizeOfJunctions()
   {
	  return ((this.junctions == null)
			  ? 0
			  : this.junctions.size ());
   }


   public boolean removeFromJunctions(DBTableJunction value)
   {
	  boolean changed = false;
	  if ((this.junctions != null) && (value != null))
	  {
		 changed = this.junctions.remove (value);
	  }
	  return changed;
   }


   public void removeAllFromJunctions()
   {
	  DBTableJunction tmpValue;
	  Iterator iter = this.iteratorOfJunctions ();
	  while (iter.hasNext ())
	  {
		 tmpValue = (DBTableJunction) iter.next ();
		 this.removeFromJunctions (tmpValue);
	  }
   }


   public Iterator iteratorOfJunctions()
   {
	  return ((this.junctions == null)
			  ? FEmptyIterator.get ()
			  : this.junctions.iterator ());
   }


   public boolean hasInJunctions(DBTableJunction value)
   {
	  return ((this.junctions != null) &&
			  (value != null) &&
			  this.junctions.contains (value));
   }


   public boolean addToJunctions(DBTableJunction value)
   {
	  boolean changed = false;
	  if (value != null)
	  {
		 if (this.junctions == null)
		 {
			this.junctions = new FPropHashSet (this, "junctions"); // or FTreeSet () or FLinkedList ()
		 }
		 changed = this.junctions.add (value);
	  }
	  return changed;
   }
}

/*
 * $Log: DBQuery.java,v $
 * Revision 1.2  2003/09/02 10:17:05  ariseppi
 * Export and view bug fixing and some minor commenting.
 *
 */
