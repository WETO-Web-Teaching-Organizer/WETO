/*
 * Created on 8.6.2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package fi.uta.dbschema.metamodel;

/**
 * @author as66033
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ModelTest
{
	public static void main(String[] args) {
		DBSchema schema = new DBSchema();
		DBTable table1 = new DBTable("Test table");
		schema.addToItems(table1);
		table1.removeYou();
		System.out.println(table1.sizeOfJunctions() == 0);
	}
}
