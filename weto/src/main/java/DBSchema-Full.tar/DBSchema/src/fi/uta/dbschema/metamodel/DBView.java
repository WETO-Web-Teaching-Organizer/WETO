/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.metamodel;

import java.util.Iterator;

import de.upb.tools.fca.FEmptyIterator;
import de.upb.tools.fca.FPropHashSet;


/**
 * DBView contains indentification information about the view (name and package) and list of
 * tables, attributes and junctions. Notice that attribute pairs and tables are independent
 * lists and both have to be managed.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:53 $
 * @version   $Revision: 1.5 $
 */

public class DBView
    extends DBSchemaItem
    implements DBTableInterface
{
   /**
    * Constructor for class DBView
    */
   public DBView()
   {
      super();
      setName ("View");
   }


   /**
    * Constructor for class DBView
    *
    * @param name  No description provided
    */
   public DBView (String name)
   {
      super();
      setName (name);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private String name = "";


   /**
    * Sets the name attribute of the DBView object
    *
    * @param newName  The new name value
    */
   public void setName (String newName)
   {
      if (!name.equals (newName))
      {
         String oldName = this.name;
         this.name = newName;
         firePropertyChange ("name", oldName, newName);
      }
   }


   /**
    * Get the name attribute of the DBView object
    *
    * @return   The name value
    */
   public String getName()
   {
      return this.name;
   }

	
   private String description = "";
	
   public String getDescription()
   {
	   return this.description;
   }
	
   public void setDescription(String newDescription)
   {
	   if (!description.equals(newDescription))
	   {
		   String oldDescription = this.description;
		   this.description = newDescription;
		   firePropertyChange("description", oldDescription, newDescription);
	   }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private String javaPackage = "";


   /**
    * Sets the javaPackage attribute of the DBView object
    *
    * @param newPackage  The new javaPackage value
    */
   public void setJavaPackage (String newPackage)
   {
      if (!javaPackage.equals (newPackage))
      {
         String oldPackage = this.javaPackage;
         this.javaPackage = newPackage;
         firePropertyChange ("javaPackage", oldPackage, newPackage);
      }
   }


   /**
    * Get the javaPackage attribute of the DBView object
    *
    * @return   The javaPackage value
    */
   public String getJavaPackage()
   {
      return this.javaPackage;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private String whereClause = "";


   /**
    * Sets the whereClause attribute of the DBView object
    *
    * @param newClause  The new whereClause value
    */
   public void setWhereClause (String newClause)
   {
      if (!whereClause.equals (newClause))
      {
         String oldClause = this.whereClause;
         this.whereClause = newClause;
         firePropertyChange ("whereClause", oldClause, newClause);
      }
   }


   /**
    * Get the whereClause attribute of the DBView object
    *
    * @return   The whereClause value
    */
   public String getWhereClause()
   {
      return this.whereClause;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @return   No description provided
    */
   public String toString()
   {
      return this.getName();
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void removeYou()
   {
      Iterator iter = iteratorOfTables();
      while (iter.hasNext())
      {
         DBTable tmpTable = (DBTable) iter.next();
         tmpTable.removeFromRevViews (this);
         removeFromTables (tmpTable);
      }
      removeAllFromAttributes();
      removeAllFromJoins();
      removeAllFromJunctions();
      super.removeYou();
   }


   /**
    * <pre>
    *             0..n   attributes   0..1
    * DBViewAttribute ---------------------- DBView
    *             attributes         tableAttribute
    * </pre>
    */
   private FPropHashSet attributes = new FPropHashSet (this, "attributes");


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @return   No description provided
    */
   public int sizeOfAttributes()
   {
      return  ( (this.attributes == null)
         ? 0
         : this.attributes.size());
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param value  No description provided
    * @return       No description provided
    */
   public boolean removeFromAttributes (DBViewAttribute value)
   {
      boolean changed = false;
      if ( (this.attributes != null) &&  (value != null))
      {
         changed = this.attributes.remove (value);
         DBTableAttribute attr = value.getAttribute();
         attr.removeFromRevViews (this);
         DBTable table = attr.getParent();
         boolean found = false;
         Iterator iter = iteratorOfAttributes();
         while (!found && iter.hasNext())
         {
            DBViewAttribute viewAttr = (DBViewAttribute) iter.next();
            DBTableAttribute curAttr = viewAttr.getAttribute();
            DBTable curTable = curAttr.getParent();
            if (curTable == table)
            {
               found = true;
            }
         }
         if (!found)
         {
            removeFromTables (table);
         }
         if (changed)
         {
            value.setParent (null);
         }
      }
      return changed;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void removeAllFromAttributes()
   {
      DBViewAttribute tmpValue;
      Iterator iter = this.iteratorOfAttributes();
      while (iter.hasNext())
      {
         tmpValue = (DBViewAttribute) iter.next();
         this.removeFromAttributes (tmpValue);
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @return   No description provided
    */
   public Iterator iteratorOfAttributes()
   {
      return  ( (this.attributes == null)
         ? FEmptyIterator.get()
         : this.attributes.iterator());
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param value  No description provided
    * @return       No description provided
    */
   public boolean hasInAttributes (DBViewAttribute value)
   {
      return  ( (this.attributes != null) &&
          (value != null) &&
         this.attributes.contains (value));
   }


   /**
    * Access method for an one to n association.
    *
    * @param value  The object added.
    * @return       No description provided
    */
   public boolean addToAttributes (DBViewAttribute value)
   {
      boolean changed = false;
      if (value != null)
      {
         if (this.attributes == null)
         {
            this.attributes = new FPropHashSet (this, "attributes"); // or FTreeSet () or FLinkedList ()
         }
         changed = this.attributes.add (value);
         if (changed)
         {
            value.setParent (this);
            DBTableAttribute attr = value.getAttribute();
            attr.addToRevViews (this);
            DBTable table = attr.getParent();
            if (!hasInTables (table))
            {
               addToTables (table);
            }
         }
      }
      return changed;
   }


   /**
    * <pre>
    *             0..n   tables   0..1
    * DBTable ---------------------- DBQuery
    *             tables         query
    * </pre>
    */
   private FPropHashSet tables;


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @return   No description provided
    */
   public int sizeOfTables()
   {
      return  ( (this.tables == null)
         ? 0
         : this.tables.size());
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param value  No description provided
    * @return       No description provided
    */
   public boolean removeFromTables (DBTable value)
   {
      boolean changed = false;
      if ( (this.tables != null) &&  (value != null))
      {
         changed = this.tables.remove (value);
         if (changed)
         {
            value.removeFromRevViews (this);
         }
      }
      return changed;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void removeAllFromTables()
   {
      DBTable tmpValue;
      Iterator iter = this.iteratorOfTables();
      while (iter.hasNext())
      {
         tmpValue = (DBTable) iter.next();
         this.removeFromTables (tmpValue);
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @return   No description provided
    */
   public Iterator iteratorOfTables()
   {
      return  ( (this.tables == null)
         ? FEmptyIterator.get()
         : this.tables.iterator());
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param value  No description provided
    * @return       No description provided
    */
   public boolean hasInTables (DBTable value)
   {
      return  ( (this.tables != null) &&
          (value != null) &&
         this.tables.contains (value));
   }


   /**
    * Access method for an one to n association.
    *
    * @param value  The object added.
    * @return       No description provided
    */
   public boolean addToTables (DBTable value)
   {
      boolean changed = false;
      if (value != null)
      {
         if (this.tables == null)
         {
            this.tables = new FPropHashSet (this, "tables"); // or FTreeSet () or FLinkedList ()
         }
         changed = this.tables.add (value);
         if (changed)
         {
            value.addToRevViews (this);
         }
      }
      return changed;
   }


   /**
    * <pre>
    *             0..n   joins   0..1
    * DBViewJoin ---------------------- DBView
    *             joins         view
    * </pre>
    */
   private FPropHashSet joins;


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @return   No description provided
    */
   public int sizeOfJoins()
   {
      return  ( (this.joins == null)
         ? 0
         : this.joins.size());
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param value  No description provided
    * @return       No description provided
    */
   public boolean removeFromJoins (DBViewJoin value)
   {
      boolean changed = false;
      if ( (this.joins != null) &&  (value != null))
      {
         changed = this.joins.remove (value);
         value.removeYou();
      }
      return changed;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void removeAllFromJoins()
   {
      DBViewJoin tmpValue;
      Iterator iter = this.iteratorOfJoins();
      while (iter.hasNext())
      {
         tmpValue = (DBViewJoin) iter.next();
         this.removeFromJoins (tmpValue);
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @return   No description provided
    */
   public Iterator iteratorOfJoins()
   {
      return  ( (this.joins == null)
         ? FEmptyIterator.get()
         : this.joins.iterator());
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param value  No description provided
    * @return       No description provided
    */
   public boolean hasInJoins (DBViewJoin value)
   {
      return  ( (this.joins != null) &&
          (value != null) &&
         this.joins.contains (value));
   }


   /**
    * Access method for an one to n association.
    *
    * @param value  The object added.
    * @return       No description provided
    */
   public boolean addToJoins (DBViewJoin value)
   {
      boolean changed = false;
      if (value != null)
      {
         value.setParent (this);
         if (this.joins == null)
         {
            this.joins = new FPropHashSet (this, "joins"); // or FTreeSet () or FLinkedList ()
         }
         changed = this.joins.add (value);
      }
      return changed;
   }


   /**
    * <pre>
    *             0..n   junctions   0..1
    * DBTableJunction ---------------------- DBView
    *             junctions         view
    * </pre>
    */
   private FPropHashSet junctions;


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @return   No description provided
    */
   public int sizeOfJunctions()
   {
      return  ( (this.junctions == null)
         ? 0
         : this.junctions.size());
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param value  No description provided
    * @return       No description provided
    */
   public boolean removeFromJunctions (DBTableJunction value)
   {
      boolean changed = false;
      if ( (this.junctions != null) &&  (value != null))
      {
         changed = this.junctions.remove (value);
      }
      return changed;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void removeAllFromJunctions()
   {
      DBTableJunction tmpValue;
      Iterator iter = this.iteratorOfJunctions();
      while (iter.hasNext())
      {
         tmpValue = (DBTableJunction) iter.next();
         this.removeFromJunctions (tmpValue);
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @return   No description provided
    */
   public Iterator iteratorOfJunctions()
   {
      return  ( (this.junctions == null)
         ? FEmptyIterator.get()
         : this.junctions.iterator());
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param value  No description provided
    * @return       No description provided
    */
   public boolean hasInJunctions (DBTableJunction value)
   {
      return  ( (this.junctions != null) &&
          (value != null) &&
         this.junctions.contains (value));
   }


   /**
    * Access method for an one to n association.
    *
    * @param value  The object added.
    * @return       No description provided
    */
   public boolean addToJunctions (DBTableJunction value)
   {
      boolean changed = false;
      if (value != null)
      {
         if (this.junctions == null)
         {
            this.junctions = new FPropHashSet (this, "junctions"); // or FTreeSet () or FLinkedList ()
         }
         changed = this.junctions.add (value);
         if (changed)
         {
            value.setTarget (this);
         }
      }
      return changed;
   }
}

/*
 * $Log: DBView.java,v $
 * Revision 1.5  2003/10/07 07:21:53  ariseppi
 * misc. corrections
 *
 */
