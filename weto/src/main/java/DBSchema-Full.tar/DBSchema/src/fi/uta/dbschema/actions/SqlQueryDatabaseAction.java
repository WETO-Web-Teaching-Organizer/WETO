/*
 * Created on 28.6.2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package fi.uta.dbschema.actions;

import java.awt.Dimension;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import de.uni_paderborn.fujaba.app.FrameMain;
import fi.uta.dbschema.gui.ResultTableDialog;
import fi.uta.dbschema.test.HsqldbController;

/**
 * @author as66033
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class SqlQueryDatabaseAction extends AbstractAction
{

	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed (ActionEvent event)
	{
		JTextArea area = new JTextArea ();
		JScrollPane pane = new JScrollPane (area);
//		JDialog dialog = new JDialog (FrameMain.get(), "Parse errors", false);
		Dimension dim = new Dimension (400, 200);
		pane.setPreferredSize (dim);
/*		dialog.getContentPane().setLayout (new BorderLayout());
		dialog.getContentPane().add (pane, BorderLayout.CENTER);
		dialog.pack();
		dialog.setVisible (true);
*/
	   int option = JOptionPane.showConfirmDialog (FrameMain.get(), pane, "SQL Query Test Database", JOptionPane.OK_CANCEL_OPTION);

	   if (option == JOptionPane.CANCEL_OPTION)
	   {
		  return;
	   }
	   Object[] result = null;
	   try {
		   result = HsqldbController.queryDatabaseEx(area.getText());
	   }
	   catch(Exception e) {
		   JOptionPane.showMessageDialog (FrameMain.get(), e.getMessage(), "SQL Error", JOptionPane.ERROR_MESSAGE);
	   }
	   
	   if(result != null) {
			ResultTableDialog tableDialog = new ResultTableDialog(FrameMain.get().getFrame(), (String[][])result[0], (String[])result[1], area.getText());
			tableDialog.showCentered();
	   }
	}
}
