/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'list
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */

package fi.uta.dbschema.metamodel.parse;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import de.uni_paderborn.fujaba.uml.UMLProject;
import fi.uta.dbschema.metamodel.DBForeignKey;
import fi.uta.dbschema.metamodel.DBJunctionPair;
import fi.uta.dbschema.metamodel.DBSchema;
import fi.uta.dbschema.metamodel.DBTable;
import fi.uta.dbschema.metamodel.DBTableAttribute;
import fi.uta.dbschema.metamodel.DBTableAttributeJunction;
import fi.uta.dbschema.metamodel.DBTableJunction;
import fi.uta.dbschema.metamodel.DBUnique;
import fi.uta.dbschema.metamodel.DBView;
import fi.uta.dbschema.metamodel.DBViewAttribute;
import fi.uta.dbschema.metamodel.DBViewJoin;

/**
 * Class parses a file given to it as a parameter and returns a String containing the parsing
 * errrors (the String is "" if there are no errors). A file can contain multiple tables and
 * views. If foreign keys or views refer to a table that hasn't yet been created, they are
 * stored in static HashMaps, the hash maps are checked after a new table is created and suitable
 * foreign keys and views are created.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:53 $
 * @version   $Revision: 1.6 $
 */
public class FileParser
{
	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	private static HashMap waitingKeys = new HashMap();

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	private static HashMap waitingViews = new HashMap();
	private static HashMap waitingViewTables = new HashMap();

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param fileName  No description provided
	 * @return          No description provided
	 */
	public static String parseFile(File f)
	{
		StringBuffer errors = new StringBuffer();
		DBSchema dbSchema = null;
		Object diagram = UMLProject.get().getCurrentDiagram();
		if (diagram instanceof DBSchema)
		{
			dbSchema = (DBSchema) diagram;
		} else
		{
			return "Current diagram is not a database schema diagram.";
		}
		HashMap tables = new HashMap();

		Iterator itemIter = dbSchema.iteratorOfItems();
		while (itemIter.hasNext())
		{
			Object obj = itemIter.next();
			if (obj instanceof DBTable)
			{
				DBTable tempTable = (DBTable) obj;
				tables.put(tempTable.getName(), tempTable);
			}
		}

		try
		{
			FileInputStream fis = new FileInputStream(f);
			InputStreamReader isr = new InputStreamReader(fis);
			BufferedReader br = new BufferedReader(isr);
			String line = br.readLine();
			StringBuffer fileBuffer = new StringBuffer();
			while (line != null)
			{
				fileBuffer.append(line + " ");
				line = br.readLine();
			}
			// file = "create table table_name(...);"
			String file = fileBuffer.toString();
			// group1: text before create table statement, group2: (attr1, attr2,..., primary key(...)[, unique(attr1, attr2)]...), group3: text after create table statement
			Pattern createPattern =
				Pattern.compile(
					"(.*)create table *([^;]*) *;(.*)",
					Pattern.CASE_INSENSITIVE);
			// group1: "primary key"|"unique"|"foreign key" group2: constraint [group3: referenced table name, group4:referenced attributes]
			Pattern constrPattern =
				Pattern.compile(
					"( *(primary +key|unique) *\\(([^\\)]*)\\)| *(foreign +key) *\\(([^\\)]*)\\) *references *([a-z_]*) *\\(([^\\)]*)\\)) *[,\\)](.*)",
					Pattern.CASE_INSENSITIVE);
			// group1: table_name, group2: type[, group3: "not null"]
			Pattern singleAttrPattern =
				Pattern.compile(
					"( *([a-z_0-9]*) +([a-z_0-9][a-z_\\(\\)0-9,]+) *(not +null)* *[,\\)]) *(.*)",
					Pattern.CASE_INSENSITIVE);
			Matcher mStart = createPattern.matcher(file);
			boolean stop = false;
			while (mStart.matches() && !stop)
			{
				if (mStart.groupCount() > 2)
				{
					// statement = "table_name(...)"
					String statement = mStart.group(2);
					int nameIndex = statement.indexOf('(');
					String tableName = statement.substring(0, nameIndex).trim();
					DBTable table = new DBTable(tableName);
					dbSchema.addToItems(table);
					tables.put(tableName, table);
					// statement = "attr_type [not null],...)"
					statement = statement.substring(nameIndex + 1);
					Matcher mConst = constrPattern.matcher(statement);
					HashMap attrHash = new HashMap();
					boolean attrFound = true;
					while (!mConst.matches()
						&& !statement.equals("")
						&& attrFound)
					{
						Matcher mAttrEnd = singleAttrPattern.matcher(statement);

						attrFound = mAttrEnd.matches();

						if (attrFound)
						{
							statement = mAttrEnd.group(mAttrEnd.groupCount());
							mConst = constrPattern.matcher(statement);

							String name = mAttrEnd.group(2);
							String type = mAttrEnd.group(3);
							type = type.toLowerCase();
							int typeNameInd = type.indexOf('(');
							int typeSizeInd = type.indexOf(')');
							String typeName = null;
							int typeSize = DBTableAttribute.NO_NUMBER;
							int typeScale = DBTableAttribute.NO_NUMBER;
							if (typeNameInd < 0
								|| typeSizeInd < typeNameInd + 1)
							{
								typeName = type;
							} else
							{
								typeName = type.substring(0, typeNameInd);
								String typeSizeAndScale =
									type.substring(
										typeNameInd + 1,
										typeSizeInd);
								int sizeToScale = typeSizeAndScale.indexOf(',');
								String typeSizeString = null;
								if (sizeToScale > 0)
								{
									typeSizeString =
										typeSizeAndScale.substring(
											0,
											sizeToScale);
								} else
								{
									typeSizeString = typeSizeAndScale;
								}
								try
								{
									typeSize = Integer.parseInt(typeSizeString);
								} catch (NumberFormatException e)
								{
									errors.append(
										"Error when parsing a create table statement.\n"
											+ "File: "
											+ f.getName()
											+ "\n"
											+ "Table: "
											+ tableName
											+ "\n"
											+ "Attribute: "
											+ mAttrEnd.group(1)
											+ "\n"
											+ "Reason: Type size "
											+ typeSizeString
											+ " is not an integer\n\n");
								}
								if (sizeToScale > 0)
								{
									String typeScaleString =
										typeSizeAndScale.substring(
											sizeToScale + 1);
									try
									{
										typeScale =
											Integer.parseInt(typeScaleString);
									} catch (NumberFormatException e)
									{
										errors.append(
											"Error when parsing a create table statement.\n"
												+ "File: "
												+ f.getName()
												+ "\n"
												+ "Table: "
												+ tableName
												+ "\n"
												+ "Attribute: "
												+ mAttrEnd.group(1)
												+ "\n"
												+ "Reason: Type scale "
												+ typeScaleString
												+ " is not an integer\n\n");
									}
								}
							}

							String firstLetter =
								typeName.substring(0, 1).toUpperCase();
							String tempType =
								firstLetter + typeName.substring(1);
							if (tempType.equals("Int"))
							{
								tempType = "Integer";
							}
							String javaType = "Sql" + tempType;

							boolean notNull = false;
							if (mAttrEnd.group(4) != null)
							{
								notNull = true;
							}
							DBTableAttribute attr = new DBTableAttribute(name);
							attr.setSqlType(typeName);
							attr.setSqlSize(typeSize);
							attr.setSqlScale(typeScale);
							attr.setJavaType(javaType);
							attr.setNotNullValue(notNull);
							attr.setParent(table);
							attrHash.put(name, attr);
						} else
						{
							int commaChar = statement.indexOf(',');
							int parenthesisChar = statement.indexOf(')');
							int endChar = -1;
							if (commaChar == -1)
							{
								endChar = parenthesisChar;
							} else if (parenthesisChar == -1)
							{
								endChar = commaChar;
							} else
							{
								endChar = Math.min(commaChar, parenthesisChar);
							}
							errors.append(
								"Error when parsing a create table statement.\n"
									+ "File: "
									+ f.getName()
									+ "\n"
									+ "Table: "
									+ tableName
									+ "\n"
									+ "Row: "
									+ new String(statement.substring(0, endChar))
									+ "\n"
									+ "Reason: Row should be an attribute, but it doesn't appear to be\n\n");
						}
					}

					// Check if not yet created foreign keys in previosly parsed files
					// refer to current table

					ArrayList list =
						(ArrayList) waitingKeys.remove(
							dbSchema.toString() + tableName);
					if (list != null)
					{
						for (int i = 0; i < list.size(); i++)
						{
							Object[] keyArray = (Object[]) list.get(i);
							DBTable origTable = (DBTable) keyArray[0];
							DBTable otherTable = table;
							String[] ownAttrs = (String[]) keyArray[1];
							String[] otherAttrs = (String[]) keyArray[2];
							String wholeClause = (String) keyArray[3];
							String origFileName = (String) keyArray[4];

							HashMap otherAttrHash = attrHash;
							HashMap ownAttrHash = new HashMap();

							Iterator iter3 = origTable.iteratorOfAttributes();
							while (iter3.hasNext())
							{
								DBTableAttribute tempAttr =
									(DBTableAttribute) iter3.next();
								ownAttrHash.put(tempAttr.getName(), tempAttr);
							}

							DBForeignKey key = new DBForeignKey();
							key.setOriginalTable(origTable);
							key.setRevTable(otherTable);
							dbSchema.addToItems(key);

							if (ownAttrs.length != otherAttrs.length)
							{
								errors.append(
									"Error when parsing a create table statement.\n"
										+ "File: "
										+ origFileName
										+ "\n"
										+ "Table: "
										+ origTable.getName()
										+ "\n"
										+ "Foreign key: "
										+ wholeClause
										+ "\n"
										+ "Reason: Different attribute counts\n\n");
							} else
							{
								for (int i2 = 0; i2 < ownAttrs.length; i2++)
								{
									DBTableAttribute ownAttr = null;
									String ownAttrName = ownAttrs[i2].trim();
									if (!ownAttrName.equals(""))
									{
										ownAttr =
											(DBTableAttribute) ownAttrHash.get(
												ownAttrName);
										if (ownAttr == null)
										{
											errors.append(
												"Error when parsing a create table statement.\n"
													+ "File: "
													+ origFileName
													+ "\n"
													+ "Table: "
													+ origTable.getName()
													+ "\n"
													+ "Foreign key: "
													+ wholeClause
													+ "\n"
													+ "Attribute name: "
													+ ownAttrName
													+ "\n"
													+ "Reason: Attribute not found\n\n");
										}
									}
									DBTableAttribute otherAttr = null;
									String otherAttrName = otherAttrs[i2].trim();
									if (!otherAttrName.equals(""))
									{
										otherAttr =
											(
												DBTableAttribute) otherAttrHash
													.get(
												otherAttrName);
										if (otherAttr == null)
										{
											errors.append(
												"Error when parsing a create table statement.\n"
													+ "File: "
													+ origFileName
													+ "\n"
													+ "Table: "
													+ origTable.getName()
													+ "\n"
													+ "Foreign key: "
													+ wholeClause
													+ "\n"
													+ "Attribute name: "
													+ otherAttrName
													+ "\n"
													+ "Reason: Attribute not found\n\n");
										}
									}
									if (ownAttr != null && otherAttr != null)
									{
										DBJunctionPair pair =
											new DBJunctionPair();
										DBTableAttributeJunction origJunc =
											new DBTableAttributeJunction(ownAttr);
										pair.setOriginalJunction(origJunc);
										DBTableAttributeJunction revJunc =
											new DBTableAttributeJunction(otherAttr);
										pair.setRevJunction(revJunc);
										key.addToJunctionPairs(pair);
									}
								}
							}
						}
					}

					// Check if not yet created views in previosly parsed files
					// refer to current table (and that no more tables are missing)

					ArrayList viewObjects =
						(ArrayList) waitingViewTables.remove(
							dbSchema.toString() + tableName);

					if (viewObjects != null)
					{
						for (int i = 0; i < viewObjects.size(); i++)
						{
							if (viewObjects.get(i) != null)
							{
								ArrayList missingTables =
									(ArrayList) waitingViews.get(
										viewObjects.get(i));
								if (missingTables.size() == 1)
								{
									waitingViews.remove(viewObjects.get(i));
									Object[] viewArray =
										(Object[]) viewObjects.get(i);
									int ind = 0;
									errors.append(
										createView(
											(String) viewArray[ind++],
											(String) viewArray[ind++],
											(String[]) viewArray[ind++],
											(String[]) viewArray[ind++],
											(String[]) viewArray[ind++],
											(DBSchema) viewArray[ind++],
											(String) viewArray[ind++],
											((Boolean) viewArray[ind++])
												.booleanValue(),
											tables));
								} else
								{
									for (int i2 = 0;
										i2 < missingTables.size();
										i2++)
									{
										if (missingTables
											.get(i2)
											.equals(tableName))
											missingTables.remove(i2);

									}
								}
							}
						}
					}

					while (mConst.matches())
					{
						// constType == primary key OR
						// constType == unique OR
						// constType == foreign key
						// (There might be multiple spaces between words "primary" and "key"
						// and "foreign" and "key".)
						String constType = mConst.group(2);
						if (constType == null)
						{
							constType = mConst.group(4);
						}
						if (constType.startsWith("primary"))
						{
							String constraint = mConst.group(3);
							String[] attrs = constraint.split(",");
							for (int i = 0; i < attrs.length; i++)
							{
								String attrName = attrs[i].trim();
								if (!attrName.equals(""))
								{
									DBTableAttribute attr =
										(DBTableAttribute) attrHash.get(
											attrName);
									if (attr == null)
									{
										errors.append(
											"Error when parsing a create table statement.\n"
												+ "File: "
												+ f.getName()
												+ "\n"
												+ "Table: "
												+ tableName
												+ "\n"
												+ "Primary key: "
												+ mConst.group(1)
												+ "\n"
												+ "Attribute name: "
												+ attrName
												+ "\n"
												+ "Reason: Attribute not found\n\n");
									} else
									{
										attr.setPrimaryKeyValue(true);
									}
								}
							}
						}
						if (constType.startsWith("unique"))
						{
							String constraint = mConst.group(3);
							String[] attrs = constraint.split(",");
							DBUnique uni = new DBUnique();
							uni.setParent(table);
							for (int i = 0; i < attrs.length; i++)
							{
								String attrName = attrs[i].trim();
								if (!attrName.equals(""))
								{
									DBTableAttribute attr =
										(DBTableAttribute) attrHash.get(
											attrName);
									if (attr == null)
									{
										errors.append(
											"Error when parsing a create table statement.\n"
												+ "File: "
												+ f.getName()
												+ "\n"
												+ "Table: "
												+ tableName
												+ "\n"
												+ "Unique: "
												+ mConst.group(1)
												+ "\n"
												+ "Attribute name: "
												+ attrName
												+ "\n"
												+ "Reason: Attribute not found\n\n");
									} else
									{
										uni.addToAttributes(attr);
									}
								}
							}
						}
						if (constType.startsWith("foreign"))
						{
							String ownAttrString = mConst.group(5);
							String[] ownAttrs = ownAttrString.split(",");
							String otherTableName = mConst.group(6);
							String otherAttrString = mConst.group(7);
							String[] otherAttrs = otherAttrString.split(",");

							DBTable otherTable =
								(DBTable) tables.get(otherTableName);
							HashMap otherAttrHash = new HashMap();
							if (otherTable != null)
							{
								Iterator iter3 =
									otherTable.iteratorOfAttributes();
								while (iter3.hasNext())
								{
									DBTableAttribute tempAttr =
										(DBTableAttribute) iter3.next();
									otherAttrHash.put(
										tempAttr.getName(),
										tempAttr);
								}
							}
							if (otherTable == null)
							{
								Object[] foreignClause = new Object[5];
								foreignClause[0] = table;
								foreignClause[1] = ownAttrs;
								foreignClause[2] = otherAttrs;
								foreignClause[3] = mConst.group(1);
								foreignClause[4] = f.getName();
								ArrayList keyList =
									(ArrayList) waitingKeys.get(
										dbSchema.toString() + otherTableName);
								if (keyList == null)
								{
									keyList = new ArrayList();
								}
								keyList.add(foreignClause);
								if(keyList.size() == 1) { 
								waitingKeys.put(
									dbSchema.toString() + otherTableName,
								keyList);
								}
							} else
							{
								DBForeignKey key = new DBForeignKey();
								key.setOriginalTable(table);
								key.setRevTable(otherTable);
								dbSchema.addToItems(key);
								if (ownAttrs.length != otherAttrs.length)
								{
									errors.append(
										"Error when parsing a create table statement.\n"
											+ "File: "
											+ f.getName()
											+ "\n"
											+ "Table: "
											+ tableName
											+ "\n"
											+ "Foreign key: "
											+ mConst.group(1)
											+ "\n"
											+ "Reason: Different attribute counts\n\n");
								} else
								{
									for (int i = 0; i < ownAttrs.length; i++)
									{
										DBTableAttribute ownAttr = null;
										String ownAttrName = ownAttrs[i].trim();
										if (!ownAttrName.equals(""))
										{
											ownAttr =
												(
													DBTableAttribute) attrHash
														.get(
													ownAttrName);
											if (ownAttr == null)
											{
												errors.append(
													"Error when parsing a create table statement.\n"
														+ "File: "
														+ f.getName()
														+ "\n"
														+ "Table: "
														+ tableName
														+ "\n"
														+ "Foreign key: "
														+ mConst.group(1)
														+ "\n"
														+ "Attribute name: "
														+ ownAttrName
														+ "\n"
														+ "Reason: Attribute not found\n\n");
											}
										}
										DBTableAttribute otherAttr = null;
										String otherAttrName =
											otherAttrs[i].trim();
										if (!otherAttrName.equals(""))
										{
											otherAttr =
												(
													DBTableAttribute) otherAttrHash
														.get(
													otherAttrName);
											if (otherAttr == null)
											{
												errors.append(
													"Error when parsing a create table statement.\n"
														+ "File: "
														+ f.getName()
														+ "\n"
														+ "Table: "
														+ tableName
														+ "\n"
														+ "Foreign key: "
														+ mConst.group(1)
														+ "\n"
														+ "Attribute name: "
														+ otherAttrName
														+ "\n"
														+ "Reason: Attribute not found\n\n");
											}
										}
										if (ownAttr != null
											&& otherAttr != null)
										{
											DBJunctionPair pair =
												new DBJunctionPair();
											key.addToJunctionPairs(pair);
											DBTableAttributeJunction origJunc =
												new DBTableAttributeJunction(ownAttr);
											origJunc.setPair(pair);
											pair.setOriginalJunction(origJunc);
											DBTableAttributeJunction revJunc =
												new DBTableAttributeJunction(otherAttr);
											revJunc.setPair(pair);
											pair.setRevJunction(revJunc);
										}
									}
								}
							}
						}
						statement = mConst.group(mConst.groupCount());
						mConst = constrPattern.matcher(statement);
					}
				}
				file = mStart.group(1) + mStart.group(3);
				mStart = createPattern.matcher(file);
			}

			// group1: text before create table statement, group2: view statement starting with the name, group3: view name, group3: text after create table statement
			Pattern createViewPattern =
				Pattern.compile(
					"(.*)create view *([^;]+;)(.*)",
					Pattern.CASE_INSENSITIVE);
			// group1: view name, group2: new attribute names or null, group3: original attribute names, group4: table names, group5: where condition or null
			Pattern viewPattern =
				Pattern.compile(
					"([^ \\(]+) *\\( *((?:[^ \\)]+(?:, *)?)*) *\\) +as +select +([^ ,]+(?:, *[^ ,]+)*) *from +([^ ]+(?: +[^ ]+)?(?:, *[^ ]+(?: +[^ ]+)?)*) *where *([^;]+)?;",
					Pattern.CASE_INSENSITIVE);

			mStart = createViewPattern.matcher(file);
			while (mStart.matches())
			{
				if (mStart.groupCount() > 2)
				{
					String statement = mStart.group(2);
					Matcher mView = viewPattern.matcher(statement);
					if (mView.matches())
					{
						String viewName = mView.group(1);
						String origAttrsString = mView.group(3);
						String[] origAttrs = null;
						boolean all = false;
						if (origAttrsString.equals("*"))
						{
							all = true;
						} else
						{
							origAttrs = origAttrsString.split(", *");
						}
						String curAttrsString = mView.group(2).trim();
						if (curAttrsString.equals(""))
						{
							curAttrsString = null;
						}

						String[] curAttrs = null;
						if (curAttrsString != null)
						{
							curAttrs = curAttrsString.split(", *");
						}

						String tablesString = mView.group(4);
						String[] viewTables = tablesString.split(", *");

						String where = mView.group(5);
						if (where == null)
						{
							where = "";
						} else
						{
							where =
								where.replaceFirst(" [wW][iI][tT][hH].*$", "");
						}
						/*                  Matcher errorMatcher = selectPattern.matcher(where);
						                  if (errorMatcher.find()) {
						                  	where = "";
											errors.append("Error when parsing a create view statement.\n" +
											   "File: " + f.getName() + "\n" +
											   "View: " + viewName + "\n" +
											   "Reason: Subqueries not supported.\n\n");
						                  }*/
						ArrayList missingTables = new ArrayList();
						for (int i = 0; i < viewTables.length; i++)
						{
							if (tables.get(viewTables[i]) == null)
							{
								missingTables.add(viewTables[i]);
							}
						}
						if (missingTables.size() == 0)
						{
							errors.append(
								createView(
									viewName,
									where,
									viewTables,
									origAttrs,
									curAttrs,
									dbSchema,
									f.getName(),
									all,
									tables));
						} else
						{
							Object[] view = new Object[8];
							int ind = 0;
							view[ind++] = viewName;
							view[ind++] = where;
							view[ind++] = viewTables;
							view[ind++] = origAttrs;
							view[ind++] = curAttrs;
							view[ind++] = dbSchema;
							view[ind++] = f.getName();
							view[ind] = new Boolean(all);
							for (int i = 0; i < missingTables.size(); i++)
							{
								ArrayList viewList =
									(ArrayList) waitingViewTables.get(
										dbSchema.toString()
											+ missingTables.get(i).toString());
								if (viewList == null)
								{
									viewList = new ArrayList();
								}
								viewList.add(view);

								if (viewList.size() == 1)
								{
									waitingViewTables.put(
										dbSchema.toString()
											+ missingTables.get(i).toString(),
										viewList);
								}
							}
							waitingViews.put(view, missingTables);
						}
					}
				}
				file = mStart.group(1) + mStart.group(3);
				mStart = createPattern.matcher(file);
			}
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		return errors.toString();
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param viewName    No description provided
	 * @param where       No description provided
	 * @param viewTables  No description provided
	 * @param origAttrs   No description provided
	 * @param curAttrs    No description provided
	 * @param dbSchema    No description provided
	 * @param fileName    No description provided
	 * @param all         No description provided
	 * @param tables      No description provided
	 * @return            No description provided
	 */
	private static String createView(
		String viewName,
		String where,
		String[] viewTables,
		String[] origAttrs,
		String[] curAttrs,
		DBSchema dbSchema,
		String fileName,
		boolean all,
		HashMap tables)
	{
		StringBuffer errors = new StringBuffer();
		DBView view = new DBView();
		view.setName(viewName);
		view.setWhereClause(where);
		dbSchema.addToItems(view);
		if (all)
		{
			for (int i = 0; i < viewTables.length; i++)
			{
				DBTable table = (DBTable) tables.get(viewTables[i]);

				if (!view.hasInTables(table))
				{
					DBViewJoin newJoin = new DBViewJoin();

					DBTableJunction firstJunc = new DBTableJunction(view);
					DBTableJunction secondJunc = new DBTableJunction(table);

					secondJunc.setAdornment(DBTableJunction.FILLED_BOX);

					newJoin.setFirstJunction(firstJunc);
					newJoin.setSecondJunction(secondJunc);

					view.addToJoins(newJoin);

					dbSchema.addToItems(newJoin);
				}
				Iterator attrIter = table.iteratorOfAttributes();
				while (attrIter.hasNext())
				{
					DBTableAttribute tableAttr =
						(DBTableAttribute) attrIter.next();
					DBViewAttribute attr = new DBViewAttribute();
					attr.setAttribute(tableAttr);
					attr.setName(tableAttr.getName());
					attr.setParent(view);
				}
			}
		} else
		{
			HashMap origAttrHash = new HashMap();
			for (int i = 0; i < viewTables.length; i++)
			{
				DBTable table = (DBTable) tables.get(viewTables[i]);

				if (!view.hasInTables(table))
				{
					DBViewJoin newJoin = new DBViewJoin();

					DBTableJunction firstJunc = new DBTableJunction(view);
					DBTableJunction secondJunc = new DBTableJunction(table);

					secondJunc.setAdornment(DBTableJunction.FILLED_BOX);

					newJoin.setFirstJunction(firstJunc);
					newJoin.setSecondJunction(secondJunc);

					view.addToJoins(newJoin);

					dbSchema.addToItems(newJoin);
				}
				Iterator attrIter = table.iteratorOfAttributes();
				while (attrIter.hasNext())
				{
					DBTableAttribute attr = (DBTableAttribute) attrIter.next();
					origAttrHash.put(
						table.getName() + "." + attr.getName(),
						attr);
					Object oldAttr = origAttrHash.get(attr.getName());
					if (oldAttr == null)
					{
						origAttrHash.put(attr.getName(), attr);
					} else
					{
						ArrayList list = null;
						if (oldAttr instanceof DBTableAttribute)
						{
							list = new ArrayList();
							list.add(
								((DBTableAttribute) oldAttr)
									.getParent()
									.getName());
						} else
						{
							list = (ArrayList) oldAttr;
						}
						list.add(attr.getParent().getName());
					}
				}
			}
			boolean differentNames = true;
			if (curAttrs == null || origAttrs.length != curAttrs.length)
			{
				differentNames = false;
			}
			if (curAttrs != null && origAttrs.length != curAttrs.length)
			{
				errors.append(
					"Error when parsing a create view statement.\n"
						+ "File: "
						+ fileName
						+ "\n"
						+ "View: "
						+ viewName
						+ "\n"
						+ "Reason: Amount of views attribute names, differs from amount of attributes.");
			}
			for (int i = 0; i < origAttrs.length; i++)
			{
				Object obj = origAttrHash.get(origAttrs[i]);
				if (obj instanceof ArrayList)
				{
					errors.append(
						"Error when parsing a create view statement.\n"
							+ "File: "
							+ fileName
							+ "\n"
							+ "View: "
							+ viewName
							+ "\n"
							+ "Attribute: "
							+ origAttrs[i]
							+ "\n"
							+ "Reason: Attribute name ambiguous, can refer to table ");
					ArrayList list = (ArrayList) obj;
					for (int i2 = 0; i2 < list.size(); i2++)
					{
						if (i2 < list.size() - 2)
						{
							errors.append(list.get(i2) + ", ");
						}
						if (i2 == list.size() - 2)
						{
							errors.append(list.get(i2) + " or ");
						}
						if (i2 == list.size() - 1)
						{
							errors.append(list.get(i2));
						}
					}
					errors.append("\n\n");
				} else if (obj == null)
				{
					errors.append(
						"Error when parsing a create view statement.\n"
							+ "File: "
							+ fileName
							+ "\n"
							+ "View: "
							+ viewName
							+ "\n"
							+ "Attribute: "
							+ origAttrs[i]
							+ "\n"
							+ "Reason: Attribute not found from ");
					int index = origAttrs[i].indexOf('.');
					if (index > -1)
					{
						errors.append("any of the tables.\n\n");
					} else
					{
						errors.append(
							"table "
								+ origAttrs[i].substring(index + 1)
								+ ".\n\n");
					}
				} else
				{
					DBTableAttribute tableAttr = (DBTableAttribute) obj;
					DBViewAttribute attr = new DBViewAttribute();
					attr.setAttribute(tableAttr);
					if (differentNames)
					{
						attr.setName(curAttrs[i]);
					} else
					{
						attr.setName(tableAttr.getName());
					}
					attr.setParent(view);
				}
			}
		}
		return errors.toString();
	}
}

/*
 * $Log: FileParser.java,v $
 * Revision 1.6  2003/10/07 07:21:53  ariseppi
 * misc. corrections
 *
 */
