/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.cs.dbswtool;



/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:48 $
 * @version   $Revision: 1.2 $
 */
public class Attribute
{
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private String name;
   
   private String description = "";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private String role;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private String sqlType;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private String javaType;
   
   private Boolean stringType;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private Integer javaTypeLength; // char-length, varchar-maxlength, real-precision
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private Integer javaTypeScale; // real-scale
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private Boolean notNull;


   /**
    * Constructor for class Attribute
    *
    * @param name      No description provided
    * @param sqlType   No description provided
    * @param javaType  No description provided
    */
   public Attribute (String name, String sqlType, String javaType, Boolean stringType)
   {
      this.name = name;
      this.role = "";
      this.sqlType = sqlType;
      this.javaType = javaType;
      this.stringType = stringType;
      this.notNull = new Boolean (false);
      this.javaTypeLength = new Integer (0);
      this.javaTypeScale = new Integer (0);
   }


   /**
    * Sets the name attribute of the Attribute object
    *
    * @param name  The new name value
    */
   public void setName (String name)
   {
	this.name = name;
   }
   
   public void setDescription (String description)
   {
	this.description = description;
   }


   /**
    * Sets the role attribute of the Attribute object
    *
    * @param role  The new role value
    */
   public void setRole (String role)
   {
   	  String newRole = role.replaceAll(" ", "");
      this.role = newRole;
   }


   /**
    * Sets the sQLType attribute of the Attribute object
    *
    * @param sqlType  The new sQLType value
    */
   public void setSQLType (String sqlType)
   {
      this.sqlType = sqlType;
   }


   /**
    * Sets the javaType attribute of the Attribute object
    *
    * @param javaType  The new javaType value
    */
   public void setJavaType (String javaType)
   {
      this.javaType = javaType;
   }


   /**
    * Sets the javaTypeLength attribute of the Attribute object
    *
    * @param javaTypeLength  The new javaTypeLength value
    */
   public void setJavaTypeLength (Integer javaTypeLength)
   {
      this.javaTypeLength = javaTypeLength;
   }


   /**
    * Sets the javaTypeScale attribute of the Attribute object
    *
    * @param javaTypeScale  The new javaTypeScale value
    */
   public void setJavaTypeScale (Integer javaTypeScale)
   {
      this.javaTypeScale = javaTypeScale;
   }


   /**
    * Sets the notNull attribute of the Attribute object
    *
    * @param notNull  The new notNull value
    */
   public void setNotNull (Boolean notNull)
   {
      this.notNull = notNull;
   }


   /**
    * Get the name attribute of the Attribute object
    *
    * @return   The name value
    */
   public String getName()
   {
      return name;
   }
   
   public String getDescription()
   {
	  return description;
   }


   /**
    * Get the role attribute of the Attribute object
    *
    * @return   The role value
    */
   public String getRole()
   {
      return role;
   }


   /**
    * Get the sQLType attribute of the Attribute object
    *
    * @return   The sQLType value
    */
   public String getSQLType()
   {
      return sqlType;
   }


   /**
    * Get the javaType attribute of the Attribute object
    *
    * @return   The javaType value
    */
   public String getJavaType()
   {
      return javaType;
   }


   /**
    * Get the javaTypeLength attribute of the Attribute object
    *
    * @return   The javaTypeLength value
    */
   public Integer getJavaTypeLength()
   {
      return javaTypeLength;
   }


   /**
    * Get the javaTypeScale attribute of the Attribute object
    *
    * @return   The javaTypeScale value
    */
   public Integer getJavaTypeScale()
   {
      return javaTypeScale;
   }


   /**
    * Get the notNull attribute of the Attribute object
    *
    * @return   The notNull value
    */
   public Boolean getNotNull()
   {
      return notNull;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void output()
   {
      System.out.println ("Attribute, name " + name + " role " + role +
         " sqlType " + sqlType + " javaType " + javaType);
      System.out.println ("   javaTypeLength " + javaTypeLength +
         "javaTypeScale " + javaTypeScale);
      System.out.println ("   javaTypeScale " + javaTypeScale +
         " notNull " + notNull.toString());
	System.out.println ("   description: " + description);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void shortOutput()
   {
      System.out.println ("Attribute, name " + name +
         " sqlType " + sqlType + " javaType " + javaType);
   }

/**
 * @return
 */
public Boolean getStringType()
{
	return this.stringType;
}

/**
 * @param boolean1
 */
public void setStringType(Boolean stringType)
{
	this.stringType = stringType;
}

	public String getJdbcType()
	{
		if ( getJavaType().equals("SqlInteger"))
		{
			return "Integer";
		} else if (getJavaType().equals("SqlBoolean"))
		{
			return "Integer";
		} else if (getJavaType().equals("SqlDate"))
		{
			return "java.sql.Date";
		} else if (getJavaType().equals("SqlTime"))
		{
			return "java.sql.Time";
		} else if (getJavaType().equals("SqlDecimal"))
		{
			return "java.math.BigDecimal";
		} else if (getJavaType().equals("SqlReal"))
		{
			return "Float";
		}
		return "String";
	}
	
	public String getBeanType()
	{
		if ( getJavaType().equals("SqlInteger"))
		{
			return "Integer";
		} else if (getJavaType().equals("SqlBoolean"))
		{
			return "Boolean";
		} else if (getJavaType().equals("SqlDate"))
		{
			return "java.util.Date";
		} else if (getJavaType().equals("SqlTime"))
		{
			return "java.util.Date";
		} else if (getJavaType().equals("SqlDecimal"))
		{
			return "java.math.BigDecimal";
		} else if (getJavaType().equals("SqlReal"))
		{
			return "Float";
		}
		return "String";
	}

}

/*
 * $Log: Attribute.java,v $
 * Revision 1.2  2003/10/07 07:21:48  ariseppi
 * misc. corrections
 *
 */
