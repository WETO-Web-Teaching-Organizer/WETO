/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this added code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.gui;

import java.awt.Cursor;
import java.awt.event.ActionEvent;

import javax.swing.JFrame;

import de.uni_paderborn.fujaba.asg.ASGDiagram;
import de.uni_paderborn.fujaba.asg.ASGElement;
import de.uni_paderborn.fujaba.gui.CMAFocusListener;
import de.uni_paderborn.fujaba.gui.PEColumn;
import de.uni_paderborn.fujaba.gui.PEEditPanel;
import de.uni_paderborn.fujaba.gui.PETextField;
import de.uni_paderborn.fujaba.uml.UMLProject;
import fi.uta.dbschema.metamodel.DBSchema;
import fi.uta.dbschema.metamodel.DBTable;
import fi.uta.dbschema.metamodel.DBTableAttribute;


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.2 $
 */
public class PEDBTable extends DBPropertyEditor
{
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PETextField tableName;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PETextField packageName;
   
   PEDBCheck strength;
   
   PETextArea description;


   /**
    * Constructor for class PEDBTable
    *
    * @param frame  No description provided
    * @param title  No description provided
    * @param modal  No description provided
    */
   public PEDBTable (JFrame frame, String title, boolean modal)
   {
      super (frame);
      setModal (modal);
      setTitle (title);
      try
      {
         pack();
         this.setTitle ("Table Editor");
      }
      catch (Exception e)
      {
         e.printStackTrace();
      }
      initPE();

      addFocusListener (new CMAFocusListener (tableName));

   }


   /**
    * Constructor for class PEDBTable
    *
    * @param frame  No description provided
    */
   public PEDBTable (JFrame frame)
   {
      this (frame, "", false);
   }


   /**
    * Constructor for class PEDBTable
    *
    * @param frame  No description provided
    * @param modal  No description provided
    */
   public PEDBTable (JFrame frame, boolean modal)
   {
      this (frame, "", modal);
   }


   /**
    * Constructor for class PEDBTable
    *
    * @param frame  No description provided
    * @param title  No description provided
    */
   public PEDBTable (JFrame frame, String title)
   {
      this (frame, title, false);
   }


   /**
    * Sets the attributeName attribute of the PEDBTable object
    *
    * @param name  The new tableName value
    */
   public void setTableName (String name)
   {
      tableName.setText (name);
   }

   public void setDescription (String desc)
   {
	  description.setText (desc);
   }

   /**
    * Sets the packageName attribute of the PEDBTable object
    *
    * @param name  The new packageName value
    */
   public void setPackageName (String name)
   {
      packageName.setText (name);
   }


   /**
	* Sets the packageName attribute of the PEDBTable object
	*
	* @param name  The new packageName value
	*/
   public void setStrength (boolean checked)
   {
	  strength.setSelected(checked);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param panel  No description provided
    */
   protected void additionalProperties (PEEditPanel panel)
   {
      tableName = new PETextField (this, "Table Name");
      packageName = new PETextField (this, "Package Name");

      tableName.setStatus ("Enter the name of the table");
      packageName.setStatus ("Enter the name of the package");
      
	  strength = new PEDBCheck(this, null, "Strong Entity");
	  
	  description = new PETextArea (this, "Description");
	  
	  description.setStatus ("Enter the description for the table");

      PEColumn column = new PEColumn (this);

      column.add (tableName);
      column.add (packageName);
	  column.add (strength);
	  column.add (description);

      panel.add (column);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void unparse()
   {
      if (getIncrement() instanceof DBTable)
      {
         DBTable selectedTable = (DBTable) getIncrement();
         tableName.setText (selectedTable.getName());
         packageName.setText (selectedTable.getJavaPackage());
		 strength.setSelected(selectedTable.getStrength());
		 description.setText (selectedTable.getDescription());
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected void parse()
   {
      ASGElement incr = getIncrement();

      if (incr instanceof DBTable)
      {
         DBTable table = (DBTable) incr;
         table.setName (getTableName());
         table.setJavaPackage (getPackageName());
         table.setStrength(getStrength());
         table.setDescription(getDescription());
         ASGDiagram diagram = UMLProject.get().getCurrentDiagram();
         if (diagram instanceof DBSchema)
         {
            DBSchema dbSchema = (DBSchema) diagram;
            if (!dbSchema.hasInItems (table))
            {
               dbSchema.addToItems (table);
            }
         }
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected void cancel()
   {
      setVisible (false);
      dispose();
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void buttonOK_actionPerformed (ActionEvent e)
   {
//      super.buttonOK_actionPerformed (e);
      if (getFrame() != null)
      {
         getFrame().setCursor (Cursor.getPredefinedCursor (Cursor.WAIT_CURSOR));
      } // if

      try
      {
         setVisible (false);
         parse();
         UMLProject.get().refreshDisplay();
      }
      finally
      {
         if (getFrame() != null)
         {
            getFrame().setCursor (Cursor.getPredefinedCursor (Cursor.DEFAULT_CURSOR));
         }
      }
   }


   /**
    * Sets the increment attribute of the PEDBTable object
    *
    * @param incr  The new increment value
    */
   public void setIncrement (ASGElement incr)
   {
      if (incr instanceof DBTableAttribute)
      {
         super.setIncrement ( ((DBTableAttribute) incr).getParent());
      }
      else
      {
         super.setIncrement (incr);
      }
      if (getTableIncrement() != null)
      {
         setTitle ("Table Editor: " + getTableIncrement().getName());
      }
   }


   /**
    * Get the tableName attribute of the PEDBTable object
    *
    * @return   The tableName value
    */
   public String getTableName()
   {
      return tableName.getText();
   }


   /**
    * Get the packageName attribute of the PEDBTable object
    *
    * @return   The tableName value
    */
   public String getPackageName()
   {
      return packageName.getText();
   }
   

   public String getDescription()
   {
	  return description.getText();
   }


   /**
	* Get the packageName attribute of the PEDBTable object
	*
	* @return   The tableName value
	*/
   public boolean getStrength()
   {
	  return strength.isSelected();
   }
}

/*
 * $Log: PEDBTable.java,v $
 * Revision 1.2  2003/10/07 07:21:52  ariseppi
 * misc. corrections
 *
 */
