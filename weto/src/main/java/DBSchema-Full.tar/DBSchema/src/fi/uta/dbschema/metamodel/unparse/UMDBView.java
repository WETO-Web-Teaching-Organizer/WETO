/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.metamodel.unparse;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;
import java.util.Set;

import javax.swing.JComponent;

import de.uni_paderborn.fujaba.fsa.FSACollapsable;
import de.uni_paderborn.fujaba.fsa.FSAObject;
import de.uni_paderborn.fujaba.fsa.FSAPanel;
import de.uni_paderborn.fujaba.fsa.FSASeparatedPanel;
import de.uni_paderborn.fujaba.fsa.FSATextFieldLabel;
import de.uni_paderborn.fujaba.fsa.listener.ArrowMoveListener;
import de.uni_paderborn.fujaba.fsa.listener.AscendDescendMouseHandler;
import de.uni_paderborn.fujaba.fsa.listener.BorderHighlighter;
import de.uni_paderborn.fujaba.fsa.listener.ComponentBorderListener;
import de.uni_paderborn.fujaba.fsa.listener.ComponentCursorListener;
import de.uni_paderborn.fujaba.fsa.listener.DragMouseListener;
import de.uni_paderborn.fujaba.fsa.listener.SelectionListenerHelper;
import de.uni_paderborn.fujaba.fsa.listener.SelectionMouseListener;
import de.uni_paderborn.fujaba.fsa.swing.ColumnRowLayout;
import de.uni_paderborn.fujaba.fsa.swing.border.AbstractColorBorder;
import de.uni_paderborn.fujaba.fsa.unparse.AbstractUnparseModule;
import de.uni_paderborn.fujaba.fsa.unparse.LogicUnparseInterface;
import de.uni_paderborn.fujaba.fsa.update.AbstractUpdater;
import fi.uta.dbschema.fsa.update.NodeCompartmentVisibilityUpdater;
import fi.uta.dbschema.metamodel.DBView;

/**
 * Similar to fi.uta.dbschema.metamodel.unparse.UMDBTable , but draws a dashed square as the
 * outline.
 *
 * @author
 * @created   $Date: 2003/10/07 07:21:54 $
 * @version   $Revision: 1.4 $
 */
public class UMDBView extends AbstractUnparseModule
{

	/**
	 * Get the childProperties attribute of the UMDBView object
	 *
	 * @param props  No description provided
	 */
	public void getChildProperties(Set props)
	{
		super.getChildProperties(props);

		// the properties which trigger unparsing of child items
		// in the metamodel hierarchy
		// in diagrams this is usually the items-association
		props.add("attributes");
	}

	/**
	 * @param parent  No description provided
	 * @param incr    No description provided
	 * @return        No description provided
	 * @see           de.uni_paderborn.fujaba.fsa.unparse.UnparseInterface#create(de.uni_paderborn.fujaba.fsa.FSAObject,
	 *      de.uni_paderborn.fujaba.fsa.unparse.LogicUnparseInterface)
	 */
	public FSAObject create(FSAObject parent, LogicUnparseInterface incr)
	{
		DBView dbTable = (DBView) incr;

		// the main component for the class
		FSASeparatedPanel panel =
			new FSASeparatedPanel(
				incr,
				getMainFsaName(),
				parent.getJComponent());
		panel.setBorder(new DashedBorder(Color.BLACK));

		JComponent jPanel = panel.getJComponent();
		jPanel.addKeyListener(ArrowMoveListener.get());
		AscendDescendMouseHandler.addMouseInputListener(
			jPanel,
			ComponentCursorListener.get());
		AscendDescendMouseHandler.addMouseInputListener(
			jPanel,
			ComponentBorderListener.get());
		AscendDescendMouseHandler.addMouseInputListener(
			jPanel,
			SelectionMouseListener.get());
		AscendDescendMouseHandler.addMouseInputListener(
			jPanel,
			DragMouseListener.get());
		SelectionListenerHelper.addSelectionListener(
			jPanel,
			BorderHighlighter.get());
		SelectionListenerHelper.addSelectionListener(
			jPanel,
			ArrowMoveListener.get());

		// -------------------------
		// the name field.
		// -------------------------
		FSAPanel namePanel =
			new FSAPanel(incr, "viewNamePanel", panel.getJComponent());
		namePanel.setLayout(new ColumnRowLayout(0, ColumnRowLayout.COLUMN));

		FSATextFieldLabel viewNameLabel =
			new FSATextFieldLabel(incr, "name", namePanel.getJComponent());

		// default updater handles text changes
		AbstractUpdater updater = viewNameLabel.createDefaultUpdater();
		viewNameLabel.addToUpdater(updater);

		panel.addSeparator();

		// The attributes panel.
		// add the panel to the collapsable components.
		FSACollapsable tmpCollapsable;
		tmpCollapsable =
			new FSACollapsable(incr, "attributesPanel", panel.getJComponent());
		updater = new NodeCompartmentVisibilityUpdater(incr, "attributes");
		tmpCollapsable.addToUpdater(updater);

		return panel;
	}

	/**
	 * Get the containerForProperty attribute of the UMDBView object
	 *
	 * @param property  No description provided
	 * @return          The containerForProperty value
	 */
	public String getContainerForProperty(String property)
	{
		// get unparse target for elements of a property
		if ("attributes".equals(property))
		{
			return "attributesPanel";
		}

		return super.getContainerForProperty(property);
	}

	/**
	 * No comment provided by developer, please add a comment to improve documentation.
	 *
	 * @author    $Author: ariseppi $
	 * @created   $Date: 2003/10/07 07:21:54 $
	 * @version   $Revision: 1.4 $
	 */
	class DashedBorder extends AbstractColorBorder
	{
		/**
		 * No comment provided by developer, please add a comment to ensure improve documentation.
		 */
		int dashLength = 5;

		/**
		 * No comment provided by developer, please add a comment to ensure improve documentation.
		 */
		int thickness = 1;

		/**
		 * Constructor for class DashedBorder
		 *
		 * @param c  No description provided
		 */
		public DashedBorder(Color c)
		{
			super(c);
		}

		/**
		 * No comment provided by developer, please add a comment to ensure improve documentation.
		 *
		 * @param c       No description provided
		 * @param g       No description provided
		 * @param x       No description provided
		 * @param y       No description provided
		 * @param width   No description provided
		 * @param height  No description provided
		 */
		public void paintBorder(
			Component c,
			Graphics g,
			int x,
			int y,
			int width,
			int height)
		{
			Color oldColor = g.getColor();

			g.setColor(getBorderColor());

			for (int i = 0; i * dashLength <= width - 1; i += 2)
			{
				int start = x + dashLength * i;
				g.drawLine(start, y, start + dashLength, y);
				g.drawLine(
					start,
					y + height - 1,
					start + dashLength,
					y + height - 1);
			}
			for (int i = 0; i * dashLength <= height; i += 2)
			{
				int start = y + dashLength * i;
				g.drawLine(x, start, x, start + dashLength);
				g.drawLine(
					x + width - 1,
					start,
					x + width - 1,
					start + dashLength);
			}
			g.setColor(oldColor);
		}

		/**
		 * Returns the insets of the border.
		 *
		 * @param c  the component for which this border insets value applies
		 * @return   The borderInsets value
		 */
		public Insets getBorderInsets(Component c)
		{
			return new Insets(thickness, thickness, thickness, thickness);
		}

		/**
		 * Reinitialize the insets parameter with this Border's current Insets.
		 *
		 * @param c       the component for which this border insets value applies
		 * @param insets  the object to be reinitialized
		 * @return        The borderInsets value
		 */
		public Insets getBorderInsets(Component c, Insets insets)
		{
			insets.left = insets.top = insets.right = insets.bottom = thickness;
			return insets;
		}

		/**
		 * Returns the thickness of the border.
		 *
		 * @return   The thickness value
		 */
		public int getThickness()
		{
			return thickness;
		}

		/**
		 * Sets the thickness of the border.
		 *
		 * @param thickness  The new thickness value
		 */
		public void setThickness(int thickness)
		{
			this.thickness = thickness;
		}

		/**
		 * Returns whether or not the border is opaque.
		 *
		 * @return   The borderOpaque value
		 */
		public boolean isBorderOpaque()
		{
			return false;
		}
	}
}

/*
 * $Log: UMDBView.java,v $
 * Revision 1.4  2003/10/07 07:21:54  ariseppi
 * misc. corrections
 *
 */
