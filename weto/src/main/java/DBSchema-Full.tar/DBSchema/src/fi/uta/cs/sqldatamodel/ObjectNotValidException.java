/*
 * Created on Oct 4, 2004
 */
package fi.uta.cs.sqldatamodel;

/**
 * Exception indicating that the object is not in valid state.
 */
public class ObjectNotValidException extends SqlDataException {

	private static final long serialVersionUID = -3949103872098962240L;

	public ObjectNotValidException() {
		super();
	}

	public ObjectNotValidException(String message) {
		super(message);
	}
}

// End of file.
