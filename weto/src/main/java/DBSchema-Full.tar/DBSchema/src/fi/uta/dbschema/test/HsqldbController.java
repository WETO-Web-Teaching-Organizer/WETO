/*
 * Created on 24.6.2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package fi.uta.dbschema.test;

import java.io.File;
import java.net.URL;
import java.net.URLClassLoader;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Properties;

import fi.uta.cs.dbswtool.RelAndQueryConstants;
import fi.uta.cs.dbswtool.RelationVector;
import fi.uta.cs.dbswtool.ViewVector;

/**
 * @author as66033
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class HsqldbController
{
	private static Connection conn = null;

	private static void connectToDatabase()
	{
		if (conn != null)
		{
			return;
		}
		try
		{
			File f = new File(".");
			URL u =
				new URL(
					"jar:file:"
						+ f.getCanonicalPath()
						+ File.separatorChar
						+ "plugins"
						+ File.separatorChar
						+ "DBSchema"
						+ File.separatorChar
						+ "hsqldb.jar!/");
			String classname = "org.hsqldb.jdbcDriver";
			URLClassLoader ucl = new URLClassLoader(new URL[] { u });
			Driver d =
				(Driver) Class.forName(classname, true, ucl).newInstance();
			Properties p = new Properties();
			p.put("user", "sa");
			p.put("password", "");

			conn = d.connect("jdbc:hsqldb:testi", p);

			/*			Class.forName("org.hsqldb.jdbcDriver");
			
						conn = DriverManager.getConnection("jdbc:hsqldb:"
														   + "testi",   // filenames
														   "sa",                    // username
														   "");
														   */
		} catch (Exception e)
		{
			e.printStackTrace();
		}

	}

	public static void deleteDatabase()
	{
		try
		{
			if (conn != null)
			{
				Statement stmt = conn.createStatement();
				stmt.executeQuery("SHUTDOWN");
				stmt.close();
				conn.close();
				conn = null;
			}
			File removeFile = new File("." + File.separatorChar + "testi.log");
			removeFile.delete();
			removeFile = new File("." + File.separatorChar + "testi.script");
			removeFile.delete();
			removeFile =
				new File("." + File.separatorChar + "testi.properties");
			removeFile.delete();
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	public static void createDatabase(
		RelationVector relVector,
		ViewVector viewVector)
	{
		deleteDatabase();
		connectToDatabase();
		String query = null;
		try
		{
			conn.setAutoCommit(true);
			ArrayList creates = new ArrayList();
			ArrayList updates = new ArrayList();
			for (int i = 0; i < relVector.size(); i++)
			{
				String[] sqlStrings = relVector.getSQLStrings(i, RelAndQueryConstants.hsqldb);
				creates.add(sqlStrings[1]);
				for (int i2 = 2; i2 < sqlStrings.length; i2++)
				{
					updates.add(sqlStrings[i2]);
				}
			}
			for (int i = 0; i < viewVector.size(); i++)
			{
				String[] sqlStrings = viewVector.getSQLStrings(i);
				creates.add(sqlStrings[1]);
			}
			for (int i = 0; i < creates.size(); i++)
			{
				Statement stmt = conn.createStatement();
				query = creates.get(i).toString();
				stmt.executeQuery(query);
				stmt.close();
			}
			for (int i = 0; i < updates.size(); i++)
			{
				Statement stmt = conn.createStatement();
				query = updates.get(i).toString();
				stmt.executeUpdate(query);
				stmt.close();
			}
		} catch (Exception e)
		{
			e.printStackTrace();
			System.out.println("Statement: " + query);
		}
	}

	public static String[][] queryDatabase(String query)
	{
		connectToDatabase();
		String[][] result = null;
		try
		{
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			ArrayList results = new ArrayList();
			int columns = rsmd.getColumnCount();
			while (rs.next())
			{
				String[] row = new String[columns];
				for (int i = 1; i <= columns; i++)
				{
					row[i - 1] = rs.getString(i);
				}
				results.add(row);
			}
			result = new String[results.size()][columns];
			for (int i = 0; i < results.size(); i++)
			{
				result[i] = (String[]) results.get(i);
			}
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		return result;
	}

	public static Object[] queryDatabaseEx(String query) throws Exception
	{
		connectToDatabase();
		String[][] result = null;
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		ResultSetMetaData rsmd = rs.getMetaData();
		ArrayList results = new ArrayList();
		int columns = rsmd.getColumnCount();
		String[] headers = new String[rsmd.getColumnCount()];
		for (int i = 1; i <= rsmd.getColumnCount(); i++)
		{
			headers[i - 1] = rsmd.getColumnName(i);
		}
		while (rs.next())
		{
			String[] row = new String[columns];
			for (int i = 1; i <= columns; i++)
			{
				row[i - 1] = rs.getString(i);
			}
			results.add(row);
		}
		result = new String[results.size()][columns];
		for (int i = 0; i < results.size(); i++)
		{
			result[i] = (String[]) results.get(i);
		}
		Object[] resultAndHeader = new Object[2];
		resultAndHeader[0] = result;
		resultAndHeader[1] = headers;

		return resultAndHeader;
	}
}