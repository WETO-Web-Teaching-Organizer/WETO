/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.actions;

import java.awt.event.ActionEvent;
import java.util.Iterator;

import javax.swing.AbstractAction;

import de.uni_paderborn.fujaba.app.FrameMain;
import de.uni_paderborn.fujaba.asg.ASGElement;
import de.uni_paderborn.fujaba.uml.UMLProject;
import fi.uta.dbschema.gui.PEDBQuery;
import fi.uta.dbschema.metamodel.DBQuery;
import fi.uta.dbschema.metamodel.DBSchema;
import fi.uta.dbschema.metamodel.DBTableJoin;


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:50 $
 * @version   $Revision: 1.2 $
 */
public class EditQueryAction extends AbstractAction
{

   /*
    *  (non-Javadoc)
    *  @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
    */
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param event  No description provided
    */
   public void actionPerformed (ActionEvent event)
   {
      Object source = event.getSource();
      if (source instanceof Iterator)
      {
         Iterator iter = (Iterator) source;
         if (iter.hasNext())
         {
            source = iter.next();
         }
      }

      DBQuery dbQuery = null;
	if (source instanceof DBQuery)
	{
	   dbQuery = (DBQuery)  source;
	}
      if (source instanceof DBTableJoin)
      {
         dbQuery = (DBQuery)  ((DBTableJoin) source).getParent();
      }

      DBSchema dbSchema = null;
      source = UMLProject.get().getCurrentDiagram();
      if (source instanceof DBSchema)
      {
         dbSchema = (DBSchema) source;
      }

      PEDBQuery queryDialog = new PEDBQuery (FrameMain.get().getFrame());
      queryDialog.setIncrement ((ASGElement) dbSchema);
      if (dbQuery != null)
      {
         queryDialog.setQuerySelection (dbQuery);
      }
      queryDialog.showCentered();

      UMLProject.get().refreshDisplay();
   }

}

/*
 * $Log: EditQueryAction.java,v $
 * Revision 1.2  2003/10/07 07:21:50  ariseppi
 * misc. corrections
 *
 */
