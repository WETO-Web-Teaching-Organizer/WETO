/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.metamodel;



/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:53 $
 * @version   $Revision: 1.2 $
 */
public class DBTableJunction extends DBSchemaItem
{
   /**
    * Constructor for class DBTableJunction
    */
   public DBTableJunction()
   {
      super();
   }


   /**
    * Constructor for class DBTableJunction
    *
    * @param target  No description provided
    */
   public DBTableJunction (DBNodeInterface target)
   {
      this();
      setTarget (target);
   }


   /**
    * Get the readOnly attribute of the DBTableJunction object
    *
    * @return   The readOnly value
    */
   public boolean isReadOnly()
   {
      return  (super.isReadOnly() ||
          (getTarget() != null && getTarget().isReadOnly()));
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private DBNodeInterface target;


   /**
    * Get the target attribute of the DBTableJunction object
    *
    * @return   The target value
    */
   public DBNodeInterface getTarget()
   {
      return target;
   }


   /**
    * Sets the target attribute of the DBTableJunction object
    *
    * @param target  The new target value
    */
   public void setTarget (DBNodeInterface target)
   {
      if (this.target != target)
      { // new partner

         DBNodeInterface oldTarget = this.target;
         if (this.target != null)
         { // inform old partner

            this.target = null;
            oldTarget.removeFromJunctions (this);
         }
         this.target = target;
         if (target != null)
         { // inform new partner

            target.addToJunctions (this);
         }

         firePropertyChange ("target", oldTarget, target);
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private final void removeTarget()
   {
      this.setTarget (null);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public final static int NONE = 0;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public final static int ARROW = 1;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public final static int FILLED_BOX = 2;

   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private int adornment = DBTableJunction.NONE;


   /**
    * Get the adornment attribute of the DBTableJunction object, one of {None, Arrow}
    *
    * @return   The adornment value
    * @see      #NONE
    * @see      #ARROW
    */
   public int getAdornment()
   {
      return adornment;
   }


   /**
    * Sets the adornment attribute of the DBTableJunction object, one of {None, Arrow}
    *
    * @param adornment  The new adornment value
    * @see              #NONE
    * @see              #ARROW
    */
   public void setAdornment (int adornment)
   {
      int oldValue = this.adornment;
      this.adornment = adornment;
      firePropertyChange ("adornment", oldValue, adornment);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private DBTableJoin join;


   /**
    * Get the join attribute of the DBTableJunction object
    *
    * @return   The join value
    */
   public DBTableJoin getJoin()
   {
      return join;
   }


   /**
    * Set the join attribute of the DBTableJunction object
    *
    * @param obj  The new join value
    * @return     The join value
    */
   public boolean setJoin (DBTableJoin obj)
   {
      boolean changed = false;

      if (this.join != obj)
      {
         DBTableJoin oldValue = this.join;

         this.join = obj;

         changed = true;

         // side effects

         firePropertyChange ("join", oldValue, obj);
      }
      return changed;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private final void removeJoin()
   {
      this.setJoin (null);
   }


   /**
    * Get the partnerJunction attribute of the DBTableJunction object
    *
    * @return   The partnerJunction value
    */
   public DBTableJunction getPartnerJunction()
   {
      DBTableJoin join = getJoin();
      if (join != null)
      {
         return  ( (join.getFirstJunction() != this)
            ? join.getFirstJunction()
            : join.getSecondJunction());
      }
      else
      {
         return null;
      }
   }


   // ######################################################################

   /**
    * Isolates the object so the garbage collector can remove it.
    */
   public void removeYou()
   {
      this.removeTarget();
      this.removeJoin();

      super.removeYou();
   }


   /**
    * @return   short string representation of current object
    */
   public String getText()
   {
      DBTable table = (DBTable) getTarget();
      if (table != null)
      {
         return table.getName();
      }
      return null;
   }


   /**
    * @return   short string representation of current object
    */
   public String toString()
   {
      return "DBTableJunction[id=" + getID() + ",target=" + getTarget() + "]";
   }
}

/*
 * $Log: DBTableJunction.java,v $
 * Revision 1.2  2003/10/07 07:21:53  ariseppi
 * misc. corrections
 *
 */
