/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.fsa.listener;

import java.awt.Component;
import java.util.Iterator;

import javax.swing.JComponent;

import de.uni_paderborn.fujaba.fsa.FSAObject;
import de.uni_paderborn.fujaba.fsa.listener.SelectionEvent;
import de.uni_paderborn.fujaba.fsa.listener.SelectionListener;
import de.uni_paderborn.fujaba.fsa.listener.SelectionListenerHelper;
import de.uni_paderborn.fujaba.fsa.unparse.FSAInterface;
import de.uni_paderborn.fujaba.fsa.unparse.LogicUnparseInterface;
import fi.uta.dbschema.metamodel.DBQuery;
import fi.uta.dbschema.metamodel.DBTableJoin;


/*
 *  Similar to de.uni_paderborn.fujaba.fsa.listener.SelectionQueryListener
 */
/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:50 $
 * @version   $Revision: 1.2 $
 */
public class SelectionQueryListener implements SelectionListener
{
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private static SelectionQueryListener singleton = null;


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @return   No description provided
    */
   public static SelectionQueryListener get()
   {
      if (singleton == null)
      {
         singleton = new SelectionQueryListener();
      }

      return singleton;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param event  No description provided
    */
   public void selectionChanged (SelectionEvent event)
   {
      JComponent source = (JComponent) event.getSource();
      Component[] targets = getTargets (source);

      for (int i = 0; i < targets.length; i++)
      {
         if (targets[i] instanceof JComponent)
         {
            JComponent tmpComp = (JComponent) targets[i];
            SelectionListenerHelper.setSelection (tmpComp, event.getSelection());
         }
      }
   }


   /**
    * Get the targets attribute of the SelectionQueryListener object
    *
    * @param source  No description provided
    * @return        The targets value
    */
   private Component[] getTargets (JComponent source)
   {
      LogicUnparseInterface logic = FSAObject.getLogicFromJComponent (source);
      if (! (logic instanceof DBTableJoin))
      {
         return new Component[0];
      }
      DBTableJoin join = (DBTableJoin) logic;
      DBQuery query = (DBQuery) join.getParent();
      Iterator iter = query.iteratorOfJoins();

      Component[] siblings = new Component[query.sizeOfJoins() - 1];

      int curPos = 0;

      while (iter.hasNext())
      {
         DBTableJoin curJoin = (DBTableJoin) iter.next();
         if (curJoin != join)
         {
            FSAInterface fsaIface = curJoin.getFSAInterface();
            FSAObject fsaObj = fsaIface.getFirstFromFsaObjects();
            siblings[curPos] = fsaObj.getJComponent();
            curPos++;
         }
      }

      return siblings;
   }
}

/*
 * $Log: SelectionQueryListener.java,v $
 * Revision 1.2  2003/10/07 07:21:50  ariseppi
 * misc. corrections
 *
 */
