/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.metamodel;

import java.util.Iterator;

import de.upb.tools.fca.FEmptyIterator;
import de.upb.tools.fca.FPropHashSet;

/**
 * DBTable contains attributes name and package. DBTable has references to + DBAttributes (naturally)
 * + DBUniques (naturally) + DBForeignKeys - their own (naturally) + DBForeignKeys - keys that
 * refer to them (to be able to easily remove the keys when the table is removed) + DBQueries
 * - queries that refer to them (to be able to easily remove the queries when the table is
 * removed)
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:53 $
 * @version   $Revision: 1.3 $
 */

public class DBTable extends DBSchemaItem implements DBTableInterface
{
	/**
	 * Constructor for class DBTable
	 */
	public DBTable()
	{
		super();
		setName("Table");
	}

	/**
	 * Constructor for class DBTable
	 *
	 * @param name  No description provided
	 */
	public DBTable(String name)
	{
		super();
		setName(name);
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	private String name = "";

	/**
	 * Sets the name attribute of the DBTable object
	 *
	 * @param newName  The new name value
	 */
	public void setName(String newName)
	{
		if (!name.equals(newName))
		{
			String oldName = this.name;
			this.name = newName;
			firePropertyChange("name", oldName, newName);
			String label = name;
			if(this.getStrength())
			{
				label = "* " + label;
			}
			this.setLabel(label);
		}
	}

	/**
	 * Get the name attribute of the DBTable object
	 *
	 * @return   The name value
	 */
	public String getName()
	{
		return this.name;
	}
	
	private String label = "";
	
	public void setLabel(String newLabel)
	{
		if (!label.equals(newLabel))
		{
			String oldLabel = this.label;
			this.label = newLabel;
			firePropertyChange("label", oldLabel, newLabel);
		}
	}	

	public String getLabel()
	{
		return label;
	}

	
	private String description = "";
	
	public String getDescription()
	{
		return this.description;
	}
	
	public void setDescription(String newDescription)
	{
		if (!description.equals(newDescription))
		{
			String oldDescription = this.description;
			this.description = newDescription;
			firePropertyChange("description", oldDescription, newDescription);
		}
	}
	
	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	private String javaPackage = "";

	/**
	 * Get the javaPackage attribute of the DBTable object
	 *
	 * @param newPackage  No description provided
	 */
	public void setJavaPackage(String newPackage)
	{
		if (!javaPackage.equals(newPackage))
		{
			String oldPackage = this.javaPackage;
			this.javaPackage = newPackage;
			firePropertyChange("javaPackage", oldPackage, newPackage);
		}
	}

	/**
	 * Get the javaPackage attribute of the DBTable object
	 *
	 * @return   The javaPackage value
	 */
	public String getJavaPackage()
	{
		return this.javaPackage;
	}

	/**
		* No comment provided by developer, please add a comment to ensure improve documentation.
		*/
	private boolean strength = false;

	/**
		* Get the strongEntity attribute of the DBTable object
		*
		* @param strongness  No description provided
		*/
	public void setStrength(boolean strength)
	{
		if (this.strength != strength)
		{
			boolean oldStrength = this.strength;
			this.strength = strength;
			firePropertyChange("strength", oldStrength, strength);
		}
	}

	/**
		* Get the strength attribute of the DBTable object
		*
		* @return   The javaPackage value
		*/
	public boolean getStrength()
	{
		return this.strength;
	}

	/**
	 * Get the text attribute of the DBTable object
	 *
	 * @return   The text value
	 */
	public String getText()
	{
		return this.getName();
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @return   No description provided
	 */
	public String toString()
	{
		return this.getName();
	}

	/**
	 * <pre>
	 *             0..n   attributes   0..1
	 * TableAttribute ---------------------- Table
	 *             attributes         table
	 * </pre>
	 */
	private FPropHashSet attributes;

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @return   No description provided
	 */
	public int sizeOfAttributes()
	{
		return ((this.attributes == null) ? 0 : this.attributes.size());
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	public void removeYou()
	{
		removeAllFromAttributes();
		Iterator iter = iteratorOfForeignKeys();
		while (iter.hasNext())
		{
			DBForeignKey tmpKey = (DBForeignKey) iter.next();
			tmpKey.removeYou();
		}
		iter = iteratorOfRevForeignKeys();
		while (iter.hasNext())
		{
			DBForeignKey tmpKey = (DBForeignKey) iter.next();
			tmpKey.removeYou();
		}
		removeAllFromUniques();
		iter = iteratorOfRevQueries();
		while (iter.hasNext())
		{
			DBQuery tmpQuery = (DBQuery) iter.next();
			tmpQuery.removeYou();
		}

		iter = iteratorOfRevViews();
		while (iter.hasNext())
		{
			DBView tmpView = (DBView) iter.next();
			tmpView.removeYou();
		}

		removeAllFromJunctions();

		super.removeYou();
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param value  No description provided
	 * @return       No description provided
	 */
	public boolean removeFromAttributes(DBTableAttribute value)
	{
		/*
		 *  id=id397   # no Name
		 */
		boolean changed = false;
		if ((this.attributes != null) && (value != null))
		{
			changed = this.attributes.remove(value);
			if (changed)
			{
				value.setParent(null);
			}
		}
		return changed;
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	public void removeAllFromAttributes()
	{
		DBTableAttribute tmpValue;
		Iterator iter = this.iteratorOfAttributes();
		while (iter.hasNext())
		{
			tmpValue = (DBTableAttribute) iter.next();
			this.removeFromAttributes(tmpValue);
		}
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @return   No description provided
	 */
	public Iterator iteratorOfAttributes()
	{
		return (
			(this.attributes == null)
				? FEmptyIterator.get()
				: this.attributes.iterator());
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param value  No description provided
	 * @return       No description provided
	 */
	public boolean hasInAttributes(DBTableAttribute value)
	{
		return (
			(this.attributes != null)
				&& (value != null)
				&& this.attributes.contains(value));
	}

	/**
	 * Access method for an one to n association.
	 *
	 * @param value  The object added.
	 * @return       No description provided
	 */
	public boolean addToAttributes(DBTableAttribute value)
	{
		boolean changed = false;
		if (value != null)
		{
			if (this.attributes == null)
			{
				this.attributes = new FPropHashSet(this, "attributes");
				// or FTreeSet () or FLinkedList ()
			}
			changed = this.attributes.add(value);
			if (changed)
			{
				value.setParent(this);
			}
		}
		return changed;
	}

	/**
	 * <pre>
	 *             0..n   foreignKeys   0..1
	 * DBForeignKey ---------------------- DBTable
	 *             foreignKey         table
	 * </pre>
	 */
	private FPropHashSet foreignKeys;

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @return   No description provided
	 */
	public int sizeOfForeignKeys()
	{
		return ((this.foreignKeys == null) ? 0 : this.foreignKeys.size());
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param value  No description provided
	 * @return       No description provided
	 */
	public boolean removeFromForeignKeys(DBForeignKey value)
	{
		boolean changed = false;
		if ((this.foreignKeys != null) && (value != null))
		{
			changed = this.foreignKeys.remove(value);
		}
		return changed;
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	public void removeAllFromForeignKeys()
	{
		DBForeignKey tmpValue;
		Iterator iter = this.iteratorOfForeignKeys();
		while (iter.hasNext())
		{
			tmpValue = (DBForeignKey) iter.next();
			this.removeFromForeignKeys(tmpValue);
		}
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @return   No description provided
	 */
	public Iterator iteratorOfForeignKeys()
	{
		return (
			(this.foreignKeys == null)
				? FEmptyIterator.get()
				: this.foreignKeys.iterator());
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param value  No description provided
	 * @return       No description provided
	 */
	public boolean hasInForeignKeys(DBForeignKey value)
	{
		return (
			(this.foreignKeys != null)
				&& (value != null)
				&& this.foreignKeys.contains(value));
	}

	/**
	 * Access method for an one to n association.
	 *
	 * @param value  The object added.
	 * @return       No description provided
	 */
	public boolean addToForeignKeys(DBForeignKey value)
	{
		boolean changed = false;
		if (value != null)
		{
			if (this.foreignKeys == null)
			{
				this.foreignKeys = new FPropHashSet(this, "foreignKeys");
				// or FTreeSet () or FLinkedList ()
			}
			changed = this.foreignKeys.add(value);
		}
		return changed;
	}

	/**
	 * <pre>
	 *             0..n   revForeignKeys   0..1
	 * DBForeignKey ---------------------- DBTable
	 *             revForeignKey         table
	 * </pre>
	 */
	private FPropHashSet revForeignKeys;

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @return   No description provided
	 */
	public int sizeOfRevForeignKeys()
	{
		return ((this.revForeignKeys == null) ? 0 : this.revForeignKeys.size());
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param value  No description provided
	 * @return       No description provided
	 */
	public boolean removeFromRevForeignKeys(DBForeignKey value)
	{
		/*
		 *  id=id397   # no Name
		 */
		boolean changed = false;
		if ((this.revForeignKeys != null) && (value != null))
		{
			changed = this.revForeignKeys.remove(value);
		}
		return changed;
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	public void removeAllFromRevForeignKeys()
	{
		/*
		 *  id=id356   # no Name
		 */
		DBForeignKey tmpValue;
		Iterator iter = this.iteratorOfRevForeignKeys();
		while (iter.hasNext())
		{
			tmpValue = (DBForeignKey) iter.next();
			this.removeFromRevForeignKeys(tmpValue);
		}
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @return   No description provided
	 */
	public Iterator iteratorOfRevForeignKeys()
	{
		/*
		 *  id=id365   # no Name
		 */
		return (
			(this.revForeignKeys == null)
				? FEmptyIterator.get()
				: this.revForeignKeys.iterator());
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param value  No description provided
	 * @return       No description provided
	 */
	public boolean hasInRevForeignKeys(DBForeignKey value)
	{
		/*
		 *  id=id381   # no Name
		 */
		return (
			(this.revForeignKeys != null)
				&& (value != null)
				&& this.revForeignKeys.contains(value));
	}

	/**
	 * Access method for an one to n association.
	 *
	 * @param value  The object added.
	 * @return       No description provided
	 */
	public boolean addToRevForeignKeys(DBForeignKey value)
	{
		/*
		 *  id=id389   # no Name
		 */
		boolean changed = false;
		if (value != null)
		{
			if (this.revForeignKeys == null)
			{
				this.revForeignKeys = new FPropHashSet(this, "revForeignKeys");
				// or FTreeSet () or FLinkedList ()
			}
			changed = this.revForeignKeys.add(value);
		}
		return changed;
	}

	/**
	 * <pre>
	 *             0..n   uniques   0..1
	 * DBUnique ---------------------- Table
	 *             uniques         table
	 * </pre>
	 */
	private FPropHashSet uniques;

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @return   No description provided
	 */
	public int sizeOfUniques()
	{
		/*
		 *  id=id373   # no Name
		 */
		return ((this.uniques == null) ? 0 : this.uniques.size());
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param value  No description provided
	 * @return       No description provided
	 */
	public boolean removeFromUniques(DBUnique value)
	{
		/*
		 *  id=id397   # no Name
		 */
		boolean changed = false;
		if ((this.uniques != null) && (value != null))
		{
			changed = this.uniques.remove(value);
			if (changed)
			{
				value.setParent(null);
			}
		}
		return changed;
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	public void removeAllFromUniques()
	{
		/*
		 *  id=id356   # no Name
		 */
		DBUnique tmpValue;
		Iterator iter = this.iteratorOfUniques();
		while (iter.hasNext())
		{
			tmpValue = (DBUnique) iter.next();
			this.removeFromUniques(tmpValue);
		}
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @return   No description provided
	 */
	public Iterator iteratorOfUniques()
	{
		/*
		 *  id=id365   # no Name
		 */
		return (
			(this.uniques == null)
				? FEmptyIterator.get()
				: this.uniques.iterator());
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param value  No description provided
	 * @return       No description provided
	 */
	public boolean hasInUniques(DBUnique value)
	{
		/*
		 *  id=id381   # no Name
		 */
		return (
			(this.uniques != null)
				&& (value != null)
				&& this.uniques.contains(value));
	}

	/**
	 * Access method for an one to n association.
	 *
	 * @param value  The object added.
	 * @return       No description provided
	 */
	public boolean addToUniques(DBUnique value)
	{
		/*
		 *  id=id389   # no Name
		 */
		boolean changed = false;
		if (value != null)
		{
			if (this.uniques == null)
			{
				this.uniques = new FPropHashSet(this, "uniques");
				// or FTreeSet () or FLinkedList ()
			}
			changed = this.uniques.add(value);
			if (changed)
			{
				value.setParent(this);
			}
		}
		return changed;
	}

	/**
	 * <pre>
	 *             0..n   revQueries   0..1
	 * DBQuery ---------------------- DBTable
	 *             revQueries         table
	 * </pre>
	 */
	private FPropHashSet revQueries;

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @return   No description provided
	 */
	public int sizeOfRevQueries()
	{
		return ((this.revQueries == null) ? 0 : this.revQueries.size());
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param value  No description provided
	 * @return       No description provided
	 */
	public boolean removeFromRevQueries(DBQuery value)
	{
		boolean changed = false;
		if ((this.revQueries != null) && (value != null))
		{
			changed = this.revQueries.remove(value);
		}
		return changed;
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	public void removeAllFromRevQueries()
	{
		DBQuery tmpValue;
		Iterator iter = this.iteratorOfRevQueries();
		while (iter.hasNext())
		{
			tmpValue = (DBQuery) iter.next();
			this.removeFromRevQueries(tmpValue);
		}
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @return   No description provided
	 */
	public Iterator iteratorOfRevQueries()
	{
		return (
			(this.revQueries == null)
				? FEmptyIterator.get()
				: this.revQueries.iterator());
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param value  No description provided
	 * @return       No description provided
	 */
	public boolean hasInRevQueries(DBQuery value)
	{
		return (
			(this.revQueries != null)
				&& (value != null)
				&& this.revQueries.contains(value));
	}

	/**
	 * Access method for an one to n association.
	 *
	 * @param value  The object added.
	 * @return       No description provided
	 */
	public boolean addToRevQueries(DBQuery value)
	{
		boolean changed = false;
		if (value != null)
		{
			if (this.revQueries == null)
			{
				this.revQueries = new FPropHashSet(this, "revQueries");
				// or FTreeSet () or FLinkedList ()
			}
			changed = this.revQueries.add(value);
		}
		return changed;
	}

	/**
	 * <pre>
	 *             0..n   junctions   0..1
	 * DBTableJunction ---------------------- DBTable
	 *             junctions         table
	 * </pre>
	 */
	private FPropHashSet junctions;

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @return   No description provided
	 */
	public int sizeOfJunctions()
	{
		return ((this.junctions == null) ? 0 : this.junctions.size());
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param value  No description provided
	 * @return       No description provided
	 */
	public boolean removeFromJunctions(DBTableJunction value)
	{
		boolean changed = false;
		if ((this.junctions != null) && (value != null))
		{
			changed = this.junctions.remove(value);
			if (changed)
			{
				value.setTarget(null);
			}
		}
		return changed;
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	public void removeAllFromJunctions()
	{
		DBTableJunction tmpValue;
		Iterator iter = this.iteratorOfJunctions();
		while (iter.hasNext())
		{
			tmpValue = (DBTableJunction) iter.next();
			this.removeFromJunctions(tmpValue);
		}
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @return   No description provided
	 */
	public Iterator iteratorOfJunctions()
	{
		return (
			(this.junctions == null)
				? FEmptyIterator.get()
				: this.junctions.iterator());
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param value  No description provided
	 * @return       No description provided
	 */
	public boolean hasInJunctions(DBTableJunction value)
	{
		return (
			(this.junctions != null)
				&& (value != null)
				&& this.junctions.contains(value));
	}

	/**
	 * Access method for an one to n association.
	 *
	 * @param value  The object added.
	 * @return       No description provided
	 */
	public boolean addToJunctions(DBTableJunction value)
	{
		boolean changed = false;
		if (value != null)
		{
			if (this.junctions == null)
			{
				this.junctions = new FPropHashSet(this, "junctions");
				// or FTreeSet () or FLinkedList ()
			}
			changed = this.junctions.add(value);
			if (changed)
			{
				value.setTarget(this);
			}
		}
		return changed;
	}

	/**
	 * <pre>
	 *             0..n   revViews   0..1
	 * DBView ---------------------- DBTable
	 *             revViews         view
	 * </pre>
	 */
	private FPropHashSet revViews;

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @return   No description provided
	 */
	public int sizeOfRevViews()
	{
		return ((this.revViews == null) ? 0 : this.revViews.size());
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param value  No description provided
	 * @return       No description provided
	 */
	public boolean removeFromRevViews(DBView value)
	{
		boolean changed = false;
		if ((this.revViews != null) && (value != null))
		{
			changed = this.revViews.remove(value);
		}
		return changed;
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	public void removeAllFromRevViews()
	{
		DBView tmpValue;
		Iterator iter = this.iteratorOfRevViews();
		while (iter.hasNext())
		{
			tmpValue = (DBView) iter.next();
			this.removeFromRevViews(tmpValue);
		}
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @return   No description provided
	 */
	public Iterator iteratorOfRevViews()
	{
		return (
			(this.revViews == null)
				? FEmptyIterator.get()
				: this.revViews.iterator());
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param value  No description provided
	 * @return       No description provided
	 */
	public boolean hasInRevViews(DBView value)
	{
		return (
			(this.revViews != null)
				&& (value != null)
				&& this.revViews.contains(value));
	}

	/**
	 * Access method for an one to n association.
	 *
	 * @param value  The object added.
	 * @return       No description provided
	 */
	public boolean addToRevViews(DBView value)
	{
		boolean changed = false;
		if (value != null)
		{
			if (this.revViews == null)
			{
				this.revViews = new FPropHashSet(this, "revViews");
				// or FTreeSet () or FLinkedList ()
			}
			changed = this.revViews.add(value);
		}
		return changed;
	}
}

/*
 * $Log: DBTable.java,v $
 * Revision 1.3  2003/10/07 07:21:53  ariseppi
 * misc. corrections
 *
 */
