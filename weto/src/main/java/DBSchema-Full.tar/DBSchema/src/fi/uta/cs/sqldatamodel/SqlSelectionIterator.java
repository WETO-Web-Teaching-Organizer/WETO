package fi.uta.cs.sqldatamodel;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Generic iterator that enumerates through a ResultSet of a select query.
 */
public class SqlSelectionIterator implements Iterator {
	private Class itemClass = null;
	
	private PreparedStatement preparedStatement;
    private ResultSet resultSet;
    private SqlAssignableObject nextObject;
	
    /**
     * Constructs the iterator by executing the given PreparedStatement.
     * Iteration constructs a new object instance of the given type for each step.
     * 
     * @param queryStatement PreparedStatement that is used to fetch the ResultSet.
     *		The ownership of the statement is vested in the iterator that also
     *      closes it when the iteration completes.
     * 
     * @param itemClass Class of the items that this iterator returns. This should
     * 		be the most-derived known class that implements SqlAssignableObject.
     * 
     * @throws SQLException If statement execution fails.
     */
    public SqlSelectionIterator( PreparedStatement queryStatement, Class itemClass ) throws SQLException {
    	preparedStatement = queryStatement;
    	resultSet = preparedStatement.executeQuery();
    	nextObject = null;
    	this.itemClass = itemClass;
    }
	
    /**
     * Checks whether there are more objects.
     * 
     * @return true If there are more objects, false otherwise.
     * 
     * @throws SqlSelectionIteratorException if the database operation 
     *	fails, or the resulting data is invalid.
     */
	public synchronized boolean hasNext() {
		if( resultSet == null ) return false;
		if( nextObject != null ) return true;
		
		// nextObject is always null here
		try {
            if( resultSet.next() ) {
           		// Create new objects
           		nextObject = (SqlAssignableObject)itemClass.newInstance();
            	nextObject.setFromResultSet( resultSet, 0 );
                return true;
            } else {
            	close();
            	return false;
            }
        } catch( Exception e ) {
        	nextObject = null;
        	// hasNext interface does not allow normal exceptions
        	throw new SqlSelectionIteratorException( e.toString() );
        }
	}

	/**
	 * Retrieves the next object.
	 * 
	 * @return Next object. The object is of the type given as a parameter to the
	 *	iterator constructor.
	 * 
	 * @throws SqlSelectionIteratorException if the database operation 
     *	fails, or the resulting data is invalid.
     * @throws NoSuchElementException if there are no more elements.
	 */
	public synchronized Object next() {
		if( hasNext() ) {
			Object retObject = nextObject;
			// Clearing nextObject allows hasNext to iterate further
			nextObject = null;
			return retObject;
		}
		throw new NoSuchElementException();
	}

	/**
	 * Remove operation is not supported, and always throws UnsupportedOperationException.
	 */
	public void remove() {
		throw new UnsupportedOperationException();
	}
	
	/**
	 * Closes the iterator. Closing is also performed when hasNext returns false
	 * or finalize is called.
	 */
	public void close() throws SQLException {
		if( resultSet!=null ) {
			resultSet.close();
			resultSet = null;
		}
		if( preparedStatement!=null ) {
			preparedStatement.close();
			preparedStatement = null;
		}
	}
	
	public void finalize() throws Throwable {
		// Finalize can throw anything, exceptions are always ignored
		close();
	}
}

// End of file.
