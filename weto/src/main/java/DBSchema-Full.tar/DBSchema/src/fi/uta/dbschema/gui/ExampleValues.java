/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this added code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.gui;

import java.awt.Cursor;
import java.awt.event.ActionEvent;
import java.util.Iterator;

import javax.swing.JFrame;
import javax.swing.JLabel;

import de.uni_paderborn.fujaba.gui.PEEditPanel;
import fi.uta.cs.sqldatatypes.SqlDataType;
import fi.uta.dbschema.metamodel.DBTable;
import fi.uta.dbschema.metamodel.DBTableAttribute;

public class ExampleValues extends BasicDialog
{
	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	BDJTable exampleTable;
	DBTable table;
	
	String[] titles;
	Object[][] values;
	SqlDataType[] types;

	/**
	 * Constructor for class ExampleValues
	 *
	 * @param frame  No description provided
	 * @param title  No description provided
	 * @param modal  No description provided
	 */
	public ExampleValues(JFrame frame, String title, boolean modal, DBTable table)
	{
		super (frame);
		setModal (modal);
		setTitle (title);
		setTable(table);
		try
		{
		   pack();
		   this.setTitle ("Database Query Definition");
		}
		catch (Exception e)
		{
		   e.printStackTrace();
		}
		initDialog();
	}

	/**
	 * Constructor for class ExampleValues
	 *
	 * @param frame  No description provided
	 */
	public ExampleValues(JFrame frame, DBTable table)
	{
		this(frame, "", false, table);
	}

	/**
	 * Constructor for class ExampleValues
	 *
	 * @param frame  No description provided
	 * @param modal  No description provided
	 */
	public ExampleValues(JFrame frame, boolean modal, DBTable table)
	{
		this(frame, "", modal, table);
	}

	/**
	 * Constructor for class ExampleValues
	 *
	 * @param frame  No description provided
	 * @param title  No description provided
	 */
	public ExampleValues(JFrame frame, String title, DBTable table)
	{
		this(frame, title, false, table);
	}

	/**
	 * Returns the forKeyRevTable attribute of the ExampleValues object
	 *
	 * @return   The curTable value
	 */
	public DBTable getTable()
	{
		return table;
	}

	/**
	 * Sets the forKeyRevTable attribute of the ExampleValues object
	 *
	 * @param table  The new curTable value
	 */
	public void setTable(DBTable table)
	{
		titles = new String[table.sizeOfAttributes()];
		values = new Object[DBTableAttribute.exampleCount][table.sizeOfAttributes()];
		types = new SqlDataType[table.sizeOfAttributes()];
		Iterator iter = table.iteratorOfAttributes();
		int attrNumber = 0;
		while(iter.hasNext()) 
		{
			DBTableAttribute attr = (DBTableAttribute) iter.next();
			titles[attrNumber] = attr.getName();
			types[attrNumber] = attr.getTypeClass();
			for(int i = 0; i < DBTableAttribute.exampleCount; i++) {
				values[i][attrNumber] = attr.getExample(i);
			}
			attrNumber++;
		}
		this.table = table;
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param panel  No description provided
	 */
	protected void additionalContents (PEEditPanel panel)
	{
		exampleTable = new BDJTable(this, "Modify example data: " + getTable().getName(), titles, values, types);
		
		BDColumn column = new BDColumn(this);
		BDRow row = new BDRow(this);
		row.add(new JLabel("Note: empty cells represent null values and \"\" cells empty values."));
		column.add(row);
		row = new BDRow(this);
		row.add(exampleTable);
		column.add(row);
		
/*		Dimension dim = panel.getMaximumSize();
		dim.height = panel.getMinimumSize().height;
		panel.setMaximumSize(dim);*/
		
		panel.add(column);
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	public void unparse()
	{
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	protected void parse()
	{
		exampleTable.stopCellEditing();
		Iterator iter = table.iteratorOfAttributes();
		DBTableAttribute[] attrs = new DBTableAttribute[table.sizeOfAttributes()];
		int attrIndex = 0;
		while(iter.hasNext()) {
			attrs[attrIndex] = (DBTableAttribute) iter.next();
			attrIndex++;
		}
		for(int i = 0; i < DBTableAttribute.exampleCount; i++) {
			if(exampleTable.hasChanged(i)) {
				for(int i2 = 0; i2 < attrs.length; i2++) {
					attrs[i2].setExample((String) exampleTable.getValueAt(i, i2), i);
				}
			}
		}
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	protected void cancel()
	{
		setVisible(false);
		dispose();
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param e  No description provided
	 */
	void buttonOK_actionPerformed(ActionEvent e)
	{
		//      super.buttonOK_actionPerformed (e);
		if (getFrame() != null)
		{
			getFrame().setCursor(
				Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
		} // if

		try
		{
			setVisible(false);
			parse();
		} finally
		{
			if (getFrame() != null)
			{
				getFrame().setCursor(
					Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
			}
		}
	}
}