/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.actions;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.util.Iterator;

import javax.swing.AbstractAction;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;

import de.uni_paderborn.fujaba.app.FrameMain;
import de.uni_paderborn.fujaba.uml.UMLProject;
import fi.uta.cs.dbswtool.Attribute;
import fi.uta.cs.dbswtool.AttributeVector;
import fi.uta.cs.dbswtool.ForeignKey;
import fi.uta.cs.dbswtool.NameVector;
import fi.uta.cs.dbswtool.Query;
import fi.uta.cs.dbswtool.QueryVector;
import fi.uta.cs.dbswtool.RelAndQueryConstants;
import fi.uta.cs.dbswtool.Relation;
import fi.uta.cs.dbswtool.RelationVector;
import fi.uta.cs.dbswtool.View;
import fi.uta.cs.dbswtool.ViewVector;
import fi.uta.cs.sqldatatypes.SqlDataType;
import fi.uta.cs.sqldatatypes.SqlString;
import fi.uta.dbschema.metamodel.DBForeignKey;
import fi.uta.dbschema.metamodel.DBJunctionPair;
import fi.uta.dbschema.metamodel.DBQuery;
import fi.uta.dbschema.metamodel.DBSchema;
import fi.uta.dbschema.metamodel.DBTable;
import fi.uta.dbschema.metamodel.DBTableAttribute;
import fi.uta.dbschema.metamodel.DBTableAttributeJunction;
import fi.uta.dbschema.metamodel.DBUnique;
import fi.uta.dbschema.metamodel.DBView;
import fi.uta.dbschema.metamodel.DBViewAttribute;


/**
 * @author
 * @created   $Date: 2003/10/07 07:21:49 $
 * @version   $Revision: 1.3 $
 * Uses DBSWTool to create Java, HTML and SQL files from current diagram.
 */
public class CreateDBFilesAction extends AbstractAction
{

   /*
    *  (non-Javadoc)
    *  @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
    */
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param event  No description provided
    */
   public void actionPerformed (ActionEvent event)
   {
      DBSchema dbSchema = null;
      Object source = UMLProject.get().getCurrentDiagram();
      if (source instanceof DBSchema)
      {
         dbSchema = (DBSchema) source;
      }
      else
      {
         return;
      }

      JFileChooser chooser = new JFileChooser();
      chooser.setApproveButtonText ("Choose");
      chooser.setFileSelectionMode (JFileChooser.DIRECTORIES_ONLY);
      JPanel databasePanel = new JPanel();
      JComboBox box = new JComboBox(RelAndQueryConstants.databases);
      box.setPreferredSize(box.getMinimumSize());
	  box.setMaximumSize(box.getMinimumSize());
	  databasePanel.setLayout(new BoxLayout(databasePanel, BoxLayout.Y_AXIS));
	  JLabel label = new JLabel("DBMS");
	  box.setAlignmentX(Component.LEFT_ALIGNMENT);
	  label.setAlignmentX(Component.LEFT_ALIGNMENT);
	  databasePanel.add(label);
	  databasePanel.add(box);
      databasePanel.add(Box.createVerticalGlue());
      chooser.setAccessory(databasePanel);
      int returnVal = chooser.showOpenDialog (FrameMain.get());

      String path = null;

      if (returnVal == JFileChooser.APPROVE_OPTION)
      {
         path = chooser.getSelectedFile().getAbsolutePath();
      }
      else
      {
         return;
      }

      Iterator iter = dbSchema.iteratorOfItems();

      RelationVector relVector = new RelationVector();
      AttributeVector attrVector = new AttributeVector();
      QueryVector queVector = new QueryVector();
      ViewVector viewVector = new ViewVector();

      while (iter.hasNext())
      {
         Object obj = iter.next();
         if (obj instanceof DBTable)
         {
            DBTable table = (DBTable) obj;
            Relation rel = new Relation();
            rel.setName (table.getName());
            rel.setPackage (table.getJavaPackage());
            rel.setDescription(table.getDescription());
            Iterator iter2 = table.iteratorOfAttributes();

            // Information about unique constraints is stored as a list
            // in DBTable, primary key information is stored as attribute
            // variables in DBTableAttributes.

            NameVector primaryKey = new NameVector();
            String[][] examples = new String[DBTableAttribute.exampleCount][table.sizeOfAttributes()];
            int attrInd = 0;
            while (iter2.hasNext())
            {
               DBTableAttribute attr = (DBTableAttribute) iter2.next();
               // DBTableAttribute uses datatype int instead of Integer for size and
               // scale with NO_NUMBER meaning null (since all the legal values are positive).
               int number = attr.getSqlSize();
               Integer size = null;
               if (number > DBTableAttribute.NO_NUMBER)
               {
                  size = new Integer (number);
               }
               number = attr.getSqlScale();
               Integer scale = null;
               if (number > DBTableAttribute.NO_NUMBER)
               {
                  scale = new Integer (number);
               }

               String sqlType = attr.getSqlType();
               if (size != null)
               {
                  sqlType += "(" + size;
                  if (scale != null)
                  {
                     sqlType += "," + scale;
                  }
                  sqlType += ")";
               }
               SqlDataType sdt = attr.getTypeClass();
               Boolean stringType = null;
               if(sdt instanceof SqlString) {
               	stringType = new Boolean(true);
               }
               else {
				stringType = new Boolean(false);
               }
               String description = attr.getDescription();
               
               Iterator iter3 = attr.iteratorOfExamples();
               int exampleInd = 0;
               while(iter3.hasNext()) {
               	  examples[exampleInd][attrInd] = (String) iter3.next();
               	  exampleInd++;
               }
               attrInd++;

               // Attribute names are created by combining the attribute name in the
               // relation (attribute role) and table name.
               Attribute a = new Attribute (rel.getName() + "_" + attr.getName(), sqlType, attr.getJavaType(), stringType);
               a.setJavaTypeLength (size);
               a.setJavaTypeScale (scale);
               if (attr.getPrimaryKeyValue())
               {
                  primaryKey.addName (attr.getName());
               }
               a.setRole (attr.getName());
               a.setNotNull (new Boolean (attr.getNotNullValue()));
               a.setDescription(description);

               // Attribute is added to attribute vector and relation.
               attrVector.addAttribute (a);
               rel.addAttribute (a);
            }
            for(int i = 0; i < DBTableAttribute.exampleCount; i++) {
            	String[] example = (String[]) examples[i];
            	boolean nonEmpty = false;
            	for(int i2 = 0; i2 < table.sizeOfAttributes(); i2++) {
            		 if(example[i2] == null) {
						example[i2] = "";
            		 }
            			if(!example[i2].equals("")) {
							nonEmpty = true;
            			}
            			if(example[i2].equals("")) {
							example[i2] = "null";
            			}
            			else if(example[i2].equals("\"\"")) {
							example[i2] = "";
            			}
            	}
            	if(nonEmpty) {
            		rel.addExample(example);
            	}
            }
            rel.setPrimaryKey (primaryKey);
            iter2 = table.iteratorOfUniques();
            while (iter2.hasNext())
            {
               DBUnique uni = (DBUnique) iter2.next();
               Iterator iter3 = uni.iteratorOfAttributes();
               NameVector uniqueConst = new NameVector();
               while (iter3.hasNext())
               {
                  DBTableAttribute attr = (DBTableAttribute) iter3.next();
                  uniqueConst.addName (attr.getName());
               }
               rel.addUnique (uniqueConst);
            }
            iter2 = table.iteratorOfForeignKeys();
            while (iter2.hasNext())
            {
               DBForeignKey key = (DBForeignKey) iter2.next();
               DBTable revTable = key.getRevTable();
               String revTableName = revTable.getName();

               Iterator iter3 = key.iteratorOfJunctionPairs();
               NameVector ownAttributes = new NameVector();
               NameVector revAttributes = new NameVector();
               while (iter3.hasNext())
               {
                  DBJunctionPair pair = (DBJunctionPair) iter3.next();
                  DBTableAttributeJunction origJunc = pair.getOriginalJunction();
                  DBTableAttribute origAttr = origJunc.getTarget();
                  DBTableAttributeJunction revJunc = pair.getRevJunction();
                  DBTableAttribute revAttr = revJunc.getTarget();
                  ownAttributes.addName (origAttr.getName());
                  revAttributes.addName (revAttr.getName());
               }
               ForeignKey toolKey = new ForeignKey();
               toolKey.setReferredTable (revTableName);
               toolKey.setReferredAttributes (revAttributes);
               toolKey.setOwnAttributes (ownAttributes);
               rel.addForeignKey (toolKey);
            }
            relVector.addRelation (rel);
         }
         if (obj instanceof DBQuery)
         {
            DBQuery dbQue = (DBQuery) obj;
            Query que = new Query();
            que.setName (dbQue.getName());
            que.setPackage (dbQue.getJavaPackage());
            Iterator iter2 = dbQue.iteratorOfTables();
            while (iter2.hasNext())
            {
               DBTable table = (DBTable) iter2.next();
               que.addRelationName (table.getName());
            }
            que.setWhereClause (dbQue.getWhereClause());
            queVector.addQuery (que);
         }
         if (obj instanceof DBView)
         {
            DBView dbView = (DBView) obj;
            View view = new View();
            view.setName (dbView.getName());
            view.setPackage (dbView.getJavaPackage());
            view.setDescription(dbView.getDescription());
            Iterator iter2 = dbView.iteratorOfAttributes();
            while (iter2.hasNext())
            {
               DBViewAttribute vAttr = (DBViewAttribute) iter2.next();
               DBTableAttribute tAttr = (DBTableAttribute) vAttr.getAttribute();
               String origName = tAttr.getName();
               view.addAttrOrigName (origName);
               view.addRelationName (tAttr.getParent().getName());
               Relation rel = relVector.getRelation (tAttr.getParent().getName());
               AttributeVector attrVec = rel.getAttributeVector();
               Attribute origAttr = attrVec.getAttributeByRole (origName);
               Attribute viewAttr = new Attribute (origAttr.getName(), origAttr.getSQLType(), origAttr.getJavaType(), origAttr.getStringType());
               viewAttr.setJavaTypeLength (origAttr.getJavaTypeLength());
               viewAttr.setJavaTypeScale (origAttr.getJavaTypeScale());
               viewAttr.setRole (vAttr.getName());
               viewAttr.setDescription(origAttr.getDescription());

               view.addAttribute (viewAttr);
            }
            view.setWhereClause (dbView.getWhereClause());
            viewVector.addView (view);
         }
      }
      attrVector.writeHtmlFile (path);
		
      relVector.sort();
      relVector.writeSQLFiles (path, box.getSelectedIndex());
      relVector.writeJavaFiles (path);
      relVector.writeHtmlFile (path);

      queVector.writeJavaFiles (path, relVector);
      queVector.writeHtmlFile (path);

      viewVector.writeSQLFiles (path);
      viewVector.writeJavaFiles (path);
      viewVector.writeHtmlFile (path);
   }
}

/*
 * $Log: CreateDBFilesAction.java,v $
 * Revision 1.3  2003/10/07 07:21:49  ariseppi
 * misc. corrections
 *
 */
