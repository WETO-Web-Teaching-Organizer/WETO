/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.cs.dbswtool;



/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:48 $
 * @version   $Revision: 1.2 $
 */
public interface RelationStore
{

   // Return codes for internal use by RelationVector:
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final int expectingRelationString = 1;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final int expectingRelationName = 2;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final int expectingAttributeString = 3;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final int expectingAttributeName = 4;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final int expectingAttributeRole = 5;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final int expectingPrimaryKey = 6;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final int expectingNotNull = 7;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final int expectingPackageString = 8;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final int expectingPackageName = 9;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final int expectingUnique = 10;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final int expectingForeignKey = 11;

   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String htmlFileHeader1 =
      "<!doctype html public '-//w3c//dtd html 4.0 transitional//en'>";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String htmlFileHeader2 =
      "<html><head><meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1'>";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String htmlFileHeader3 =
      "<title>Relations</title></head>";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String htmlFileHeader4 =
      "<body text='#000000' bgcolor='#FFFFFF' link='#0000EE' vlink='#551A8B' alink='#FF0000'>";

   // Return codes
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final int relationFileReadOk = -1;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final int relationFileReadFailed = -2;

   // Add a relation to a relation store:
   /**
    * Access method for an one to n association.
    *
    * @param newRelation  The object added.
    */
   void addRelation (Relation newRelation);

   // Get a relation from a relation store:
   /**
    * Get the relation attribute of the RelationStore object
    *
    * @param relationName  No description provided
    * @return              The relation value
    */
   Relation getRelation (String relationName);

   // Read relations from a relation store, assume base
   // attributes have already been read in AttributeVector
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param projectdir  No description provided
    * @param filename    No description provided
    * @param as          No description provided
    * @return            No description provided
    */
   int readRelationFile (String projectdir, String filename, AttributeVector as);

   // Write SQL table creation statements in the .sql files:
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param projectdir  No description provided
    * @return            No description provided
    */
   int writeSQLFiles (String projectdir);

   // Write Java classes in .java files
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param projectdir  No description provided
    * @return            No description provided
    */
   int writeJavaFiles (String projectdir);

   // Write Java classes in .java files
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param projectdir  No description provided
    * @return            No description provided
    */
   int writeHtmlFile (String projectdir);
}

/*
 * $Log: RelationStore.java,v $
 * Revision 1.2  2003/10/07 07:21:48  ariseppi
 * misc. corrections
 *
 */
