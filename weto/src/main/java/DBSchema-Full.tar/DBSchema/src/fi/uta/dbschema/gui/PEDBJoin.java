/*
 * Created on 26.7.2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package fi.uta.dbschema.gui;

import java.awt.Cursor;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.HashMap;
import java.util.Iterator;

import javax.swing.Box;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import de.uni_paderborn.fujaba.app.FrameMain;
import de.uni_paderborn.fujaba.asg.ASGElement;
import de.uni_paderborn.fujaba.gui.PEColumn;
import de.uni_paderborn.fujaba.gui.PEEditPanel;
import de.uni_paderborn.fujaba.gui.PERow;
import de.uni_paderborn.fujaba.gui.PETextField;
import de.uni_paderborn.fujaba.uml.UMLProject;
import fi.uta.dbschema.metamodel.DBForeignKey;
import fi.uta.dbschema.metamodel.DBJunctionPair;
import fi.uta.dbschema.metamodel.DBSchema;
import fi.uta.dbschema.metamodel.DBTable;
import fi.uta.dbschema.metamodel.DBTableAttribute;
import fi.uta.dbschema.metamodel.DBTableAttributeJunction;
import fi.uta.dbschema.metamodel.DBTableJunction;
import fi.uta.dbschema.metamodel.DBUnique;
import fi.uta.dbschema.metamodel.DBView;
import fi.uta.dbschema.metamodel.DBViewAttribute;
import fi.uta.dbschema.metamodel.DBViewJoin;

/**
 * @author as66033
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class PEDBJoin extends DBPropertyEditor
{
	PEDBCombo firstTableChoise;
	PEDBCombo secondTableChoise;
	PEDBCheck makeViews;

	PETextField tableName;

	public PEDBJoin(JFrame frame, String title, boolean modal)
	{
		super(frame);
		setModal(modal);
		setTitle(title);
		try
		{
			pack();
			this.setTitle("Join editor");
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		initPE();
	}

	public PEDBJoin(JFrame frame)
	{
		this(frame, "", false);
	}

	public PEDBJoin(JFrame frame, boolean modal)
	{
		this(frame, "", modal);
	}

	public PEDBJoin(JFrame frame, String title)
	{
		this(frame, title, false);
	}

	public DBTable getFirstTableChoise()
	{
		return (DBTable) firstTableChoise.getSelectedObject();
	}

	public void setFirstTableChoise(DBTable table)
	{
		firstTableChoise.setSelectedObject(table);
	}

	public DBTable getSecondTableChoise()
	{
		return (DBTable) secondTableChoise.getSelectedObject();
	}

	public void setSecondTableChoise(DBTable table)
	{
		secondTableChoise.setSelectedObject(table);
	}

	public String getTableName()
	{
		return tableName.getText();
	}

	public void setMakeViews(boolean makeViews)
	{
		this.makeViews.setSelected(makeViews);
	}

	public boolean getMakeViews()
	{
		return this.makeViews.isSelected();
	}

	protected void additionalProperties(PEEditPanel panel)
	{
		tableName = new PETextField(this, "Name of the joined table");

		firstTableChoise = new PEDBCombo(this, "First table to be joined");
		secondTableChoise = new PEDBCombo(this, "Second table to be joined");

		makeViews =
			new PEDBCheck(
				this,
				"Create views",
				"Create views containing attributes from the old tables");

		Object source = UMLProject.get().getCurrentDiagram();
		if (source instanceof DBSchema)
		{
			DBSchema dbSchema = (DBSchema) source;
			Iterator it = dbSchema.iteratorOfItems();
			while (it.hasNext())
			{
				Object item = it.next();
				if (item instanceof DBTable)
				{
					firstTableChoise.addObject(item);
				}
			}
		}

		refreshSecondChoise();

		firstTableChoise.addItemListener(new PEDBJoin_ItemListener(this));

		PEColumn column = new PEColumn(this);

		PERow row = new PERow(this);
		row.add(firstTableChoise);
		row.add(Box.createVerticalGlue());
		row.add(secondTableChoise);

		column.add(row);
		column.add(tableName);
		column.add(makeViews);

		panel.add(column);
	}

	public void buttonOK_actionPerformed(ActionEvent e)
	{
		//		 super.buttonOK_actionPerformed (e);
		if (getFrame() != null)
		{
			getFrame().setCursor(
				Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
		}
		if (getFirstTableChoise() == null)
		{
			JOptionPane.showMessageDialog(
				FrameMain.get().getFrame(),
				"Error: First table not selected.",
				"Select first table",
				JOptionPane.ERROR_MESSAGE);
			return;
		}
		if (getSecondTableChoise() == null)
		{
			JOptionPane.showMessageDialog(
				FrameMain.get().getFrame(),
				"Error: Second table not selected.",
				"Select second table",
				JOptionPane.ERROR_MESSAGE);
			return;
		}
		if (getTableName().equals(""))
		{
			JOptionPane.showMessageDialog(
				FrameMain.get().getFrame(),
				"Error: New table name missing.",
				"Insert new table name",
				JOptionPane.ERROR_MESSAGE);
			return;
		}
		if (getMakeViews())
		{
			if (getTableName().equals(getFirstTableChoise().getName()))
			{
				JOptionPane.showMessageDialog(
					FrameMain.get().getFrame(),
					"Error: The name of the first table is the same\n"
						+ "as the name of the joined table. Cannot create a view.",
					"Illegal name",
					JOptionPane.ERROR_MESSAGE);
				return;
			}
			if (getTableName().equals(getSecondTableChoise().getName()))
			{
				JOptionPane.showMessageDialog(
					FrameMain.get().getFrame(),
					"Error: The name of the second table is the same\n"
						+ "as the name of the joined table. Cannot create a view.",
					"Illegal name",
					JOptionPane.ERROR_MESSAGE);
				return;
			}
		}

		try
		{
			setVisible(false);
			parse();
			UMLProject.get().refreshDisplay();
		} finally
		{
			if (getFrame() != null)
			{
				getFrame().setCursor(
					Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
			}
		}
	}

	protected void unparse()
	{

	}

	/* (non-Javadoc)
	 * @see de.uni_paderborn.fujaba.gui.BasicPropertyEditor#parse()
	 */
	protected void parse()
	{
		DBSchema dbSchema = null;
		Object diagram = UMLProject.get().getCurrentDiagram();
		if (diagram instanceof DBSchema)
		{
			dbSchema = (DBSchema) diagram;
		} else
		{
			return;
		}
		ASGElement incr = getIncrement();

		DBTable firstTable = getFirstTableChoise();
		DBTable secondTable = getSecondTableChoise();
		if (firstTable.sizeOfAttributes() < secondTable.sizeOfAttributes())
		{
			DBTable tempTable = firstTable;
			firstTable = secondTable;
			secondTable = tempTable;
		}
		String oldName = firstTable.getName();
		firstTable.setName(getTableName());
		HashMap attrsInFirst = new HashMap();

		/*
		 * Are there foreign keys pointing from the first table to the
		 * second or the other way around?
		 */

		boolean fromFirst = false;
		boolean fromSecond = false;

		Iterator iter = secondTable.iteratorOfForeignKeys();
		while (iter.hasNext())
		{
			DBForeignKey fk = (DBForeignKey) iter.next();
			if (fk.getRevTable() == firstTable)
			{
				Iterator iter2 = fk.iteratorOfJunctionPairs();
				while (iter2.hasNext())
				{
					DBJunctionPair pair = (DBJunctionPair) iter2.next();
					attrsInFirst.put(
						pair.getOriginalJunction().getTarget(),
						pair.getRevJunction().getTarget());
					if (!fromSecond)
					{
						fromSecond = true;
					}
				}
				fk.removeYou();
			}
		}
		iter = firstTable.iteratorOfForeignKeys();
		while (iter.hasNext())
		{
			DBForeignKey fk = (DBForeignKey) iter.next();
			if (fk.getRevTable() == secondTable)
			{
				Iterator iter2 = fk.iteratorOfJunctionPairs();
				while (iter2.hasNext())
				{
					DBJunctionPair pair = (DBJunctionPair) iter2.next();
					attrsInFirst.put(
						pair.getRevJunction().getTarget(),
						pair.getOriginalJunction().getTarget());
					if (!fromFirst)
					{
						fromFirst = true;
					}
				}
				fk.removeYou();
			}
		}
		boolean secondHasPrimary = !fromFirst && fromSecond;

		/*
		 * Other primary is only interesting if there are foreign keys from
		 * both tables to each other.
		 */
		HashMap otherPrimary = null;

		if (secondHasPrimary)
		{
			iter = firstTable.iteratorOfAttributes();
			while (iter.hasNext())
			{
				DBTableAttribute attr = (DBTableAttribute) iter.next();
				if (attr.getPrimaryKeyValue())
				{
					attr.setPrimaryKeyValue(false);
				}
			}
		} else
		{
			if (fromFirst && fromSecond)
			{
				otherPrimary = new HashMap();
			}
			iter = secondTable.iteratorOfAttributes();
			while (iter.hasNext())
			{
				DBTableAttribute attr = (DBTableAttribute) iter.next();
				if (attr.getPrimaryKeyValue())
				{
					attr.setPrimaryKeyValue(false);
					if (fromFirst && fromSecond)
					{
						otherPrimary.put(attr.getName(), "");
					}
				}
			}
		}
		iter = secondTable.iteratorOfAttributes();
		while (iter.hasNext())
		{
			DBTableAttribute attr = (DBTableAttribute) iter.next();
			DBTableAttribute firstTableAttr =
				(DBTableAttribute) attrsInFirst.get(attr);
			if (firstTableAttr == null)
			{
				DBTableAttribute newAttr = (DBTableAttribute) attr.clone();
				firstTable.addToAttributes(newAttr);
				attrsInFirst.put(attr, newAttr);
			} else
			{
				if (secondHasPrimary)
				{
					if (attr.getPrimaryKeyValue())
					{
						firstTableAttr.setPrimaryKeyValue(true);
					}
				}
			}
		}

		iter = secondTable.iteratorOfUniques();
		while (iter.hasNext())
		{
			DBUnique uni = (DBUnique) iter.next();
			DBUnique newUni = new DBUnique();
			Iterator iter2 = uni.iteratorOfAttributes();
			while (iter2.hasNext())
			{
				Object oldAttr = iter2.next();
				DBTableAttribute newAttr =
					(DBTableAttribute) attrsInFirst.get(oldAttr);
				newUni.addToAttributes(newAttr);
			}
			newUni.setParent(firstTable);
		}

		if (otherPrimary != null)
		{
			Iterator iter2 = firstTable.iteratorOfAttributes();
			boolean currentPrimary = true;
			while (iter2.hasNext() && currentPrimary)
			{
				ASGElement elem = (ASGElement) iter.next();
				if (!otherPrimary.containsKey(elem.getName()))
				{
					currentPrimary = false;
				}
			}
			if (!currentPrimary)
			{
				DBUnique uni = (DBUnique) iter.next();
				DBUnique newUni = new DBUnique();
				Iterator iter3 = firstTable.iteratorOfAttributes();
				while (iter3.hasNext())
				{
					DBTableAttribute attr = (DBTableAttribute) iter3.next();
					if (otherPrimary.containsKey(attr.getName()))
					{
						newUni.addToAttributes(attr);
					}
				}
				newUni.setParent(firstTable);
			}
		}

		iter = secondTable.iteratorOfForeignKeys();
		while (iter.hasNext())
		{
			DBForeignKey key = (DBForeignKey) iter.next();
			if (!keyExists(key, firstTable))
			{
				DBForeignKey newKey = new DBForeignKey();
				newKey.setOriginalTable(firstTable);
				newKey.setRevTable(key.getRevTable());
				Iterator iter2 = key.iteratorOfJunctionPairs();
				while (iter2.hasNext())
				{
					DBJunctionPair pair = (DBJunctionPair) iter2.next();
					DBTableAttribute own =
						pair.getOriginalJunction().getTarget();
					DBTableAttribute otherAttr =
						pair.getRevJunction().getTarget();

					DBTableAttribute ownAttr =
						(DBTableAttribute) attrsInFirst.get(own);

					DBJunctionPair newPair = new DBJunctionPair();
					newKey.addToJunctionPairs(newPair);
					DBTableAttributeJunction origJunc =
						new DBTableAttributeJunction(ownAttr);
					origJunc.setPair(newPair);
					newPair.setOriginalJunction(origJunc);
					DBTableAttributeJunction revJunc =
						new DBTableAttributeJunction(otherAttr);
					revJunc.setPair(newPair);
					newPair.setRevJunction(revJunc);
				}
				dbSchema.addToItems(newKey);
			}
		}

		iter = secondTable.iteratorOfRevForeignKeys();
		while (iter.hasNext())
		{
			DBForeignKey key = (DBForeignKey) iter.next();
			if (!revKeyExists(key, firstTable))
			{
				DBForeignKey newKey = new DBForeignKey();
				newKey.setOriginalTable(key.getOriginalTable());
				newKey.setRevTable(firstTable);
				Iterator iter2 = key.iteratorOfJunctionPairs();
				while (iter2.hasNext())
				{
					DBJunctionPair pair = (DBJunctionPair) iter2.next();
					DBTableAttribute ownAttr =
						pair.getOriginalJunction().getTarget();
					DBTableAttribute other = pair.getRevJunction().getTarget();

					DBTableAttribute otherAttr =
						(DBTableAttribute) attrsInFirst.get(other);

					DBJunctionPair newPair = new DBJunctionPair();
					newKey.addToJunctionPairs(newPair);
					DBTableAttributeJunction origJunc =
						new DBTableAttributeJunction(ownAttr);
					origJunc.setPair(newPair);
					newPair.setOriginalJunction(origJunc);
					DBTableAttributeJunction revJunc =
						new DBTableAttributeJunction(otherAttr);
					revJunc.setPair(newPair);
					newPair.setRevJunction(revJunc);
				}
				dbSchema.addToItems(newKey);
			}
		}

		if (this.getMakeViews())
		{
			DBView firstView = new DBView(oldName);
			firstView.setJavaPackage(firstTable.getJavaPackage());
			iter = firstTable.iteratorOfAttributes();
			while (iter.hasNext())
			{
				DBTableAttribute attr = (DBTableAttribute) iter.next();
				if (!attrsInFirst.containsValue(attr))
				{
					DBViewAttribute viewAttr = new DBViewAttribute();
					viewAttr.setAttribute(attr);
					viewAttr.setName(attr.getName());
					viewAttr.setParent(firstView);
				}
			}
			DBViewJoin newJoin = new DBViewJoin();

			DBTableJunction firstJunc = new DBTableJunction(firstView);
			DBTableJunction secondJunc = new DBTableJunction(firstTable);

			secondJunc.setAdornment(DBTableJunction.FILLED_BOX);

			newJoin.setFirstJunction(firstJunc);
			newJoin.setSecondJunction(secondJunc);

			firstView.addToJoins(newJoin);

			dbSchema.addToItems(firstView);
			dbSchema.addToItems(newJoin);

			DBView secondView = new DBView(secondTable.getName());
			secondView.setJavaPackage(secondTable.getJavaPackage());

			iter = secondTable.iteratorOfAttributes();
			while (iter.hasNext())
			{
				ASGElement oldAttr = (ASGElement) iter.next();
				DBTableAttribute newAttr =
					(DBTableAttribute) attrsInFirst.get(oldAttr);
				DBViewAttribute viewAttr = new DBViewAttribute();
				viewAttr.setAttribute(newAttr);
				viewAttr.setName(oldAttr.getName());
				viewAttr.setParent(secondView);
			}
			newJoin = new DBViewJoin();

			firstJunc = new DBTableJunction(secondView);
			secondJunc = new DBTableJunction(firstTable);

			secondJunc.setAdornment(DBTableJunction.FILLED_BOX);

			newJoin.setFirstJunction(firstJunc);
			newJoin.setSecondJunction(secondJunc);

			secondView.addToJoins(newJoin);

			dbSchema.addToItems(secondView);
			dbSchema.addToItems(newJoin);
		}

		secondTable.removeYou();
	}

	/* (non-Javadoc)
	 * @see de.uni_paderborn.fujaba.gui.BasicPropertyEditor#cancel()
	 */
	protected void cancel()
	{
		setVisible(false);
		dispose();
	}

	private boolean keyExists(DBForeignKey key, DBTable table)
	{
		Iterator iter = null;
		iter = table.iteratorOfForeignKeys();
		while (iter.hasNext())
		{
			DBForeignKey testKey = (DBForeignKey) iter.next();
			if (testKey.getRevTable() == key.getRevTable()
				&& testKey.sizeOfJunctionPairs() == key.sizeOfJunctionPairs())
			{
				Iterator iter2 = key.iteratorOfJunctionPairs();
				while (iter2.hasNext())
				{
					DBJunctionPair pair = (DBJunctionPair) iter2.next();
					Iterator iter3 = testKey.iteratorOfJunctionPairs();
					boolean matched = false;
					while (iter3.hasNext() && !matched)
					{
						DBJunctionPair testPair = (DBJunctionPair) iter3.next();
						if (testPair.getRevJunction().getTarget()
							== pair.getRevJunction().getTarget()
							&& testPair
								.getOriginalJunction()
								.getTarget()
								.getName()
								.equals(
								pair
									.getOriginalJunction()
									.getTarget()
									.getName()))
						{
							matched = true;
						}
					}
					if (!matched)
					{
						return false;
					}
				}
				return true;
			}
		}
		return false;
	}

	private boolean revKeyExists(DBForeignKey key, DBTable table)
	{
		Iterator iter = null;
		iter = table.iteratorOfRevForeignKeys();
		while (iter.hasNext())
		{
			DBForeignKey testKey = (DBForeignKey) iter.next();
			if (testKey.getOriginalTable() == key.getOriginalTable()
				&& testKey.sizeOfJunctionPairs() == key.sizeOfJunctionPairs())
			{
				Iterator iter2 = key.iteratorOfJunctionPairs();
				while (iter2.hasNext())
				{
					DBJunctionPair pair = (DBJunctionPair) iter2.next();
					Iterator iter3 = testKey.iteratorOfJunctionPairs();
					boolean matched = false;
					while (iter3.hasNext() && !matched)
					{
						DBJunctionPair testPair = (DBJunctionPair) iter3.next();
						if (testPair
							.getRevJunction()
							.getTarget()
							.getName()
							.equals(pair.getRevJunction().getTarget().getName())
							&& testPair.getOriginalJunction().getTarget()
								== pair.getOriginalJunction().getTarget())
						{
							matched = true;
						}
					}
					if (!matched)
					{
						return false;
					}
				}
				return true;
			}
		}
		return false;
	}

	public void refreshSecondChoise()
	{
		secondTableChoise.removeAllItems();
		DBTable firstTable = getFirstTableChoise();
		if (firstTable == null)
		{
			return;
		}
		HashMap added = new HashMap();
		Iterator iter = firstTable.iteratorOfForeignKeys();
		while (iter.hasNext())
		{
			DBForeignKey key = (DBForeignKey) iter.next();
			DBTable table = key.getRevTable();
			if (!added.containsKey(table))
			{
				secondTableChoise.addObject(table);
				added.put(table, "");
			}
		}
		iter = firstTable.iteratorOfRevForeignKeys();
		while (iter.hasNext())
		{
			DBForeignKey key = (DBForeignKey) iter.next();
			DBTable table = key.getOriginalTable();
			if (!added.containsKey(table))
			{
				secondTableChoise.addObject(table);
				added.put(table, "");
			}
		}
	}
}

class PEDBJoin_ItemListener implements ItemListener
{
	PEDBJoin joinGui;

	public PEDBJoin_ItemListener(PEDBJoin j)
	{
		joinGui = j;
	}

	public void itemStateChanged(ItemEvent e)
	{
		joinGui.refreshSecondChoise();
	}
}