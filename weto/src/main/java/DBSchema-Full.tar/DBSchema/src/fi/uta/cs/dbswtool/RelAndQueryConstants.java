/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.cs.dbswtool;

/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:48 $
 * @version   $Revision: 1.2 $
 */
public interface RelAndQueryConstants
{

   public static final String[] databases = {"Generic SQL92", "MySQL", "HSQLDB"};
   public static final int generic = 0;
   public static final int mySql = 1;
   public static final int hsqldb = 2;
   public static final int oldPostgre = 3;

   // closeParenthesisChar
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final char closeParenthesisChar = ')';

   // Reserved words, which appear in the file describing relations:
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String relationString = "relation";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String packageString = "package";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String attributeString = "attribute";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String endRelationString = "endrelation";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String primaryKeyString = "primary_key";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String uniqueString = "unique";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String foreignKeyString = "foreign_key";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String queryString = "query";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String relationsString = "relations";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String whereString = "where";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String viewString = "view";

   // Characters defined as constant strings,
   // these are used in Java and SQL code generation:
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String tabString = "    ";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String tab2String = "        ";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String tab3String = "            ";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String tab4String = "                ";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String comma = ",";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String endLine = "\n";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String openParenthesis = "(";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String closeParenthesis = ")";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String openCurly = "{";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String closeCurly = "}";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String semicolon = ";";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String equalsChar = "=";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String slashChar = "/";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String period = ".";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String questionMark = "?";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String javaString = "java";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String sqlString = "sql";

   // Words used in JDBC/SQL code generation:
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String sqlDropTableString = "drop table";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String sqlCreateTableString = "create table";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String sqlDropViewString = "drop view";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String sqlCreateViewString = "create view";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String sqlPrimaryKeyString = "primary key";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String sqlUniqueString = "unique";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String sqlForeignKeyString = "foreign key";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String sqlReferencesString = "references";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String sqlNotNullString = "not null";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String sqlInsertString = "insert into ";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String sqlValuesString = "values";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String sqlUpdateString = "update ";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String sqlDeleteString = "delete from ";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String sqlSelectAllString = "select * from ";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String sqlSetString = "set";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String sqlWhereString = "where";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String sqlQuoteChar = "'";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String sqlPrepareString = "String prepareString = \"";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String sqlPreparedStatement = "PreparedStatement ps = con.prepareStatement(prepareString);";

   // Words used in Html code generation
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String attributeHtmlFileName = "attributes.html";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String relationHtmlFileName = "relations.html";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String queryHtmlFileName = "queries.html";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String viewHtmlFileName = "views.html";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String htmlParagraph = "<p>";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String htmlLineBreak = "<br>";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String htmlBeginBold = "<b>";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String htmlEndBold = "</b>";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String beginHtmlTable = "<table>";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String endHtmlTable = "</table>";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String beginHtmlTableRow = "<tr>";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String endHtmlTableRow = "</tr>";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String beginHtmlTableColumn = "<td>";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String endHtmlTableColumn = "</td>";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String endHtmlFile = "</body>\n </html>\n";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String beginHtmlTarget = "<a name='";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String endHtmlTarget = "'></a>";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String beginHtmlHref = "<a href='#";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String endHtmlHref = "'>";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String endHtmlA = "</a>";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String relationNameHtmlString = "<b>Relation name</b>";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String queryNameHtmlString = "<b>Query name</b>";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String roleHtmlString = "<b>Relation attribute</b>";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String baseAttributeHtmlString = "<b>Base attribute Name</b>";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String notNullHtmlString = "<b>Not Null</b>";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String htmlBeginPrimaryKeyString = "primary key ( ";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String htmlEndPrimaryKeyString = " )";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String htmlBeginUniqueString = "unique ( ";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String htmlEndUniqueString = " ) ";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String htmlBeginForeignKeyString = "foreign key ( ";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String htmlReferencesString = ") references ";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String htmlEndForeignKeyString = " )";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String sqlHtmlString = "<b>SQL Data Type</b>";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String javaHtmlString = "<b>Java Data Type</b>";

// ------------------------------------------------------------
// Constants for code generation
// ------------------------------------------------------------

   // Words and prefixes used in Java code generation
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String javaPublicString = "public";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String javaPrivateString = "private";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String javaThisPrefix = "this.";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String javaAssignString = "=";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String javaReturnString = "return";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String javaVoidString = "void";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String javaTempString = "temp";   
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String javaPackageString = "package";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String javaCommentString = "//";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String javaTryString = "try";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String javaCatchString = "catch";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String javaCatchSqlString = "catch (SQLException e) {";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String javaThrowSqlString = "throw e;";
   /**
    * Prefix for database access class files.
    */
   final String javaDbPrefix = "Db";
   /**
    * Prefix for bean class files.
    */
   final String javaBeanPrefix = "Bean";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String javaImportSqlString = "import java.sql.*;";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String javaImportIteratorString = "import java.util.Iterator;";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String javaImportSqlDatatypesString = "import fi.uta.cs.sqldatatypes.*;";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String javaImportSqlDatamodelString = "import fi.uta.cs.sqldatamodel.*;";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   final String javaDbClassInheritance = "extends SqlAssignableObject implements Cloneable";
   /**
    * Suffix for database access class attribute names.
    */
   final String javaDbAttributeSuffix = "Data";
}

/*
 * $Log: RelAndQueryConstants.java,v $
 * Revision 1.2  2003/10/07 07:21:48  ariseppi
 * misc. corrections
 *
 */
