/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this added code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.gui;

import java.awt.Cursor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Iterator;

import javax.swing.JFrame;

import de.uni_paderborn.fujaba.asg.ASGElement;
import de.uni_paderborn.fujaba.gui.CMAFocusListener;
import de.uni_paderborn.fujaba.gui.PEColumn;
import de.uni_paderborn.fujaba.gui.PEEditPanel;
import de.uni_paderborn.fujaba.gui.PETextField;
import de.uni_paderborn.fujaba.uml.UMLProject;
import de.upb.tools.fca.FLinkedList;
import fi.uta.dbschema.metamodel.DBTable;
import fi.uta.dbschema.metamodel.DBTableAttribute;


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:51 $
 * @version   $Revision: 1.4 $
 */
public class PEDBAttribute extends DBPropertyEditor
{
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PETextField attributeName;
   
   PETextArea description;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PETextField sqlSize;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PETextField sqlScale;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBDataTypeSelection typeSelection;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBAttributeSelection attributeSelection;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBCheck primaryKeyModifier;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBCheck notNullModifier;

   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   FLinkedList addAttributes = new FLinkedList();
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   FLinkedList delAttributes = new FLinkedList();


   /**
    * Constructor for class PEDBAttribute
    *
    * @param frame  No description provided
    * @param title  No description provided
    * @param modal  No description provided
    */
   public PEDBAttribute (JFrame frame, String title, boolean modal)
   {
      super (frame);
      setModal (modal);
      setTitle (title);
      try
      {
         pack();
         this.setTitle ("Attribute Editor");
      }
      catch (Exception e)
      {
         e.printStackTrace();
      }
      initPE();

      addFocusListener (new CMAFocusListener (attributeName));

      attributeName.addActionListener (
         new ActionListener()
         {
            public void actionPerformed (ActionEvent e)
            {
               addButton_actionPerformed (e);
            }
         }
         );
   }


   /**
    * Constructor for class PEDBAttribute
    *
    * @param frame  No description provided
    */
   public PEDBAttribute (JFrame frame)
   {
      this (frame, "", false);
   }


   /**
    * Constructor for class PEDBAttribute
    *
    * @param frame  No description provided
    * @param modal  No description provided
    */
   public PEDBAttribute (JFrame frame, boolean modal)
   {
      this (frame, "", modal);
   }


   /**
    * Constructor for class PEDBAttribute
    *
    * @param frame  No description provided
    * @param title  No description provided
    */
   public PEDBAttribute (JFrame frame, String title)
   {
      this (frame, title, false);
   }


   /**
    * Sets the attributeName attribute of the PEDBAttribute object
    *
    * @param name  The new propertyName value
    */
   public void setAttributeName (String name)
   {
      attributeName.setText (name);
   }

   public void setDescription (String desc)
   {
	  description.setText (desc);
   }


   /**
    * Sets the sqlSize attribute of the PEDBAttribute object
    *
    * @param value  The new sqlSize value
    */
   public void setSqlSize (String value)
   {
      sqlSize.setText (value);
   }


   /**
    * Sets the sqlScale attribute of the PEDBAttribute object
    *
    * @param value  The new sqlSize value
    */
   public void setSqlScale (String value)
   {
      sqlScale.setText (value);
   }


   /**
    * Sets the sqlType attribute of the PEDBAttribute object
    *
    * @param value  The new sqlType value
    */
   public void setSqlType (String value)
   {
      typeSelection.setSqlType (value);
   }


   /**
    * Sets the javaType attribute of the PEDBAttribute object
    *
    * @param value  The new javaType value
    */
   public void setJavaType (String value)
   {
      typeSelection.setJavaType (value);
   }


   /**
    * Sets the primaryKeyModifier attribute of the PEDBAttribute object
    *
    * @param b  The new primaryKeyModifier value
    */
   public void setPrimaryKeyModifier (boolean b)
   {
      primaryKeyModifier.setSelected (b);
   }


   /**
    * Sets the notNullModifier attribute of the PEDBAttribute object
    *
    * @param b  The new notNullModifier value
    */
   public void setNotNullModifier (boolean b)
   {
      notNullModifier.setSelected (b);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param panel  No description provided
    */
   protected void additionalProperties (PEEditPanel panel)
   {
      attributeName = new PETextField (this, "Attribute Name");
	  
	  description = new PETextArea (this, "Description");
	  
	  description.setStatus ("Enter the description for the table");
	
      sqlSize = new PETextField (this, "SQL Type Size");
      sqlSize.setReadOnly (true);
      sqlScale = new PETextField (this, "SQL Type Scale");
      sqlScale.setReadOnly (true);
      attributeSelection = new PEDBAttributeSelection (this);
      typeSelection = new PEDBDataTypeSelection (this);
      primaryKeyModifier = new PEDBCheck (this, "Primary Key Modifier", "Attribute is a part of a primary key");
      notNullModifier = new PEDBCheck (this, "Not Null Modifier", "Attribute is not null");

      attributeName.setText (getAttributeName());
      attributeName.setStatus ("Enter the name of the attribute");

      sqlSize.setText ("");
      sqlSize.setStatus ("Enter the length of the SQL type");

      sqlScale.setText ("");
      sqlScale.setStatus ("Enter the scale of the SQL type");

      attributeSelection.setAddListener (new PEDBAttribute_addButton_actionAdapter (this));
      attributeSelection.setRemoveListener (new PEDBAttribute_removeButton_actionAdapter (this));
      attributeSelection.setModifyListener (new PEDBAttribute_modifyButton_actionAdapter (this));

      PEColumn column = new PEColumn (this);

      column.add (attributeName);
	  column.add (description);
      column.add (primaryKeyModifier);
      column.add (notNullModifier);
      column.add (typeSelection);
      column.add (sqlSize);
      column.add (sqlScale);
      column.add (attributeSelection);

      panel.add (column);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void unparse()
   {
      if (getIncrement() instanceof DBTable)
      {
         DBTable selectedTable = (DBTable) getIncrement();
         attributeName.setText (getAttributeName());
         attributeSelection.setIncrement (selectedTable);
         attributeName.selectAll();
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected void parse()
   {
      ASGElement incr = getIncrement();

      if (incr instanceof DBTable)
      {
         DBTableAttribute attribute = null;

         Iterator iter = addAttributes.iterator();
         while (iter.hasNext())
         {
            attribute = (DBTableAttribute) iter.next();
            attribute.setParent ((DBTable) incr);
         }
         addAttributes.clear();

         iter = delAttributes.iterator();
         while (iter.hasNext())
         {
            attribute = (DBTableAttribute) iter.next();

            attribute.removeYou();
         }
         delAttributes.clear();
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected void cancel()
   {
      addAttributes.clear();
      delAttributes.clear();
      setVisible (false);
      dispose();
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void buttonOK_actionPerformed (ActionEvent e)
   {
//      super.buttonOK_actionPerformed (e);
      if (getFrame() != null)
      {
         getFrame().setCursor (Cursor.getPredefinedCursor (Cursor.WAIT_CURSOR));
      } // if

      try
      {
         setVisible (false);
         parse();
         UMLProject.get().refreshDisplay();
      }
      finally
      {
         if (getFrame() != null)
         {
            getFrame().setCursor (Cursor.getPredefinedCursor (Cursor.DEFAULT_CURSOR));
         }
      }
   }


   /**
    * Access method for an one to n association.
    *
    * @param e  The object added.
    */

   void addButton_actionPerformed (ActionEvent e)
   {
      if ( (typeSelection.getSqlType() != null) &&  (typeSelection.getSqlType().length() > 0) &&  (attributeName.getText().length() > 0))
      {
         DBTableAttribute newAttribute = new DBTableAttribute();
         newAttribute.setName (attributeName.getText());
		 newAttribute.setDescription (description.getText());
         newAttribute.setPrimaryKeyValue (primaryKeyModifier.isSelected());
         newAttribute.setNotNullValue (notNullModifier.isSelected());
		 if(sqlSize.getText().equals("") && sqlSize.isEnabled()) {
			newAttribute.setSqlSize (DBTableAttribute.NOT_DEFINED);
		 }
         try
         {
            newAttribute.setSqlSize (Integer.parseInt (sqlSize.getText()));
         }
         catch (NumberFormatException e2)
         {
         }

		if(sqlScale.getText().equals("") && sqlScale.isEnabled()) {
		   newAttribute.setSqlScale (DBTableAttribute.NOT_DEFINED);
		}
         try
         {
            newAttribute.setSqlScale (Integer.parseInt (sqlScale.getText()));
         }
         catch (NumberFormatException e2)
         {
         }

         newAttribute.setSqlType (typeSelection.getSqlType());

         String javaType = typeSelection.getJavaType();
         if (javaType == null)
         {
            javaType = "";
         }

         newAttribute.setJavaType (javaType);

         addAttributes.add (newAttribute);
         attributeSelection.addToList (newAttribute, newAttribute.getName() + ": " + newAttribute.getCompleteSqlType());
         attributeName.setText ("");
         attributeName.requestFocus();

         primaryKeyModifier.setSelected (false);
         notNullModifier.setSelected (false);
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   protected void removeButton_actionPerformed (ActionEvent e)
   {
      ASGElement incr = attributeSelection.getListSelectedIncr();
      if (incr != null)
      {
         if (incr instanceof DBTableAttribute)
         {
            DBTableAttribute attribute = (DBTableAttribute) incr;
         }
         delAttributes.add (incr);
         attributeSelection.removeFromList (incr);
         addAttributes.remove (incr);
      }
   }


   /**
    * Sets the increment attribute of the PEDBAttribute object
    *
    * @param incr  The new increment value
    */
   public void setIncrement (ASGElement incr)
   {
      if (incr instanceof DBTableAttribute)
      {
         super.setIncrement ( ((DBTableAttribute) incr).getParent());
         attributeSelection.getList().selectIncrement (incr);
      }
      else
      {
         super.setIncrement (incr);
      }
      if (getTableIncrement() != null)
      {
         setTitle ("Attribute Editor: " + getTableIncrement().getName());
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   void modifyButton_actionPerformed (ActionEvent e)
   {
      ASGElement oldIncr = attributeSelection.getListSelectedIncr();
      if (oldIncr != null && oldIncr instanceof DBTableAttribute &&  (typeSelection.getSqlType() != null) &&  (typeSelection.getSqlType().length() > 0) &&  (attributeName.getText().length() > 0))
      {
         // Fix me: The new editor should make it better handling modified items.
         DBTableAttribute curAttribute = (DBTableAttribute) oldIncr;

         DBTableAttribute oldAttribute = new DBTableAttribute();
         oldAttribute.setName (curAttribute.getName());
		 oldAttribute.setDescription (curAttribute.getDescription());
         oldAttribute.setPrimaryKeyValue (curAttribute.getPrimaryKeyValue());
         oldAttribute.setNotNullValue (curAttribute.getNotNullValue());
         oldAttribute.setSqlSize (curAttribute.getSqlSize());

         oldAttribute.setSqlScale (curAttribute.getSqlScale());

         oldAttribute.setSqlType (curAttribute.getSqlType());
         oldAttribute.setJavaType (curAttribute.getJavaType());

         try
         {
            curAttribute.setSqlSize (Integer.parseInt (sqlSize.getText()));
         }
         catch (NumberFormatException e2)
         {
         }

         try
         {
            curAttribute.setSqlScale (Integer.parseInt (sqlScale.getText()));
         }
         catch (NumberFormatException e2)
         {
         }

         curAttribute.setName (attributeName.getText());
		curAttribute.setDescription (description.getText());
         curAttribute.setPrimaryKeyValue (primaryKeyModifier.isSelected());
         curAttribute.setNotNullValue (notNullModifier.isSelected());

         try
         {
            curAttribute.setSqlSize (Integer.parseInt (sqlSize.getText()));
         }
         catch (NumberFormatException e2)
         {
         }

         try
         {
            curAttribute.setSqlScale (Integer.parseInt (sqlScale.getText()));
         }
         catch (NumberFormatException e2)
         {
         }

         curAttribute.setSqlType (typeSelection.getSqlType());

         String javaType = typeSelection.getJavaType();
         if (javaType == null)
         {
            javaType = "";
         }

         curAttribute.setJavaType (javaType);

         attributeSelection.removeFromList (curAttribute);
         attributeSelection.addToList (curAttribute, curAttribute.getName() + ": " + curAttribute.getCompleteSqlType());
      }
   }


   /**
    * Get the attributeName attribute of the PEDBAttribute object
    *
    * @return   The attributeName value
    */
   protected String getAttributeName()
   {
      if (getTableIncrement() != null)
      {
         int count = 1;
         Iterator iter = getTableIncrement().iteratorOfAttributes();
         while (iter.hasNext())
         {
            count++;
            iter.next();
         }

         return "attribute" + count;
      }

      return "New Attribute";
   }
   

   public String getDescription()
   {
	  return description.getText();
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void enableSqlSize()
   {
      sqlSize.setReadOnly (false);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void disableSqlSize()
   {
      sqlSize.setReadOnly (true);
      sqlSize.setText ("");
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void enableSqlScale()
   {
      sqlScale.setReadOnly (false);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void disableSqlScale()
   {
      sqlScale.setReadOnly (true);
      sqlScale.setText ("");
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:51 $
 * @version   $Revision: 1.4 $
 */
class PEDBAttribute_addButton_actionAdapter implements java.awt.event.ActionListener
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBAttribute adaptee;


   /**
    * Constructor for class PEDBAttribute_addButton_actionAdapter
    *
    * @param adaptee  No description provided
    */
   PEDBAttribute_addButton_actionAdapter (PEDBAttribute adaptee)
   {
      this.adaptee = adaptee;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void actionPerformed (ActionEvent e)
   {
      adaptee.addButton_actionPerformed (e);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:51 $
 * @version   $Revision: 1.4 $
 */
class PEDBAttribute_removeButton_actionAdapter implements java.awt.event.ActionListener
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBAttribute adaptee;


   /**
    * Constructor for class PEVariable_removeButton_actionAdapter
    *
    * @param adaptee  No description provided
    */
   PEDBAttribute_removeButton_actionAdapter (PEDBAttribute adaptee)
   {
      this.adaptee = adaptee;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void actionPerformed (ActionEvent e)
   {
      adaptee.removeButton_actionPerformed (e);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:51 $
 * @version   $Revision: 1.4 $
 */
class PEDBAttribute_modifyButton_actionAdapter implements java.awt.event.ActionListener
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBAttribute adaptee;


   /**
    * Constructor for class PEDBAttribute_modifyButton_actionAdapter
    *
    * @param adaptee  No description provided
    */
   PEDBAttribute_modifyButton_actionAdapter (PEDBAttribute adaptee)
   {
      this.adaptee = adaptee;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void actionPerformed (ActionEvent e)
   {
      adaptee.modifyButton_actionPerformed (e);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:51 $
 * @version   $Revision: 1.4 $
 */
class PEDBDataTypeSelection extends PEDoubleListSelection
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private PEDBAttribute attributeEditor;

   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private HashMap typeMap;

   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private HashMap typePairs;

   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private final String LENGTH = "len";
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private final String LENGTH_AND_SCALE = "lenandsca";


   /**
    * Constructor for class PEVariableSelection
    *
    * @param parent  No description provided
    */
   PEDBDataTypeSelection (DBPropertyEditor parent)
   {
      super (parent);
      getLeft().setHeader ("SQL data types");
      getRight().setHeader ("Java data types");
      fillLeftList();
      fillRightList();
      attributeEditor = (PEDBAttribute) parent;

      typePairs = new HashMap();

      typePairs.put ("bit", "SqlBoolean");
      typePairs.put ("tinyint", "SqlInteger");
      typePairs.put ("smallint", "SqlInteger");
      typePairs.put ("int", "SqlInteger");
      typePairs.put ("bigint", "SqlInteger");
      typePairs.put ("float", "SqlDecimal");
      typePairs.put ("real", "SqlReal");
      typePairs.put ("double", "SqlDecimal");
      typePairs.put ("numeric", "SqlDecimal");
      typePairs.put ("decimal", "SqlDecimal");
      typePairs.put ("time", "SqlTime");
      typePairs.put ("date", "SqlDate");
      typePairs.put ("char", "SqlChar");
      typePairs.put ("varchar", "SqlVarchar");
      typePairs.put ("longvarchar", "SqlLongvarchar");
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected void leftSelectionChanged()
   {
      String type = getSqlType();

      String enabled = (String) typeMap.get (type);

      if (enabled == null)
      {
         attributeEditor.disableSqlSize();
         attributeEditor.disableSqlScale();
      }
      else
      {
         if (enabled.equals (LENGTH))
         {
            attributeEditor.enableSqlSize();
            attributeEditor.disableSqlScale();
         }
         else if (enabled.equals (LENGTH_AND_SCALE))
         {
            attributeEditor.enableSqlSize();
            attributeEditor.enableSqlScale();
         }
         else
         {
            attributeEditor.disableSqlSize();
            attributeEditor.disableSqlScale();
         }
      }
      String javaType = (String) typePairs.get (type);
      setJavaType (javaType);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void fillLeftList()
   {
      clearLeft();
      left.add ("bit");
      left.add ("tinyint");
      left.add ("smallint");
      left.add ("int");
      left.add ("bigint");
      left.add ("float");
      left.add ("real");
      left.add ("double");
      left.add ("numeric");
      left.add ("decimal");
      left.add ("time");
      left.add ("date");
      left.add ("char");
      left.add ("varchar");
      left.add ("longvarchar");

      typeMap = new HashMap();
      typeMap.put ("varchar", LENGTH);
	  typeMap.put ("char", LENGTH);
      typeMap.put ("decimal", LENGTH_AND_SCALE);
	  typeMap.put ("numeric", LENGTH_AND_SCALE);
  	  typeMap.put ("double", LENGTH_AND_SCALE);
	  typeMap.put ("float", LENGTH_AND_SCALE);
   }


   /**
    * Get the sqlType attribute of the PEDBDataTypeSelection object
    *
    * @return   The sqlType value
    */
   public String getSqlType()
   {
      String name = (String) left.getList().getSelectedValue();
      return name;
   }


   /**
    * Sets the sqlType attribute of the PEDBDataTypeSelection object
    *
    * @param type  The new sqlType value
    */
   public void setSqlType (String type)
   {
      left.getList().setSelectedValue (type, true);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected void rightSelectionChanged()
   {
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void fillRightList()
   {
      clearRight();
      right.add ("SqlBoolean");
      right.add ("SqlInteger");
      right.add ("SqlReal");
      right.add ("SqlDecimal");
      right.add ("SqlChar");
      right.add ("SqlVarchar");
      right.add ("SqlLongvarchar");
      right.add ("SqlDate");
      right.add ("SqlTime");
   }


   /**
    * Get the javaType attribute of the PEDBDataTypeSelection object
    *
    * @return   The javaType value
    */
   public String getJavaType()
   {
      String name = (String) right.getList().getSelectedValue();
      return name;
   }


   /**
    * Sets the javaType attribute of the PEDBDataTypeSelection object
    *
    * @param type  The new javaType value
    */
   public void setJavaType (String type)
   {
      right.getList().setSelectedValue (type, true);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:51 $
 * @version   $Revision: 1.4 $
 */
class PEDBAttributeSelection extends PESingleSelection
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private PEDBAttribute attributeEditor;


   /**
    * Constructor for class PEDBAttributeSelection
    *
    * @param parent  No description provided
    */
   PEDBAttributeSelection (DBPropertyEditor parent)
   {
      super (parent);
      getList().setHeader ("Attributes");
      attributeEditor = (PEDBAttribute) parent;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected void listSelectionChanged()
   {
      ASGElement incr = list.getSelectedIncrement();
      if (incr instanceof DBTableAttribute)
      {
         DBTableAttribute attribute = (DBTableAttribute) incr;
         attributeEditor.setAttributeName (attribute.getName());
		 attributeEditor.setDescription(attribute.getDescription());
         attributeEditor.setPrimaryKeyModifier (attribute.getPrimaryKeyValue());
         attributeEditor.setNotNullModifier (attribute.getNotNullValue());
         if (attribute.getSqlSize() > DBTableAttribute.NO_NUMBER)
         {
            attributeEditor.setSqlSize (String.valueOf (attribute.getSqlSize()));
         }
         else
         {
            attributeEditor.setSqlSize ("");
         }
         if (attribute.getSqlScale() > DBTableAttribute.NO_NUMBER)
         {
            attributeEditor.setSqlScale (String.valueOf (attribute.getSqlScale()));
         }
         else
         {
            attributeEditor.setSqlScale ("");
         }
         attributeEditor.setSqlType (attribute.getSqlType());
         attributeEditor.setJavaType (attribute.getJavaType());

      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void fillList()
   {
      clearList();
      ASGElement incr = getIncrement();
      if (incr instanceof DBTable)
      {
         Iterator iter =  ((DBTable) incr).iteratorOfAttributes();
         DBTableAttribute attr;
         while (iter.hasNext())
         {
            attr = (DBTableAttribute) iter.next();
            if (attr != null)
            {
               addToList (attr, attr.getName() + ": " + attr.getCompleteSqlType());
            }
         }
      }
   }
}

/*
 * $Log: PEDBAttribute.java,v $
 * Revision 1.4  2003/10/07 07:21:51  ariseppi
 * misc. corrections
 *
 */
