/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this added code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.gui;

import java.awt.Cursor;
import java.awt.event.ActionEvent;

import javax.swing.JFrame;

import de.uni_paderborn.fujaba.asg.ASGDiagram;
import de.uni_paderborn.fujaba.asg.ASGElement;
import de.uni_paderborn.fujaba.gui.CMAFocusListener;
import de.uni_paderborn.fujaba.gui.PEColumn;
import de.uni_paderborn.fujaba.gui.PEEditPanel;
import de.uni_paderborn.fujaba.gui.PETextField;
import de.uni_paderborn.fujaba.uml.UMLProject;
import fi.uta.dbschema.metamodel.DBSchema;
import fi.uta.dbschema.metamodel.DBView;
import fi.uta.dbschema.metamodel.DBViewAttribute;


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.2 $
 */
public class PEDBView extends DBPropertyEditor
{
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PETextField viewName;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PETextField packageName;
   
   PETextArea description;


   /**
    * Constructor for class PEDBView
    *
    * @param frame  No description provided
    * @param title  No description provided
    * @param modal  No description provided
    */
   public PEDBView (JFrame frame, String title, boolean modal)
   {
      super (frame);
      setModal (modal);
      setTitle (title);
      try
      {
         pack();
         this.setTitle ("View Editor");
      }
      catch (Exception e)
      {
         e.printStackTrace();
      }
      initPE();

      addFocusListener (new CMAFocusListener (viewName));

   }


   /**
    * Constructor for class PEDBView
    *
    * @param frame  No description provided
    */
   public PEDBView (JFrame frame)
   {
      this (frame, "", false);
   }


   /**
    * Constructor for class PEDBView
    *
    * @param frame  No description provided
    * @param modal  No description provided
    */
   public PEDBView (JFrame frame, boolean modal)
   {
      this (frame, "", modal);
   }


   /**
    * Constructor for class PEDBView
    *
    * @param frame  No description provided
    * @param title  No description provided
    */
   public PEDBView (JFrame frame, String title)
   {
      this (frame, title, false);
   }


   /**
    * Sets the attributeName attribute of the PEDBView object
    *
    * @param name  The new viewName value
    */
   public void setViewName (String name)
   {
      viewName.setText (name);
   }


   /**
    * Sets the packageName attribute of the PEDBView object
    *
    * @param name  The new packageName value
    */
   public void setPackageName (String name)
   {
      packageName.setText (name);
   }
   
   public void setDescription (String desc)
   {
	  description.setText (desc);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param panel  No description provided
    */
   protected void additionalProperties (PEEditPanel panel)
   {
      viewName = new PETextField (this, "View Name");
      packageName = new PETextField (this, "Package Name");
	  description = new PETextArea (this, "Description");

      viewName.setStatus ("Enter the name of the view");
      packageName.setStatus ("Enter the name of the package");
	  description.setStatus ("Enter the description of the view");

      PEColumn column = new PEColumn (this);

      column.add (viewName);
      column.add (packageName);
	  column.add (description);

      panel.add (column);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void unparse()
   {
      if (getIncrement() instanceof DBView)
      {
         DBView selectedView = (DBView) getIncrement();
         viewName.setText (selectedView.getName());
         packageName.setText (selectedView.getJavaPackage());
		 description.setText (selectedView.getDescription());
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected void parse()
   {
      ASGElement incr = getIncrement();

      if (incr instanceof DBView)
      {
         DBView view = (DBView) incr;
         view.setName (getViewName());
         view.setJavaPackage (getPackageName());
		view.setDescription (getDescription());
         ASGDiagram diagram = UMLProject.get().getCurrentDiagram();
         if (diagram instanceof DBSchema)
         {
            DBSchema dbSchema = (DBSchema) diagram;
            if (!dbSchema.hasInItems (view))
            {
               dbSchema.addToItems (view);
            }
         }
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected void cancel()
   {
      setVisible (false);
      dispose();
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void buttonOK_actionPerformed (ActionEvent e)
   {
//      super.buttonOK_actionPerformed (e);
      if (getFrame() != null)
      {
         getFrame().setCursor (Cursor.getPredefinedCursor (Cursor.WAIT_CURSOR));
      } // if

      try
      {
         setVisible (false);
         parse();
         UMLProject.get().refreshDisplay();
      }
      finally
      {
         if (getFrame() != null)
         {
            getFrame().setCursor (Cursor.getPredefinedCursor (Cursor.DEFAULT_CURSOR));
         }
      }
   }


   /**
    * Sets the increment attribute of the PEDBView object
    *
    * @param incr  The new increment value
    */
   public void setIncrement (ASGElement incr)
   {
      if (incr instanceof DBViewAttribute)
      {
         super.setIncrement ( ((DBViewAttribute) incr).getParent());
      }
      else
      {
         super.setIncrement (incr);
      }
      if (getIncrement() != null)
      {
         setTitle ("View Editor: " +  ((DBView) getIncrement()).getName());
      }
   }


   /**
    * Get the viewName attribute of the PEDBView object
    *
    * @return   The viewName value
    */
   public String getViewName()
   {
      return viewName.getText();
   }


   /**
    * Get the packageName attribute of the PEDBView object
    *
    * @return   The viewName value
    */
   public String getPackageName()
   {
      return packageName.getText();
   }
   
   public String getDescription()
   {
	  return description.getText();
   }
}

/*
 * $Log: PEDBView.java,v $
 * Revision 1.2  2003/10/07 07:21:52  ariseppi
 * misc. corrections
 *
 */
