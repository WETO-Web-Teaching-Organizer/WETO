/*
 * Created on 2.6.2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package fi.uta.dbschema.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;

import de.uni_paderborn.fujaba.app.FrameMain;
import fi.uta.cs.sqldatatypes.SqlDataType;

/**
 * @author as66033
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class BDJTable extends BDHeaderComponent
{
	SilentSetJTable table;
	JScrollPane scroller;

	public BDJTable(BasicDialog parent, String title)
	{
		super(parent, title);
	}

	/**
	 * Constructor for class BDJTable
	 *
	 * @param parent  No description provided
	 * @param title   No description provided
	 * @param value   No description provided
	 */
	public BDJTable(
		BasicDialog parent,
		String title,
		String[] titles,
		Object[][] values,
		SqlDataType[] types)
	{
		this(parent, title);
		if(types != null) {
			table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			table.setModel(values, titles, types);
		}
		else {
			table.setModel(values, titles);
		}
		setWidths();
		Dimension dim = scroller.getViewport().getPreferredSize();
		dim.height = table.getPreferredSize().height;
		scroller.getViewport().setPreferredSize(dim);
	}

	/* (non-Javadoc)
	 * @see de.uni_paderborn.fujaba.gui.PEBaseComponent#addComponents()
	 */
	protected void addComponents()
	{
		scroller = new JScrollPane();
		if (table == null)
		{
			table = new SilentSetJTable();
		}
		scroller.getViewport().add(table);
		add(scroller);
	}

	/* (non-Javadoc)
	 * @see de.uni_paderborn.fujaba.gui.PEBaseComponent#setReadOnly(boolean)
	 */
	public void setReadOnly(boolean arg0)
	{
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see de.uni_paderborn.fujaba.gui.PEResizable#isHorzResizable()
	 */
	public boolean isHorzResizable()
	{
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see de.uni_paderborn.fujaba.gui.PEResizable#isVertResizable()
	 */
	public boolean isVertResizable()
	{
		// TODO Auto-generated method stub
		return true;
	}
	
	public Object getValueAt(int row, int column)
	{
		return table.getValueAt(row, column);
	}
	
	public boolean isEditing() {
		return table.isEditing();
	}
	
	public void stopCellEditing() {
		table.stopCellEditing();
	}
	
	public void setValueAt(Object value, int row, int column)
	{
		table.setValueAtSilent(value, row, column);
	}
	
	public boolean hasChanged(int row)
	{
		return table.hasChanged(row);
	}
	
	public void setWidths() {
		table.setWidths(FrameMain.get().getGraphics());
	}
	
	public String getHtml(String indent) {
		return table.getHtml(indent);
	}
}

class SilentSetJTable extends JTable
{
	public SilentSetJTable()
	{
		super();
	}

	public SilentSetJTable(TableModel m)
	{
		super(m);
	}

	public SilentSetJTable(Object[][] values, String[] titles)
	{
		super(new ObjectTableModel(values, titles));
	}

	public SilentSetJTable(Object[][] values, String[] titles, SqlDataType[] types)
	{
		super(new ExampleTableModel(values, titles, types));
	}

	public void setModel(Object[][] values, String[] titles, SqlDataType[] types)
	{
		this.setModel(new ExampleTableModel(values, titles, types));
		for(int i = 0; i < this.getColumnCount(); i++) {
			TableColumn col = this.getColumnModel().getColumn(i);
			col.setCellRenderer(new ColoredTableCellRenderer());
		}
	}

	public void setModel(Object[][] values, String[] titles)
	{
		this.setModel(new ObjectTableModel(values, titles));
	}
	
	public void setWidths(Graphics g) {
		FontMetrics fm = g.getFontMetrics();
		for(int i = 0; i < this.getColumnCount(); i++) {
			TableColumn col = this.getColumnModel().getColumn(i);
			int maxValue = 0;
			if(getSqlType(i) != null) {
				maxValue = fm.stringWidth(getSqlType(i).getLongestString());
			} 
			if(getRowCount() > 0 && getValueAt(0, i) instanceof String) {
				for(int i2 = 0; i2 < this.getRowCount(); i2++) {
					maxValue = Math.max(maxValue, fm.stringWidth((String) getValueAt(i2, i)));
				}
			}
			maxValue = Math.max(maxValue, fm.stringWidth((String)col.getHeaderValue()));
			if(col.getHeaderValue().equals(DefineQueryDialog.titles[DefineQueryDialog.titles.length - 1])) 
			{
				maxValue = 250;
			}
			maxValue += 7;
			col.setPreferredWidth(maxValue);
			col.setMinWidth(maxValue);
			col.setWidth(maxValue);
		}
	}

	public void setValueAt(Object o, int row, int column)
	{
		dataModel.setValueAt(o, row, column);
	}

	public void setValueAtSilent(Object o, int row, int column)
	{
		SilentTableModel model = (SilentTableModel) dataModel;
		model.setValueAtSilent(o, row, column);
	}

	public SqlDataType getSqlType(int column)
	{
		if(!(dataModel instanceof ExampleTableModel)) {
			return null;
		}
		ExampleTableModel model = (ExampleTableModel) dataModel;
		return model.getSqlType(column);
	}

	public Object getValueAt(int row, int column)
	{
		return dataModel.getValueAt(row, column);
	}

	public boolean hasChanged(int row)
	{
		SilentTableModel model = (SilentTableModel) dataModel;
		return model.hasChanged(row);
	}

	public boolean stopCellEditing()
	{
		if(cellEditor == null) {
			return true;
		}
		return cellEditor.stopCellEditing();
	}
	
	public boolean isFalseValue(int row, int column) {
		if(!(dataModel instanceof ExampleTableModel)) {
			return false;
		}
		ExampleTableModel model = (ExampleTableModel) dataModel;
		return model.isFalseValue(row, column);
	}
	
	public String getHtml(String indent) {
		StringBuffer html = new StringBuffer(indent + "<table>\n");
		int colCount = this.getColumnCount();
		int rowCount = this.getRowCount();
		html.append(indent + "\t<tr>\n");
		for(int i2 = 0; i2 < colCount; i2++) {
			html.append(indent + "\t\t<th>" + this.getColumnName(i2) + "</th>\n");
		}
		html.append(indent + "\t</tr>\n");
		for(int i = 0; i < rowCount; i++) {
			html.append(indent + "\t<tr>\n");
			for(int i2 = 0; i2 < colCount; i2++) {
				html.append(indent + "\t\t<td>" + this.getValueAt(i, i2) + "</td>\n");
			}
			html.append(indent + "\t</tr>\n");
		}
		html.append(indent + "</table>\n");
		return html.toString();
	}
}

interface SilentTableModel {
	public void setValueAtSilent(Object value, int row, int col);
	public boolean hasChanged(int row);
}

class ObjectTableModel extends AbstractTableModel implements SilentTableModel
{
	private String[] columnNames = null;
	private Object[][] data = null;
	private boolean[] changed = null;

	ObjectTableModel(Object[][] data, String[] columnNames)
	{
		this.data = data;
		this.columnNames = columnNames;
		this.changed = new boolean[data.length];
		for (int i = 0; i < data.length; i++)
		{
			this.changed[i] = false;
		}
	}

	public int getColumnCount()
	{
		return columnNames.length;
	}

	public int getRowCount()
	{
		return data.length;
	}

	public boolean hasChanged(int row)
	{
		return changed[row];
	}

	public String getColumnName(int col)
	{
		return columnNames[col];
	}

	public Object getValueAt(int row, int col)
	{
		return data[row][col];
	}

	public Class getColumnClass(int c)
	{
		return data[0][c].getClass();
	}

	/*
	 * Don't need to implement this method unless your table's
	 * editable.
	 */
	public boolean isCellEditable(int row, int col)
	{
		if(col < 2) {
			return false;
		}
		return true;
	}

	/*
	 * Don't need to implement this method unless your table's
	 * data can change.
	 */
	public void setValueAt(Object value, int row, int col)
	{
		data[row][col] = value;
		changed[row] = true;
		fireTableCellUpdated(row, col);
	}
	
	/*
	 * Don't need to implement this method unless your table's
	 * data can change.
	 */
	public void setValueAtSilent(Object value, int row, int col)
	{
		data[row][col] = value;
		fireTableCellUpdated(row, col);
	}
}

class ExampleTableModel extends AbstractTableModel implements SilentTableModel
{
	private String[] columnNames = null;
	private Object[][] data = null;
	private SqlDataType[] types = null;
	private boolean[] changed = null;
	private boolean[][] falseValues = null;

	ExampleTableModel(Object[][] data, String[] columnNames, SqlDataType[] types)
	{
		this.data = data;
		this.columnNames = columnNames;
		this.types = types;
		this.changed = new boolean[data.length];
		for (int i = 0; i < data.length; i++)
		{
			this.changed[i] = false;
		}
		this.falseValues = new boolean[data.length][columnNames.length];
		for (int i = 0; i < data.length; i++)
		{
			for (int i2 = 0; i2 < columnNames.length; i2++)
			{
				SqlDataType sdt = getSqlType(i2);
				String valueString = (String) data[i][i2];
				if(valueString.equals("")) {
					valueString = null;
				}
				if(valueString != null && valueString.equals("\"\"")) {
					valueString = "";
				}
				boolean isOk = true;
				try {
					sdt.fromString(valueString);
				} catch (Exception e) {
					isOk = false;
				}
				if(!isOk) {
					falseValues[i][i2] = true;
				}
				else {
					falseValues[i][i2] = false;
				}
			}
		}
	}

	public int getColumnCount()
	{
		return columnNames.length;
	}

	public int getRowCount()
	{
		return data.length;
	}

	public boolean hasChanged(int row)
	{
		return changed[row];
	}

	public String getColumnName(int col)
	{
		return columnNames[col];
	}

	public Object getValueAt(int row, int col)
	{
		return data[row][col];
	}

	public Class getColumnClass(int c)
	{
		return data[0][c].getClass();
	}

	public SqlDataType getSqlType(int c)
	{
		return types[c];
	}

	/*
	 * Don't need to implement this method unless your table's
	 * editable.
	 */
	public boolean isCellEditable(int row, int col)
	{
		return true;
	}

	/*
	 * Don't need to implement this method unless your table's
	 * data can change.
	 */
	public void setValueAt(Object value, int row, int col)
	{
		data[row][col] = value;
		changed[row] = true;
		SqlDataType sdt = getSqlType(col);
		String valueString = (String) value;
		if(valueString.equals("")) {
			valueString = null;
		}
		if(valueString != null && valueString.equals("\"\"")) {
			valueString = "";
		}
		boolean isOk = true;
		try {
			sdt.fromString(valueString);
		} catch (Exception e) {
			isOk = false;
		}
		if(!isOk) {
			falseValues[row][col] = true;
		}
		else {
			falseValues[row][col] = false;
		}
		fireTableCellUpdated(row, col);
	}
	
	public boolean isFalseValue(int row, int column) {
		return falseValues[row][column];
	}

	/*
	 * Don't need to implement this method unless your table's
	 * data can change.
	 */
	public void setValueAtSilent(Object value, int row, int col)
	{
		data[row][col] = value;
		SqlDataType sdt = getSqlType(col);
		String valueString = (String) value;
		if(valueString.equals("")) {
			valueString = null;
		}
		if(valueString != null && valueString.equals("\"\"")) {
			valueString = "";
		}
		boolean isOk = true;
		try {
			sdt.fromString(valueString);
		} catch (Exception e) {
			isOk = false;
		}
		if(!isOk) {
			falseValues[row][col] = true;
		}
		else {
			falseValues[row][col] = false;
		}
		fireTableCellUpdated(row, col);
	}
}

class ColoredTableCellRenderer
	extends DefaultTableCellRenderer
{
	public Component getTableCellRendererComponent
		(JTable table, Object value, boolean selected, boolean focused, int row, int column)
	{
		setEnabled(table == null || table.isEnabled());

		SilentSetJTable sTable = (SilentSetJTable) table;
		
		if (sTable.isFalseValue(row, column) && selected) {
			setBackground(Color.pink);
			selected = false;
		}
		else if (sTable.isFalseValue(row, column)) {
			setBackground(Color.red);
		}
		else {
			setBackground(null);
		}
		
		super.getTableCellRendererComponent(table, value, selected, focused, row, column);

		return this;
	}
}