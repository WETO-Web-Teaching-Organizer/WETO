/*
 * Created on Oct 4, 2004
 */
package fi.uta.cs.sqldatamodel;

/**
 * An exception indicating that too many items exist.
 */
public class TooManyItemsException extends SqlDataException {

	private static final long serialVersionUID = -4085854446648675849L;

	public TooManyItemsException() {
		super();
	}

	public TooManyItemsException(String message) {
		super(message);
	}
}

// End of file.
