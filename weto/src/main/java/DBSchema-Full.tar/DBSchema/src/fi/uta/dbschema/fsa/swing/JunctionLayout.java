/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.fsa.swing;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.LayoutManager2;
import java.awt.Rectangle;

import javax.swing.JComponent;

import de.uni_paderborn.fujaba.fsa.swing.Direction;
import de.uni_paderborn.fujaba.fsa.swing.JGrab;


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:50 $
 * @version   $Revision: 1.2 $
 */
public class JunctionLayout implements LayoutManager2
{
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private final static int PAD = 3;


   /**
    * Constructor for class JunctionLayout
    *
    * @param grab                No description provided
    * @param adornmentComponent  No description provided
    */
   public JunctionLayout (JGrab grab, JComponent adornmentComponent)
   {
      this.grab = grab;
      this.adornmentComponent = adornmentComponent;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private JComponent adornmentComponent;


   /**
    * Sets the adornmentComponent attribute of the JunctionLayout object
    *
    * @param value  The new adornmentComponent value
    * @return       No description provided
    */
   public boolean setAdornmentComponent (JComponent value)
   {
      if (this.adornmentComponent != value)
      {
         this.adornmentComponent = value;
         return true;
      }

      return false;
   }


   /**
    * Get the adornmentComponent attribute of the JunctionLayout object
    *
    * @return   The adornmentComponent value
    */
   public JComponent getAdornmentComponent()
   {
      return this.adornmentComponent;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private JGrab grab;


   /**
    * Sets the grab attribute of the JunctionLayout object
    *
    * @param value  The new grab value
    * @return       No description provided
    */
   public boolean setGrab (JGrab value)
   {
      if (this.grab != value)
      {
         this.grab = value;
         return true;
      }

      return false;
   }


   /**
    * Get the grab attribute of the JunctionLayout object
    *
    * @return   The grab value
    */
   public JGrab getGrab()
   {
      return this.grab;
   }


   /**
    * Returns the amount of space the layout would like to have.
    *
    * @param parent  the Container for which this layout manager is being used
    * @return        a Dimension object containing the layout's preferred size
    */
   public Dimension preferredLayoutSize (Container parent)
   {
      Dimension adornDim = null;

      if (adornmentComponent != null &&
      /*
       *  adornmentComponent.isVisible() &&
       */
         adornmentComponent.getParent() == parent)
      {
         adornDim = adornmentComponent.getPreferredSize();
      }
      return calculateSize (parent, adornDim);
   }


   /**
    * Returns the minimum amount of space the layout needs.
    *
    * @param parent  the Container for which this layout manager is being used
    * @return        a Dimension object containing the layout's minimum size
    */
   public Dimension minimumLayoutSize (Container parent)
   {
      return preferredLayoutSize (parent);
      /*
       *  Dimension adornDim=null;
       *  Dimension roleDim=null;
       *  Dimension cardDim=null;
       *  if(adornmentComponent != null && adornmentComponent.isVisible())
       *  {
       *  adornDim = adornmentComponent.getMinimumSize();
       *  }
       *  if(roleComponent != null && roleComponent.isVisible())
       *  {
       *  roleDim = roleComponent.getMinimumSize();
       *  }
       *  if(cardComponent != null && cardComponent.isVisible())
       *  {
       *  cardDim = cardComponent.getMinimumSize();
       *  }
       *  return calculateSize(parent adornDim, roleDim, cardDim);
       */
   }


   /**
    * Returns the maximum amount of space the layout can use.
    *
    * @param parent  No description provided
    * @return        a Dimension object containing the layout's maximum size
    */
   public Dimension maximumLayoutSize (Container parent)
   {
      return preferredLayoutSize (parent);
      /*
       *  Dimension adornDim=null;
       *  Dimension roleDim=null;
       *  Dimension cardDim=null;
       *  if(adornmentComponent != null && adornmentComponent.isVisible())
       *  {
       *  adornDim = adornmentComponent.getMaximumSize();
       *  }
       *  if(roleComponent != null && roleComponent.isVisible())
       *  {
       *  roleDim = roleComponent.getMaximumSize();
       *  }
       *  if(cardComponent != null && cardComponent.isVisible())
       *  {
       *  cardDim = cardComponent.getMaximumSize();
       *  }
       *  return calculateSize(parent, adornDim, roleDim, cardDim);
       */
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param parent    No description provided
    * @param adornDim  No description provided
    * @return          No description provided
    */
   protected Dimension calculateSize (Container parent, Dimension adornDim)
   {
      Dimension result = new Dimension();
      Insets insets = parent.getInsets();
      Direction orient = grab.getOrientation();

      int adornWidth;
      int adornHeight;

      if (adornDim == null)
      {
         adornWidth = 0;
         adornHeight = 0;
      }
      else
      {
         adornWidth = adornDim.width;
         adornHeight = adornDim.height;
      } // else

     if (orient == Direction.BOTTOM || orient == Direction.TOP)
      {
         if (adornWidth % 2 > 0)
         {
            adornWidth++;
         }
         result.width = adornWidth +
            insets.left + insets.right;

         result.height = adornHeight + insets.top + insets.bottom;
      }
      else
      {
         if (adornHeight % 2 > 0)
         {
            adornHeight++;
         }
         result.height = adornHeight +
            insets.top + insets.bottom;

         result.width = adornWidth + insets.left + insets.right;
      } // else
      return result;
   }


   /**
    * Instructs the layout manager to perform the layout for the specified container.
    *
    * @param parent  No description provided
    */
   public void layoutContainer (Container parent)
   {
      Rectangle bounds = parent.getBounds();
      Insets insets = parent.getInsets();
      Direction orient = grab.getOrientation();

      Dimension adornDim = null;

      if (adornmentComponent != null &&
      /*
       *  adornmentComponent.isVisible() &&
       */
         adornmentComponent.getParent() == parent)
      {
         adornDim = adornmentComponent.getPreferredSize();
         adornmentComponent.setSize (adornDim);
      }

      Dimension preferredDim = calculateSize (parent, adornDim);
      int xOff = 0;
      int yOff = 0;
      int center = 0;
      int alignOffset = 0;

      if (orient == Direction.TOP || orient == Direction.BOTTOM)
      {
         xOff =  (bounds.width - preferredDim.width - insets.left - insets.right) / 2 + insets.left;
         center = xOff;
         if (adornDim != null)
         {
            center = Math.max (center, xOff + adornDim.width / 2);
         } // else

         if (orient == Direction.TOP)
         {
            if (adornDim != null)
            {
               alignOffset = bounds.height - adornDim.height - insets.bottom;
            }
            else
            {
               alignOffset = bounds.height - insets.bottom;
            }
         }
         else
         {
            if (adornDim != null)
            {
               alignOffset = insets.top + adornDim.height;
            }
            else
            {
               alignOffset = insets.top;
            }
         }
      }
      else
      {
         yOff =  (bounds.height - preferredDim.height - insets.top - insets.bottom) / 2 + insets.top;
         center = yOff;
         if (adornDim != null)
         {
            center = Math.max (center, yOff + adornDim.height / 2);
         } // else

         if (orient == Direction.LEFT)
         {
            if (adornDim != null)
            {
               alignOffset = bounds.width - adornDim.width - insets.right;
            }
            else
            {
               alignOffset = bounds.width - insets.right;
            }
         }
         else
         {
            if (adornDim != null)
            {
               alignOffset = insets.right + adornDim.width;
            }
            else
            {
               alignOffset = insets.right;
            }
         }
      } // else

      if (adornDim != null)
      {
         if (orient == Direction.TOP)
         {
            adornmentComponent.setLocation (center - adornDim.width / 2, alignOffset);
         }
         else if (orient == Direction.BOTTOM)
         {
            adornmentComponent.setLocation (center - adornDim.width / 2, insets.top);
         }
         else if (orient == Direction.LEFT)
         {
            adornmentComponent.setLocation (alignOffset, center - adornDim.height / 2);
         }
         else if (orient == Direction.RIGHT)
         {
            adornmentComponent.setLocation (insets.left, center - adornDim.height / 2);
         }
      }

      Component[] children = parent.getComponents();
      for (int i = 0; i < children.length; i++)
      {
         if (children[i].isVisible() && children[i] != adornmentComponent)
         {
            children[i].setSize (children[i].getPreferredSize());
         }
      } // for
   }


   /**
    * Access method for an one to n association.
    *
    * @param name  The object added.
    * @param comp  The object added.
    */
   public void addLayoutComponent (String name, Component comp) { }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param comp  No description provided
    */
   public void removeLayoutComponent (Component comp) { }


   /**
    * Access method for an one to n association.
    *
    * @param comp         The object added.
    * @param constraints  The object added.
    */
   public void addLayoutComponent (Component comp, Object constraints) { }


   /**
    * Get the layoutAlignmentX attribute of the RoleLayout object
    *
    * @param target  No description provided
    * @return        The layoutAlignmentX value
    */
   public float getLayoutAlignmentX (Container target)
   {
      return 0.0f;
   }


   /**
    * Get the layoutAlignmentY attribute of the RoleLayout object
    *
    * @param target  No description provided
    * @return        The layoutAlignmentY value
    */
   public float getLayoutAlignmentY (Container target)
   {
      return 0.0f;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param target  No description provided
    */
   public void invalidateLayout (Container target) { }
}

/*
 * $Log: JunctionLayout.java,v $
 * Revision 1.2  2003/10/07 07:21:50  ariseppi
 * misc. corrections
 *
 */
