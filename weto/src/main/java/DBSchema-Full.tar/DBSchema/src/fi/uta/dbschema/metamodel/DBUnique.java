/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.metamodel;

import java.util.Iterator;

import de.upb.tools.fca.FEmptyIterator;
import de.upb.tools.fca.FPropHashSet;


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:53 $
 * @version   $Revision: 1.2 $
 */
public class DBUnique
    extends DBSchemaItem
{
   /**
    * Constructor for class DBUnique
    */
   public DBUnique()
   {
      super();
   }
   
   public Object clone() {
   	DBUnique newUnique = new DBUnique();
   	Iterator iter = iteratorOfAttributes();
   	while(iter.hasNext()) 
   	{
   		newUnique.addToAttributes((DBTableAttribute) iter.next());
   	}
   	return newUnique;
   }


   /**
    * <pre>
    *           0..n   uniqueGroups     0..n
    * DBUnique -------------------------------- DBTableAttribute
    *          uniqueGroups     uniqueAttribute
    * </pre>
    */
   private FPropHashSet attributes;


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @return   No description provided
    */
   public int sizeOfAttributes()
   {
      return  ( (this.attributes == null)
         ? 0
         : this.attributes.size());
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void removeYou()
   {
      /*
       *  id=id348   # no Name
       */
      removeAllFromAttributes();
      setParent (null);
      super.removeYou();
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param value  No description provided
    * @return       No description provided
    */
   public boolean removeFromAttributes (DBTableAttribute value)
   {
      /*
       *  id=id397   # no Name
       */
      boolean changed = false;
      if ( (this.attributes != null) &&  (value != null))
      {
         changed = this.attributes.remove (value);
         if (changed)
         {
            value.removeFromRevUniques (this);
         }
      }
      return changed;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void removeAllFromAttributes()
   {
      DBTableAttribute tmpValue;
      Iterator iter = this.iteratorOfAttributes();
      while (iter.hasNext())
      {
         tmpValue = (DBTableAttribute) iter.next();
         this.removeFromAttributes (tmpValue);
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @return   No description provided
    */
   public Iterator iteratorOfAttributes()
   {
      return  ( (this.attributes == null)
         ? FEmptyIterator.get()
         : this.attributes.iterator());
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param value  No description provided
    * @return       No description provided
    */
   public boolean hasInAttributes (DBTableAttribute value)
   {
      return  ( (this.attributes != null) &&
          (value != null) &&
         this.attributes.contains (value));
   }


   /**
    * Access method for an one to n association.
    *
    * @param value  The object added.
    * @return       No description provided
    */
   public boolean addToAttributes (DBTableAttribute value)
   {
      boolean changed = false;
      if (value != null)
      {
         if (this.attributes == null)
         {
            this.attributes = new FPropHashSet (this, "attributes"); // or FTreeSet () or FLinkedList ()
         }
         changed = this.attributes.add (value);
      }
      return changed;
   }


   /**
    * <pre>
    *          +-----------+ 1              1
    * DBTable  | getName() +------------------ DBUnique
    *          +-----------+ parent     attrs
    * </pre>
    */
   private transient DBTable parent;


   /**
    * Sets the parent attribute of the DBUnique object
    *
    * @param obj  The new parent value
    * @return     No description provided
    */
   public boolean setParent (DBTable obj)
   {
      boolean changed = false;

      if (this.parent != obj)
      {
         DBTable oldValue = this.parent;
         if (this.parent != null)
         {
            this.parent = null;
            oldValue.removeFromUniques (this);
         }
         this.parent = obj;
         if (obj != null)
         {
            obj.addToUniques (this);
         }
         changed = true;

         // side effects

         firePropertyChange ("parent", oldValue, obj);
      }

      return changed;
   }


   /**
    * Get the parent attribute of the DBForeignKey object
    *
    * @return   The parent value
    */
   public DBTable getParent()
   {
      return parent;
   }


   /**
    * Get the text attribute of the DBForeignKey object
    *
    * @return   The text value
    */
   public String getText()
   {
      String name = "";
      Iterator i = iteratorOfAttributes();
      while (i.hasNext())
      {
         DBTableAttribute attr = (DBTableAttribute) i.next();
         name += attr.getText();
         if (i.hasNext())
         {
            name += " - ";
         }
      }
      return name;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @return   No description provided
    */
   public String toString()
   {
      return getText();
   }
}

/*
 * $Log: DBUnique.java,v $
 * Revision 1.2  2003/10/07 07:21:53  ariseppi
 * misc. corrections
 *
 */
