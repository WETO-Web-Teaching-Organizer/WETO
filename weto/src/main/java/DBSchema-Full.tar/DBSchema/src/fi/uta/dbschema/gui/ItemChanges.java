/*
 * Created on 17.6.2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package fi.uta.dbschema.gui;

import java.awt.Cursor;
import java.awt.event.ActionEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import de.uni_paderborn.fujaba.app.FrameMain;
import de.uni_paderborn.fujaba.asg.ASGElement;
import de.uni_paderborn.fujaba.gui.BasicPropertyEditor;
import de.uni_paderborn.fujaba.gui.PEColumn;
import de.uni_paderborn.fujaba.gui.PEEditPanel;
import fi.uta.dbschema.metamodel.DBItemRenamed;
import fi.uta.dbschema.metamodel.DBSchemaItem;
import fi.uta.dbschema.metamodel.DBTable;
import fi.uta.dbschema.metamodel.DBTableAttribute;
import fi.uta.dbschema.metamodel.DBTableInterface;
import fi.uta.dbschema.metamodel.parse.DatabaseManager;
import fi.uta.dbschema.metamodel.parse.MetaDataReader;

/**
 * @author as66033
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ItemChanges extends DBPropertyEditor
{
	ChangeItemPanel changedItemsPanel;

	ItemPanel itemPanel;

	HashMap oldItems;
	HashMap constraints;
	
	// Key: new item, value: old item
	public static HashMap renames = null;
	public static HashMap others = null;

	public static final int TABLE_TYPE = 0;
	public static final int ATTRIBUTE_TYPE = 1;

	private int type = -1;
	
	private ArrayList[] addsAndRemoves;
	
	private DBTable editedTable;
	
	// Temporary lists of changes to the adds, removes and renames
	// for attribute type, when OK is pressed this data is synchronized
	// with addsAndRemoves and renames
	
	private ArrayList removes, adds, removeFromRenames;
	private HashMap addToRenames;

	public ItemChanges(JFrame frame, String title, boolean modal, int type)
	{
		super(frame);
		setType(type);
		setModal(modal);
		setTitle(title);
		try
		{
			pack();
			this.setTitle("Alter database");
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		initPE();
		if(type == ItemChanges.TABLE_TYPE)
		{
			renames = new HashMap();
			others = new HashMap();
		}
		if(type == ItemChanges.ATTRIBUTE_TYPE)
		{
			removeFromRenames = new ArrayList();
			addToRenames = new HashMap();
		}
	}

	/**
	 * Constructor for class FindAttributeDialog
	 *
	 * @param frame  No description provided
	 */
	public ItemChanges(JFrame frame, int type)
	{
		this(frame, "", false, type);
	}

	/**
	 * Constructor for class FindAttributeDialog
	 *
	 * @param frame  No description provided
	 * @param modal  No description provided
	 */
	public ItemChanges(JFrame frame, boolean modal, int type)
	{
		this(frame, "", modal, type);
	}

	/**
	 * Constructor for class FindAttributeDialog
	 *
	 * @param frame  No description provided
	 * @param title  No description provided
	 */
	public ItemChanges(JFrame frame, String title, int type)
	{
		this(frame, title, false, type);
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param panel  No description provided
	 */
	protected void additionalProperties (PEEditPanel panel)
	{
		changedItemsPanel = new ChangeItemPanel(this, false);

		boolean showEditInItemPanel = false;
		if (getType() == ItemChanges.TABLE_TYPE)
		{
			showEditInItemPanel = true;
		}
		itemPanel = new ItemPanel(this, showEditInItemPanel, false);

/*		changedItemsPanel.setAddListener(
			new ItemChanges_addToAddedButton_actionAdapter(this));
		changedItemsPanel.setRemoveListener(
			new ItemChanges_removeFromAddedButton_actionAdapter(this));
			*/
		changedItemsPanel.setMergeListener(
			new ItemChanges_mergeButton_actionAdapter(this));

		itemPanel.setAddListener(
			new ItemChanges_detachButton_actionAdapter(this));
			/*
		itemPanel.setRemoveListener(
			new ItemChanges_removeFromKeptButton_actionAdapter(this));
			*/
		itemPanel.setModifyListener(
			new ItemChanges_editButton_actionAdapter(this));

		PEColumn column = new PEColumn(this);

		column.add(changedItemsPanel);
		column.add(itemPanel);

		panel.add(column);
	}

	public void setListsTable(
		ArrayList added,
		ArrayList kept,
		ArrayList removed,
		HashMap oldItems)
	{
		this.oldItems = oldItems;
		Iterator iterAdded = added.iterator();
		while (iterAdded.hasNext())
		{
			Object addItem = iterAdded.next();
			changedItemsPanel.addToAdded((ASGElement) addItem);
		}
		Iterator iterRemoved = removed.iterator();
		while (iterRemoved.hasNext())
		{
			Object removeItem = iterRemoved.next();
			changedItemsPanel.addToRemoved((ASGElement) removeItem);
		}
		Iterator iterKept = kept.iterator();
		while (iterKept.hasNext())
		{
			itemPanel.addToList((ASGElement) iterKept.next());
		}
	}

	public void setListsAttribute(
		ArrayList added,
		ArrayList kept,
		ArrayList removed,
		HashMap oldItems)
	{
		this.oldItems = oldItems;
		boolean listsCollected = others.containsKey(getEditedTable());
		if(listsCollected)
		{
			addsAndRemoves = (ArrayList[]) others.get(getEditedTable());
		}
		else
		{
			addsAndRemoves = new ArrayList[2];
			addsAndRemoves[0] = new ArrayList();
			addsAndRemoves[1] = new ArrayList();
		}
		
		
		Iterator iterAdded = added.iterator();
		while (iterAdded.hasNext())
		{
			Object addItem = iterAdded.next();
			changedItemsPanel.addToAdded((ASGElement) addItem);
			if(!listsCollected)
			{
				addsAndRemoves[0].add(addItem);
			}
		}
		Iterator iterRemoved = removed.iterator();
		while (iterRemoved.hasNext())
		{
			Object removeItem = iterRemoved.next();
			changedItemsPanel.addToRemoved((ASGElement) removeItem);
			if(!listsCollected)
			{
				addsAndRemoves[1].add(removeItem);
			}
		}
		Iterator iterKept = kept.iterator();
		while (iterKept.hasNext())
		{
			itemPanel.addToList((ASGElement) iterKept.next());
		}
		others.put(getEditedTable(), addsAndRemoves);
		adds = (ArrayList) addsAndRemoves[0].clone();
		removes = (ArrayList) addsAndRemoves[1].clone();
	}

	public void mergeButton_actionPerformed(ActionEvent e)
	{
		PEDBListIncr addedList = changedItemsPanel.getAdded();
		PEDBListIncr removedList = changedItemsPanel.getRemoved();
		DBSchemaItem addItem = (DBSchemaItem) addedList.getSelectedIncrement();
		DBSchemaItem removeItem =
			(DBSchemaItem) removedList.getSelectedIncrement();
		if (addItem == null || removeItem == null)
		{
			return;
		}
		if (addItem.getClass() != removeItem.getClass())
		{
			return;
		}
		addedList.remove(addItem);
		removedList.remove(removeItem);
		itemPanel.addToList(new DBItemRenamed(removeItem, addItem));
		if(this.type == ItemChanges.ATTRIBUTE_TYPE)
		{ 
			addToRenames.put(addItem, removeItem);
			adds.remove(addItem);
			removes.remove(removeItem);
		}
	}
/*
	public void removeFromKeptButton_actionPerformed(ActionEvent e)
	{
		PEDBListIncr keptList = itemPanel.getList();
		DBSchemaItem keptItem = (DBSchemaItem) keptList.getSelectedIncrement();
		if (keptItem == null)
		{
			return;
		}
		keptList.remove(keptItem);
		if (keptItem instanceof DBTable
			|| keptItem instanceof DBTableAttribute)
		{
			changedItemsPanel.addToRemoved(keptItem);
			if(oldItems.containsKey(keptItem))
		}
		if (keptItem instanceof DBItemRenamed)
		{
			DBItemRenamed renamedItem = (DBItemRenamed) keptItem;
			changedItemsPanel.addToRemoved(renamedItem.getOrigItem());
			changedItemsPanel.addToRemoved(
				renamedItem.getNewItem(),
				"* " + renamedItem.getNewItem().getName());
			renames.remove(renamedItem.getNewItem());
		}
	}
*/
	public void detachButton_actionPerformed(ActionEvent e)
	{
		PEDBListIncr keptList = itemPanel.getList();
		DBSchemaItem keptItem = (DBSchemaItem) keptList.getSelectedIncrement();
		if (keptItem == null || !(keptItem instanceof DBItemRenamed))
		{
			return;
		}
		keptList.remove(keptItem);
		DBItemRenamed renamedItem = (DBItemRenamed) keptItem;
		changedItemsPanel.addToAdded(renamedItem.getNewItem());
		changedItemsPanel.addToRemoved(renamedItem.getOrigItem());
		if(this.type == ItemChanges.ATTRIBUTE_TYPE){ 
			removeFromRenames.add(renamedItem.getNewItem());
			adds.add(renamedItem.getOrigItem());
			removes.add(renamedItem.getNewItem());
		}
	}

	public void editButton_actionPerformed(ActionEvent e)
	{
		PEDBListIncr keptList = itemPanel.getList();
		DBSchemaItem keptItem = (DBSchemaItem) keptList.getSelectedIncrement();
		if (keptItem == null)
		{
			return;
		}
		DBTableInterface editTable = null;
		DBTableInterface oldTable = null;
		if (keptItem instanceof DBTableInterface)
		{
			editTable = (DBTableInterface) keptItem;
			oldTable = (DBTableInterface) oldItems.get(editTable.getName());
		}
		if (keptItem instanceof DBItemRenamed)
		{
			DBItemRenamed renamedItem = (DBItemRenamed) keptItem;
			editTable = (DBTableInterface) renamedItem.getNewItem();
			oldTable = (DBTableInterface) renamedItem.getOrigItem();
		}
		HashMap attributes = new HashMap();
		Iterator iter = oldTable.iteratorOfAttributes();
		while (iter.hasNext())
		{
			DBSchemaItem item = (DBSchemaItem) iter.next();
			attributes.put(item.getName(), item);
		}
		Iterator iter2 = editTable.iteratorOfAttributes();
		ArrayList added = new ArrayList();
		ArrayList removed = new ArrayList();
		ArrayList kept = new ArrayList();
//		HashMap oldAttributes = new HashMap();
		ArrayList[] addsAndRemoves = (ArrayList[]) others.get(editTable);
		if(addsAndRemoves != null)
		{
			added.addAll(addsAndRemoves[0]);
			removed.addAll(addsAndRemoves[1]);
		}
		while (iter2.hasNext())
		{
			DBTableAttribute attr = (DBTableAttribute) iter2.next();
			String attrName = attr.getName();
			DBTableAttribute oldAttribute = (DBTableAttribute) attributes.get(attrName);
			if (oldAttribute == null || !oldAttribute.getSqlType().equals(attr.getSqlType()) || oldAttribute.getSqlScale() != attr.getSqlScale() || oldAttribute.getSqlSize() != attr.getSqlSize()) 
			{
				if(addsAndRemoves == null)
				{
					added.add(attr);
				}
				else
				{
					if(renames.containsKey(attr))
					{
						kept.add(new DBItemRenamed(attr, (DBSchemaItem) renames.get(attr)));
					}
				}
			} else 
			{
				attributes.remove(attrName);
//				oldAttributes.put(attrName, oldAttribute);
				kept.add(attr);
			}
		}
		if (!attributes.isEmpty() && addsAndRemoves == null)
		{
			Iterator iter3 = ((Collection) attributes.values()).iterator();
			while (iter3.hasNext())
			{
				DBTableAttribute removeAttr = (DBTableAttribute) iter3.next();
				removed.add(removeAttr);
//				oldAttributes.put(removeAttr.getName(), removeAttr);
			}
		}
		ItemChanges alterDialog = new ItemChanges (getFrame(), ItemChanges.ATTRIBUTE_TYPE);
		alterDialog.setEditedTable((DBTable) editTable);
		alterDialog.setListsAttribute(added, kept, removed, null);
		alterDialog.showCentered();
	}
/*
	public void removeFromAddedButton_actionPerformed(ActionEvent e)
	{
		PEDBListIncr addedList = changedItemsPanel.getAdded();
		DBSchemaItem addedItem =
			(DBSchemaItem) addedList.getSelectedIncrement();
		if (addedItem == null)
		{
			return;
		}
		addedList.remove(addedItem);
		changedItemsPanel.addToRemoved(addedItem, "* " + addedItem.getName());
	}

	public void addToAddedButton_actionPerformed(ActionEvent e)
	{
		PEDBListIncr removedList = changedItemsPanel.getRemoved();
		DBSchemaItem removedItem =
			(DBSchemaItem) removedList.getSelectedIncrement();
		if (removedItem == null)
		{
			return;
		}
		removedList.remove(removedItem);
		if (oldItems.get(removedItem) == null)
		{
			changedItemsPanel.addToAdded(removedItem);
		} else
		{
			itemPanel.addToList(removedItem);
		}
	}
	*/
	
	/**
	 * @return
	 */
	public int getType()
	{
		return type;
	}

	/**
	 * @param i
	 */
	public void setType(int i)
	{
		type = i;
	}
	
	public void unparse()
	{
	}

	protected void parse()
	{
	}

	public Iterator[] getIterators()
	{
		Iterator[] iterators = new Iterator[3];
		ArrayList iterable = new ArrayList();
		Iterator iter = changedItemsPanel.getAdded().iterator();
		while(iter.hasNext())
		{
			PEDBItem item = (PEDBItem) iter.next();
			iterable.add(item.getIncrement());
		}
		iterators[0] = iterable.iterator();
		ArrayList iterable2 = new ArrayList();
		iter = changedItemsPanel.getRemoved().iterator();
		while(iter.hasNext())
		{
			PEDBItem item = (PEDBItem) iter.next();
			iterable2.add(item.getIncrement());
		}
		iterators[1] = iterable2.iterator();
		ArrayList iterable3 = new ArrayList();
		iter = itemPanel.getList().iterator();
		while(iter.hasNext())
		{
			PEDBItem item = (PEDBItem) iter.next();
			iterable3.add(item.getIncrement());
		}
		iterators[2] = iterable3.iterator();
		return iterators;
	}

	public void buttonOK_actionPerformed (ActionEvent e)
	{
//		 super.buttonOK_actionPerformed (e);
	   if (getFrame() != null)
	   {
		  getFrame().setCursor (Cursor.getPredefinedCursor (Cursor.WAIT_CURSOR));
	   } // if

	   try
	   {
		  setVisible (false);
		if(this.type == ItemChanges.TABLE_TYPE){ 
			DatabaseManager.makeChanges(getIterators(), oldItems, constraints);
		}
		if(this.type == ItemChanges.ATTRIBUTE_TYPE){ 
			addsAndRemoves[0] = adds;
			addsAndRemoves[1] = removes;
			for(int i = 0; i < removeFromRenames.size(); i++)
			{
				renames.remove(removeFromRenames.get(i));
			}
			Iterator iter = addToRenames.keySet().iterator();
			while(iter.hasNext())
			{
				Object key = iter.next();
				renames.put(key, addToRenames.get(key));
			}
		}
	   }
	   finally
	   {
		  if (getFrame() != null)
		  {
			 getFrame().setCursor (Cursor.getPredefinedCursor (Cursor.DEFAULT_CURSOR));
		  }
	   }
	}

	protected void cancel()
	{
	   try {
		MetaDataReader.conn.close();
		MetaDataReader.conn = null;
	   } catch (SQLException ex)
		{
		 JOptionPane.showMessageDialog(
		 FrameMain.get(),
		 ex.getSQLState(),
		"Database error",
		 JOptionPane.ERROR_MESSAGE);
		}
	   setVisible (false);
	   dispose();
	}
	/**
	 * @return
	 */
	public DBTable getEditedTable()
	{
		return editedTable;
	}

	/**
	 * @param table
	 */
	public void setEditedTable(DBTable table)
	{
		editedTable = table;
	}

	/**
	 * @return
	 */
	public HashMap getConstraints()
	{
		return constraints;
	}

	/**
	 * @param map
	 */
	public void setConstraints(HashMap map)
	{
		constraints = map;
	}

}

class ItemChanges_mergeButton_actionAdapter
	implements java.awt.event.ActionListener
{
	ItemChanges adaptee;

	ItemChanges_mergeButton_actionAdapter(ItemChanges adaptee)
	{
		this.adaptee = adaptee;
	}

	public void actionPerformed(ActionEvent e)
	{
		adaptee.mergeButton_actionPerformed(e);
	}
}
/*
class ItemChanges_addToAddedButton_actionAdapter
	implements java.awt.event.ActionListener
{
	ItemChanges adaptee;

	ItemChanges_addToAddedButton_actionAdapter(ItemChanges adaptee)
	{
		this.adaptee = adaptee;
	}

	public void actionPerformed(ActionEvent e)
	{
		adaptee.addToAddedButton_actionPerformed(e);
	}
}

class ItemChanges_removeFromAddedButton_actionAdapter
	implements java.awt.event.ActionListener
{
	ItemChanges adaptee;

	ItemChanges_removeFromAddedButton_actionAdapter(ItemChanges adaptee)
	{
		this.adaptee = adaptee;
	}

	public void actionPerformed(ActionEvent e)
	{
		adaptee.removeFromAddedButton_actionPerformed(e);
	}
}

class ItemChanges_removeFromKeptButton_actionAdapter
	implements java.awt.event.ActionListener
{
	ItemChanges adaptee;

	ItemChanges_removeFromKeptButton_actionAdapter(ItemChanges adaptee)
	{
		this.adaptee = adaptee;
	}

	public void actionPerformed(ActionEvent e)
	{
		adaptee.removeFromKeptButton_actionPerformed(e);
	}
}
*/
class ItemChanges_detachButton_actionAdapter
	implements java.awt.event.ActionListener
{
	ItemChanges adaptee;

	ItemChanges_detachButton_actionAdapter(ItemChanges adaptee)
	{
		this.adaptee = adaptee;
	}

	public void actionPerformed(ActionEvent e)
	{
		adaptee.detachButton_actionPerformed(e);
	}
}

class ItemChanges_editButton_actionAdapter
	implements java.awt.event.ActionListener
{
	ItemChanges adaptee;

	ItemChanges_editButton_actionAdapter(ItemChanges adaptee)
	{
		this.adaptee = adaptee;
	}

	public void actionPerformed(ActionEvent e)
	{
		adaptee.editButton_actionPerformed(e);
	}
}

class ChangeItemPanel extends PEDoubleListButtonSelection
{
	/**
	 * @param parent
	 */
	public ChangeItemPanel(BasicPropertyEditor parent, boolean showAddAndRemove)
	{
		super(parent);
		if (!showAddAndRemove)
		{
			PEColumn col = this.getButtonColumn();
			col.remove(2);
			col.remove(1);
		}
		// TODO Auto-generated constructor stub
	}

}

class ItemPanel extends PESingleSelection
{
	/**
	 * @param parent
	 */
	public ItemPanel(BasicPropertyEditor parent, boolean showEdit, boolean showRemove)
	{
		super(parent);
		this.setAddButtonText("separate");
		this.setModifyButtonText("attributes");
		if (!showEdit)
		{
			PEColumn col = this.getButtonColumn();
			col.remove(2);
		}
		if (!showRemove)
		{
			PEColumn col = this.getButtonColumn();
			col.remove(1);
		}
	}
}