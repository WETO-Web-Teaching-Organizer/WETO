/*
 * Created on 28.7.2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package fi.uta.dbschema.fsa.update;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.JComponent;

import de.uni_paderborn.fujaba.asg.ASGElement;
import de.uni_paderborn.fujaba.fsa.unparse.LogicUnparseInterface;
import de.uni_paderborn.fujaba.fsa.update.VisibilityUpdater;
import fi.uta.dbschema.metamodel.DBTable;
import fi.uta.dbschema.metamodel.DBView;

/**
 * Based on de.uni_paderborn.fujaba.uml.update.ClassCompartmentVisibilityUpdater
 */
public class NodeCompartmentVisibilityUpdater
	extends VisibilityUpdater
	implements PropertyChangeListener
{
	/**
	 * Default Constructor
	 */
	public NodeCompartmentVisibilityUpdater()
	{
		super();
		super.setFsaAttrName("visible");
	}

	/**
	 * Constructor for class ClassCompartmentVisibilityUpdater
	 *
	 * @param incr  No description provided
	 * @param attr  No description provided
	 */
	public NodeCompartmentVisibilityUpdater(
		LogicUnparseInterface incr,
		String attr)
	{
		this();
		setLogicObject(incr);
		setLogicAttrName(attr);
	}

	/**
	 * Sets the logicObject attribute of the ClassCompartmentVisibilityUpdater object
	 *
	 * @param object  The new logicObject value
	 * @return        No description provided
	 */
	public boolean setLogicObject(Object object)
	{
		if (object == null
			|| object instanceof DBTable
			|| object instanceof DBView)
		{
			return super.setLogicObject(object);
		}
		throw new IllegalArgumentException("Object must be of instance DBTable or DBView");
	}

	/**
	 * Sets the fsaAttrName attribute of the NodeCompartmentVisibilityUpdater object
	 *
	 * @param name  The new fsaAttrName value
	 * @return      No description provided
	 */
	public boolean setFsaAttrName(String name)
	{
		if ("visible".equals(name))
		{
			return false;
		}

		throw new UnsupportedOperationException("Cannot change VisibilityUpdater.fsaAttrName from \"visible\"");
	}

	/**
	 * Sets the logicAttrName attribute of the ClassCompartmentVisibilityUpdater object
	 *
	 * @param name  The new logicAttrName value
	 * @return      No description provided
	 */
	public boolean setLogicAttrName(String name)
	{
		if ("attributes".equals(name))
		{
			return super.setLogicAttrName(name);
		}

		throw new UnsupportedOperationException("Cannot change to name");
	}

	/**
	 * expects an array of 3 int numbers:</p> 0: Number of Stereotypes 1: Number of Attrs</p>
	 * 2: Number of Methods</p> 3: Number of Signals</p> translates that array to a boolean
	 * value according to UML class compartment visibility rules.
	 *
	 * @param data  No description provided
	 * @return      Boolean.TRUE if compartment is to be shown, Boolean.FALSE else
	 */
	public Object translateLogicToFsa(Object elements)
	{
		String attrName = getLogicAttrName();
		Boolean result;
		try
		{
			if ("attributes".equals(attrName))
			{
//				result =
//					((Integer) elements).intValue() > 0
//						? Boolean.TRUE : Boolean.FALSE;
							result = Boolean.TRUE;
			} else
			{
				result = Boolean.FALSE;
			}

		} catch (Exception e)
		{
			result = Boolean.FALSE;
		}

		return result;
	}

	/**
	 * Access method for an one to n association.
	 */
	protected void addListener()
	{
		if (!(getLogicObject() == null
			|| getLogicAttrName() == null
			|| getFsaObject() == null
			|| getFsaAttrName() == null))
		{
			if (getLogicListener() == null)
			{
				setLogicListener(this);
			}
			if ("attributes".equals(getLogicAttrName()))
			{
				((ASGElement) getLogicObject()).addPropertyChangeListener(
					"attributes",
					(PropertyChangeListener) getLogicListener());
			}
		}
	}

	/**
	 * No comment provided by developer, please add a comment to improve documentation.
	 */
	protected void removeListener()
	{
		if (!(getLogicObject() == null
			|| getLogicAttrName() == null
			|| getFsaObject() == null
			|| getFsaAttrName() == null))
		{
			if (getLogicListener() != null)
			{
				if ("attributes".equals(getLogicAttrName()))
				{
					(
						(ASGElement) getLogicObject())
							.removePropertyChangeListener(
						"attributes",
						(PropertyChangeListener) getLogicListener());
				}
			}
		}
	}

	/**
	 * No comment provided by developer, please add a comment to improve documentation.
	 */
	public void initialize()
	{
		if (!(getLogicObject() == null
			|| getLogicAttrName() == null
			|| getFsaObject() == null
			|| getFsaAttrName() == null))
		{
//			int attributes = 0;
			Object logicObject = getLogicObject();
/*			if (logicObject instanceof DBTable)
			{
				DBTable table = (DBTable) logicObject;
				attributes = table.sizeOfAttributes();
			} else
			{
				DBView view = (DBView) logicObject;
				attributes = view.sizeOfAttributes();
			}
*/
			Boolean value =
				(Boolean) getTranslator().translateLogicToFsa(
					null);
			boolean isVisible = value.booleanValue();

			getFsaObject().setVisible(isVisible);
		}
	}

	// counters for elements
	/**
	 * No comment provided by developer, please add a comment to improve documentation.
	 */
//	private int attributes = 0;

	/**
	 * No comment provided by developer, please add a comment to improve documentation.
	 *
	 * @param e  No description provided
	 */
	public void propertyChange(PropertyChangeEvent e)
	{
		Object oldValue = e.getOldValue();
		Object newValue = e.getNewValue();

		boolean changed = false;

		if ("attributes".equals(e.getPropertyName()))
		{
			if ((oldValue != null && newValue == null) || (oldValue == null && newValue != null))
			{
				changed = true;
			}
			else
			{
				System.out.println(
					"Strange PCEvent in CompartmentUpdater: " + e);
			}
		} else
		{
			System.out.println(
				"Strange PropertyName in CompartmentUpdater: "
					+ e.getPropertyName());
		}

		if (changed)
		{
			Boolean value =
				(Boolean) getTranslator().translateLogicToFsa(
					null);
			getFsaObject().setVisible(value.booleanValue());
		}

		JComponent component = getFsaObject().getJComponent();
		JComponent parent = (JComponent) component.getParent();

		if (parent != null)
		{
			while (parent != null && parent.getParent() instanceof JComponent)
			{
				parent.setPreferredSize(null);
				parent = (JComponent) parent.getParent();
			} // end of while ()
			parent.setPreferredSize(null);
			parent.revalidate();
			parent.repaint();
		} // end of if ()
	}
}