/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this added code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.gui;

// Based on de.uni_paderborn.fujaba.gui.PETypeSelection

import java.awt.Graphics;
import java.awt.Insets;
import java.awt.event.MouseListener;
import java.util.Enumeration;

import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import de.uni_paderborn.fujaba.asg.ASGElement;
import de.uni_paderborn.fujaba.gui.BasicPropertyEditor;
import de.uni_paderborn.fujaba.gui.PEColumn;
import de.uni_paderborn.fujaba.gui.PEHeaderComponent;
import de.uni_paderborn.fujaba.gui.PEResizable;
import de.uni_paderborn.fujaba.gui.PERow;


/**
 * A selection element with two lists and no buttons.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/09/02 10:17:05 $
 * @version   $Revision: 1.2 $
 */
public class PEDoubleListSelection extends PEHeaderComponent implements PEResizable
{
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBListIncr left;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBListIncr right;


   /**
    * Constructor for class PEDoubleListSelection
    *
    * @param parent  No description provided
    */
   public PEDoubleListSelection (BasicPropertyEditor parent)
   {
      super();
      setParent (parent);
      left = new PEDBListIncr (this.parent, "Left");
      left.setInsets (new Insets (1, 1, 1, 10));
      right = new PEDBListIncr (this.parent, "Right");
      right.setInsets (new Insets (1, 1, 1, 0));
      left.addSelectionListener (new PELeftSelectionListener (this));
      right.addSelectionListener (new PERightSelectionListener (this));
      setLayout (getLayoutManager());
      addComponents();
   }


   /**
    * The function addToLeft () adds a new entry represented by a valid reference to an object
    * of the AST to the added list.
    *
    * @param incr  a valid reference to an object of the AST
    */
   public void addToLeft (ASGElement incr)
   {
      PEDBItem item = new PEDBItem (incr);
      left.add (item);
   }


   /**
    * The function addToLeft () adds a new entry represented by a valid reference to an object
    * of the AST and a string to the list.
    *
    * @param incr  a valid reference to an object of the AST
    * @param s     a valid string represented the entry in the list
    */
   public void addToLeft (ASGElement incr, String s)
   {
      PEDBItem item = new PEDBItem (incr, s);
      left.add (item);
   }


   /**
    * The function addToRight () adds a new entry represented by a valid reference to an object
    * of the AST to the added list.
    *
    * @param incr  a valid reference to an object of the AST
    */
   public void addToRight (ASGElement incr)
   {
      PEDBItem item = new PEDBItem (incr);
      right.add (item);
   }


   /**
    * The function addToRight () adds a new entry represented by a valid reference to an object
    * of the AST and a string to the list.
    *
    * @param incr  a valid reference to an object of the AST
    * @param s     a valid string represented the entry in the list
    */
   public void addToRight (ASGElement incr, String s)
   {
      PEDBItem item = new PEDBItem (incr, s);
      right.add (item);
   }


   /**
    * Sets the readOnly attribute of the PEDoubleListSelection object
    *
    * @param b  The new readOnly value
    */
   public void setReadOnly (boolean b)
   {
   }


   /**
    * Get the parentPE attribute of the PEDoubleListSelection object
    *
    * @return   The parentPE value
    */
   protected BasicPropertyEditor getParentPE()
   {
      return parent;
   }


   /**
    * Access method for an one to n association.
    */
   protected void addComponents()
   {
      PEColumn column = new PEColumn (getParentPE());
      PERow row = new PERow (getParentPE());
      row.add (left);

      row.add (right);
      column.add (row);
      add (column);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
//   private ASGElement umlIncr = null;


   /**
    * The function setIncrement () sets the corresponding object of the AST
    */
   /*
    *  public void setIncrement (ASGElement incr)
    *  {
    *  umlIncr = incr;
    *  left.removeAll();
    *  right.removeAll();
    *  fillLeftList();
    *  fillRightList();
    *  }
    */
   /**
    * The function getIncrement () returns a valid reference of the corresponding AST object.
    */
   /*
    *  public ASGElement getIncrement()
    *  {
    *  return umlIncr;
    *  }
    */
   /**
    * The function clearLeft () removes all entries of the left list.
    */
   public void clearLeft()
   {
      left.removeAll();
   }


   /**
    * The function clearRight () removes all entries of the right list
    */
   public void clearRight()
   {
      right.removeAll();
   }


   /**
    * The function getLeftSelectedIncr () returns a valid reference of an object of the AST.
    * The function returns the first entry, if more than one selected.
    *
    * @param listener  The new leftMouseListener value
    */
   /*
    *  public ASGElement getLeftSelectedIncr()
    *  {
    *  return left.getSelectedIncrement();
    *  }
    */
   /**
    * The function getRightIncr () returns a valid reference of an object of the AST. The function
    * returns the first entry, if more than one selected.
    *
    * @param listener  The new leftMouseListener value
    */
   /*
    *  public ASGElement getRightSelectedIncr()
    *  {
    *  return right.getSelectedIncrement();
    *  }
    */
   /**
    * Sets the leftSelectedIncr attribute of the PEDoubleListSelection object
    *
    * @param listener  The new leftMouseListener value
    */
   /*
    *  public void setLeftSelectedIncr (ASGElement incr)
    *  {
    *  getLeft().selectIncrement (incr);
    *  }
    */
   /**
    * Sets the rightSelectedIncr attribute of the PEDoubleListSelection object
    *
    * @param listener  The new leftMouseListener value
    */
   /*
    *  public void setRightSelectedIncr (ASGElement incr)
    *  {
    *  getRight().selectIncrement (incr);
    *  }
    */
   /**
    * The function setLeftMouseListener sets a listener for the left list
    *
    * @param listener  a valid reference of an action adapter
    */
   public void setLeftMouseListener (MouseListener listener)
   {
      left.addMouseListener (listener);
   }


   /**
    * The function setRightMouseListener sets a listener for the right list
    *
    * @param listener  a valid reference of an action adapter
    */
   public void setRightMouseListener (MouseListener listener)
   {
      right.addMouseListener (listener);
   }


   /**
    * The function addToLeft () adds a new entry represented by a valid reference to an object
    * of the AST to the left list.
    *
    * @return   The leftList value
    */
   /*
    *  public void addToLeft (ASGElement incr)
    *  {
    *  PEItem item = new PEItem (incr);
    *  left.add (item);
    *  }
    */
   /**
    * The function addToLeft () adds a new entry represented by a valid reference to an object
    * of the AST and a string to the left list.
    *
    * @return   The leftList value
    */
   /*
    *  public void addToLeft (ASGElement incr, String s)
    *  {
    *  PEItem item = new PEItem (incr, s);
    *  left.add (item);
    *  }
    */
   /**
    * The function addToRight () adds a new entry represented by a valid reference to an object
    * of the AST to the right list.
    *
    * @return   The leftList value
    */
   /*
    *  public void addToRight (ASGElement incr)
    *  {
    *  PEItem item = new PEItem (incr);
    *  right.add (item);
    *  }
    */
   /**
    * The function addToRight () adds a new entry represented by a valid reference to an object
    * of the AST and a string to the right list.
    *
    * @return   The leftList value
    */

   /*
    *  public void addToRight (ASGElement incr, String s)
    *  {
    *  PEItem item = new PEItem (incr, s);
    *  right.add (item);
    *  }
    */
   /**
    * The function removeFromLeft () removes a existing entry from the left list. The entry
    * will be identified by the reference of the represented object.
    *
    * @return   The leftList value
    */
   /*
    *  public void removeFromLeft (ASGElement incr)
    *  {
    *  left.remove (incr);
    *  }
    */
   /**
    * The function removeFromRight () removes a existing entry from the right list. The entry
    * will be identified by the reference of the represented object.
    *
    * @return   The leftList value
    */
   /*
    *  public void removeFromRight (ASGElement incr)
    *  {
    *  right.remove (incr);
    *  }
    */
   /**
    * The function getLeftLsit returns a enumeration of the objects represented by the left
    * list.
    *
    * @return   a valid enumeration of the entries.
    */
   public Enumeration getLeftList()
   {
      return left.elements();
   }


   /**
    * Get the added attribute of the PEDoubleListSelection object
    *
    * @return   The left value
    */
   public PEDBListIncr getLeft()
   {
      return left;
   }


   /**
    * Get the right attribute of the PEDoubleListSelection object
    *
    * @return   The dest value
    */
   public PEDBListIncr getRight()
   {
      return right;
   }


   /**
    * Override the function fillLeftList () to initialize the left list. This function will
    * be called if a increment will be set.
    */
   protected void fillLeftList()
   {
   }


   /**
    * Override the function fillRightList () to initialize the right list. This function will
    * be called if a increment will be set.
    */
   protected void fillRightList()
   {
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected void leftSelectionChanged()
   {
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected void rightSelectionChanged()
   {
   }


   /**
    * Get the leftIncrementByName attribute of the PEDoubleListSelection object
    *
    * @return   The leftIncrementByName value
    */
   /*
    *  public ASGElement getLeftIncrementByName (String name)
    *  {
    *  return left.getIncrementByName (name);
    *  }
    */
   /**
    * Get the rightIncrementByName attribute of the PEDoubleListSelection object
    *
    * @return   The rightIncrementByName value
    */
   /*
    *  public ASGElement getRightIncrementByName (String name)
    *  {
    *  return right.getIncrementByName (name);
    *  }
    */
   /**
    * Get the horzResizable attribute of the PEDoubleListSelection object
    *
    * @return   The horzResizable value
    */
   public boolean isHorzResizable()
   {
      return true;
   }


   /**
    * Get the vertResizable attribute of the PEDoubleListSelection object
    *
    * @return   The vertResizable value
    */
   public boolean isVertResizable()
   {
      return true;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param g  No description provided
    */
   public void paint (Graphics g)
   {
      super.paint (g);
      g.drawString ("test", 0, 0);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/09/02 10:17:05 $
 * @version   $Revision: 1.2 $
 */
class PELeftSelectionListener implements ListSelectionListener
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDoubleListSelection adaptor;


   /**
    * Constructor for class PELeftSelectionListener
    *
    * @param adapter  No description provided
    */
   PELeftSelectionListener (PEDoubleListSelection adapter)
   {
      adaptor = adapter;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void valueChanged (ListSelectionEvent e)
   {
      adaptor.leftSelectionChanged();
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/09/02 10:17:05 $
 * @version   $Revision: 1.2 $
 */
class PERightSelectionListener implements ListSelectionListener
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDoubleListSelection adaptor;


   /**
    * Constructor for class PERightSelectionListener
    *
    * @param adapter  No description provided
    */
   PERightSelectionListener (PEDoubleListSelection adapter)
   {
      adaptor = adapter;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void valueChanged (ListSelectionEvent e)
   {
      adaptor.rightSelectionChanged();
   }
}

/*
 * $Log: PEDoubleListSelection.java,v $
 * Revision 1.2  2003/09/02 10:17:05  ariseppi
 * Export and view bug fixing and some minor commenting.
 *
 */
