/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this added code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.gui;

// Based on de.uni_paderborn.fujaba.gui.PEListIncr

import de.uni_paderborn.fujaba.asg.ASGElement;
import de.uni_paderborn.fujaba.gui.BasicPropertyEditor;


/**
 * Similar to de.uni_paderborn.fujaba.gui.PEListIncr, but works with fi.uta.dbschema.gui.PEDBListItem
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/09/02 10:17:05 $
 * @version   $Revision: 1.2 $
 */
public class PEDBListIncr extends PEDBList
{
   /**
    * Constructor for class PEDBListIncr
    *
    * @param parent  No description provided
    * @param title   No description provided
    */
   PEDBListIncr (BasicPropertyEditor parent, String title)
   {
      super (parent, title);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param incr  No description provided
    */
   public void add (ASGElement incr)
   {
      getList().add (incr);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param item  No description provided
    */
   public void add (PEDBItem item)
   {
      getList().add (item);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param incr  No description provided
    * @param s     No description provided
    */
   public void add (ASGElement incr, String s)
   {
      PEDBItem item = new PEDBItem (incr, s);
      add (item);
   }


   /**
    * Get the itemByIndex attribute of the PEDBListIncr object
    *
    * @param index  No description provided
    * @return       The itemByIndex value
    */
   public PEDBItem getItemByIndex (int index)
   {
      return getList().getItemByIndex (index);
   }


   /**
    * Get the selectedIncrement attribute of the PEDBListIncr object
    *
    * @return   The selectedIncrement value
    */
   public ASGElement getSelectedIncrement()
   {
      return getList().getSelectedIncrement();
   }


   /**
    * Get the incrementIndex attribute of the PEDBListIncr object
    *
    * @param incr  No description provided
    * @return      The incrementIndex value
    */
   public int getIncrementIndex (ASGElement incr)
   {
      return getList().getIncrementIndex (incr);
   }


   /**
    * Get the incrementByName attribute of the PEDBListIncr object
    *
    * @param name  No description provided
    * @return      The incrementByName value
    */
   public ASGElement getIncrementByName (String name)
   {
      return getList().getIncrementByName (name);
   }


   /**
	* Get the incrementByName attribute of the PEDBListIncr object
	*
	* @param name  No description provided
	* @return      The incrementByName value
	*/
   public String getSelectedText ()
   {
	  return getList().getSelectedText ();
   }


   /**
    * Get the incrementSelected attribute of the PEDBListIncr object
    *
    * @param incr  No description provided
    * @return      The incrementSelected value
    */
   public boolean isIncrementSelected (ASGElement incr)
   {
      return getList().isIncrementSelected (incr);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param incr  No description provided
    */
   public void remove (ASGElement incr)
   {
      getList().remove (incr);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param incr  No description provided
    */
   public void selectIncrement (ASGElement incr)
   {
      getList().selectIncrement (incr);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param incrs  No description provided
    */
   public void selectIncrements (ASGElement[] incrs)
   {
      int[] indices = new int[incrs.length];
      for (int i = 0; i < incrs.length; i++)
      {
         indices[i] = getList().getIncrementIndex (incrs[i]);
      }
      getList().setSelectedIndices (indices);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void clearSelection()
   {
      getList().clearSelection();
   }
}

/*
 * $Log: PEDBListIncr.java,v $
 * Revision 1.2  2003/09/02 10:17:05  ariseppi
 * Export and view bug fixing and some minor commenting.
 *
 */
