/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this added code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.gui;

import java.awt.Cursor;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import javax.swing.Box;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import de.uni_paderborn.fujaba.app.FrameMain;
import de.uni_paderborn.fujaba.asg.ASGElement;
import de.uni_paderborn.fujaba.gui.PEColumn;
import de.uni_paderborn.fujaba.gui.PEEditPanel;
import de.uni_paderborn.fujaba.gui.PERow;
import de.uni_paderborn.fujaba.gui.PETextField;
import de.uni_paderborn.fujaba.uml.UMLProject;
import fi.uta.dbschema.metamodel.DBForeignKey;
import fi.uta.dbschema.metamodel.DBJunctionPair;
import fi.uta.dbschema.metamodel.DBSchema;
import fi.uta.dbschema.metamodel.DBTable;
import fi.uta.dbschema.metamodel.DBTableAttribute;
import fi.uta.dbschema.metamodel.DBTableAttributeJunction;
import fi.uta.dbschema.metamodel.DBTableJunction;
import fi.uta.dbschema.metamodel.DBUnique;
import fi.uta.dbschema.metamodel.DBView;
import fi.uta.dbschema.metamodel.DBViewAttribute;
import fi.uta.dbschema.metamodel.DBViewJoin;

/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:51 $
 * @version   $Revision: 1.4 $
 */
public class PEDBDecompose extends DBPropertyEditor
{
	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	PETextField firstTableName;
	PETextField secondTableName;
	PEDBCheck makeViews;
	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */

	PEDBAttributesSelection attributesSelection;

	/**
	 * Constructor for class PEDBAttribute
	 *
	 * @param frame  No description provided
	 * @param title  No description provided
	 * @param modal  No description provided
	 */
	public PEDBDecompose(JFrame frame, String title, boolean modal)
	{
		super(frame);
		setModal(modal);
		setTitle(title);
		try
		{
			pack();
			this.setTitle("Decompose editor");
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		initPE();
	}

	/**
	 * Constructor for class PEDBAttribute
	 *
	 * @param frame  No description provided
	 */
	public PEDBDecompose(JFrame frame)
	{
		this(frame, "", false);
	}

	/**
	 * Constructor for class PEDBAttribute
	 *
	 * @param frame  No description provided
	 * @param modal  No description provided
	 */
	public PEDBDecompose(JFrame frame, boolean modal)
	{
		this(frame, "", modal);
	}

	/**
	 * Constructor for class PEDBAttribute
	 *
	 * @param frame  No description provided
	 * @param title  No description provided
	 */
	public PEDBDecompose(JFrame frame, String title)
	{
		this(frame, title, false);
	}

	/**
	 * Sets the attributeName attribute of the PEDBAttribute object
	 *
	 * @param name  The new propertyName value
	 */
	public void setFirstTableName(String name)
	{
		firstTableName.setText(name);
	}

	public void setSecondTableName(String name)
	{
		secondTableName.setText(name);
	}
	
	public String getFirstTableName()
	{
		return firstTableName.getText();
	}
	
	public String getSecondTableName()
	{
		return secondTableName.getText();
	}
	
	public void setMakeViews(boolean makeViews)
	{
		this.makeViews.setSelected(makeViews);
	}
	
	public boolean getMakeViews()
	{
		return this.makeViews.isSelected();
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param panel  No description provided
	 */
	protected void additionalProperties(PEEditPanel panel)
	{
		firstTableName = new PETextField(this, "First Table Name");
		secondTableName = new PETextField(this, "Second Table Name");
		attributesSelection = new PEDBAttributesSelection(this);
		
		makeViews = new PEDBCheck(this, "Create views", "Create a view containing attributes from the old table (only works if the primary key is preserved on both tables)");

		firstTableName.setStatus("Enter the name of the first table");
		secondTableName.setStatus("Enter the name of the second table");

		PEColumn column = new PEColumn(this);

		PERow row = new PERow(this);
		row.add(firstTableName);
		row.add(Box.createVerticalGlue());
		row.add(secondTableName);

		column.add(row);

		column.add(attributesSelection);
		column.add(makeViews);

		panel.add(column);
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	public void unparse()
	{
		if (getIncrement() instanceof DBTable)
		{
			this.setTitle("Decompose " + getIncrement().getName());
			//         attributesSelection.setIncrement ((DBTable) getIncrement());
		}
	}

	/**
	 * - Drop the old table
	 * - Create new ones by cloning the needed attributes from old table
	 * - Create uniques from the old table to a new table if possible (if the new
	 * has the needed attributes) 
	 * - Create foreign keys from the old table to a new table if possible (if the new
	 * has the needed attributes)
	 */
	protected void parse()
	{
		DBSchema dbSchema = null;
		Object diagram = UMLProject.get().getCurrentDiagram();
		if (diagram instanceof DBSchema)
		{
			dbSchema = (DBSchema) diagram;
		} else
		{
			return;
		}
		ASGElement incr = getIncrement();

		if (incr instanceof DBTable)
		{
			DBTable table = (DBTable) incr;
			DBTable first = new DBTable(firstTableName.getText());
			DBTable second = new DBTable(secondTableName.getText());
			dbSchema.addToItems(first);
			dbSchema.addToItems(second);

			Iterator iter = table.iteratorOfAttributes();
			ArrayList primary = new ArrayList();
			while (iter.hasNext())
			{
				DBTableAttribute attr = (DBTableAttribute) iter.next();
				if (attr.getPrimaryKeyValue())
				{
					primary.add(attr);
				}
			}
			HashMap firstAttrs = new HashMap();
			HashMap secondAttrs = new HashMap();
			iter = table.iteratorOfAttributes();
			while (iter.hasNext())
			{
				DBTableAttribute attr = (DBTableAttribute) iter.next();
				if (attributesSelection.getLeft().isIncrementSelected(attr))
				{
					DBTableAttribute attrFirst =
						(DBTableAttribute) attr.clone();
					first.addToAttributes(attrFirst);
					firstAttrs.put(attrFirst.getName(), attrFirst);
				}
				if (attributesSelection.getRight().isIncrementSelected(attr))
				{
					DBTableAttribute attrSecond =
						(DBTableAttribute) attr.clone();
					second.addToAttributes(attrSecond);
					secondAttrs.put(attrSecond.getName(), attrSecond);
				}
			}
			/*
			 * If a new table has all the attributes from the decomposed table,
			 * old primary key will be used as the primary key,
			 * if not, all of the attributes will be used as the primary key.
			 * If both of new tables use the old primary key, then a foreign
			 * key will be created between the new tables.  
			 */
			boolean firstHasAll = true;
			boolean secondHasAll = true;
			iter = primary.iterator();
			while (iter.hasNext())
			{
				DBTableAttribute attr = (DBTableAttribute) iter.next();
				if (!firstAttrs.containsKey(attr.getName()))
				{
					firstHasAll = false;
				}
				if (!secondAttrs.containsKey(attr.getName()))
				{
					secondHasAll = false;
				}
			}
			if (!firstHasAll)
			{
				iter = first.iteratorOfAttributes();
				while (iter.hasNext())
				{
					DBTableAttribute attr = (DBTableAttribute) iter.next();
					if (!attr.getPrimaryKeyValue())
					{
						attr.setPrimaryKeyValue(true);
					}
				}
			}
			if (!secondHasAll)
			{
				iter = second.iteratorOfAttributes();
				while (iter.hasNext())
				{
					DBTableAttribute attr = (DBTableAttribute) iter.next();
					if (!attr.getPrimaryKeyValue())
					{
						attr.setPrimaryKeyValue(true);
					}
				}
			}
			DBForeignKey betweenKey = null;
			if (firstHasAll && secondHasAll)
			{
				betweenKey = new DBForeignKey();
				betweenKey.setOriginalTable(first);
				betweenKey.setRevTable(second);
				iter = primary.iterator();
				while (iter.hasNext())
				{
					DBTableAttribute primaryAttr =
						(DBTableAttribute) iter.next();
					DBTableAttribute firstAttr =
						(DBTableAttribute) firstAttrs.get(
							primaryAttr.getName());
					DBTableAttribute secondAttr =
						(DBTableAttribute) secondAttrs.get(
							primaryAttr.getName());

					DBJunctionPair newPair = new DBJunctionPair();
					betweenKey.addToJunctionPairs(newPair);
					DBTableAttributeJunction origJunc =
						new DBTableAttributeJunction(firstAttr);
					origJunc.setPair(newPair);
					newPair.setOriginalJunction(origJunc);
					DBTableAttributeJunction revJunc =
						new DBTableAttributeJunction(secondAttr);
					revJunc.setPair(newPair);
					newPair.setRevJunction(revJunc);
				}
				dbSchema.addToItems(betweenKey);
			}
			iter = table.iteratorOfUniques();
			boolean addFirst = true;
			boolean addSecond = true;
			while (iter.hasNext())
			{
				addFirst = true;
				addSecond = true;
				DBUnique uni = (DBUnique) iter.next();
				Iterator iter2 = uni.iteratorOfAttributes();
				while (iter2.hasNext())
				{
					DBTableAttribute attr = (DBTableAttribute) iter2.next();
					if (!attributesSelection
						.getLeft()
						.isIncrementSelected(attr))
					{
						addFirst = false;
					}
					if (!attributesSelection
						.getRight()
						.isIncrementSelected(attr))
					{
						addSecond = false;
					}
				}
				if (addFirst)
				{
					iter2 = uni.iteratorOfAttributes();
					DBUnique newUnique = new DBUnique();
					while (iter2.hasNext())
					{
						ASGElement elem = (ASGElement) iter2.next();
						DBTableAttribute tableAttr =
							(DBTableAttribute) firstAttrs.get(elem.getName());
						newUnique.addToAttributes(tableAttr);
					}
					newUnique.setParent(first);
				}
				if (addSecond)
				{
					iter2 = uni.iteratorOfAttributes();
					DBUnique newUnique = new DBUnique();
					while (iter2.hasNext())
					{
						ASGElement elem = (ASGElement) iter2.next();
						DBTableAttribute tableAttr =
							(DBTableAttribute) secondAttrs.get(elem.getName());
						newUnique.addToAttributes(tableAttr);
					}
					newUnique.setParent(first);
				}
			}
			iter = table.iteratorOfForeignKeys();
			while (iter.hasNext())
			{
				addFirst = true;
				addSecond = true;
				DBForeignKey fk = (DBForeignKey) iter.next();
				Iterator iter2 = fk.iteratorOfJunctionPairs();
				while (iter2.hasNext())
				{
					DBJunctionPair pair = (DBJunctionPair) iter2.next();
					if (!attributesSelection
						.getLeft()
						.isIncrementSelected(
							pair.getOriginalJunction().getTarget()))
					{
						addFirst = false;
					}
					if (!attributesSelection
						.getRight()
						.isIncrementSelected(
							pair.getOriginalJunction().getTarget()))
					{
						addSecond = false;
					}
				}
				if (addFirst)
				{
					iter2 = fk.iteratorOfJunctionPairs();
					DBForeignKey newKey = new DBForeignKey();
					newKey.setOriginalTable(first);
					newKey.setRevTable(fk.getRevTable());
					while (iter2.hasNext())
					{
						DBJunctionPair pair = (DBJunctionPair) iter2.next();
						DBTableAttribute own =
							pair.getOriginalJunction().getTarget();
						DBTableAttribute otherAttr =
							pair.getRevJunction().getTarget();

						DBTableAttribute ownAttr =
							(DBTableAttribute) firstAttrs.get(own.getName());

						DBJunctionPair newPair = new DBJunctionPair();
						newKey.addToJunctionPairs(newPair);
						DBTableAttributeJunction origJunc =
							new DBTableAttributeJunction(ownAttr);
						origJunc.setPair(newPair);
						newPair.setOriginalJunction(origJunc);
						DBTableAttributeJunction revJunc =
							new DBTableAttributeJunction(otherAttr);
						revJunc.setPair(newPair);
						newPair.setRevJunction(revJunc);
					}
					dbSchema.addToItems(newKey);
				}
				if (addSecond)
				{
					iter2 = fk.iteratorOfJunctionPairs();
					DBForeignKey newKey = new DBForeignKey();
					newKey.setOriginalTable(second);
					newKey.setRevTable(fk.getRevTable());
					while (iter2.hasNext())
					{
						DBJunctionPair pair = (DBJunctionPair) iter2.next();
						DBTableAttribute own =
							pair.getOriginalJunction().getTarget();
						DBTableAttribute otherAttr =
							pair.getRevJunction().getTarget();

						DBTableAttribute ownAttr =
							(DBTableAttribute) secondAttrs.get(own.getName());

						DBJunctionPair newPair = new DBJunctionPair();
						newKey.addToJunctionPairs(newPair);
						DBTableAttributeJunction origJunc =
							new DBTableAttributeJunction(ownAttr);
						origJunc.setPair(newPair);
						newPair.setOriginalJunction(origJunc);
						DBTableAttributeJunction revJunc =
							new DBTableAttributeJunction(otherAttr);
						revJunc.setPair(newPair);
						newPair.setRevJunction(revJunc);
					}
					dbSchema.addToItems(newKey);
				}
			}
			iter = table.iteratorOfRevForeignKeys();
			while (iter.hasNext())
			{
				addFirst = true;
				addSecond = true;
				DBForeignKey fk = (DBForeignKey) iter.next();
				Iterator iter2 = fk.iteratorOfJunctionPairs();
				while (iter2.hasNext())
				{
					DBJunctionPair pair = (DBJunctionPair) iter2.next();
					if (!attributesSelection
						.getLeft()
						.isIncrementSelected(pair.getRevJunction().getTarget()))
					{
						addFirst = false;
					}
					if (!attributesSelection
						.getRight()
						.isIncrementSelected(pair.getRevJunction().getTarget()))
					{
						addSecond = false;
					}
				}
				if (addFirst)
				{
					iter2 = fk.iteratorOfJunctionPairs();
					DBForeignKey newKey = new DBForeignKey();
					newKey.setOriginalTable(fk.getOriginalTable());
					newKey.setRevTable(first);
					while (iter2.hasNext())
					{
						DBJunctionPair pair = (DBJunctionPair) iter2.next();
						DBTableAttribute ownAttr =
							pair.getOriginalJunction().getTarget();
						DBTableAttribute other =
							pair.getRevJunction().getTarget();

						DBTableAttribute otherAttr =
							(DBTableAttribute) firstAttrs.get(other.getName());

						DBJunctionPair newPair = new DBJunctionPair();
						newKey.addToJunctionPairs(newPair);
						DBTableAttributeJunction origJunc =
							new DBTableAttributeJunction(ownAttr);
						origJunc.setPair(newPair);
						newPair.setOriginalJunction(origJunc);
						DBTableAttributeJunction revJunc =
							new DBTableAttributeJunction(otherAttr);
						revJunc.setPair(newPair);
						newPair.setRevJunction(revJunc);
					}
					dbSchema.addToItems(newKey);
				}
				if (addSecond)
				{
					iter2 = fk.iteratorOfJunctionPairs();
					DBForeignKey newKey = new DBForeignKey();
					newKey.setOriginalTable(fk.getOriginalTable());
					newKey.setRevTable(second);
					while (iter2.hasNext())
					{
						DBJunctionPair pair = (DBJunctionPair) iter2.next();
						DBTableAttribute ownAttr =
							pair.getOriginalJunction().getTarget();
						DBTableAttribute other =
							pair.getRevJunction().getTarget();

						DBTableAttribute otherAttr =
							(DBTableAttribute) secondAttrs.get(other.getName());

						DBJunctionPair newPair = new DBJunctionPair();
						newKey.addToJunctionPairs(newPair);
						DBTableAttributeJunction origJunc =
							new DBTableAttributeJunction(ownAttr);
						origJunc.setPair(newPair);
						newPair.setOriginalJunction(origJunc);
						DBTableAttributeJunction revJunc =
							new DBTableAttributeJunction(otherAttr);
						revJunc.setPair(newPair);
						newPair.setRevJunction(revJunc);
					}
					dbSchema.addToItems(newKey);
				}
				if(betweenKey != null && getMakeViews())
				{
					DBView view = new DBView(table.getName());
					view.setJavaPackage(table.getJavaPackage());
					iter = table.iteratorOfAttributes();
					while(iter.hasNext())
					{
						ASGElement attr = (ASGElement) iter.next();
						if(attributesSelection
						.getLeft()
						.isIncrementSelected(attr)) 
						{
							DBViewAttribute viewAttr = new DBViewAttribute();
							DBTableAttribute firstAttr = (DBTableAttribute) firstAttrs.get(attr.getName());
							viewAttr.setAttribute(firstAttr);
							viewAttr.setName(firstAttr.getName());
							viewAttr.setParent(view);
						}
						else if(attributesSelection
						.getRight()
						.isIncrementSelected(attr))
						{
							DBViewAttribute viewAttr = new DBViewAttribute();
							DBTableAttribute secondAttr = (DBTableAttribute) secondAttrs.get(attr.getName());
							viewAttr.setAttribute(secondAttr);
							viewAttr.setName(secondAttr.getName());
							viewAttr.setParent(view);
						}
					}
					DBViewJoin firstJoin = new DBViewJoin();

					DBTableJunction firstJunc = new DBTableJunction (view);
					DBTableJunction secondJunc = new DBTableJunction (first);

					secondJunc.setAdornment (DBTableJunction.FILLED_BOX);

					firstJoin.setFirstJunction (firstJunc);
					firstJoin.setSecondJunction (secondJunc);

					view.addToJoins (firstJoin);
					
					DBViewJoin secondJoin = new DBViewJoin();

					firstJunc = new DBTableJunction (view);
					secondJunc = new DBTableJunction (second);

					secondJunc.setAdornment (DBTableJunction.FILLED_BOX);

					secondJoin.setFirstJunction (firstJunc);
					secondJoin.setSecondJunction (secondJunc);

					view.addToJoins (secondJoin);
					
					view.setWhereClause(betweenKey.getWhereClause());

					dbSchema.addToItems (view);
					dbSchema.addToItems (firstJoin);
					dbSchema.addToItems (secondJoin);
				}
			}
			table.removeYou();
		}
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	protected void cancel()
	{
		setVisible(false);
		dispose();
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param e  No description provided
	 */
	public void buttonOK_actionPerformed(ActionEvent e)
	{
		//      super.buttonOK_actionPerformed (e);
		if (getFrame() != null)
		{
			getFrame().setCursor(
				Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
		} // if

		try
		{
			if (getFirstTableName().equals(""))
			{
				JOptionPane.showMessageDialog(
					FrameMain.get().getFrame(),
					"Error: The name of the first table missing.",
					"Missing table name",
					JOptionPane.ERROR_MESSAGE);
				return;
			}
			if (getSecondTableName().equals(""))
			{
				JOptionPane.showMessageDialog(
					FrameMain.get().getFrame(),
					"Error: The name of the second table missing.",
					"Missing table name",
					JOptionPane.ERROR_MESSAGE);
				return;
			}
			if (getMakeViews())
			{
				if (getFirstTableName().equals(getIncrement().getName()))
				{
					JOptionPane.showMessageDialog(
						FrameMain.get().getFrame(),
						"Error: The name of the first table is the same\n"
							+ "as the name of the decomposed table. Cannot create a view.",
						"Illegal name",
						JOptionPane.ERROR_MESSAGE);
					return;
				}
				if (getSecondTableName().equals(getIncrement().getName()))
				{
					JOptionPane.showMessageDialog(
						FrameMain.get().getFrame(),
						"Error: The name of the second table is the same\n"
							+ "as the name of the decomposed table. Cannot create a view.",
						"Illegal name",
						JOptionPane.ERROR_MESSAGE);
					return;
				}
			}
			if (!attributesSelection.areAllSelected())
			{
				JOptionPane.showMessageDialog(
									FrameMain.get().getFrame(),
									"Error: Not all attributes are selected.",
									"Unselected attributes",
									JOptionPane.ERROR_MESSAGE);
			}
			parse();
			setVisible(false);
			UMLProject.get().refreshDisplay();
		} finally
		{
			if (getFrame() != null)
			{
				getFrame().setCursor(
					Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
			}
		}
	}

	/**
	 * Sets the increment attribute of the PEDBAttribute object
	 *
	 * @param incr  The new increment value
	 */
	public void setIncrement(ASGElement incr)
	{
		super.setIncrement(incr);
		attributesSelection.fillLeftList();
		attributesSelection.fillRightList();
	}
}

/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:51 $
 * @version   $Revision: 1.4 $
 */
class PEDBAttributesSelection extends PEDoubleListSelection
{
	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	private PEDBDecompose decomposeEditor;

	/**
	 * Constructor for class PEVariableSelection
	 *
	 * @param parent  No description provided
	 */
	PEDBAttributesSelection(DBPropertyEditor parent)
	{
		super(parent);
		getLeft().setHeader("Attributes of the first table");
		getRight().setHeader("Attributes of the second table");
		decomposeEditor = (PEDBDecompose) parent;
		getLeft().setSingleSelection(false);
		getRight().setSingleSelection(false);
	}

	public static final int none = 0;
	public static final int first = 1;
	public static final int second = 2;
	public static final int both = 3;

	public int isSelected(ASGElement incr)
	{
		int value = 0;
		if (getLeft().isIncrementSelected(incr))
		{
			value++;
		}
		if (getRight().isIncrementSelected(incr))
		{
			value += 2;
		}
		return value;
	}

	public boolean areAllSelected()
	{
		Iterator iter =
			((DBTable) decomposeEditor.getIncrement()).iteratorOfAttributes();
		while (iter.hasNext())
		{
			ASGElement elem = (ASGElement) iter.next();
			if (!getLeft().isIncrementSelected(elem)
				&& !getRight().isIncrementSelected(elem))
			{
				return false;
			}
		}
		return true;
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	public void fillLeftList()
	{
		clearLeft();
		Object incr = decomposeEditor.getIncrement();
		if (incr != null)
		{
			DBTable table = (DBTable) incr;
			Iterator iter = table.iteratorOfAttributes();
			while (iter.hasNext())
			{
				left.add((ASGElement) iter.next());
			}
		}
	}

	public void fillRightList()
	{
		clearRight();
		Object incr = decomposeEditor.getIncrement();
		if (incr != null)
		{
			DBTable table = (DBTable) incr;
			Iterator iter = table.iteratorOfAttributes();
			while (iter.hasNext())
			{
				right.add((ASGElement) iter.next());
			}
		}
	}

	/**
	 * Get the sqlType attribute of the PEDBDataTypeSelection object
	 *
	 * @return   The sqlType value
	 */
	public DBTableAttribute[] getFirstAttributes()
	{
		DBTableAttribute[] attributes =
			(DBTableAttribute[]) left.getList().getSelectedValues();
		return attributes;
	}

	public DBTableAttribute[] getSecondAttributes()
	{
		DBTableAttribute[] attributes =
			(DBTableAttribute[]) right.getList().getSelectedValues();
		return attributes;
	}
}

/*
 * $Log: PEDBAttribute.java,v $
 * Revision 1.4  2003/10/07 07:21:51  ariseppi
 * misc. corrections
 *
 */
