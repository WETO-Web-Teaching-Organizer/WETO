/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.cs.dbswtool;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StreamTokenizer;
import java.util.Vector;


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:48 $
 * @version   $Revision: 1.2 $
 */
public class AttributeVector implements AttributeStore
{
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private Vector attributeVector;
   
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @return   No description provided
    */
   public int size()
   {
      return attributeVector.size();
   }


   /**
    * Constructor for class AttributeVector
    */
   public AttributeVector()
   {
      attributeVector = new Vector();
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void output()
   {
      System.out.println ("AttributeVector with size " + attributeVector.size());
      for (int i = 0; i < attributeVector.size(); i++)
      {
         Attribute a = (Attribute) attributeVector.elementAt (i);
         a.output();
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void shortOutput()
   {
      System.out.println ("AttributeVector with size " + attributeVector.size());
      for (int i = 0; i < attributeVector.size(); i++)
      {
         Attribute a = (Attribute) attributeVector.elementAt (i);
         a.shortOutput();
      }
   }


   /**
    * Get the attribute attribute of the AttributeVector object
    *
    * @param name  No description provided
    * @return      The attribute value
    */
   public Attribute getAttribute (String name)
   {
      Attribute aFound = null;
      int i = 0;
      while ( (i < attributeVector.size()) &&  (aFound == null))
      {
         Attribute a = (Attribute) attributeVector.elementAt (i);
         i++;
         if (name.equals (a.getName()))
         {
            aFound = a;
         }
      }
      return aFound;
   }


   /**
    * Get the attribute attribute of the AttributeVector object
    *
    * @param i  No description provided
    * @return   The attribute value
    */
   public Attribute getAttribute (int i)
   {
      return (Attribute) attributeVector.elementAt (i);
   }


   /**
    * Get the attributeByRole attribute of the AttributeVector object
    *
    * @param role  No description provided
    * @return      The attributeByRole value
    */
   public Attribute getAttributeByRole (String role)
   {
      Attribute aFound = null;
      int i = 0;
      while ( (i < attributeVector.size()) &&  (aFound == null))
      {
         Attribute a = (Attribute) attributeVector.elementAt (i);
         i++;
         if (role.equals (a.getRole()))
         {
            aFound = a;
         }
      }
      return aFound;
   }


   /**
    * Access method for an one to n association.
    *
    * @param newAttribute  The object added.
    */
   public void addAttribute (Attribute newAttribute)
   {
      //	output();
      // if (getAttribute(newAttribute.getName())==null) {
      attributeVector.add (newAttribute);
      // }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param projectdir  No description provided
    */
   public void writeHtmlFile (String projectdir)
   {
      StringBuffer sb = new StringBuffer();
      sb.append (htmlFileHeader1);
      sb.append (htmlFileHeader2);
      sb.append (htmlFileHeader3);
      sb.append (htmlFileHeader4);
      sb.append (beginHtmlTable);
      sb.append (beginHtmlTableRow + endLine);
      sb.append (beginHtmlTableColumn + " " + nameString + " " + endHtmlTableColumn + endLine);
      sb.append (beginHtmlTableColumn + " " + sqlString + " " + endHtmlTableColumn + endLine);
      sb.append (beginHtmlTableColumn + " " + javaString + " " + endHtmlTableColumn + endLine);
	sb.append (beginHtmlTableColumn + " <b>Description</b> " + endHtmlTableColumn + endLine);
      sb.append (endHtmlTableRow + endLine);
      for (int i = 0; i < attributeVector.size(); i++)
      {
         Attribute a = (Attribute) attributeVector.elementAt (i);
         sb.append (beginHtmlTableRow + endLine);
         sb.append (beginHtmlTableColumn + " " + beginHtmlTarget + " " + a.getName() + " " +
            endHtmlTarget + " " + a.getName() + " " + endHtmlTableColumn + endLine);
         sb.append (beginHtmlTableColumn + " " + a.getSQLType() + " " + endHtmlTableColumn + endLine);
         sb.append (beginHtmlTableColumn + " " + a.getJavaType());
         if ( (a.getJavaType() == dbVarcharName) ||  (a.getJavaType() == dbCharName))
         {
            sb.append (openParent + a.getJavaTypeLength().toString() + closeParent);
         }
         if (a.getJavaType() == dbDecimalName)
         {
            sb.append (openParent + a.getJavaTypeLength().toString() +
               a.getJavaTypeScale().toString() + closeParent);
         }
         sb.append (" " + endHtmlTableColumn + endLine);
		 sb.append (beginHtmlTableColumn + " " + a.getDescription() + " " + endHtmlTableColumn + endLine);
         sb.append (endHtmlTableRow + endLine);
      }
      sb.append (endHtmlFile);

      try
      { // Write the contents of output to a file using a FileWriter
         File outFile = new File (projectdir + "/" + attributeHtmlFileName);
         FileWriter writer = new FileWriter (outFile);
         writer.write (sb.toString());
         writer.close();
      }
      catch (Exception e)
      {
         System.out.println (e);
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param projectdir  No description provided
    * @param filename    No description provided
    * @return            No description provided
    */
   public int readAttributeFile (String projectdir, String filename)
   {

      String name = "";
      String sqlType = "";
      String javaType = "";
      Integer javaTypeLength = new Integer (0);
      Integer javaTypeScale = new Integer (0);

      try
      {

         // Open the file, do the technicalities to get StreamTokenizer
         FileInputStream fis = new FileInputStream (projectdir + "/" + filename);

         InputStreamReader isr = new InputStreamReader (fis);
         BufferedReader br = new BufferedReader (isr);
         StreamTokenizer st = new StreamTokenizer (br);
         st.slashSlashComments (false);
         st.wordChars ('_', '_');
         st.wordChars ('[', '[');
         st.wordChars (']', ']');
         st.wordChars ('(', '(');
         st.wordChars (')', ')');
         st.ordinaryChars ('0', '9');
         st.wordChars ('0', '9');

         int nextType = expectingAttributeName;

         while (st.nextToken() != StreamTokenizer.TT_EOF)
         {
            if (st.ttype != StreamTokenizer.TT_WORD)
            {
               System.out.println ("Expecting a string, got " + st.toString());
            }
            else
            {
               switch (nextType)
               {
                  case expectingAttributeName:
                     name = st.sval.toLowerCase();
                     javaTypeLength = new Integer (0);
                     javaTypeScale = new Integer (0);
                     nextType = expectingSQLType;
                     break;
                  case expectingSQLType:
                     sqlType = st.sval;
                     nextType = expectingJavaType;
                     break;
                  case expectingJavaType:
                     javaType = st.sval;
                     // System.out.println("Adding " + name + sqlType + javaType);
                     if ( (javaType.equals (dbVarcharName)) ||  (javaType.equals (dbCharName)) ||
                         (javaType.equals (dbDecimalName)) ||  (javaType.equals (dbLongvarcharName)))
                     {
                        nextType = expectingJavaTypeLength;
                     }
                     else
                     {
                        Attribute a = new Attribute (name, sqlType, javaType, AttributeVector.isStringClass(javaType));
                        addAttribute (a);
                        nextType = expectingAttributeName;
                     }
                     break;
                  case expectingJavaTypeLength:
                     javaTypeLength = new Integer (st.sval);
                     if (javaType.equals (dbDecimalName))
                     {
                        nextType = expectingJavaTypeScale;
                     }
                     else
                     {
                        Attribute a = new Attribute (name, sqlType, javaType, AttributeVector.isStringClass(javaType));
                        a.setJavaTypeLength (javaTypeLength);
                        addAttribute (a);
                        nextType = expectingAttributeName;
                     }
                     break;
                  case expectingJavaTypeScale:
                     javaTypeScale = new Integer (st.sval);
                     nextType = expectingAttributeName;
                     Attribute a = new Attribute (name, sqlType, javaType, AttributeVector.isStringClass(javaType));
                     a.setJavaTypeLength (javaTypeLength);
                     a.setJavaTypeScale (javaTypeScale);
                     addAttribute (a);
                     break;
                  default:
                     break;
               } // end switch
            } // end of getting a string
         }
         return attributeFileReadOk;
      }
      catch (IOException e)
      {
         System.out.println (e);
         return attributeFileReadFailed;
      }
   }
	
	public static Boolean isStringClass(String javaType) {
		boolean isString = false;   
		try {
			Class testClass = Class.forName("fi.uta.cs.sqldatatypes." + javaType);
			if(Dbswtool.stringClass.isAssignableFrom(testClass)) {
				isString = true;
			}
		}
		catch (Exception e) {}
		return new Boolean(isString);
	}

}

/*
 * $Log: AttributeVector.java,v $
 * Revision 1.2  2003/10/07 07:21:48  ariseppi
 * misc. corrections
 *
 */
