/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.cs.sqldatatypes;

import fi.uta.cs.sqldatamodel.InvalidValueException;
import fi.uta.cs.sqldatamodel.NullNotAllowedException;
import fi.uta.cs.sqldatamodel.ValueTooLongException;

/**
 * Concrete implementation of string-based SQL data types.
 * 
 * Value data type is java.lang.String.
 * JDBC data type is java.lang.String.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:49 $
 * @version   $Revision: $
 */
public class SqlString extends SqlDataType {
	/**
	 * Value attribute.
	 */
	private String value;
	
	/**
	 * Maximum length attribute.
	 */
	private int maxLength;

	/**
	 * Constructor for class SqlString.
	 * 
	 * @param maxLength Maximum length of the string value.
	 * 	If -1 is given, the length is not limited.
	 */
	public SqlString( int maxLength ) {
		super();
		value = null;
		this.maxLength = maxLength;
	}
	
	/**
	 * Initializing constructor for Fujaba.
	 *
	 * @param maxLength Maximum length of the string value.
	 * 	If -1 is given, the length is not limited. 
	 * @param value Initial value as its string representation.
	 *  If an invalid value is given, the result is undefined
	 *  (a runtime exception may be thrown).
	 */
	public SqlString( int maxLength, String value )
	{
		this( maxLength );
		try {
			fromString( value );
		} catch( InvalidValueException e ) {
			// Ignored
		}
	}

//	======================================================================
//	Bean property methods
//	======================================================================
	
	/**
	 * Gets the value.
	 * 
	 * @return The current value.
	 */
	public String getValue() {
		// String is immutable
		return value;
	}
	
	/**
	 * Sets the value.
	 * 
	 * @param value New value, passed by copy.
	 * 
	 * @throws NullNotAllowedException if a null-value is given, but
	 * 	not allowed.
	 * @throws ValueTooLongException if the given value exceeds the
	 * 	maximum length.
	 */
	public void setValue( String value ) throws NullNotAllowedException, ValueTooLongException {
		if( value==null && !isNullAllowed() ) 
			throw new NullNotAllowedException();
		if( value!=null && maxLength>=0 ) {
			if( value.length()>maxLength ) throw new ValueTooLongException();
		}
		setValueUnchecked( value );
	}
	
	/**
	 * Sets the value without performing any checks.
	 * 
	 * @param value New value.
	 */
	public void setValueUnchecked( String value ) {
		if( value == null ) {
			this.value = null;
		} else {
			// String is immutable
			this.value = value;
		}
	}
	
	/**
	 * Gets the maximum length of the string.
	 * 
	 * @return Maximum length as an integer.
	 */
	public int getMaxLength() {
		if( maxLength<0 ) return Integer.MAX_VALUE;
		return maxLength;
	}

//	======================================================================
//	JDBC property methods
//	======================================================================

	/**
	 * Gets the value as the type used with JDBC.
	 * 
	 * @return The current value.
	 */
	public String jdbcGetValue() {
		return getValue();
	}
	
	/**
	 * Sets the value as the type used with JDBC.
	 * 
	 * @param value New value.
	 *
	 * @throws NullNotAllowedException if a null-value is given, but
	 * 	not allowed.
	 * @throws ValueTooLongException if the given value exceeds the
	 * 	maximum length.
	 */
	public void jdbcSetValue( String value ) throws NullNotAllowedException, ValueTooLongException {
		setValue( value );
	}
	
//	======================================================================
//	SqlDataType methods
//	======================================================================

	public String toString() {
		if( value == null ) return "";
		return value;
	}

	/**
	 * Sets the value of the object from the given string.
	 * 
	 * Note that for SqlString-derived classes this is not the
	 * exact inverse of toString-operations, since an empty
	 * string does not assign null value.
	 * 
	 * @param str String value
	 * 
	 * @see fi.uta.cs.sqldatatypes.SqlDataType#fromString(java.lang.String)
	 */
	public void fromString( String str ) throws NullNotAllowedException, ValueTooLongException {
		String newValue = null;
		if( str!=null ) {
			newValue = str;
		}
		setValue( newValue );
	}

	public boolean isValid() {
		if( (value==null) && (!isNullAllowed()) ) return false;
		if( value!=null && maxLength>=0 ) {
			if( value.length()>maxLength ) return false;
		}
		return true;
	}

	public boolean equals(Object obj) {
		if( !(obj instanceof SqlString) ) return false;
		SqlString strObj = (SqlString)obj;
		
		if( value==null || strObj.value==null ) {
			if( value==null && strObj.value==null ) return true;
			return false;
		}
		
		return value.equals( strObj.value );
	}

	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	
	public String getLongestString() {
		int stringLength = getMaxLength();
		if( stringLength == Integer.MAX_VALUE ) {
			// Use 64K for unlimited strings
			stringLength = 65536;
		}
		StringBuffer sb = new StringBuffer(stringLength);
        for(int i = 0; i < stringLength; i++) {
        	sb.append("M");
        }
        return sb.toString();
	}
}

/*
 * $Log: SqlString.java,v $
 * Revision 1.2  2003/10/07 07:21:49  ariseppi
 * misc. corrections
 *
 */

// End of file.
