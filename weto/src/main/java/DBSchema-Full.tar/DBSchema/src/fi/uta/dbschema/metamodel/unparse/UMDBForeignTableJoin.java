/*
 * Created on 14.6.2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package fi.uta.dbschema.metamodel.unparse;

import de.uni_paderborn.fujaba.fsa.FSAObject;
import de.uni_paderborn.fujaba.fsa.unparse.AbstractUnparseModule;
import de.uni_paderborn.fujaba.fsa.unparse.LogicUnparseInterface;

/**
 * @author as66033
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class UMDBForeignTableJoin extends AbstractUnparseModule
{
	/**
	 * @param parent  No description provided
	 * @param incr    No description provided
	 * @return        No description provided
	 * @see           de.uni_paderborn.fujaba.fsa.unparse.UnparseInterface#create(de.uni_paderborn.fujaba.fsa.FSAObject,
	 *      de.uni_paderborn.fujaba.fsa.unparse.LogicUnparseInterface)
	 */
	public FSAObject create (FSAObject parent, LogicUnparseInterface incr)
	{
		return null;
	}
}
