/*
 * Created on Oct 4, 2004
 */
package fi.uta.cs.sqldatamodel;

/**
 * Exception indicating that the given value is incompatible,
 * or otherwise invalid.
 */
public class InvalidValueException extends SqlDataException {

	private static final long serialVersionUID = 7106019379440346376L;

	public InvalidValueException() {
		super();
	}

	public InvalidValueException(String message) {
		super(message);
	}
}

// End of file.
