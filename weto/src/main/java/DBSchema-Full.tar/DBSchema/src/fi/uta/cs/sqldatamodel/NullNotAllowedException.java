/*
 * Created on Oct 4, 2004
 */
package fi.uta.cs.sqldatamodel;

/**
 * Exception indicating that a null-value was given, but not
 * allowed.
 */
public class NullNotAllowedException extends InvalidValueException {

	private static final long serialVersionUID = 2649634584982885919L;

	public NullNotAllowedException() {
		super();
	}

	public NullNotAllowedException(String message) {
		super(message);
	}
}

// End of file.
