/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this added code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.gui;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import de.uni_paderborn.fujaba.gui.PEButton;
import de.uni_paderborn.fujaba.gui.PEResizable;


/**
 * Similar to de.uni_paderborn.fujaba.gui.PEBaseComponent, but works with fi.uta.dbschema.gui.BasicDialog
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:51 $
 * @version   $Revision: 1.3 $
 */
public abstract class BDBaseComponent extends JPanel implements PEResizable
{
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private String componentName = null;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private String status = null;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private Insets inset = null;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected BasicDialog parent = null;


   /**
    * Constructor for class BDBaseComponent
    *
    * @param editor  No description provided
    */
   public BDBaseComponent (BasicDialog editor)
   {
      super();
      setParent (editor);
      setLayout (getLayoutManager());
      addComponents();
   }


   /**
    * Constructor for class BDBaseComponent
    *
    * @param editor  No description provided
    * @param name    No description provided
    */
   public BDBaseComponent (BasicDialog editor, String name)
   {
      this (editor);
      setComponentName (name);
   }


   /**
    * Overridden method to provide a write access method for insets.
    *
    * @return   The insets value
    */
   public Insets getInsets()
   {
      if (this.inset == null)
      {
         return super.getInsets();
      }
      else
      {
         return inset;
      }
   }


   /**
    * Missing write access method in JComponent
    *
    * @param newInset  The new insets value
    */
   public void setInsets (Insets newInset)
   {
      this.inset = newInset;
   }


   /**
    * Sets the componentName attribute of the BDBaseComponent object
    *
    * @param name  The new componentName value
    */
   public void setComponentName (String name)
   {
      componentName = name;
   }


   /**
    * Get the componentName attribute of the BDBaseComponent object
    *
    * @return   The componentName value
    */
   public String getComponentName()
   {
      return componentName;
   }


   /**
    * Get the componentByName attribute of the BDBaseComponent object
    *
    * @param searchName  No description provided
    * @return            The componentByName value
    */
   public BDBaseComponent getComponentByName (String searchName)
   {
      int nmembers = getComponentCount();
      Component comp = null;
      BDBaseComponent basecomp = null;
      for (int i = 0; i < nmembers; i++)
      {
         comp = getComponent (i);
         if (comp instanceof BDBaseComponent)
         {
            basecomp = (BDBaseComponent) comp;
            if ( (basecomp.getComponentName() != null) &&  (basecomp.getComponentName().equals (searchName)))
            {
               return basecomp;
            }
            if (basecomp instanceof BDComponentGroup)
            {
               BDBaseComponent c = basecomp.getComponentByName (searchName);
               if (c != null)
               {
                  return c;
               }
            }
         }
      }
      return null;
   }


   /**
    * Constructor for class BDBaseComponent
    */
   public BDBaseComponent()
   {
      super();
   }


   /**
    * Sets the parent attribute of the BDBaseComponent object
    *
    * @param parent  The new parent value
    */
   protected void setParent (BasicDialog parent)
   {
      this.parent = parent;
   }


   /**
    * Get the layoutManager attribute of the BDBaseComponent object
    *
    * @return   The layoutManager value
    */
   protected LayoutManager getLayoutManager()
   {
      return new BDComponentLayout();
   }


   /**
    * Access method for an one to n association.
    */
   protected abstract void addComponents();


   /**
    * Sets the readOnly attribute of the BDBaseComponent object
    *
    * @param b  The new readOnly value
    */
   public abstract void setReadOnly (boolean b);


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void focusGained()
   {
      parent.setStatus (getStatus());
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void focusLost()
   {
      parent.setStatus ("");
   }


   /**
    * Sets the status attribute of the BDBaseComponent object
    *
    * @param status  The new status value
    */
   public void setStatus (String status)
   {
      this.status = status;
   }


   /**
    * Get the status attribute of the BDBaseComponent object
    *
    * @return   The status value
    */
   protected String getStatus()
   {
      if (status == null)
      {
         return "";
      }
      return status;
   }

   //////////////////////////////////////////////////////////////////////////
   // thsa : added some function to handle button events for
   // in subclasses introduced buttons
   // --> to be overwritten by each subclass which
   // introduces any new button

   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param buttonIdentifier  No description provided
    * @param e                 No description provided
    * @return                  No description provided
    */
   public boolean buttonActionPerformed (String buttonIdentifier, ActionEvent e)
   {
      return PEButton.remainedUnbound;
   }

}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:51 $
 * @version   $Revision: 1.3 $
 */
class BDComponentLayout implements LayoutManager,
   java.io.Serializable
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private int labelHeight = 0;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private int height = 0;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private int listCount = 0;
   // these methods are not used for this layout

   /**
    * Access method for an one to n association.
    *
    * @param name  The object added.
    * @param comp  The object added.
    */
   public void addLayoutComponent (String name, Component comp)
   {
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param comp  No description provided
    */
   public void removeLayoutComponent (Component comp)
   {
   }

   // methods to layout the DisplayClass
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param target  No description provided
    * @return        No description provided
    */
   public Dimension preferredLayoutSize (Container target)
   {
      Dimension dim = new Dimension (0, 0);
      Insets inset = new Insets (1, 1, 1, 1);
      Component item = null;
      listCount = 0;
      height = 0;
      labelHeight = 0;
      int nmembers = target.getComponentCount();
      for (int i = 0; i < nmembers; i++)
      {
         item = target.getComponent (i);
         if (item instanceof JScrollPane)
         {
            listCount++;
         }
         else if (item instanceof JLabel)
         {
            labelHeight = item.getPreferredSize().height;
         }
         dim.height += item.getPreferredSize().height;
         dim.width = Math.max (dim.width, item.getPreferredSize().width);
      }
      // no insets between the components
      dim.height += inset.top + inset.bottom;
      height = dim.height;
      dim.width += inset.left + inset.right;
      return dim;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param target  No description provided
    * @return        No description provided
    */
   public Dimension minimumLayoutSize (Container target)
   {
      return preferredLayoutSize (target);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param target  No description provided
    */
   public void layoutContainer (Container target)
   {
      Insets inset = target.getInsets();
      // determines the current size
      Dimension size = target.getSize();
      // rezize all components to the current width and
      int nmembers = target.getComponentCount();
      int y = 0;
      Component item = null;
      for (int i = 0; i < nmembers; i++)
      {
         item = target.getComponent (i);
         if (item instanceof JLabel)
         {
            item.setLocation (inset.left + 3, inset.top);
            item.setSize (size.width - inset.left - inset.right,
               item.getPreferredSize().height);
            y = inset.top + item.getPreferredSize().height;
         }
         else if (item instanceof JScrollPane)
         {

            item.setSize (size.width - inset.left - inset.right,
               item.getPreferredSize().height +  (size.height - height) / listCount);
            item.setLocation (inset.left, y);
            y += item.getSize().height;
         }
         else
         {
            item.setSize (size.width - inset.left - inset.right,
               item.getPreferredSize().height);
            item.setLocation (inset.left, y);
            y += item.getSize().height;
         }
      }
   }
}

/*
 * $Log: BDBaseComponent.java,v $
 * Revision 1.3  2003/10/07 07:21:51  ariseppi
 * misc. corrections
 *
 */
