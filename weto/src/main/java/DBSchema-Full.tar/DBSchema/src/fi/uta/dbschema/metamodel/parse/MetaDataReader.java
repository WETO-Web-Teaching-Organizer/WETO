/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.metamodel.parse;

import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.net.URL;
import java.net.URLClassLoader;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.Driver;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import de.uni_paderborn.fujaba.app.FrameMain;
import de.uni_paderborn.fujaba.uml.UMLProject;
import fi.uta.cs.dbswtool.RelAndQueryConstants;
import fi.uta.dbschema.metamodel.DBForeignKey;
import fi.uta.dbschema.metamodel.DBJunctionPair;
import fi.uta.dbschema.metamodel.DBSchema;
import fi.uta.dbschema.metamodel.DBTable;
import fi.uta.dbschema.metamodel.DBTableAttribute;
import fi.uta.dbschema.metamodel.DBTableAttributeJunction;
import fi.uta.dbschema.metamodel.DBUnique;

/**
 * Reads the database schema via JDBC from DatabaseMetaData. Views are imported as ordinary
 * tables.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:53 $
 * @version   $Revision: 1.5 $
 */
public class MetaDataReader
{
	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	final static String[] fields =
		{
			"Driver",
			"Class.forName",
			"URL",
			"User",
			"Password",
			"Catalog",
			"Schema" };
	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	final static boolean[] browses =
		{ true, false, false, false, false, false, false };
	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	final static boolean[] passes =
		{ false, false, false, false, true, false, false };

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @throws Exception  Exception description not provided
	 */

	static private HashMap data = null;
	static private HashMap constraints = null;

	public static String sqlErrors = "";

	public static Connection conn = null;
	
	public static void readData(final boolean toList) throws Exception
	{
		final JDialog dialog =
			new JDialog(FrameMain.get(), "Database properties", false);
		dialog.getContentPane().setLayout(new BorderLayout());

		JPanel fieldPanel = new JPanel();
		GridBagLayout gridbag = new GridBagLayout();
		GridBagConstraints c = new GridBagConstraints();
		Insets in = c.insets;
		in.top = 5;
		in.bottom = 5;
		in.right = 5;
		in.left = 5;

		fieldPanel.setLayout(gridbag);
		final JTextField[] fieldArray = new JTextField[fields.length];

		c.anchor = GridBagConstraints.WEST;
		c.gridwidth = GridBagConstraints.REMAINDER;

		JLabel noticeLabel = new JLabel("Note: views are imported as tables.");
		gridbag.setConstraints(noticeLabel, c);
		fieldPanel.add(noticeLabel);

		c.gridwidth = 1;

		String[] defaults = null;
		Object source = UMLProject.get().getCurrentDiagram();
		if (source instanceof DBSchema)
		{
			DBSchema dbSchema = (DBSchema) source;
			defaults = dbSchema.getDefaultDatabaseConnection();
		}

		for (int i = 0; i < fields.length; i++)
		{
			JLabel label = new JLabel(fields[i]);
			c.anchor = GridBagConstraints.WEST;
			gridbag.setConstraints(label, c);
			fieldPanel.add(label);
			c.gridwidth = 2;
			JTextField field = null;
			if (passes[i])
			{
				field = new JPasswordField(15);
			} else
			{
				field = new JTextField(45);
			}
			if (defaults != null)
			{
				field.setText(defaults[i]);
			}
			fieldArray[i] = field;
			gridbag.setConstraints(field, c);
			fieldPanel.add(field);
			c.anchor = GridBagConstraints.CENTER;
			JComponent lastComp = null;
			if (browses[i])
			{
				lastComp = new JButton("Browse");
				final JFileChooser chooser = new JFileChooser();
				chooser.setApproveButtonText("Choose");
				final JTextField curField = field;
				((JButton) lastComp).addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						int returnVal = chooser.showOpenDialog(FrameMain.get());

						if (returnVal == JFileChooser.APPROVE_OPTION)
						{
							File file = chooser.getSelectedFile();
							curField.setText(file.getAbsolutePath());
						}
					}
				});
			} else
			{
				lastComp = new JLabel();
			}
			c.gridwidth = GridBagConstraints.REMAINDER;
			gridbag.setConstraints(lastComp, c);
			fieldPanel.add(lastComp);
			c.gridwidth = 1;
		}
	    final JComboBox box = new JComboBox(RelAndQueryConstants.databases);
		if(toList)
		{
			JLabel label = new JLabel("Database engine");
			c.anchor = GridBagConstraints.WEST;
			gridbag.setConstraints(label, c);
			fieldPanel.add(label);
			c.gridwidth = 2;
			
			gridbag.setConstraints(box, c);
			fieldPanel.add(box);
			c.anchor = GridBagConstraints.CENTER;
			JComponent lastComp = null;
			lastComp = new JLabel();
			c.gridwidth = GridBagConstraints.REMAINDER;
			gridbag.setConstraints(lastComp, c);
			fieldPanel.add(lastComp);
		}

		c.anchor = GridBagConstraints.EAST;
		c.gridwidth = 2;
		JButton saveDefaultsButton = new JButton("Save as Schema defaults");
		
		saveDefaultsButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				DBSchema dbSchema = null;
				Object source = UMLProject.get().getCurrentDiagram();
				if (source instanceof DBSchema)
				{
					dbSchema = (DBSchema) source;
				}
				else
				{
					return;
				}
				
				String[] parameters = new String[fields.length];

				for (int i = 0; i < fields.length; i++)
				{
					if (passes[i])
					{
						JPasswordField psField = (JPasswordField) fieldArray[i];
						parameters[i] = new String(psField.getPassword());
					} else
					{
						parameters[i] = fieldArray[i].getText();
					}
				}
				dbSchema.setDefaultDatabaseConnection(parameters);
			}
		});
		
		gridbag.setConstraints(saveDefaultsButton, c);
		fieldPanel.add(saveDefaultsButton);

		JButton okButton = new JButton("OK");
		okButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				String[] parameters = new String[fields.length];

				for (int i = 0; i < fields.length; i++)
				{
					if (passes[i])
					{
						JPasswordField psField = (JPasswordField) fieldArray[i];
						parameters[i] = new String(psField.getPassword());
					} else
					{
						parameters[i] = fieldArray[i].getText();
					}
				}
				try
				{
					fetchMetaData(parameters, !toList);
				} catch (Exception ex)
				{
					ex.printStackTrace();
					JOptionPane.showMessageDialog(
						FrameMain.get(),
					    ex.getMessage(),
						"Schema extraction error",
						JOptionPane.ERROR_MESSAGE);
				}
				if (toList)
				{
					DatabaseManager.processChanges(MetaDataReader.data, MetaDataReader.constraints, box.getSelectedIndex());
					MetaDataReader.data = null;
					MetaDataReader.constraints = null;
				}
				dialog.dispose();
			}
		});
		
		c.gridwidth = 1;
		gridbag.setConstraints(okButton, c);
		fieldPanel.add(okButton);

		JButton cancelButton = new JButton("Cancel");
		cancelButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				dialog.dispose();
			}
		});
		c.gridwidth = GridBagConstraints.REMAINDER;
		gridbag.setConstraints(cancelButton, c);
		fieldPanel.add(cancelButton);

		dialog.getContentPane().add(fieldPanel, BorderLayout.CENTER);
		dialog.pack();
		dialog.setVisible(true);
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param parameters  No description provided
	 * @throws Exception  Exception description not provided
	 */
	private static void fetchMetaData(String[] parameters, boolean toSchema)
		throws Exception
	{
		DBSchema dbSchema = null;
		if (toSchema)
		{
			Object diagram = UMLProject.get().getCurrentDiagram();
			if (diagram instanceof DBSchema)
			{
				dbSchema = (DBSchema) diagram;
			} else
			{
				throw new Exception("Current diagram is not a database schema diagram.");
			}
		} else
		{
			MetaDataReader.data = new HashMap();
			MetaDataReader.constraints = new HashMap();
		}

		HashMap waitingKeys = new HashMap();

		URL u = new URL("jar:file:" + parameters[0] + "!/");
		String classname = parameters[1];
		URLClassLoader ucl = new URLClassLoader(new URL[] { u });
		Driver d = (Driver) Class.forName(classname, true, ucl).newInstance();
		Properties p = new Properties();
		p.put("user", parameters[3]);
		p.put("password", parameters[4]);

		conn = d.connect(parameters[2], p);

		DatabaseMetaData md = conn.getMetaData();

		ResultSet rs = md.getTables(null, null, "%", null);
		while (rs.next())
		{
			String tableName = rs.getString("TABLE_NAME");
			DBTable table = new DBTable(tableName);
			if (toSchema)
			{
				dbSchema.addToItems(table);
			} else
			{
				MetaDataReader.data.put(tableName, table);
			}

			HashMap attrHash = new HashMap();
			ResultSet rs2 =
				md.getColumns(parameters[5], parameters[6], tableName, "%");
			while (rs2.next())
			{
				String attrName = rs2.getString("COLUMN_NAME");
				int intType = rs2.getInt("DATA_TYPE");
				String attrType = intToType(intType);

				String firstLetter = attrType.substring(0, 1).toUpperCase();
				String tempType = firstLetter + attrType.substring(1);
				if (tempType.equals("Int"))
				{
					tempType = "Integer";
				}
				String javaType = "Sql" + tempType;

				int colSize = -1;
				if (intType == java.sql.Types.DOUBLE
					|| intType == java.sql.Types.NUMERIC
					|| intType == java.sql.Types.DECIMAL
					|| intType == java.sql.Types.FLOAT
					|| intType == java.sql.Types.CHAR
					|| intType == java.sql.Types.VARCHAR)
				{
					colSize = rs2.getInt("COLUMN_SIZE");
				}
				int decDigits = -1;
				if (intType == java.sql.Types.DOUBLE
					|| intType == java.sql.Types.NUMERIC
					|| intType == java.sql.Types.DECIMAL
					|| intType == java.sql.Types.FLOAT)
				{
					decDigits = rs2.getInt("DECIMAL_DIGITS");
				}
				String isNull = rs2.getString("IS_NULLABLE");
				boolean notNull = false;
				if (isNull.equals("NO"))
				{
					notNull = true;
				}
				DBTableAttribute attr = new DBTableAttribute(attrName);
				attr.setSqlType(attrType);
				attr.setSqlSize(colSize);
				attr.setSqlScale(decDigits);
				attr.setJavaType(javaType);
				attr.setNotNullValue(notNull);
				attr.setParent(table);
				attrHash.put(attrName, attr);
			}

			ArrayList keyList = (ArrayList) waitingKeys.remove(tableName);
			if (keyList != null)
			{
				for (int i = 0; i < keyList.size(); i++)
				{
					Object[] keyArray = (Object[]) keyList.get(i);
					DBTable origTable = (DBTable) keyArray[0];
					DBTable otherTable = table;
					ArrayList ownAttrs = (ArrayList) keyArray[1];
					ArrayList otherAttrs = (ArrayList) keyArray[2];
					String name = (String) keyArray[3];

					HashMap otherAttrHash = attrHash;
					HashMap ownAttrHash = new HashMap();

					Iterator iter3 = origTable.iteratorOfAttributes();
					while (iter3.hasNext())
					{
						DBTableAttribute tempAttr =
							(DBTableAttribute) iter3.next();
						ownAttrHash.put(tempAttr.getName(), tempAttr);
					}

					DBForeignKey key = new DBForeignKey();
					int keysThis = origTable.sizeOfForeignKeys();
					int keysOther = otherTable.sizeOfRevForeignKeys();
					key.setOriginalTable(origTable);
					key.setRevTable(otherTable);
					if (toSchema)
					{
						dbSchema.addToItems(key);
					}
					else
					{
						MetaDataReader.constraints.put(key, name);
					}

					for (int i2 = 0; i2 < ownAttrs.size(); i2++)
					{
						String ownAttrName = (String) ownAttrs.get(i2);
						DBTableAttribute ownAttr =
							(DBTableAttribute) ownAttrHash.get(ownAttrName);
						String otherAttrName = (String) otherAttrs.get(i2);
						DBTableAttribute otherAttr =
							(DBTableAttribute) otherAttrHash.get(otherAttrName);

						if (otherAttr == null)
						{
							i2 = ownAttrs.size();
							key.removeYou();
						}

						DBJunctionPair pair = new DBJunctionPair();
						key.addToJunctionPairs(pair);
						DBTableAttributeJunction origJunc =
							new DBTableAttributeJunction(ownAttr);
						origJunc.setPair(pair);
						pair.setOriginalJunction(origJunc);
						DBTableAttributeJunction revJunc =
							new DBTableAttributeJunction(otherAttr);
						revJunc.setPair(pair);
						pair.setRevJunction(revJunc);
					}
				}
			}

			ResultSet rs3 =
				md.getPrimaryKeys(parameters[5], parameters[6], tableName);
			HashMap primaryKey = new HashMap();
			while (rs3.next())
			{
				String attrName = rs3.getString("COLUMN_NAME");
				primaryKey.put(attrName, attrName);
				DBTableAttribute attr =
					(DBTableAttribute) attrHash.get(attrName);
				attr.setPrimaryKeyValue(true);
			}
			ResultSet rs4 =
				md.getIndexInfo(
					parameters[5],
					parameters[6],
					tableName,
					true,
					false);
			String currentIndexName = "";
			ArrayList currentUnique = new ArrayList();
			while (rs4.next())
			{
				String indexName = rs4.getString("INDEX_NAME");
				String attrName = rs4.getString("COLUMN_NAME");
				if (indexName.equals(currentIndexName))
				{
					currentUnique.add(attrName);
				} else
				{
					if (currentUnique.size() > 0)
					{
						boolean allSame = true;
						if (currentUnique.size() != primaryKey.size())
						{
							allSame = false;
						}
						for (int i = 0;
							i < currentUnique.size() && allSame;
							i++)
						{
							if (primaryKey.get(currentUnique.get(i)) == null)
							{
								allSame = false;
							}
						}
						if (!allSame)
						{
							DBUnique uni = new DBUnique();
							if(!toSchema)
							{
								MetaDataReader.constraints.put(uni, currentIndexName);
							}
							uni.setParent(table);
							for (int i = 0; i < currentUnique.size(); i++)
							{
								DBTableAttribute attr =
									(DBTableAttribute) attrHash.get(
										currentUnique.get(i));
								uni.addToAttributes(attr);
							}
						}
					}
					currentUnique = new ArrayList();
					currentUnique.add(attrName);
					currentIndexName = indexName;
				}
			}
			if (!currentUnique.equals(""))
			{
				if (currentUnique.size() > 0)
				{
					boolean allSame = true;
					if (currentUnique.size() != primaryKey.size())
					{
						allSame = false;
					}
					for (int i = 0; i < currentUnique.size() && allSame; i++)
					{
						if (primaryKey.get(currentUnique.get(i)) == null)
						{
							allSame = false;
						}
					}
					if (!allSame)
					{
						DBUnique uni = new DBUnique();
						if(!toSchema)
						{
							MetaDataReader.constraints.put(uni, currentIndexName);
						}
						uni.setParent(table);
						for (int i = 0; i < currentUnique.size(); i++)
						{
							DBTableAttribute attr =
								(DBTableAttribute) attrHash.get(
									currentUnique.get(i));
							uni.addToAttributes(attr);
						}
					}
				}
			}
			ResultSet rs5 =
				md.getImportedKeys(parameters[5], parameters[6], tableName);
			String currentKeyName = null;
			ArrayList ownAttr = new ArrayList();
			ArrayList oppAttr = new ArrayList();
			String oppTable = null;
			String oppTableName = null;
			while (rs5.next())
			{
				String oppAttrName = rs5.getString("PKCOLUMN_NAME");
				String attrName = rs5.getString("FKCOLUMN_NAME");

				// Problem: FK_NAME can be null, but it's the only way to identify foreign keys

				String thisKeyName = rs5.getString("FK_NAME");
				if (currentKeyName != null
					&& thisKeyName.equals(currentKeyName))
				{
					ownAttr.add(attrName);
					oppAttr.add(oppAttrName);
				} else
				{
					// If there are attributes to make a foreign key...
					if (ownAttr.size() > 0)
					{
						DBTable otherTable = null;
						Iterator iter2 = null;
						if (toSchema)
						{
							iter2 = dbSchema.iteratorOfItems();
						} else
						{
							iter2 = MetaDataReader.data.entrySet().iterator();
						}
						HashMap otherAttrHash = new HashMap();
						while (otherTable == null && iter2.hasNext())
						{
							Object obj = iter2.next();
							if(obj instanceof Map.Entry)
							{
								obj = ((Map.Entry) obj).getValue();
							}
							if (obj instanceof DBTable)
							{
								DBTable tempTable = (DBTable) obj;
								if (tempTable.getName().equals(oppTableName))
								{
									otherTable = tempTable;
									Iterator iter3 =
										otherTable.iteratorOfAttributes();
									while (iter3.hasNext())
									{
										DBTableAttribute tempAttr =
											(DBTableAttribute) iter3.next();
										otherAttrHash.put(
											tempAttr.getName(),
											tempAttr);
									}
								}
							}
						}
						if (otherTable == null)
						{
							ArrayList list =
								(ArrayList) waitingKeys.get(oppTableName);
							if (list == null)
							{
								list = new ArrayList();
								waitingKeys.put(oppTableName, list);
							}
							Object[] foreignClause = new Object[4];
							foreignClause[0] = table;
							foreignClause[1] = ownAttr;
							foreignClause[2] = oppAttr;
							foreignClause[3] = currentKeyName;							
							list.add(foreignClause);
						} else
						{
							DBForeignKey key = new DBForeignKey();
							key.setOriginalTable(table);
							key.setRevTable(otherTable);
							if (toSchema)
							{
								dbSchema.addToItems(key);
							}
							else
							{
								MetaDataReader.constraints.put(key, currentKeyName);
							}
							for (int i = 0; i < ownAttr.size(); i++)
							{
								String ownAttrName = (String) ownAttr.get(i);
								DBTableAttribute ownAttribute =
									(DBTableAttribute) attrHash.get(
										ownAttrName);
								String otherAttrName = (String) oppAttr.get(i);
								DBTableAttribute otherAttribute =
									(DBTableAttribute) otherAttrHash.get(
										otherAttrName);

								if (otherAttribute == null)
								{
									i = ownAttr.size();
									key.removeYou();
								}

								DBJunctionPair pair = new DBJunctionPair();
								key.addToJunctionPairs(pair);
								DBTableAttributeJunction origJunc =
									new DBTableAttributeJunction(ownAttribute);
								origJunc.setPair(pair);
								pair.setOriginalJunction(origJunc);
								DBTableAttributeJunction revJunc =
									new DBTableAttributeJunction(otherAttribute);
								revJunc.setPair(pair);
								pair.setRevJunction(revJunc);
							}
						}
					}

					oppTableName = rs5.getString("PKTABLE_NAME");
					ownAttr = new ArrayList();
					oppAttr = new ArrayList();
					ownAttr.add(attrName);
					oppAttr.add(oppAttrName);
					currentKeyName = thisKeyName;
				}
			}

			// This is to add the last key, if there are keys.

			if (ownAttr.size() > 0)
			{
				DBTable otherTable = null;
				Iterator iter2 = null;
				if (toSchema)
				{
					iter2 = dbSchema.iteratorOfItems();
				} else
				{
					iter2 = MetaDataReader.data.entrySet().iterator();
				}
				HashMap otherAttrHash = new HashMap();
				while (otherTable == null && iter2.hasNext())
				{
					Object obj = iter2.next();
					if(obj instanceof Map.Entry)
					{
						obj = ((Map.Entry) obj).getValue();
					}
					if (obj instanceof DBTable)
					{
						DBTable tempTable = (DBTable) obj;
						if (tempTable.getName().equals(oppTableName))
						{
							otherTable = tempTable;
							Iterator iter3 = otherTable.iteratorOfAttributes();
							while (iter3.hasNext())
							{
								DBTableAttribute tempAttr =
									(DBTableAttribute) iter3.next();
								otherAttrHash.put(tempAttr.getName(), tempAttr);
							}
						}
					}
				}
				if (otherTable == null)
				{
					ArrayList list = (ArrayList) waitingKeys.get(oppTableName);
					if (list == null)
					{
						list = new ArrayList();
						waitingKeys.put(oppTableName, list);
					}
					Object[] foreignClause = new Object[4];
					foreignClause[0] = table;
					foreignClause[1] = ownAttr;
					foreignClause[2] = oppAttr;
					foreignClause[3] = currentKeyName;
					list.add(foreignClause);
				} else
				{
					DBForeignKey key = new DBForeignKey();
					key.setOriginalTable(table);
					key.setRevTable(otherTable);
					if (toSchema)
					{
						dbSchema.addToItems(key);
					}
					else
					{
						MetaDataReader.constraints.put(key, currentKeyName);
					}

					for (int i = 0; i < ownAttr.size(); i++)
					{
						String ownAttrName = (String) ownAttr.get(i);
						DBTableAttribute ownAttribute =
							(DBTableAttribute) attrHash.get(ownAttrName);
						String otherAttrName = (String) oppAttr.get(i);
						DBTableAttribute otherAttribute =
							(DBTableAttribute) otherAttrHash.get(otherAttrName);

						if (otherAttribute == null)
						{
							i = ownAttr.size();
							key.removeYou();
						}

						DBJunctionPair pair = new DBJunctionPair();
						key.addToJunctionPairs(pair);
						DBTableAttributeJunction origJunc =
							new DBTableAttributeJunction(ownAttribute);
						origJunc.setPair(pair);
						pair.setOriginalJunction(origJunc);
						DBTableAttributeJunction revJunc =
							new DBTableAttributeJunction(otherAttribute);
						revJunc.setPair(pair);
						pair.setRevJunction(revJunc);
					}
				}
			}
		}
		if(toSchema)
		{
			MetaDataReader.conn.close();
			MetaDataReader.conn = null;
		}
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param type  No description provided
	 * @return      No description provided
	 */
	private static String intToType(int type)
	{
		if (type == java.sql.Types.BIT)
		{
			return "bit";
		}
		if (type == java.sql.Types.TINYINT)
		{
			return "tinyint";
		}
		if (type == java.sql.Types.SMALLINT)
		{
			return "smallint";
		}
		if (type == java.sql.Types.INTEGER)
		{
			return "int";
		}
		if (type == java.sql.Types.BIGINT)
		{
			return "bigint";
		}
		if (type == java.sql.Types.FLOAT)
		{
			return "float";
		}
		if (type == java.sql.Types.REAL)
		{
			return "real";
		}
		if (type == java.sql.Types.DOUBLE)
		{
			return "double";
		}
		if (type == java.sql.Types.NUMERIC)
		{
			return "numeric";
		}
		if (type == java.sql.Types.DECIMAL)
		{
			return "decimal";
		}
		if (type == java.sql.Types.CHAR)
		{
			return "char";
		}
		if (type == java.sql.Types.VARCHAR)
		{
			return "varchar";
		}
		if (type == java.sql.Types.LONGVARCHAR)
		{
			return "longvarchar";
		}
		if (type == java.sql.Types.DATE)
		{
			return "date";
		}
		if (type == java.sql.Types.TIME)
		{
			return "time";
		}
		if (type == java.sql.Types.TIMESTAMP)
		{
			return "timestamp";
		}
		if (type == java.sql.Types.BINARY)
		{
			return "binary";
		}
		if (type == java.sql.Types.VARBINARY)
		{
			return "varbinary";
		}
		if (type == java.sql.Types.LONGVARBINARY)
		{
			return "longvarbinary";
		}
		return null;
	}
}

/*
 * $Log: MetaDataReader.java,v $
 * Revision 1.5  2003/10/07 07:21:53  ariseppi
 * misc. corrections
 *
 */
