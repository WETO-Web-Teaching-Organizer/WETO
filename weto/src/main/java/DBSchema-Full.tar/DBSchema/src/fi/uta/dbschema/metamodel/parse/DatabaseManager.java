/*
 * Created on 6.8.2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package fi.uta.dbschema.metamodel.parse;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

import javax.swing.JOptionPane;

import de.uni_paderborn.fujaba.app.FrameMain;
import de.uni_paderborn.fujaba.asg.ASGElement;
import de.uni_paderborn.fujaba.uml.UMLProject;
import fi.uta.cs.dbswtool.Attribute;
import fi.uta.cs.dbswtool.AttributeVector;
import fi.uta.cs.dbswtool.ForeignKey;
import fi.uta.cs.dbswtool.NameVector;
import fi.uta.cs.dbswtool.RelAndQueryConstants;
import fi.uta.cs.dbswtool.Relation;
import fi.uta.cs.dbswtool.RelationVector;
import fi.uta.cs.dbswtool.View;
import fi.uta.cs.dbswtool.ViewVector;
import fi.uta.dbschema.gui.ItemChanges;
import fi.uta.dbschema.metamodel.DBForeignKey;
import fi.uta.dbschema.metamodel.DBItemRenamed;
import fi.uta.dbschema.metamodel.DBJunctionPair;
import fi.uta.dbschema.metamodel.DBSchema;
import fi.uta.dbschema.metamodel.DBSchemaItem;
import fi.uta.dbschema.metamodel.DBTable;
import fi.uta.dbschema.metamodel.DBTableAttribute;
import fi.uta.dbschema.metamodel.DBTableAttributeJunction;
import fi.uta.dbschema.metamodel.DBTableInterface;
import fi.uta.dbschema.metamodel.DBUnique;
import fi.uta.dbschema.metamodel.DBView;
import fi.uta.dbschema.metamodel.DBViewAttribute;

/**
 * @author as66033
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class DatabaseManager {
    private static int database = 0; 
    
	public static void processChanges(HashMap tables, HashMap constraints, int database) {
	    DatabaseManager.database = database;
		DBSchema dbSchema = null;
		Object source = UMLProject.get().getCurrentDiagram();
		if (source instanceof DBSchema) {
			dbSchema = (DBSchema) source;
		} else {
			return;
		}
		Iterator iter = dbSchema.iteratorOfItems();
		ArrayList added = new ArrayList();
		ArrayList removed = new ArrayList();
		ArrayList kept = new ArrayList();


		HashMap oldTables = new HashMap();
		HashMap primaries = new HashMap();
		while (iter.hasNext()) {
			DBSchemaItem item = (DBSchemaItem) iter.next();
			if (item instanceof DBTable) {
				DBTable table = (DBTable) item;
				Iterator attrIter = table.iteratorOfAttributes();
				HashMap primary = new HashMap();
				while(attrIter.hasNext())
				{
				    DBTableAttribute attr = (DBTableAttribute) attrIter.next(); 
				    if(attr.getPrimaryKeyValue())
				    {
				        primary.put(attr.getName() + " " + attr.getSqlType() + " " + attr.getSqlSize() + " " + attr.getSqlScale(), Boolean.TRUE);
				    }
				}
		        primaries.put(table, primary);
			}
		}
		Iterator iter2 = ((Collection) tables.values()).iterator();
		while (iter2.hasNext()) 
		{
			DBTable oldTable = (DBTable) iter2.next();
			ArrayList oldPrimary = new ArrayList();
			Iterator attrIter = oldTable.iteratorOfAttributes();
			while(attrIter.hasNext())
			{
			    DBTableAttribute attr = (DBTableAttribute) attrIter.next();
			    if(attr.getPrimaryKeyValue())
			    {
			        oldPrimary.add(attr.getName() + " " + attr.getSqlType() + " " + attr.getSqlSize() + " " + attr.getSqlScale());
			    }
			}
			Iterator iter3 = ((Collection) primaries.keySet()).iterator();
			boolean matched = false;
			while(!matched && iter3.hasNext())
			{
			    DBTable newTable = (DBTable) iter3.next();
			    HashMap newPrimary = (HashMap) primaries.get(newTable);
			    boolean failed = false; 
			    if(oldPrimary.size() == newPrimary.size())
			    {
			        for(int i = 0; i < oldPrimary.size() && !failed; i++)
			        {
			            if(!newPrimary.containsKey(oldPrimary.get(i)))
			            {
			                failed = true;
			            }
			        }
			        if(!failed)
			        {
			            matched = true;
						oldTables.put(oldTable.getName(), oldTable);
						kept.add(newTable);
						primaries.remove(newTable);
			        }
			    }
			}
			if(!matched)
			{
				removed.add(oldTable);
				oldTables.put(oldTable.getName(), oldTable);
			}
		}
		Iterator primIter = primaries.keySet().iterator();
		while(primIter.hasNext())
		{
		    DBTable table = (DBTable) primIter.next();
		    added.add(table);
		}
		ItemChanges alterDialog = new ItemChanges(FrameMain.get().getFrame(),
				ItemChanges.TABLE_TYPE);
		alterDialog.setConstraints(constraints);
		alterDialog.setIncrement(dbSchema);
		alterDialog.setListsTable(added, kept, removed, oldTables);
		alterDialog.showCentered();
	}

	public static void makeChanges(Iterator[] iterators, HashMap oldItems,
			HashMap constraints) {
		ArrayList alterTables = new ArrayList();
		Iterator iterAdded = (Iterator) iterators[0];
		RelationVector relVector = new RelationVector();
		ViewVector viewVector = new ViewVector();
		ArrayList viewList = new ArrayList();

		HashMap recreates = new HashMap();
		
		while (iterAdded.hasNext()) {
			Object obj = iterAdded.next();
			if (obj instanceof DBTable) {
				DatabaseManager.addTable((DBTable) obj, relVector);
			}
			if (obj instanceof DBView) {
				viewList.add(obj);
			}
		}
		Iterator iterRemoved = (Iterator) iterators[1];
		while (iterRemoved.hasNext()) {
			DBTableInterface table = (DBTableInterface) iterRemoved.next();
			StringBuffer dropClause = new StringBuffer("DROP ");
			if (table instanceof DBTable) {
				dropClause.append("TABLE ");
			}
			if (table instanceof DBView) {
				dropClause.append("VIEW ");
			}
			dropClause.append(table.getName() + ";");
			alterTables.add(dropClause);
		}

		// Do constraints need to be changed

		HashMap changedConstraints = new HashMap();

		Iterator iterKept = (Iterator) iterators[2];
		HashMap tables = new HashMap();

		HashMap droppedAttributes = new HashMap();

		HashMap tableAlters = new HashMap();

		while (iterKept.hasNext()) {
			DBSchemaItem item = (DBSchemaItem) iterKept.next();
			if (item instanceof DBItemRenamed) {
				DBItemRenamed renamed = (DBItemRenamed) item;
				DBSchemaItem originalItem = renamed.getOrigItem();
				DBSchemaItem newItem = renamed.getNewItem();
				if (originalItem instanceof DBTable) {
					String alterClause = "ALTER TABLE "
							+ originalItem.getName() + " RENAME TO "
							+ newItem.getName() + ";";
					ArrayList clauses = (ArrayList) tableAlters.get(newItem);
					if (clauses == null) {
						clauses = new ArrayList();
						tableAlters.put(newItem, clauses);
					}
					clauses.add(alterClause);

					tables.put(newItem, originalItem);
				}
				if (originalItem instanceof DBView) {
					String deleteClause = "DROP VIEW " + originalItem.getName()
							+ ";";
					alterTables.add(deleteClause);
					viewList.add(newItem);
				}
			}
			if (item instanceof DBTable) {
				tables.put(item, oldItems.get(item.getName()));
			}
			if (item instanceof DBView) {
				String deleteClause = "DROP VIEW " + item.getName() + ";";
				alterTables.add(deleteClause);
				viewList.add(item);
			}
			ArrayList[] addsAndRemoves = (ArrayList[]) ItemChanges.others
					.get(item);
			DBTableInterface newTable = null;
			DBTableInterface oldTable = null;
			if (item instanceof DBItemRenamed) {
				DBItemRenamed renamed = (DBItemRenamed) item;
				newTable = (DBTableInterface) renamed.getNewItem();
				oldTable = (DBTableInterface) renamed.getOrigItem();
			} else {
				newTable = (DBTableInterface) item;
				oldTable = (DBTableInterface) oldItems.get(item.getName());
			}
			if (addsAndRemoves == null) {
				addsAndRemoves = new ArrayList[2];
				addsAndRemoves[0] = new ArrayList();
				addsAndRemoves[1] = new ArrayList();
				HashMap attributes = new HashMap();
				Iterator iter = oldTable.iteratorOfAttributes();
				while (iter.hasNext()) {
					DBSchemaItem schemaItem = (DBSchemaItem) iter.next();
					attributes.put(schemaItem.getName(), schemaItem);
				}
				Iterator iter2 = newTable.iteratorOfAttributes();
				while (iter2.hasNext()) {
					DBTableAttribute attr = (DBTableAttribute) iter2.next();
					String attrName = attr.getName();
					DBTableAttribute oldAttribute = (DBTableAttribute) attributes
							.get(attrName);
					if (oldAttribute == null
							|| !oldAttribute.getSqlType().equals(
									attr.getSqlType())
							|| oldAttribute.getSqlScale() != attr.getSqlScale()
							|| oldAttribute.getSqlSize() != attr.getSqlSize()) {
						addsAndRemoves[0].add(attr);
					} else {
						attributes.remove(attrName);
					}
				}
				if (!attributes.isEmpty()) {
					Iterator iter3 = ((Collection) attributes.values())
							.iterator();
					while (iter3.hasNext()) {
						DBTableAttribute removeAttr = (DBTableAttribute) iter3
								.next();
						addsAndRemoves[1].add(removeAttr);
					}
				}
			}
			for (int i = 0; i < addsAndRemoves[0].size(); i++) {
				DBTableAttribute attr = (DBTableAttribute) addsAndRemoves[0]
						.get(i);
				String clause = "ALTER TABLE " + item.getName()
						+ " ADD COLUMN " + attr.getName() + " "
						+ attr.getSqlType();
				if (attr.getSqlSize() != -1) {
					clause += "(" + attr.getSqlSize();
					if (attr.getSqlScale() != -1) {
						clause += ", " + attr.getSqlScale();
					}
					clause += ");";
				}
				ArrayList clauses = (ArrayList) tableAlters.get(newTable);
				if (clauses == null) {
					clauses = new ArrayList();
					tableAlters.put(newTable, clauses);
				}
				clauses.add(clause);
			}
			for (int i = 0; i < addsAndRemoves[1].size(); i++) {
			    i = addsAndRemoves[1].size();
			    recreates.put(newTable, oldTable);
/*				DBTableAttribute attr = (DBTableAttribute) addsAndRemoves[1]
						.get(i);
				String clause = "ALTER TABLE " + item.getName()
						+ " DROP COLUMN " + attr.getName() + " CASCADE;";
				ArrayList clauses = (ArrayList) tableAlters.get(newTable);
				if (clauses == null) {
					clauses = new ArrayList();
					tableAlters.put(newTable, clauses);
				}
				clauses.add(clause);
				if (attr.getPrimaryKeyValue()) {
					changedConstraints.put(item, Boolean.TRUE);
				}
				Iterator revUniIter = attr.iteratorOfRevUniques();
				while (revUniIter.hasNext()) {
					changedConstraints.put(revUniIter.next(), Boolean.TRUE);
				}
				Iterator juncIter = attr.iteratorOfJunctions();
				while (juncIter.hasNext()) {
					DBTableAttributeJunction junc = (DBTableAttributeJunction) juncIter
							.next();
					changedConstraints.put(junc.getPair().getParent(),
							Boolean.TRUE);
				}
				droppedAttributes.put(attr, Boolean.TRUE);*/
			}
		}
		for (int i = 0; i < viewList.size(); i++) {
			DBView view = (DBView) viewList.get(i);
			DatabaseManager.addView(view, relVector, viewVector);
		}
		for (int i = 0; i < viewVector.size(); i++) {
			alterTables.add(viewVector.getSQLString(i));
		}

		Iterator keys = ItemChanges.renames.keySet().iterator();

		while (keys.hasNext()) {
			DBTableAttribute item = (DBTableAttribute) keys.next();
			DBTableAttribute oldItem = (DBTableAttribute) ItemChanges.renames
					.get(item);
			boolean rename = !item.getName().equals(oldItem.getName());
			boolean changeType = !item.getSqlType()
					.equals(oldItem.getSqlType())
					|| item.getSqlScale() != oldItem.getSqlScale()
					|| item.getSqlSize() != oldItem.getSqlSize();
			if (rename && !changeType) {
				String clause = "ALTER TABLE " + item.getParent().getName()
						+ " RENAME COLUMN " + oldItem.getName() + " TO "
						+ item.getName() + ";";
				ArrayList clauses = (ArrayList) tableAlters.get(item
						.getParent());
				if (clauses == null) {
					clauses = new ArrayList();
					tableAlters.put(item.getParent(), clauses);
				}
				clauses.add(clause);
			}
			if (changeType) {
				droppedAttributes.put(oldItem, Boolean.TRUE);
				String tempName = "temp_col";
				if (rename) {
					tempName = item.getName();
				} else {
					tempName = "temp_col";
					DBTable table;
					Iterator iter;
					boolean again = false;
					do {
						again = false;
						table = item.getParent();
						iter = table.iteratorOfAttributes();
						while (iter.hasNext()) {
							DBTableAttribute attr = (DBTableAttribute) iter
									.next();
							if (tempName.equals(attr.getName())) {
								tempName += "z";
								again = true;
								break;
							}
						}
					} while (again);
					do {
						again = false;
						table = oldItem.getParent();
						iter = table.iteratorOfAttributes();
						while (iter.hasNext()) {
							DBTableAttribute attr = (DBTableAttribute) iter
									.next();
							if (tempName.equals(attr.getName())) {
								tempName += "z";
								again = true;
								break;
							}
						}
					} while (again);
				}
				String clause = "ALTER TABLE " + item.getParent().getName()
						+ " ADD COLUMN " + tempName + " " + item.getSqlType();
				if (item.getSqlSize() > -1) {
					clause += "(" + item.getSqlSize();
					if (item.getSqlScale() > -1) {
						clause += ", " + item.getSqlScale();
					}
					clause += ");";
				}
				ArrayList clauses = (ArrayList) tableAlters.get(item
						.getParent());
				if (clauses == null) {
					clauses = new ArrayList();
					tableAlters.put(item, clauses);
				}
				clauses.add(clause);
				clauses.add("UPDATE " + item.getParent().getName() + " SET "
						+ tempName + " = " + item.getName() + ";");
				if (item.getNotNullValue()) {
					clauses.add("ALTER TABLE " + item.getParent().getName()
							+ " ALTER COLUMN " + tempName + " SET NOT NULL;");
				}
				clauses.add("ALTER TABLE " + item.getParent().getName()
						+ " DROP COLUMN " + oldItem.getName() + ";");
				if (!rename) {
					clauses.add("ALTER TABLE " + item.getParent().getName()
							+ " RENAME COLUMN " + tempName + " TO "
							+ oldItem.getName() + ";");
				}
			}
		}

		Iterator iter = tables.keySet().iterator();

		while (iter.hasNext()) {
			boolean change = false;
			DBTable newTable = (DBTable) iter.next();
			StringBuffer key = new StringBuffer();
			if (changedConstraints.get(newTable) != null) {
				change = true;
			}
			DBTable oldTable = (DBTable) tables.get(newTable);
			Iterator iter2 = newTable.iteratorOfAttributes();
			while (iter2.hasNext()) {
				DBTableAttribute newAttr = (DBTableAttribute) iter2.next();
				if (newAttr.getPrimaryKeyValue()) {
					if (key.length() > 0) {
						key.append(",");
					}
					key.append(newAttr.getName());
				}
				if (!change) {
					DBTableAttribute oldAttr = (DBTableAttribute) ItemChanges.renames
							.get(newAttr);
					if (oldAttr != null) {
						change = (newAttr.getPrimaryKeyValue() != oldAttr
								.getPrimaryKeyValue());
					} else {
						boolean found = false;
						String name = newAttr.getName();
						Iterator iter3 = oldTable.iteratorOfAttributes();
						while (iter3.hasNext() && !found) {
							oldAttr = (DBTableAttribute) iter3.next();
							if (oldAttr.getName().equals(name)) {
								found = true;
								change = (newAttr.getPrimaryKeyValue() != oldAttr
										.getPrimaryKeyValue());
							}
						}
						if (!found) {
							change = newAttr.getPrimaryKeyValue();
						}
					}
				}
			}
			if (change) {
				ArrayList clauses = (ArrayList) tableAlters.get(newTable);
				if (clauses == null) {
					clauses = new ArrayList();
					tableAlters.put(newTable, clauses);
				}
				clauses.add("ALTER TABLE " + newTable.getName()
						+ " ADD PRIMARY KEY (" + key.toString()
						+ ");");
			}
		}

		iter = tables.keySet().iterator();

		while (iter.hasNext()) {
			DBTable newTable = (DBTable) iter.next();
			DBTable oldTable = (DBTable) tables.get(newTable);
			Iterator iter2 = newTable.iteratorOfUniques();
			while (iter2.hasNext()) {
				boolean change = false;
				DBUnique newUnique = (DBUnique) iter2.next();
				StringBuffer attributes = new StringBuffer();
				// attrHash contains unique's attributes so that
				// similarity of uniques can easily be checked even
				// if the attributes are in different order in the uniques.
				HashMap attrHash = new HashMap();
				Iterator attrIter = newUnique.iteratorOfAttributes();
				while (attrIter.hasNext()) {
					DBTableAttribute attr = (DBTableAttribute) attrIter.next();
					if (attributes.length() > 0) {
						attributes.append(",");
					}
					attributes.append(attr.getName());
					if (!change) {
						DBTableAttribute oldAttr = (DBTableAttribute) ItemChanges.renames
								.get(attr);
						// if corresponding attribute from old table has been removed,
						// the unique constraint must be re-created
						if (droppedAttributes.containsKey(oldAttr)) {
							change = true;
						} else {
							if (oldAttr != null) {
								attrHash.put(oldAttr.getName(), Boolean.TRUE);
							} else {
								attrHash.put(attr.getName(), Boolean.TRUE);
							}
						}
					}
				}
				if (!change) {
					boolean found = false;
					Iterator iter3 = oldTable.iteratorOfUniques();
					while (iter3.hasNext() && !found) {
						DBUnique oldUnique = (DBUnique) iter3.next();
						if (!changedConstraints.containsKey(oldUnique)
								&& oldUnique.sizeOfAttributes() == newUnique
										.sizeOfAttributes()) {
							boolean matches = true;
							attrIter = oldUnique.iteratorOfAttributes();
							while (attrIter.hasNext() && matches) {
								ASGElement elem = (ASGElement) attrIter.next();
								if (!attrHash.containsKey(elem.getName())) {
									matches = false;
								}
							}
							if (matches) {
								found = true;
								// Used unique constraint is added to used constraints
								// so that non-used uniques (those to be removed)
								// could be found easily
								changedConstraints.put(oldUnique, Boolean.TRUE);
							}
						}
					}
					if (!found) {
						change = true;
					}
				}
				if (change) {
					ArrayList clauses = (ArrayList) tableAlters.get(newTable);
					if (clauses == null) {
						clauses = new ArrayList();
						tableAlters.put(newTable, clauses);
					}
					clauses.add("ALTER TABLE " + newTable.getName()
							+ " ADD UNIQUE ("
							+ attributes.toString() + ");");
				}
			}
		}

		iter = tables.keySet().iterator();

		while (iter.hasNext()) {
			Object key = iter.next();
			DBTable newTable = (DBTable) key;
			DBTable oldTable = (DBTable) tables.get(key);
			Iterator uniIter = oldTable.iteratorOfUniques();
			while (uniIter.hasNext()) {
				Object uniKey = uniIter.next();
				if (!changedConstraints.containsKey(uniKey)) {
					ArrayList clauses = (ArrayList) tableAlters.get(key);
					if (clauses == null) {
						clauses = new ArrayList();
						tableAlters.put(key, clauses);
					}
					String alter = "ALTER TABLE " + newTable.getName()
					+ " DROP CONSTRAINT "
					+ constraints.get(uniKey);
					if(database != RelAndQueryConstants.oldPostgre)
					{
					    alter += " CASCADE";   
					}
					alter += ";";
					clauses.add(alter);
				}
			}
		}

		iter = tables.keySet().iterator();

		while (iter.hasNext()) {
			DBTable newTable = (DBTable) iter.next();
			DBTable oldTable = (DBTable) tables.get(newTable);
			Iterator iter2 = newTable.iteratorOfForeignKeys();
			while (iter2.hasNext()) {
				boolean change = false;
				DBForeignKey newKey = (DBForeignKey) iter2.next();
				StringBuffer attributes1 = new StringBuffer();
				StringBuffer attributes2 = new StringBuffer();
				// attrHashes contains foreign key's attributes so that
				// similarity of foreign keys can easily be checked even
				// if the attributes are in different order in the foreign keys.
				HashMap attrHash = new HashMap();
				Iterator juncIter = newKey.iteratorOfJunctionPairs();
				if (recreates.containsKey(newKey.getOriginalTable())
						|| recreates.containsKey(newKey.getRevTable())) {
					change = true;
				}
				while (juncIter.hasNext()) {
					DBJunctionPair pair = (DBJunctionPair) juncIter.next();
					DBTableAttribute attr1 = pair.getOriginalJunction()
							.getTarget();
					DBTableAttribute attr2 = pair.getRevJunction().getTarget();
					if (attributes1.length() > 0) {
						attributes1.append(",");
						attributes2.append(",");
					}
					attributes1.append(attr1.getName());
					attributes2.append(attr2.getName());
					DBTableAttribute oldAttr1 = (DBTableAttribute) ItemChanges.renames
							.get(attr1);
					DBTableAttribute oldAttr2 = (DBTableAttribute) ItemChanges.renames
							.get(attr2);
					// if corresponding attribute from old table has been removed,
					// the foreign key constraint must be re-created
					if (droppedAttributes.containsKey(oldAttr1)
							|| droppedAttributes.containsKey(oldAttr2)) {
						change = true;
					} else {
						if (oldAttr1 != null) {
							if (oldAttr2 != null) {
								attrHash.put(oldAttr1.getName(), oldAttr2
										.getName());
							} else {
								attrHash.put(oldAttr1.getName(), attr2
										.getName());
							}
						} else {
							if (oldAttr2 != null) {
								attrHash.put(attr1.getName(), oldAttr2
										.getName());
							} else {
								attrHash.put(attr1.getName(), attr2.getName());
							}
						}
					}
				}
				if (!change) {
					boolean found = false;
					Iterator iter3 = oldTable.iteratorOfForeignKeys();
					while (iter3.hasNext() && !found) {
						DBForeignKey oldKey = (DBForeignKey) iter3.next();
						if (!changedConstraints.containsKey(oldKey)
								&& oldKey.sizeOfJunctionPairs() == attrHash
										.size()) {
							boolean matches = true;
							juncIter = oldKey.iteratorOfJunctionPairs();
							while (juncIter.hasNext() && matches) {
								DBJunctionPair pair = (DBJunctionPair) juncIter
										.next();
								ASGElement elem1 = pair.getOriginalJunction()
										.getTarget();
								ASGElement elem2 = pair.getRevJunction()
										.getTarget();
								Object secondName = attrHash.get(elem1
										.getName());
								if (secondName == null
										|| !secondName.equals(elem2.getName())) {
									matches = false;
								}
							}
							if (matches) {
								found = true;
								// Used foreign key constraint is added to used constraints
								// so that non-used foreign keys (those to be removed)
								// could be found easily
								changedConstraints.put(oldKey, Boolean.TRUE);
							}
						}
					}
					if (!found) {
						change = true;
					}
				}
				if (change) {
					ArrayList clauses = (ArrayList) tableAlters.get(newTable);
					if (clauses == null) {
						clauses = new ArrayList();
						tableAlters.put(newTable, clauses);
					}
					clauses.add("ALTER TABLE " + newTable.getName()
							+ " ADD FOREIGN KEY ("
							+ attributes1.toString() + ") REFERENCES "
							+ newKey.getRevTable() + " ("
							+ attributes2.toString() + ");");
				}
			}
		}

		iter = tables.keySet().iterator();

		while (iter.hasNext()) {
			Object key = iter.next();
			if (!recreates.containsKey(key)) {
				DBTable newTable = (DBTable) key;
				DBTable oldTable = (DBTable) tables.get(key);
				Iterator keyIter = oldTable.iteratorOfForeignKeys();
				while (keyIter.hasNext()) {
					Object fkKey = keyIter.next();
					if (!changedConstraints.containsKey(fkKey)) {
						ArrayList clauses = (ArrayList) tableAlters.get(key);
						if (clauses == null) {
							clauses = new ArrayList();
							tableAlters.put(key, clauses);
						}
						clauses.add("ALTER TABLE " + newTable.getName()
								+ " DROP CONSTRAINT "
								+ constraints.get(fkKey) + " CASCADE;");
					}
				}
			}
		}

		iter = tables.keySet().iterator();

		while (iter.hasNext()) {
			Object key = iter.next();
			DBTable oldTable = (DBTable) recreates.get(key);
			if (oldTable == null) {
				ArrayList list = (ArrayList) tableAlters.get(key);
				if (list != null) {
					alterTables.addAll(list);
				}
			} else {
				DBTable table = (DBTable) key;
				DatabaseManager.addTable(table, relVector);
				Iterator recreateForKeysIter = table.iteratorOfRevForeignKeys();
				while (recreateForKeysIter.hasNext()) {
					DBForeignKey forKey = (DBForeignKey) recreateForKeysIter
							.next();
					StringBuffer sb = new StringBuffer("ALTER TABLE "
							+ forKey.getOriginalTable().getName()
							+ " ADD FOREIGN KEY (");
					StringBuffer sb2 = new StringBuffer(") REFERENCES "
							+ forKey.getRevTable().getName() + "(");
					Iterator juncIter = forKey.iteratorOfJunctionPairs();
					while (juncIter.hasNext()) {
						DBJunctionPair pair = (DBJunctionPair) juncIter.next();
						sb.append(pair.getOriginalJunction().getTarget()
								.getName());
						sb2.append(pair.getRevJunction().getTarget().getName());
						if (juncIter.hasNext()) {
							sb.append(",");
							sb2.append(",");
						}
					}
					alterTables.add(sb.toString() + sb2.toString() + ")");
				}
			}
		}

		ItemChanges.renames = null;

		relVector.sort();

		for (int i = 0; i < relVector.size(); i++) {
			alterTables.add(i, relVector.getSQLString(i, database));
		}
		
		String clause = null;
			try {

				for (int i = 0; i < alterTables.size(); i++) {
				    clause = alterTables.get(i).toString();
				    Statement stmt = MetaDataReader.conn.createStatement();
				    stmt.execute(alterTables.get(i).toString());
				}
				MetaDataReader.conn.close();
				MetaDataReader.conn = null;
				
			} catch (SQLException ex) {
			    System.out.println(clause);
			    ex.printStackTrace();
				JOptionPane.showMessageDialog(FrameMain.get(), ex.getSQLState(),
						"Database error", JOptionPane.ERROR_MESSAGE);
			}


			for (int i = 0; i < alterTables.size(); i++) {
			    System.out.println(alterTables.get(i).toString());
			}
			
	}

	public static void addTable(DBTable table, RelationVector relVector) {
		Relation rel = new Relation();
		rel.setName(table.getName());
		rel.setPackage(table.getJavaPackage());
		Iterator iter2 = table.iteratorOfAttributes();

		// Information about unique constraints is stored as a list
		// in DBTable, primary key information is stored as attribute
		// variables in DBTableAttributes.

		NameVector primaryKey = new NameVector();
		while (iter2.hasNext()) {
			DBTableAttribute attr = (DBTableAttribute) iter2.next();
			// DBTableAttribute uses datatype int instead of Integer for size and
			// scale with NO_NUMBER meaning null (since all the legal values are positive).
			int number = attr.getSqlSize();
			Integer size = null;
			if (number > DBTableAttribute.NO_NUMBER) {
				size = new Integer(number);
			}
			number = attr.getSqlScale();
			Integer scale = null;
			if (number > DBTableAttribute.NO_NUMBER) {
				scale = new Integer(number);
			}

			String sqlType = attr.getSqlType();
			if (size != null) {
				sqlType += "(" + size;
				if (scale != null) {
					sqlType += "," + scale;
				}
				sqlType += ")";
			}
			Boolean stringType = null;
			if (attr.getJavaType().equals("SqlChar")
					|| attr.getJavaType().equals("SqlVarchar")
					|| attr.getJavaType().equals("SqlLongvarchar")) {
				stringType = new Boolean(true);
			} else {
				stringType = new Boolean(false);
			}

			// Attribute names are created by combining the attribute name in the
			// relation (attribute role) and table name.

			Attribute a = new Attribute(rel.getName() + "_" + attr.getName(),
					sqlType, attr.getJavaType(), stringType);
			a.setJavaTypeLength(size);
			a.setJavaTypeScale(scale);
			if (attr.getPrimaryKeyValue()) {
				primaryKey.addName(attr.getName());
			}
			a.setRole(attr.getName());
			a.setNotNull(new Boolean(attr.getNotNullValue()));

			// Attribute is added to relation.
			rel.addAttribute(a);
		}
		rel.setPrimaryKey(primaryKey);
		iter2 = table.iteratorOfUniques();
		while (iter2.hasNext()) {
			DBUnique uni = (DBUnique) iter2.next();
			Iterator iter3 = uni.iteratorOfAttributes();
			NameVector uniqueConst = new NameVector();
			while (iter3.hasNext()) {
				DBTableAttribute attr = (DBTableAttribute) iter3.next();
				uniqueConst.addName(attr.getName());
			}
			rel.addUnique(uniqueConst);
		}
		iter2 = table.iteratorOfForeignKeys();
		while (iter2.hasNext()) {
			DBForeignKey key = (DBForeignKey) iter2.next();
			DBTable revTable = key.getRevTable();
			String revTableName = revTable.getName();

			Iterator iter3 = key.iteratorOfJunctionPairs();
			NameVector ownAttributes = new NameVector();
			NameVector revAttributes = new NameVector();
			while (iter3.hasNext()) {
				DBJunctionPair pair = (DBJunctionPair) iter3.next();
				DBTableAttributeJunction origJunc = pair.getOriginalJunction();
				DBTableAttribute origAttr = origJunc.getTarget();
				DBTableAttributeJunction revJunc = pair.getRevJunction();
				DBTableAttribute revAttr = revJunc.getTarget();
				ownAttributes.addName(origAttr.getName());
				revAttributes.addName(revAttr.getName());
			}
			ForeignKey toolKey = new ForeignKey();
			toolKey.setReferredTable(revTableName);
			toolKey.setReferredAttributes(revAttributes);
			toolKey.setOwnAttributes(ownAttributes);
			rel.addForeignKey(toolKey);
		}
		relVector.addRelation(rel);
	}

	public static void addView(DBView dbView, RelationVector relVector,
			ViewVector viewVector) {
		View view = new View();
		view.setName(dbView.getName());
		view.setPackage(dbView.getJavaPackage());
		Iterator iter2 = dbView.iteratorOfAttributes();
		while (iter2.hasNext()) {
			DBViewAttribute vAttr = (DBViewAttribute) iter2.next();
			DBTableAttribute tAttr = (DBTableAttribute) vAttr.getAttribute();
			String origName = tAttr.getName();
			view.addAttrOrigName(origName);
			view.addRelationName(tAttr.getParent().getName());
			Relation rel = relVector.getRelation(tAttr.getParent().getName());
			AttributeVector attrVec = rel.getAttributeVector();
			Attribute origAttr = attrVec.getAttributeByRole(origName);
			Attribute viewAttr = new Attribute(origAttr.getName(), origAttr
					.getSQLType(), origAttr.getJavaType(), origAttr
					.getStringType());
			viewAttr.setJavaTypeLength(origAttr.getJavaTypeLength());
			viewAttr.setJavaTypeScale(origAttr.getJavaTypeScale());
			viewAttr.setRole(vAttr.getName());

			view.addAttribute(viewAttr);
		}
		view.setWhereClause(dbView.getWhereClause());
		viewVector.addView(view);
	}
}