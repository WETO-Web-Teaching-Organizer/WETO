/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.metamodel;

import java.util.Iterator;

import de.uni_paderborn.fujaba.asg.ASGDiagram;
import de.uni_paderborn.fujaba.uml.UMLProject;
import de.upb.tools.fca.FEmptyIterator;
import de.upb.tools.fca.FPropHashSet;


/**
 * DBForeignKey has references to both of the tables it's connected to,
 * the join object between the tables and to all attribute junction pairs.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.2 $
 */
public class DBForeignKey
    extends DBSchemaItem
{
   /**
    * Constructor for class DBForeignKey
    */
   public DBForeignKey()
   {
      super();
      join = new DBForeignTableJoin();
      join.setParent (this);
   }


   /**
    * <pre>
    *             0..n   junctionPairs   0..1
    * DBForeingKeyPair ---------------------- DBForeingKey
    *             junctionPairs     foreingKey
    * </pre>
    */
   private FPropHashSet junctionPairs;


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @return   No description provided
    */
   public int sizeOfJunctionPairs()
   {
      return  ( (this.junctionPairs == null)
         ? 0
         : this.junctionPairs.size());
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void removeYou()
   {
      removeAllFromJunctionPairs();
      ASGDiagram curDiagram = UMLProject.get().getCurrentDiagram();
      if (curDiagram instanceof DBSchema)
      {
          ((DBSchema) curDiagram).removeFromItems (this);
      }
      if(getOriginalTable() != null) {
	      getOriginalTable().removeFromForeignKeys (this);
	  }
	  if(getRevTable() != null) {
	      getRevTable().removeFromRevForeignKeys (this);
	  }
      join.removeYou();
      super.removeYou();
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param value  No description provided
    * @return       No description provided
    */
   public boolean removeFromJunctionPairs (DBJunctionPair value)
   {
      boolean changed = false;
      if ( (this.junctionPairs != null) &&  (value != null))
      {
         changed = this.junctionPairs.remove (value);
         if (changed)
         {
            value.removeYou();
         }
      }
      return changed;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void removeAllFromJunctionPairs()
   {
      DBJunctionPair tmpValue;
      Iterator iter = this.iteratorOfJunctionPairs();
      while (iter.hasNext())
      {
         tmpValue = (DBJunctionPair) iter.next();
         this.removeFromJunctionPairs (tmpValue);
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @return   No description provided
    */
   public Iterator iteratorOfJunctionPairs()
   {
      return  ( (this.junctionPairs == null)
         ? FEmptyIterator.get()
         : this.junctionPairs.iterator());
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param value  No description provided
    * @return       No description provided
    */
   public boolean hasInJunctionPairs (DBJunctionPair value)
   {
      return  ( (this.junctionPairs != null) &&
          (value != null) &&
         this.junctionPairs.contains (value));
   }


   /**
    * Access method for an one to n association.
    *
    * @param value  The object added.
    * @return       No description provided
    */
   public boolean addToJunctionPairs (DBJunctionPair value)
   {
      boolean changed = false;
      if (value != null)
      {
         if (this.junctionPairs == null)
         {
            this.junctionPairs = new FPropHashSet (this, "junctionPairs"); // or FTreeSet () or FLinkedList ()
         }
         changed = this.junctionPairs.add (value);
         value.setParent(this);
      }
      return changed;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private DBForeignTableJoin join;


   /**
    * Sets the join attribute of the DBForeignKey object
    *
    * @param obj  The new join value
    * @return     No description provided
    */
   public boolean setJoin (DBForeignTableJoin obj)
   {
      boolean changed = false;

      if (this.join != obj)
      {
         DBForeignTableJoin oldValue = this.join;
         if (this.join != null)
         {
            this.join = null;
         }
         this.join = obj;
         changed = true;

         // side effects

         firePropertyChange ("join", oldValue, obj);
      }

      return changed;
   }


   /**
    * Get the join attribute of the DBForeignKey object
    *
    * @return   The join value
    */
   public DBForeignTableJoin getJoin()
   {
      return join;
   }


   /**
    * <pre>
    *          +-----------+ 1              1
    * DBTable  | getName() +------------------ DBForeignKey
    *          +-----------+ revTAble     attrs
    * </pre>
    */
   private DBTable revTable;


   /**
    * Sets the revTable attribute of the DBForeignKey object
    *
    * @param obj  The new revTable value
    * @return     No description provided
    */
   public boolean setRevTable (DBTable obj)
   {
      boolean changed = false;

      if (this.revTable != obj)
      {
         DBTable oldValue = this.revTable;
         if (this.revTable != null)
         {
            this.revTable = null;
            oldValue.removeFromRevForeignKeys (this);
         }
         this.revTable = obj;
         if (obj != null)
         {
            DBTableJunction junc = new DBTableJunction (obj);
            junc.setJoin (this.join);
            junc.setAdornment (DBTableJunction.ARROW);
            join.setSecondJunction (junc);
            obj.addToRevForeignKeys (this);
         }
         changed = true;

         // side effects

         firePropertyChange ("revTable", oldValue, obj);
      }

      return changed;
   }


   /**
    * Get the revTable attribute of the DBForeignKey object
    *
    * @return   The parent value
    */
   public DBTable getRevTable()
   {
      return revTable;
   }


   /**
    * <pre>
    *          +-----------+ 1              1
    * DBTable  | getName() +------------------ DBForeignKey
    *          +-----------+ originalTable key
    * </pre>
    */
   private DBTable originalTable;


   /**
    * Sets the originalTable attribute of the DBForeignKey object
    *
    * @param obj  The new originalTable value
    * @return     No description provided
    */
   public boolean setOriginalTable (DBTable obj)
   {
      boolean changed = false;

      if (this.originalTable != obj)
      {
         DBTable oldValue = this.originalTable;
         if (this.originalTable != null)
         {
            this.originalTable = null;
            oldValue.removeFromForeignKeys (this);
         }
         this.originalTable = obj;
         if (obj != null)
         {
            DBTableJunction junc = new DBTableJunction ((DBNodeInterface) obj);
            junc.setJoin (this.join);
            junc.setAdornment (DBTableJunction.NONE);
            join.setFirstJunction (junc);
            obj.addToForeignKeys (this);
         }
         changed = true;

         // side effects

         firePropertyChange ("originalTable", oldValue, obj);
      }

      return changed;
   }


   /**
    * Get the originalTable attribute of the DBForeignKey object
    *
    * @return   The parent value
    */
   public DBTable getOriginalTable()
   {
      return originalTable;
   }


   /**
    * Get the text attribute of the DBForeignKey object
    *
    * @return   The text value
    */
   public String getText()
   {
      String name = null;
      Iterator i = iteratorOfJunctionPairs();
      if (i.hasNext())
      {
         DBJunctionPair pair = (DBJunctionPair) i.next();
         DBTableAttributeJunction junc = pair.getRevJunction();
         DBTableAttribute attr = junc.getTarget();
         String tableName = attr.getParent().getName();
         name = tableName + ": " + pair.getText();
         int size = sizeOfJunctionPairs();
         if (size > 1)
         {
            name += "... (" + size + " pairs)";
         }
      }
      return name;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @return   No description provided
    */
   public String toString()
   {
      return "DBForeignKey[join=" + join + ",junctionPairs=" + junctionPairs + ",originalTable=" + originalTable + ",revTable=" + revTable + "]";
   }
   
   public String getWhereClause() 
   {
   		String origTable = getOriginalTable().getName();
   		String revTable = getRevTable().getName();
   		StringBuffer sb = new StringBuffer();
   		Iterator iter = this.iteratorOfJunctionPairs();
   		while(iter.hasNext()) {
   			DBJunctionPair pair = (DBJunctionPair) iter.next();
   			DBTableAttributeJunction origJunc = pair.getOriginalJunction();
			DBTableAttributeJunction revJunc = pair.getRevJunction();
			sb.append(origTable + "." + origJunc.getTarget().getName() + "=" + revTable + "." + revJunc.getTarget().getName());
			if(iter.hasNext()) {
				sb.append(" AND ");
			}
   		}
   		return sb.toString();
   }
}

/*
 * $Log: DBForeignKey.java,v $
 * Revision 1.2  2003/10/07 07:21:52  ariseppi
 * misc. corrections
 *
 */
