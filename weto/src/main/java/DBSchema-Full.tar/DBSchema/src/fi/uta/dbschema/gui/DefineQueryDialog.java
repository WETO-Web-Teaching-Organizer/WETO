/*
 * Created on 22.6.2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package fi.uta.dbschema.gui;

import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import de.uni_paderborn.fujaba.gui.PEEditPanel;
import fi.uta.cs.sqldatatypes.SqlString;
import fi.uta.dbschema.metamodel.DBTableAttribute;
import fi.uta.dbschema.metamodel.DBViewAttribute;
import fi.uta.dbschema.test.HsqldbController;

/**
 * @author as66033
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class DefineQueryDialog extends BasicDialog
{
	private BDJTable definitionTable;
	
	private BDButton backButton;
	
	private String whereClause;
	
	public static String[] titles = {"Attribute", "Table", "Show", "Value"};
	private Object[][] values;
	
	private boolean[] strings;
	
	private String[] tables;
	
	public DefineQueryDialog(JFrame frame, String title, boolean modal, ArrayList list, String[] tables) {
		   super (frame);
		   setModal (modal);
		   setTitle (title);
		   setTable (list);
		   setTables (tables);
		   try
		   {
			  pack();
			  this.setTitle ("Database Query Definition");
		   }
		   catch (Exception e)
		   {
			  e.printStackTrace();
		   }
		   initDialog();
	}
	
	public DefineQueryDialog (JFrame frame, ArrayList list, String[] tables)
	{
	   this (frame, "", false, list, tables);
	}

	public DefineQueryDialog (JFrame frame, boolean modal, ArrayList list, String[] tables)
	{
	   this (frame, "", modal, list, tables);
	}

	public DefineQueryDialog (JFrame frame, String title, ArrayList list, String[] tables)
	{
	   this (frame, title, false, list, tables);
	}

	protected void additionalButtons(BDComponentGroup buttons)
	{
		backButton = new BDButton(this, "Back");
		buttons.add(backButton);
		backButton.setListener(
			new DefineQueryDialog_backButton_actionAdapter(this));
	}
	
	protected void additionalContents (PEEditPanel panel)
	{
		definitionTable = new BDJTable(this, "Query constraints", titles, values, null);
		panel.add(definitionTable);
	}
	
	public void setTable(ArrayList attributes) {
		values = new Object[attributes.size()][titles.length];
		strings = new boolean[attributes.size()];
		for(int i = 0; i < attributes.size(); i++)
		{
			Object attrObj = attributes.get(i);
			if(attrObj instanceof DBTableAttribute) {
				DBTableAttribute attr = (DBTableAttribute) attrObj;
				values[i][0] = attr.getName();
				values[i][1] = attr.getParent().getName();
				if(attr.getTypeClass() instanceof SqlString) {
					strings[i] = true;
				}
				else {
					strings[i] = false;
				}
			}
			else if(attrObj instanceof Object[]) {
				Object[] attrArray = (Object[]) attrObj;
				DBTableAttribute attr = (DBTableAttribute) attrArray[0];
				values[i][0] = attr.getName();
				values[i][1] = attr.getParent().getName() + ", " + attrArray[1];
				if(attr.getTypeClass() instanceof SqlString) {
					strings[i] = true;
				}
				else {
					strings[i] = false;
				}
			}
			else if(attrObj instanceof DBViewAttribute) {
				DBViewAttribute attr = (DBViewAttribute) attrObj;
				values[i][0] = attr.getName();
				values[i][1] = attr.getParent().getName();
				if(attr.getAttribute().getTypeClass() instanceof SqlString) {
					strings[i] = true;
				}
				else {
					strings[i] = false;
				}
				titles[1] = "View";
			}
			values[i][2] = new Boolean(false);
			values[i][3] = "";
		}
	}
	/**
	 * @return
	 */
	public String getWhereClause()
	{
		return whereClause;
	}

	/**
	 * @param string
	 */
	public void setWhereClause(String string)
	{
		whereClause = string;
	}
	
	void buttonOK_actionPerformed(ActionEvent e)
	{
		definitionTable.stopCellEditing();
		StringBuffer sb = new StringBuffer("SELECT ");
		ArrayList showAttributes = new ArrayList();
		boolean first = true;
		for(int i = 0; i < values.length; i++) {
			if(definitionTable.getValueAt(i, 2).equals(Boolean.TRUE)) {
				if(first) {
					first = false;
				}
				else {
					sb.append(",");
				}
				String tableName = definitionTable.getValueAt(i, 1).toString();
				int commaIndex = tableName.indexOf(',');
				if(commaIndex > -1) {
					tableName = tableName.substring(0, commaIndex);
				}
				sb.append(tableName + "." + definitionTable.getValueAt(i, 0));
				if(commaIndex < 0) {
					showAttributes.add(definitionTable.getValueAt(i, 1) + "." + definitionTable.getValueAt(i, 0));
				}
				else {
					showAttributes.add(definitionTable.getValueAt(i, 1) + ": " + definitionTable.getValueAt(i, 0));
				}
			}
		}
		if(showAttributes.size() == 0) {
			JOptionPane.showMessageDialog(
				getFrame(),
				"Error: No attributes selected to be shown in result.",
				"Select attributes to result",
				JOptionPane.ERROR_MESSAGE);
				return;
		}
		sb.append(" FROM ");
		String[] tables = getTables();
		for(int i = 0; i < tables.length; i++) {
			sb.append(tables[i]);
			if(i < tables.length - 1) {
				sb.append(",");
			}
		}
		boolean nonEmpty = false;
		if(!getWhereClause().equals("")) {
			nonEmpty = true;
		}
		StringBuffer whereBuffer = new StringBuffer(whereClause);
		for(int i = 0; i < values.length; i++) {
			String value = (String) definitionTable.getValueAt(i, 3);
			if(!value.equals("")) {
				if(nonEmpty) {
					whereBuffer.append(" AND ");
				}
				else {
					nonEmpty = true;
				}
				String tableName = definitionTable.getValueAt(i, 1).toString();
				int commaIndex = tableName.indexOf(',');
				if(commaIndex != -1) {
					tableName = tableName.substring(0, commaIndex);
				}
				whereBuffer.append(tableName + "." + definitionTable.getValueAt(i, 0));
				if(value.equals("null")) {
					whereBuffer.append("is null");
				}
				else if(strings[i]) {
					if(value.equals("\"\"") || value.equals("\'\'")) {
						value = "";
					}
					whereBuffer.append("=\'" +value +"\'");
				}
				else {
					whereBuffer.append("=" +value);
				}
			}
		}
		if(whereBuffer.length() > 0) {
			sb.append(" WHERE " + whereBuffer.toString());
		}
		sb.append(";");
		String[][] result = HsqldbController.queryDatabase(sb.toString());
		String[] titles = new String[showAttributes.size()];
		Iterator iter = showAttributes.iterator();
		int ind = 0;
		while(iter.hasNext()) {
			titles[ind] = (String) iter.next();
			ind++;
		}
		ResultTableDialog tableDialog = new ResultTableDialog(getFrame(), result, titles, sb.toString());
		tableDialog.showCentered();
	}
	
	void backButton_actionPerformed(ActionEvent e)
	{
		setVisible(false);
		dispose();
	}
	/**
	 * @return
	 */
	public String[] getTables()
	{
		return tables;
	}

	/**
	 * @param strings
	 */
	public void setTables(String[] strings)
	{
		tables = strings;
	}

}

class DefineQueryDialog_backButton_actionAdapter
	implements java.awt.event.ActionListener
{
	DefineQueryDialog adaptee;

	DefineQueryDialog_backButton_actionAdapter(DefineQueryDialog adaptee)
	{
		this.adaptee = adaptee;
	}

	public void actionPerformed(ActionEvent e)
	{
		adaptee.backButton_actionPerformed(e);
	}
}