/*
 * Created on 17.6.2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package fi.uta.dbschema.actions;

import java.awt.event.ActionEvent;
import java.sql.SQLException;

import javax.swing.AbstractAction;
import javax.swing.JOptionPane;

import de.uni_paderborn.fujaba.app.FrameMain;
import fi.uta.dbschema.metamodel.parse.MetaDataReader;

/**
 * @author as66033
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class AlterDatabaseAction extends AbstractAction
{
	public void actionPerformed(ActionEvent event)
	{
		try {
			MetaDataReader.readData(true);
		} catch (SQLException ex)
		{
			 JOptionPane.showMessageDialog(
			 FrameMain.get(),
			 ex.getSQLState(),
			"Schema extraction error",
			 JOptionPane.ERROR_MESSAGE);
		} catch (Exception ex)
		{
			 JOptionPane.showMessageDialog(
			 FrameMain.get(),
			 ex.getMessage(),
			"Schema extraction error",
			 JOptionPane.ERROR_MESSAGE);
		}
	}
}