/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.cs.sqldatatypes;

import java.math.BigDecimal;

import fi.uta.cs.sqldatamodel.InvalidValueException;
import fi.uta.cs.sqldatamodel.NullNotAllowedException;
import fi.uta.cs.sqldatamodel.ValueTooLongException;

/**
 * Concrete implementation of decimal SQL data type.
 * 
 * Value data type is java.math.BigDecimal.
 * JDBC data type is java.math.BigDecimal.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:49 $
 * @version   $Revision: $
 */
public class SqlDecimal extends SqlDataType {
	/**
	 * Value attribute.
	 */
	private BigDecimal value;
	
	/**
	 * Total length attribute.
	 */
	private int totalLength;
	
	/**
	 * Decimal width attribute.
	 */
	private int decimalWidth;

	/**
	 * Default constructor for class SqlDecimal.
	 * 
	 * @param totalLength Total length of the number (precision).
	 * @param decimalWidth Decimal width (scale).
	 */
	public SqlDecimal( int totalLength, int decimalWidth ) {
		super();
		value = null;
		this.totalLength = totalLength;
		this.decimalWidth = decimalWidth;
	}
	
	/**
	 * Initializing constructor for Fujaba.
	 * 
	 * @param totalLength Total length of the number (precision).
	 * @param decimalWidth Decimal width (scale).
	 * @param value Initial value as its string representation.
	 *  If an invalid value is given, the result is undefined
	 *  (a runtime exception may be thrown).
	 */
	public SqlDecimal( int totalLength, int decimalWidth, String value )
	{
		this( totalLength, decimalWidth );
		try {
			fromString( value );
		} catch( InvalidValueException e ) {
			// Ignored
		}
	}

//	======================================================================
//	Bean property methods
//	======================================================================	
	
	/**
	 * Gets the value.
	 * 
	 * @return The current value. Passed by copy.
	 */
	public BigDecimal getValue() {
		if( value == null ) return null;
		return new BigDecimal( value.toString() );
	}
	
	/**
	 * Sets the value.
	 * 
	 * @param value New value, passed by copy.
	 * 
	 * @throws NullNotAllowedException if a null-value is given, but
	 * 	not allowed.
	 * @throws InvalidValueException if the given decimal value
	 *  does not fit inside the given total length and decimal width.
	 */
	public void setValue( BigDecimal value ) throws InvalidValueException {
		checkValue( value );
		setValueUnchecked( value );
	}
	
	/**
	 * Sets the value without performing any checks.
	 * 
	 * @param value New value, passed by copy.
	 */
	public void setValueUnchecked( BigDecimal value ) {
		if( value == null ) {
			this.value = null;
		} else {
			this.value = new BigDecimal( value.toString() );
		}
	}
	
	/**
	 * Gets the total length of the number.
	 * 
	 * @return Total length as an integer.
	 */
	public int getTotalLength() {
		return totalLength;
	}
	
	/**
	 * Gets the width of the decimal part.
	 * 
	 * @return Width of the decimal part as an integer.
	 */
	public int getDecimalWidth() {
		return decimalWidth;
	}
	
//	======================================================================
//	JDBC property methods
//	======================================================================
	
	/**
	 * Gets the value as the type used with JDBC.
	 * 
	 * @return The current value.
	 */
	public BigDecimal jdbcGetValue() {
		return getValue();
	}
	
	/**
	 * Sets the value as the type used with JDBC.
	 * 
	 * @param value New value.
	 *
	 * @throws NullNotAllowedException if a null-value is given, but
	 * 	not allowed.
	 * @throws InvalidValueException if the value is incompatible
	 *  with the given total length and decimal width.
	 */
	public void jdbcSetValue( BigDecimal value ) throws InvalidValueException {
		setValue( value );
	}
	
//	======================================================================
//	SqlDataType methods
//	======================================================================

	public String toString() {
		if( value == null ) return "";
		return value.toString();
	}
	
	public void fromString( String str ) throws InvalidValueException {
		java.math.BigDecimal newValue = null;
		if( str!=null ) {
			if( str.length()>0 ) {
				newValue = new java.math.BigDecimal( str );
			}
		}
		setValue( newValue );
	}

	public boolean isValid() {
		try {
			checkValue( value );
		} catch( InvalidValueException e ) {
			return false;
		}
		
		return true;
	}

	public boolean equals(Object obj) {
		if( !(obj instanceof SqlDecimal) ) return false;
		SqlDecimal decObj = (SqlDecimal)obj;
		
		if( value==null || decObj.value==null ) {
			if( value==null && decObj.value==null ) return true;
			return false;
		}
		
		return value.equals( decObj.value );
	}

	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	
//	======================================================================
//	Internal methods
//	======================================================================
	
	/**
	 * Checks the given value, and throws an exception if it is invalid.
	 */
	protected void checkValue( BigDecimal decimal ) throws InvalidValueException {
		if( decimal==null && !isNullAllowed() ) 
			throw new NullNotAllowedException();

		if( decimal != null ) {
			BigDecimal absMax = new BigDecimal( Math.pow(10,(totalLength-decimalWidth)) );
		    if( decimal.abs().compareTo(absMax) >= 0 ) 
		    	throw new ValueTooLongException("Number total length exceeded");
	
		    String stringValue = decimal.toString();
		    int pointIndex = stringValue.indexOf('.');
		    if( pointIndex>-1 && pointIndex+decimalWidth+1<stringValue.length() )
		    	throw new InvalidValueException("Insufficient decimal width");
		}
	}
	
	public String getLongestString() {
		StringBuffer sb = new StringBuffer(2 + totalLength);
        sb.append("+.");
        for(int i = 0; i < totalLength; i++)
        	sb.append("8");
        return sb.toString();
    }
}

/*
 * $Log: SqlDecimal.java,v $
 * Revision 1.2  2003/10/07 07:21:49  ariseppi
 * misc. corrections
 *
 */

// End of file.
