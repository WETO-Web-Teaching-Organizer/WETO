/*
 * Created on 17.6.2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package fi.uta.dbschema.metamodel;

/**
 * @author as66033
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class DBItemRenamed extends DBSchemaItem
{

	private DBSchemaItem newItem = null;
	
	private DBSchemaItem origItem = null;
	
	/**
	 * 
	 */
	public DBItemRenamed(DBSchemaItem origItem, DBSchemaItem newItem)
	{
		super();
		setOrigItem(origItem);
		setNewItem(newItem);
	}

	/**
	 * @return
	 */
	public DBSchemaItem getNewItem()
	{
		return newItem;
	}

	/**
	 * @param table
	 */
	public void setNewItem(DBSchemaItem item)
	{
		newItem = item;
	}

	public String getName() {
		return newItem.getName() + " (was " + origItem.getName() + ")";
	}

	public String getText() {
		return getName();
	}
	/**
	 * @return
	 */
	public DBSchemaItem getOrigItem()
	{
		return origItem;
	}

	public void setOrigItem(DBSchemaItem item)
	{
		origItem = item;
	}
}
