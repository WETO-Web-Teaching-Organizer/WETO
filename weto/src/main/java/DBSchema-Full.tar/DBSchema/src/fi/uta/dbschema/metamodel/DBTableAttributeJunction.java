/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.metamodel;



/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:53 $
 * @version   $Revision: 1.2 $
 */
public class DBTableAttributeJunction extends DBSchemaItem
{
   /**
    * Constructor for class DBTableAttributeJunction
    */
   public DBTableAttributeJunction()
   {
      super();
   }


   /**
    * Constructor for class DBTableAttributeJunction
    *
    * @param target  No description provided
    */
   public DBTableAttributeJunction (DBTableAttribute target)
   {
      this();
      setTarget (target);
   }


   /**
    * Constructor for class DBTableAttributeJunction
    *
    * @param target  No description provided
    * @param pair    No description provided
    */
   public DBTableAttributeJunction (DBTableAttribute target, DBJunctionPair pair)
   {
      this();
      setTarget (target);
      setPair (pair);
   }


   /**
    * Get the readOnly attribute of the DBTableAttributeJunction object
    *
    * @return   The readOnly value
    */
   public boolean isReadOnly()
   {
      return  (super.isReadOnly() ||
          (getTarget() != null && getTarget().isReadOnly()));
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private DBTableAttribute target;


   /**
    * Get the target attribute of the DBTableAttributeJunction object
    *
    * @return   The target value
    */
   public DBTableAttribute getTarget()
   {
      return target;
   }


   /**
    * Sets the target attribute of the DBTableAttributeJunction object
    *
    * @param target  The new target value
    */
   public void setTarget (DBTableAttribute target)
   {
      if (this.target != target)
      { // new partner

         DBTableAttribute oldTarget = this.target;
         if (this.target != null)
         { // inform old partner

            this.target = null;
            oldTarget.removeFromJunctions (this);
         }
         this.target = target;
         if (target != null)
         { // inform new partner
            target.addToJunctions (this);
         }
         firePropertyChange ("target", oldTarget, target);
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private final void removeTarget()
   {
      this.setTarget (null);
   }


   /**
    * Get the adornment attribute of the DBTableAttributeJunction object
    *
    * @return   The adornment value
    */
   public int getAdornment()
   {
      return -1;
   }


   /**
    * Sets the adornment attribute of the DBTableAttributeJunction object
    *
    * @param i  The new adornment value
    */
   public void setAdornment (int i) { }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private DBJunctionPair pair;


   /**
    * Get the join attribute of the DBTableAttributeJunction object
    *
    * @return   The join value
    */
   public DBJunctionPair getPair()
   {
      return pair;
   }


   /**
    * Set the join attribute of the DBTableAttributeJunction object
    *
    * @param obj  The new pair value
    * @return     The join value
    */
   public boolean setPair (DBJunctionPair obj)
   {
      boolean changed = false;

      if (this.pair != obj)
      {
         DBJunctionPair oldValue = this.pair;

         this.pair = obj;

         changed = true;

         // side effects

         firePropertyChange ("pair", oldValue, obj);
      }
      return changed;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private final void removePair()
   {
      this.setPair (null);
   }


   /**
    * Get the partnerJunction attribute of the DBTableAttributeJunction object
    *
    * @return   The partnerJunction value
    */
   public DBTableAttributeJunction getPartnerJunction()
   {
      DBJunctionPair pair = getPair();
      if (pair != null)
      {
         if (pair.getOriginalJunction() == this)
         {
            return pair.getRevJunction();
         }
         if (pair.getRevJunction() == this)
         {
            return pair.getOriginalJunction();
         }
      }
      return null;
   }


   // ######################################################################

   /**
    * Isolates the object so the garbage collector can remove it.
    */
   public void removeYou()
   {
      this.removeTarget();
      this.removePair();

      super.removeYou();
   }


   /**
    * @return   short string representation of current object
    */
   public String toString()
   {
      return "DBTableAttributeJunction[id=" + getID() + ",target=" + getTarget() + "]";
   }
}

/*
 * $Log: DBTableAttributeJunction.java,v $
 * Revision 1.2  2003/10/07 07:21:53  ariseppi
 * misc. corrections
 *
 */
