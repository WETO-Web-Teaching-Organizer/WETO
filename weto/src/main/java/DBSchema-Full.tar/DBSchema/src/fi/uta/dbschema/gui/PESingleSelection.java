/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this added code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.gui;

// Based on de.uni_paderborn.fujaba.gui.PETypeSelection

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.util.Enumeration;

import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import de.uni_paderborn.fujaba.asg.ASGElement;
import de.uni_paderborn.fujaba.gui.BasicPropertyEditor;
import de.uni_paderborn.fujaba.gui.PEButton;
import de.uni_paderborn.fujaba.gui.PEColumn;
import de.uni_paderborn.fujaba.gui.PEHeaderComponent;
import de.uni_paderborn.fujaba.gui.PEResizable;
import de.uni_paderborn.fujaba.gui.PERow;


/**
 * A single list with three buttons.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.4 $
 */
public class PESingleSelection extends PEHeaderComponent implements PEResizable
{
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBListIncr list;

   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEColumn buttonCol = null;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private PEButton addButton = null;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private PEButton removeButton = null;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private PEButton modifyButton = null;


   /**
    * Constructor for class PESingleSelection
    *
    * @param parent  No description provided
    */
   public PESingleSelection (BasicPropertyEditor parent)
   {
      super();
      setParent (parent);
      list = new PEDBListIncr (this.parent, "List");
      list.addSelectionListener (new PEListSingleSelectionListener (this));
      setLayout (getLayoutManager());
      addComponents();
   }


   /**
    * Constructor for class PESingleSelection
    *
    * @param parent  No description provided
    * @param add     No description provided
    */
   public PESingleSelection (BasicPropertyEditor parent, boolean add)
   {
      super();
      setParent (parent);
      list = new PEDBListIncr (this.parent, "List");
      list.addSelectionListener (new PEListSingleSelectionListener (this));
      setLayout (getLayoutManager());
      addComponents (add);
   }


   /**
    * Sets the readOnly attribute of the PESingleSelection object
    *
    * @param b  The new readOnly value
    */
   public void setReadOnly (boolean b)
   {
   }


   /**
    * Get the buttonColumn attribute of the PESingleSelection object
    *
    * @return   The buttonColumn value
    */
   protected PEColumn getButtonColumn()
   {
      return buttonCol;
   }


   /**
    * Get the parentPE attribute of the PESingleSelection object
    *
    * @return   The parentPE value
    */
   protected BasicPropertyEditor getParentPE()
   {
      return parent;
   }


   /**
    * Access method for an one to n association.
    */
   protected void addComponents()
   {
      PEColumn column = new PEColumn (getParentPE());
      PERow row = new PERow (getParentPE());

      buttonCol = new PEColumn (getParentPE());
      buttonCol.setComponentName ("buttons");

      // thsa : changed creation of buttons
      addButton = new PEButton (this, "add");
      removeButton = new PEButton (this, "remove");
      modifyButton = new PEButton (this, "apply");
      buttonCol.add (addButton);
      buttonCol.add (removeButton);
      buttonCol.add (modifyButton);

      row.add (buttonCol);

      row.add (list);

      column.add (row);

      add (column);
   }


   /**
    * Access method for an one to n association.
    *
    * @param add  The object added.
    */
   protected void addComponents (boolean add)
   {
      PEColumn column = new PEColumn (getParentPE());
      PERow row = new PERow (getParentPE());

      buttonCol = new PEColumn (getParentPE());
      buttonCol.setComponentName ("buttons");

      // thsa : changed creation of buttons
      if (add)
      {
         addButton = new PEButton (this, "add");
      }
      removeButton = new PEButton (this, "remove");
      modifyButton = new PEButton (this, "apply");
      if (add)
      {
         buttonCol.add (addButton);
      }
      buttonCol.add (removeButton);
      buttonCol.add (modifyButton);

      row.add (buttonCol);

      row.add (list);

      column.add (row);

      add (column);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private ASGElement umlIncr = null;


   /**
    * The function setIncrement () sets the corresponding object of the AST
    *
    * @param incr  The new increment value
    */
   public void setIncrement (ASGElement incr)
   {
      umlIncr = incr;
      list.removeAll();
      fillList();
   }


   /**
    * The function getIncrement () returns a valid reference of the corresponding AST object.
    *
    * @return   a valid reference of a AST object
    */
   public ASGElement getIncrement()
   {
      return umlIncr;
   }


   /**
    * The function clearList () removes all entries of the list.
    */
   public void clearList()
   {
      list.removeAll();
   }


   /**
    * The function getSelectedIndex () gets the selected index of the list.
    *
    * @return   The selectedIndex value
    */
   public int getSelectedIndex()
   {
      int[] indexes = list.getSelectedIndices();
      if (indexes.length > 0)
      {
         return indexes[0];
      }
      else
      {
         return -1;
      }
   }


   /**
    * The function setSelectedIndex () sets the selected index of the list.
    *
    * @param index  The new selectedIndex value
    */
   public void setSelectedIndex (int index)
   {
      list.selectByIndex (index);
   }


   /**
    * The function getListSelectedIncr () returns a valid reference of an object of the AST.
    * The function returns the first entry, if more than one selected.
    *
    * @return   a valid reference to an object of the AST
    */
   public ASGElement getListSelectedIncr()
   {
      return list.getSelectedIncrement();
   }


   /**
    * Sets the listSelectedIncr attribute of the PESingleSelection object
    *
    * @param incr  The new sourceSelectedIncr value
    */
   public void setListSelectedIncr (ASGElement incr)
   {
      getList().selectIncrement (incr);
   }


   /**
    * The function setAddListener sets a listener for the add button
    *
    * @param listener  a valid reference of an action adapter
    */
   public void setAddListener (ActionListener listener)
   {
      addButton.setListener (listener);
   }


   /**
    * The function setAddListener sets a listener for the remove button
    *
    * @param listener  a valid reference of an action adapter
    */
   public void setRemoveListener (ActionListener listener)
   {
      removeButton.setListener (listener);
   }


   /**
    * The function setModifyListener sets a listener for the modify button
    *
    * @param listener  a valid reference of an action adapter
    */
   public void setModifyListener (ActionListener listener)
   {
      modifyButton.setListener (listener);
   }


   /**
    * The function setListMouseListener sets a listener for the list
    *
    * @param listener  a valid reference of an action adapter
    */
   public void setListMouseListener (MouseListener listener)
   {
      list.addMouseListener (listener);
   }


   /**
    * The function addToList () adds a new entry represented by a valid reference to an object
    * of the AST to the added list.
    *
    * @param incr  a valid reference to an object of the AST
    */
   public void addToList (ASGElement incr)
   {
      PEDBItem item = new PEDBItem (incr);
      list.add (item);
   }


   /**
    * The function addToList () adds a new entry represented by a valid reference to an object
    * of the AST and a string to the list.
    *
    * @param incr  a valid reference to an object of the AST
    * @param s     a valid string represented the entry in the list
    */
   public void addToList (ASGElement incr, String s)
   {
      PEDBItem item = new PEDBItem (incr, s);
      list.add (item);
   }


   /**
    * The function removeFromList () removes a existing entry from the list. The entry will
    * be identified by the reference of the represented object.
    *
    * @param incr  a valid reference of an object
    */
   public void removeFromList (ASGElement incr)
   {
      list.remove (incr);
   }


   /**
    * The function getListList returns a enumeration of the objects represented by the list.
    * Strange name due to being consistent with the naming conventions used in the classes
    * this class was modified from.
    *
    * @return   a valid enumeration of the entries.
    */
   public Enumeration getListList()
   {
      return list.elements();
   }


   /**
    * The function hasElements returns true if list has elements.
    *
    * @return   boolean value of attribute hasElements
    */
   public boolean hasElements()
   {
      return list.elements().hasMoreElements();
   }


   /**
    * Get the list attribute of the PESingleSelection object
    *
    * @return   The added value
    */
   public PEDBListIncr getList()
   {
      return list;
   }


   /**
    * Override the function fillList () to initialize the list. This function will be called
    * if a increment will be set.
    */
   protected void fillList()
   {
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected void listSelectionChanged()
   {
   }


   /**
    * Get the listIncrementByName attribute of the PESingleSelection object
    *
    * @param name  No description provided
    * @return      The listIncrementByName value
    */
   public ASGElement getListIncrementByName (String name)
   {
      return list.getIncrementByName (name);
   }


   /**
    * Get the horzResizable attribute of the PESingleSelection object
    *
    * @return   The horzResizable value
    */
   public boolean isHorzResizable()
   {
      return true;
   }


   /**
    * Get the vertResizable attribute of the PESingleSelection object
    *
    * @return   The vertResizable value
    */
   public boolean isVertResizable()
   {
      return true;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param g  No description provided
    */
   public void paint (Graphics g)
   {
      super.paint (g);
      g.drawString ("test", 0, 0);
   }


   //////////////////////////////////////////////////////////////////////////
   // thsa : added some function to handle button events for
   // introduced buttons
   // --> to be overwritten by each subclass which
   // takes use of buttons add/remove/modify

   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param buttonIdentifier  No description provided
    * @param e                 No description provided
    * @return                  No description provided
    */
   public boolean buttonActionPerformed (String buttonIdentifier, ActionEvent e)
   {
      return PEButton.remainedUnbound;
   }

   // added return functions for buttons
   /**
    * Get the addButton attribute of the PESelection object
    *
    * @return   The addButton value
    */
   protected PEButton getAddButton()
   {
      return addButton;
   }
   
   public void setAddButtonText(String name) {
   	   addButton.setText(name);
   }


   /**
    * Get the removeButton attribute of the PESelection object
    *
    * @return   The removeButton value
    */
   protected PEButton getRemoveButton()
   {
      return removeButton;
   }
   
   public void setRemoveButtonText(String name) {
	   removeButton.setText(name);
   }


   /**
    * Get the modifyButton attribute of the PESelection object
    *
    * @return   The modifyButton value
    */
   protected PEButton getModifyButton()
   {
      return modifyButton;
   }
   
   public void setModifyButtonText(String name) {
	   modifyButton.setText(name);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.4 $
 */
class PEListSingleSelectionListener implements ListSelectionListener
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PESingleSelection adaptor;


   /**
    * Constructor for class PEListSingleSelectionListener
    *
    * @param adapter  No description provided
    */
   PEListSingleSelectionListener (PESingleSelection adapter)
   {
      adaptor = adapter;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void valueChanged (ListSelectionEvent e)
   {
      adaptor.listSelectionChanged();
   }
}

/*
 * $Log: PESingleSelection.java,v $
 * Revision 1.4  2003/10/07 07:21:52  ariseppi
 * misc. corrections
 *
 */
