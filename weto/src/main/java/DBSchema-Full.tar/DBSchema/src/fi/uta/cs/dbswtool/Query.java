/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.cs.dbswtool;



/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:48 $
 * @version   $Revision: 1.2 $
 */
public class Query
{
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private String name;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private String packageName; // Java package for the generated files
   //    private AttributeVector attributeVector;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private NameVector relationNameVector;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private String whereClause; // This is for unique namevectors here.


   /**
    * Constructor for class Query
    */
   public Query()
   {
      name = "";
      packageName = "";
      relationNameVector = new NameVector();
      whereClause = "";
   }


   /**
    * Sets the name attribute of the Query object
    *
    * @param name  The new name value
    */
   public void setName (String name)
   {
      this.name = name;
   }


   /**
    * Get the name attribute of the Query object
    *
    * @return   The name value
    */
   public String getName()
   {
      return name;
   }


   /**
    * Sets the package attribute of the Query object
    *
    * @param packageName  The new package value
    */
   public void setPackage (String packageName)
   {
      this.packageName = packageName;
   }


   /**
    * Get the package attribute of the Query object
    *
    * @return   The package value
    */
   public String getPackage()
   {
      return packageName;
   }


   /**
    * Get the relationNameVector attribute of the Query object
    *
    * @return   The relationNameVector value
    */
   public NameVector getRelationNameVector()
   {
      return relationNameVector;
   }


   /**
    * Sets the relationNameVector attribute of the Query object
    *
    * @param relationNameVector  The new relationNameVector value
    */
   public void setRelationNameVector (NameVector relationNameVector)
   {
      this.relationNameVector = relationNameVector;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param name  No description provided
    * @return      No description provided
    */
   public boolean relationNameExists (String name)
   {
      if (relationNameVector.nameExists (name))
      {
         return false;
      }
      else
      {
         return true;
      }
   }


   /**
    * Access method for an one to n association.
    *
    * @param newRelationName  The object added.
    */
   public void addRelationName (String newRelationName)
   {
      relationNameVector.addName (newRelationName);
   }


   /**
    * Sets the whereClause attribute of the Query object
    *
    * @param whereClause  The new whereClause value
    */
   public void setWhereClause (String whereClause)
   {
      this.whereClause = whereClause;
   }


   /**
    * Get the whereClause attribute of the Query object
    *
    * @return   The whereClause value
    */
   public String getWhereClause()
   {
      return whereClause;
   }



   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void output()
   {
      System.out.println ("Query " + name);
      relationNameVector.output();
      System.out.println (whereClause);
   }

}

/*
 * $Log: Query.java,v $
 * Revision 1.2  2003/10/07 07:21:48  ariseppi
 * misc. corrections
 *
 */
