/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this added code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.gui;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;

import javax.swing.Box;
import javax.swing.JComboBox;
import javax.swing.JFrame;

import de.uni_paderborn.fujaba.asg.ASGElement;
import de.uni_paderborn.fujaba.gui.PEBaseComponent;
import de.uni_paderborn.fujaba.gui.PEButton;
import de.uni_paderborn.fujaba.gui.PEColumn;
import de.uni_paderborn.fujaba.gui.PEEditPanel;
import de.uni_paderborn.fujaba.gui.PEListEntry;
import de.uni_paderborn.fujaba.gui.PERow;
import de.uni_paderborn.fujaba.gui.PETextField;
import de.uni_paderborn.fujaba.uml.UMLProject;
import de.upb.tools.fca.FLinkedList;
import fi.uta.dbschema.metamodel.DBForeignKey;
import fi.uta.dbschema.metamodel.DBJunctionPair;
import fi.uta.dbschema.metamodel.DBSchema;
import fi.uta.dbschema.metamodel.DBTable;
import fi.uta.dbschema.metamodel.DBTableAttribute;
import fi.uta.dbschema.metamodel.DBTableAttributeJunction;


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.3 $
 */
public class PEDBSuggestedForeignKey extends DBPropertyEditor
{
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PETextField curTable;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PETextField revTable;

   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEButton swapButton;

   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBSuggestedKeyAttrPanel keyAttrPanel;

   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBSuggestedKeyAttrSelection keyAttrSelection;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBSuggestedKeySelection keySelection;

   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   FLinkedList addForKeys = new FLinkedList();

   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   FLinkedList addPairs = new FLinkedList();
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   FLinkedList delPairs = new FLinkedList();


   /**
    * Constructor for class PEDBSuggestedForeignKey
    *
    * @param frame  No description provided
    * @param title  No description provided
    * @param modal  No description provided
    */
   public PEDBSuggestedForeignKey (JFrame frame, String title, boolean modal)
   {
      super (frame);
      setModal (modal);
      setTitle (title);
      try
      {
         pack();
         this.setTitle ("Foreign Key Editor");
      }
      catch (Exception e)
      {
         e.printStackTrace();
      }
      initPE();
   }


   /**
    * Constructor for class PEDBSuggestedForeignKey
    *
    * @param frame  No description provided
    */
   public PEDBSuggestedForeignKey (JFrame frame)
   {
      this (frame, "", false);
   }


   /**
    * Constructor for class PEDBSuggestedForeignKey
    *
    * @param frame  No description provided
    * @param modal  No description provided
    */
   public PEDBSuggestedForeignKey (JFrame frame, boolean modal)
   {
      this (frame, "", modal);
   }


   /**
    * Constructor for class PEDBSuggestedForeignKey
    *
    * @param frame  No description provided
    * @param title  No description provided
    */
   public PEDBSuggestedForeignKey (JFrame frame, String title)
   {
      this (frame, title, false);
   }


   /**
    * Returns the curTableName attribute of the PEDBSuggestedForeignKey object
    *
    * @return   The curTableName value
    */
   public String getCurTableName()
   {
      return curTable.getText();
   }


   /**
    * Returns the forKeyRevTable attribute of the PEDBSuggestedForeignKey object
    *
    * @return   The curTable value
    */
   public Object getCurTable()
   {
      return getForKey().getOriginalTable();
   }


   /**
    * Sets the forKeyRevTable attribute of the PEDBSuggestedForeignKey object
    *
    * @param table  The new curTable value
    */
   public void setCurTable (DBTable table)
   {
      String tableName = table.getName();
      curTable.setText (tableName);
      keyAttrPanel.reloadLeftBox (table);
   }


   /**
    * Returns the forKeyRevTable attribute of the PEDBSuggestedForeignKey object
    *
    * @return   The revTable value
    */
   public Object getRevTable()
   {
      return getForKey().getRevTable();
   }


   /**
    * Sets the forKeyRevTable attribute of the PEDBSuggestedForeignKey object
    *
    * @param table  The new revTable value
    */
   public void setRevTable (DBTable table)
   {
      String tableName = table.getName();
      revTable.setText (tableName);
      keyAttrPanel.reloadRightBox (table);
   }


   /**
    * Sets the keyAttrSelection attribute of the PEDBSuggestedForeignKey object
    *
    * @param fk  The new keyAttrSelection value
    */
   public void setKeyAttrSelection (DBForeignKey fk)
   {
      keyAttrSelection.clearList();
      Iterator i = fk.iteratorOfJunctionPairs();
      DBJunctionPair pair;
      while (i.hasNext())
      {
         pair = (DBJunctionPair) i.next();
         keyAttrSelection.addToList (pair);
      }
      if (keyAttrSelection.hasElements())
      {
         keyAttrSelection.setSelectedIndex (0);
      }
      addPairs.clear();
      delPairs.clear();
   }


   /**
    * Sets the keySelection attribute of the PEDBSuggestedForeignKey object
    *
    * @param fk  The new keySelection value
    */
   public void setKeySelection (DBForeignKey fk)
   {
      keySelection.getList().selectIncrement (fk);
   }


   /**
    * Returns the selected foreignKey attribute of the PEDBSuggestedForeignKey object
    *
    * @return   The forKey value
    */
   public DBForeignKey getForKey()
   {
      return (DBForeignKey) keySelection.getListSelectedIncr();
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param panel  No description provided
    */
   protected void additionalProperties (PEEditPanel panel)
   {
      curTable = new PETextField (this, "Table of the foreign key");
      curTable.setReadOnly (true);

      revTable = new PETextField (this, "Table where the key refers to");
      revTable.setReadOnly (true);

      swapButton = new PEButton (this, "Swap tables");

      swapButton.setListener (new PEDBSuggestedForeignKey_swapTables_actionAdapter (this));

      keyAttrPanel = new PEDBSuggestedKeyAttrPanel (this);
      keyAttrSelection = new PEDBSuggestedKeyAttrSelection (this);
      keySelection = new PEDBSuggestedKeySelection (this, false);

      keyAttrSelection.setAddListener (new PEDBSuggestedForeignKey_addPairButton_actionAdapter (this));
      keyAttrSelection.setRemoveListener (new PEDBSuggestedForeignKey_removePairButton_actionAdapter (this));
      keyAttrSelection.setModifyListener (new PEDBSuggestedForeignKey_modifyPairButton_actionAdapter (this));

      keySelection.setRemoveListener (new PEDBSuggestedForeignKey_removeKeyButton_actionAdapter (this));
      keySelection.setModifyListener (new PEDBSuggestedForeignKey_modifyKeyButton_actionAdapter (this));

      PEColumn column = new PEColumn (this);

      PERow row = new PERow (this);
      row.add (curTable);
      row.add (Box.createVerticalGlue());
      row.add (revTable);
      row.add (swapButton);

      column.add (row);
      column.add (keyAttrPanel);
      column.add (keyAttrSelection);
      column.add (keySelection);

      panel.add (column);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void unparse()
   {
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected void parse()
   {
      ASGElement incr = getIncrement();

      if (incr instanceof DBSchema)
      {
         DBSchema schema = (DBSchema) incr;
         DBForeignKey key = null;

         Iterator iter = addForKeys.iterator();
         while (iter.hasNext())
         {
            key = (DBForeignKey) iter.next();
            schema.addToItems (key);
         }
         addForKeys.clear();
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected void cancel()
   {
      Iterator iter = addForKeys.iterator();
      while (iter.hasNext())
      {
         DBForeignKey key = (DBForeignKey) iter.next();
         key.removeYou();
      }
      addForKeys.clear();
      setVisible (false);
      dispose();
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void buttonOK_actionPerformed (ActionEvent e)
   {
//      super.buttonOK_actionPerformed (e);
      if (getFrame() != null)
      {
         getFrame().setCursor (Cursor.getPredefinedCursor (Cursor.WAIT_CURSOR));
      } // if

      try
      {
         setVisible (false);
         parse();
         UMLProject.get().refreshDisplay();
      }
      finally
      {
         if (getFrame() != null)
         {
            getFrame().setCursor (Cursor.getPredefinedCursor (Cursor.DEFAULT_CURSOR));
         }
      }
   }


   /**
    * Access method for an one to n association.
    *
    * @param e  The object added.
    */

   void addPairButton_actionPerformed (ActionEvent e)
   {
      if ( (keyAttrPanel.getLeftComboSelectedIndex() != -1) &&  (keyAttrPanel.getRightComboSelectedIndex() != -1))
      {
         DBJunctionPair newPair = new DBJunctionPair();

         DBTableAttributeJunction origJunction = new DBTableAttributeJunction();
         origJunction.setTarget ((DBTableAttribute) keyAttrPanel.getLeftComboSelectedItem().getItem());
         newPair.setOriginalJunction (origJunction);
         DBTableAttributeJunction revJunction = new DBTableAttributeJunction();
         revJunction.setTarget ((DBTableAttribute) keyAttrPanel.getRightComboSelectedItem().getItem());
         newPair.setRevJunction (revJunction);

         addPairs.add (newPair);
         keyAttrSelection.addToList (newPair);
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   protected void removePairButton_actionPerformed (ActionEvent e)
   {
      ASGElement incr = keyAttrSelection.getListSelectedIncr();
      if (incr != null)
      {
         addPairs.remove (incr);
         delPairs.add (incr);
         keyAttrSelection.removeFromList (incr);
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   protected void removeKeyButton_actionPerformed (ActionEvent e)
   {
      addPairs.clear();
      delPairs.clear();
      ASGElement incr = keySelection.getListSelectedIncr();
      if (incr != null)
      {
         /*
          *  if (incr instanceof DBJunctionPair)
          *  {
          *  DBJunctionPair pair = (DBJunctionPair) incr;
          *  }
          */
         addForKeys.remove (incr);
         keySelection.removeFromList (incr);
         keyAttrSelection.clearList();
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   void modifyKeyButton_actionPerformed (ActionEvent e)
   {
      ASGElement oldIncr = keySelection.getListSelectedIncr();
      if (oldIncr != null && oldIncr instanceof DBForeignKey)
      {
         // Fix me: The new editor should make it better handling modified items.
         DBForeignKey curKey = (DBForeignKey) oldIncr;

         DBForeignKey oldKey = new DBForeignKey();
         Iterator i = curKey.iteratorOfJunctionPairs();
         while (i.hasNext())
         {
            DBJunctionPair pair = (DBJunctionPair) i.next();
            if (!delPairs.contains (pair))
            {
               DBJunctionPair newPair = new DBJunctionPair();
               DBTableAttributeJunction origJunc = new DBTableAttributeJunction (pair.getOriginalJunction().getTarget());
               newPair.setOriginalJunction (origJunc);
               DBTableAttributeJunction revJunc = new DBTableAttributeJunction (pair.getRevJunction().getTarget());
               newPair.setRevJunction (revJunc);
               oldKey.addToJunctionPairs (newPair);
            }
         }
         delPairs.clear();

         DBJunctionPair pair = null;

         Iterator iter = addPairs.iterator();
         while (iter.hasNext())
         {
            pair = (DBJunctionPair) iter.next();
            oldKey.addToJunctionPairs (pair);
         }
         addPairs.clear();

         oldKey.setOriginalTable (curKey.getOriginalTable());
         oldKey.setRevTable (curKey.getRevTable());

         int curInd = keySelection.getSelectedIndex();

         keySelection.setSelectedIndex (-1);

         Enumeration enum = keySelection.getListList();

         ArrayList tempList = new ArrayList();

         while (enum.hasMoreElements())
         {
            tempList.add (enum.nextElement());
         }
         for (int i2 = 0; i2 < tempList.size(); i2++)
         {
            PEDBItem item = (PEDBItem) tempList.get (i2);

            DBForeignKey elem = (DBForeignKey) item.getIncrement();

            keySelection.removeFromList (elem);

            if (elem != curKey)
            {
               keySelection.addToList (elem, elem.getOriginalTable() + " - " + elem.getText());
            }
            else
            {
               keySelection.addToList (oldKey, oldKey.getOriginalTable() + " - " + oldKey.getText());
            }
         }
         keySelection.setSelectedIndex (curInd);

         addForKeys.remove (curKey);
         addForKeys.add (oldKey);

      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   void modifyPairButton_actionPerformed (ActionEvent e)
   {
      if ( (keyAttrPanel.getLeftComboSelectedIndex() != -1) &&  (keyAttrPanel.getRightComboSelectedIndex() != -1) &&  (keyAttrSelection.getListSelectedIncr() != null))
      {
         DBJunctionPair pair = (DBJunctionPair) keyAttrSelection.getListSelectedIncr();
         DBJunctionPair newPair = new DBJunctionPair();
         DBTableAttributeJunction origJunction = new DBTableAttributeJunction();
         origJunction.setTarget ((DBTableAttribute) keyAttrPanel.getLeftComboSelectedItem().getItem());
         newPair.setOriginalJunction (origJunction);
         DBTableAttributeJunction revJunction = new DBTableAttributeJunction();
         revJunction.setTarget ((DBTableAttribute) keyAttrPanel.getRightComboSelectedItem().getItem());
         newPair.setRevJunction (revJunction);

         delPairs.add (pair);
         addPairs.remove (pair);
         addPairs.add (newPair);

         keyAttrSelection.removeFromList (pair);
         keyAttrSelection.addToList (newPair);

      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   void swapTables_actionPerformed (ActionEvent e)
   {
      DBForeignKey key = getForKey();
      if (key == null)
      {
         return;
      }

      DBForeignKey newKey = new DBForeignKey();

      Iterator iter = key.iteratorOfJunctionPairs();
      while (iter.hasNext())
      {
         DBJunctionPair pair = (DBJunctionPair) iter.next();
         DBTableAttributeJunction origJunc = pair.getOriginalJunction();
         DBTableAttributeJunction revJunc = pair.getRevJunction();

         DBJunctionPair newPair = new DBJunctionPair();

         DBTableAttributeJunction newOrigJunc = new DBTableAttributeJunction (revJunc.getTarget());
         newPair.setOriginalJunction (newOrigJunc);
         DBTableAttributeJunction newRevJunc = new DBTableAttributeJunction (origJunc.getTarget());
         newPair.setRevJunction (newRevJunc);
         newKey.addToJunctionPairs (newPair);
      }

      newKey.setRevTable (key.getOriginalTable());
      newKey.setOriginalTable (key.getRevTable());

      int curInd = keySelection.getSelectedIndex();

      keySelection.setSelectedIndex (-1);

      Enumeration enum = keySelection.getListList();

      ArrayList tempList = new ArrayList();

      while (enum.hasMoreElements())
      {
         tempList.add (enum.nextElement());
      }
      for (int i = 0; i < tempList.size(); i++)
      {
         PEDBItem item = (PEDBItem) tempList.get (i);

         DBForeignKey elem = (DBForeignKey) item.getIncrement();

         keySelection.removeFromList (elem);

         if (elem != key)
         {
            keySelection.addToList (elem, elem.getOriginalTable() + " - " + elem.getText());
         }
         else
         {
            keySelection.addToList (newKey, newKey.getOriginalTable() + " - " + newKey.getText());
         }
      }
      keySelection.setSelectedIndex (curInd);
   }


   /**
    * Sets the attrPair attribute of the PEDBSuggestedForeignKey object
    *
    * @param origAttribute  The new attrPair value
    * @param revAttribute   The new attrPair value
    */
   public void setAttrPair (DBTableAttribute origAttribute, DBTableAttribute revAttribute)
   {
      keyAttrPanel.setLeftComboSelectedItem (origAttribute);
      keyAttrPanel.setRightComboSelectedItem (revAttribute);
   }


   /**
    * Access method for an one to n association.
    *
    * @param list  The object added.
    */
   public void addKeys (ArrayList list)
   {
      keySelection.fillList (list);
      addForKeys.addAll (list);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.3 $
 */
class PEDBSuggestedForeignKey_swapTables_actionAdapter implements java.awt.event.ActionListener
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBSuggestedForeignKey adaptee;


   /**
    * Constructor for class PEDBSuggestedForeignKey_addPairButton_actionAdapter
    *
    * @param adaptee  No description provided
    */
   PEDBSuggestedForeignKey_swapTables_actionAdapter (PEDBSuggestedForeignKey adaptee)
   {
      this.adaptee = adaptee;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void actionPerformed (ActionEvent e)
   {
      adaptee.swapTables_actionPerformed (e);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.3 $
 */
class PEDBSuggestedForeignKey_addPairButton_actionAdapter implements java.awt.event.ActionListener
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBSuggestedForeignKey adaptee;


   /**
    * Constructor for class PEDBSuggestedForeignKey_addPairButton_actionAdapter
    *
    * @param adaptee  No description provided
    */
   PEDBSuggestedForeignKey_addPairButton_actionAdapter (PEDBSuggestedForeignKey adaptee)
   {
      this.adaptee = adaptee;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void actionPerformed (ActionEvent e)
   {
      adaptee.addPairButton_actionPerformed (e);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.3 $
 */
class PEDBSuggestedForeignKey_removePairButton_actionAdapter implements java.awt.event.ActionListener
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBSuggestedForeignKey adaptee;


   /**
    * Constructor for class PEDBSuggestedForeignKey_removePairButton_actionAdapter
    *
    * @param adaptee  No description provided
    */
   PEDBSuggestedForeignKey_removePairButton_actionAdapter (PEDBSuggestedForeignKey adaptee)
   {
      this.adaptee = adaptee;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void actionPerformed (ActionEvent e)
   {
      adaptee.removePairButton_actionPerformed (e);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.3 $
 */
class PEDBSuggestedForeignKey_removeKeyButton_actionAdapter implements java.awt.event.ActionListener
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBSuggestedForeignKey adaptee;


   /**
    * Constructor for class PEDBSuggestedForeignKey_removeKeyButton_actionAdapter
    *
    * @param adaptee  No description provided
    */
   PEDBSuggestedForeignKey_removeKeyButton_actionAdapter (PEDBSuggestedForeignKey adaptee)
   {
      this.adaptee = adaptee;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void actionPerformed (ActionEvent e)
   {
      adaptee.removeKeyButton_actionPerformed (e);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.3 $
 */
class PEDBSuggestedForeignKey_modifyPairButton_actionAdapter implements java.awt.event.ActionListener
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBSuggestedForeignKey adaptee;


   /**
    * Constructor for class PEDBSuggestedForeignKey_modifyPairButton_actionAdapter
    *
    * @param adaptee  No description provided
    */
   PEDBSuggestedForeignKey_modifyPairButton_actionAdapter (PEDBSuggestedForeignKey adaptee)
   {
      this.adaptee = adaptee;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void actionPerformed (ActionEvent e)
   {
      adaptee.modifyPairButton_actionPerformed (e);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.3 $
 */
class PEDBSuggestedForeignKey_modifyKeyButton_actionAdapter implements java.awt.event.ActionListener
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   PEDBSuggestedForeignKey adaptee;


   /**
    * Constructor for class PEDBSuggestedForeignKey_modifyKeyButton_actionAdapter
    *
    * @param adaptee  No description provided
    */
   PEDBSuggestedForeignKey_modifyKeyButton_actionAdapter (PEDBSuggestedForeignKey adaptee)
   {
      this.adaptee = adaptee;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param e  No description provided
    */
   public void actionPerformed (ActionEvent e)
   {
      adaptee.modifyKeyButton_actionPerformed (e);
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.3 $
 */
class PEDBSuggestedKeySelection extends PESingleSelection
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private PEDBSuggestedForeignKey keyEditor;


   /**
    * Constructor for class PEDBSuggestedKeySelection
    *
    * @param parent  No description provided
    * @param add     No description provided
    */
   PEDBSuggestedKeySelection (DBPropertyEditor parent, boolean add)
   {
      super (parent, add);
      getList().setHeader ("Foreign Keys");
      keyEditor = (PEDBSuggestedForeignKey) parent;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected void listSelectionChanged()
   {
      DBForeignKey key = (DBForeignKey) list.getSelectedIncrement();
      if (key != null)
      {
         keyEditor.setCurTable (key.getOriginalTable());
         keyEditor.setRevTable (key.getRevTable());
         keyEditor.setKeyAttrSelection (key);
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param keys  No description provided
    */
   public void fillList (ArrayList keys)
   {
      clearList();
      for (int i = 0; i < keys.size(); i++)
      {
         DBForeignKey key = (DBForeignKey) keys.get (i);
         addToList (key, key.getOriginalTable() + " - " + key.getText());
      }
   }
}


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.3 $
 */
class PEDBSuggestedKeyAttrSelection extends PESingleSelection
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private PEDBSuggestedForeignKey keyEditor;


   /**
    * Constructor for class PEDBSuggestedKeyAttrSelection
    *
    * @param parent  No description provided
    */
   PEDBSuggestedKeyAttrSelection (DBPropertyEditor parent)
   {
      super (parent);
      getList().setHeader ("Key Attribute Pairs");
      keyEditor = (PEDBSuggestedForeignKey) parent;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   protected void listSelectionChanged()
   {
      ASGElement incr = list.getSelectedIncrement();
      if (incr instanceof DBJunctionPair)
      {
         DBJunctionPair pair = (DBJunctionPair) incr;
         DBTableAttribute origAttr = pair.getOriginalJunction().getTarget();
         DBTableAttribute revAttr = pair.getRevJunction().getTarget();
         keyEditor.setAttrPair (origAttr, revAttr);
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void fillList()
   {
      clearList();
      DBForeignKey key = keyEditor.getForKey();
      if (key != null)
      {
         Iterator iter = key.iteratorOfJunctionPairs();
         DBJunctionPair pair;
         while (iter.hasNext())
         {
            pair = (DBJunctionPair) iter.next();
            if (pair != null)
            {
               addToList (pair);
            }
         }
      }
   }
}


/**
 * Class mainly copy-pasted from class de.uni_paderborn.fujaba.gui.PERolePanel
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:52 $
 * @version   $Revision: 1.3 $
 */

class PEDBSuggestedKeyAttrPanel extends PEBaseComponent
{


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private JComboBox leftCombo;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private JComboBox rightCombo;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
//   private PEButton addButton;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private int gapHorz = 10;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private int gapVert = 20;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private int gapLine = 40;

   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private HashMap rightHash = new HashMap();
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private HashMap leftHash = new HashMap();

   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private PEDBSuggestedForeignKey keyEditor;


   /**
    * Constructor for class PEDBSuggestedKeyAttrPanel
    *
    * @param fk  No description provided
    */
   public PEDBSuggestedKeyAttrPanel (PEDBSuggestedForeignKey fk)
   {
      super();

      keyEditor = fk;

      // initialize the buttons and combo boxes
      /*
       *  addButton = new PEButton (keyEditor, "Add");
       *  addButton.addActionListener (new PEAddButtonActionAdapter (keyEditor));
       *  this.add (addButton);
       */
      leftCombo = new JComboBox();
      leftCombo.setEditable (false);
      this.add (leftCombo);

      rightCombo = new JComboBox();
      rightCombo.setEditable (false);
      this.add (rightCombo);

      setInsets (new Insets (1, 1, 10, 1));
   }


   /**
    * Read access method for horizontal gap.
    *
    * @return   The gapHorz value
    */
   public int getGapHorz()
   {
      return gapHorz;
   }


   /**
    * Write access method for horizontal gap.
    *
    * @param newGapHorz  The new gapHorz value
    */
   public void setGapHorz (int newGapHorz)
   {
      if (newGapHorz > 0 && newGapHorz != gapHorz)
      {
         gapHorz = newGapHorz;
      }
   }


   /**
    * Read access method for vertical gap.
    *
    * @return   The gapVert value
    */
   public int getGapVert()
   {
      return gapVert;
   }


   /**
    * Write access method for vertical gap.
    *
    * @param newGapVert  The new gapVert value
    */
   public void setGapVert (int newGapVert)
   {
      if (newGapVert > 0 && newGapVert != gapVert)
      {
         gapVert = newGapVert;
      }
   }


   /**
    * Read access method for line gap.
    *
    * @return   The gapLine value
    */
   public int getGapLine()
   {
      return gapLine;
   }


   /**
    * Write access method for line gap.
    *
    * @param newGapLine  The new gapLine value
    */
   public void setGapLine (int newGapLine)
   {
      if (newGapLine > 0 && newGapLine != gapLine)
      {
         gapLine = newGapLine;
      }
   }


   /**
    * Calculates the preferred size of the component, which includes also an inset.
    *
    * @return   The preferredSize value
    */
   public Dimension getPreferredSize()
   {
      Dimension dim = new Dimension (0, 0);

      // Calculate the size of the boxes
      Dimension leftSize = leftCombo.getPreferredSize();
      Dimension rightSize = rightCombo.getPreferredSize();
//      Dimension buttonSize = addButton.getPreferredSize();

      // take combo boxes into accunt
      dim.width = leftSize.width + rightSize.width + 4 * getGapHorz();
      dim.height = Math.max (leftSize.height, rightSize.height) + 2 * getGapVert();

      // add the buttons width
//      dim.width = dim.width + buttonSize.width + 2 * getGapLine();
//      dim.height = Math.max (dim.height, 2 * buttonSize.height);

      // Add the inset rectangle
      Insets inset = getInsets();
      dim.width = dim.width + inset.left + inset.right;
      dim.height = dim.height + inset.top + inset.bottom;

      return dim;
   }


   /**
    * Calculates the minimal size of the component, which is the preferred size.
    *
    * @return   The minimumSize value
    */
   public Dimension getMinimumSize()
   {
      return getPreferredSize();
   }


   /**
    * Delegates the call to the left combo box
    *
    * @param item  The object added.
    */
   public void addItemToLeftComboBox (Object item)
   {
      PEListEntry entry = new PEListEntry (item);
      leftCombo.addItem (entry);
      leftHash.put (item, entry);
   }


   /**
    * Delegates the call to the right combo box.
    *
    * @param item  The object added.
    */
   public void addItemToRightComboBox (Object item)
   {
      PEListEntry entry = new PEListEntry (item);
      rightCombo.addItem (entry);
      rightHash.put (item, entry);
   }


   /**
    * Delegates the call to the left combo box
    *
    * @param item  The object added.
    */
   public void addItemToLeftComboBox (PEListEntry item)
   {
      leftCombo.addItem (item);
      leftHash.put (item.getItem(), item);
   }


   /**
    * Delegates the call to the right combo box.
    *
    * @param item  The object added.
    */
   public void addItemToRightComboBox (PEListEntry item)
   {
      rightCombo.addItem (item);
      rightHash.put (item.getItem(), item);
   }


   /**
    * Removes all items from the left combo box.
    */
   public void removeAllItemsLeft()
   {
      leftCombo.removeAllItems();
      leftHash = new HashMap();
   }


   /**
    * Removes all items from the right combo box.
    */
   public void removeAllItemsRight()
   {
      rightCombo.removeAllItems();
      rightHash = new HashMap();
   }


   /**
    * Returns the selected item in the left combo box.
    *
    * @return   The leftComboSelectedItem value
    */
   public PEListEntry getLeftComboSelectedItem()
   {
      return  ((PEListEntry) leftCombo.getSelectedItem());
   }


   /**
    * Sets the selected item in the left combo box.
    *
    * @param item  The new leftComboSelectedItem value
    */
   public void setLeftComboSelectedItem (PEListEntry item)
   {
      leftCombo.setSelectedItem (item);
   }


   /**
    * Sets the selected item in the left combo box.
    *
    * @param item  The new leftComboSelectedItem value
    */
   public void setLeftComboSelectedItem (Object item)
   {
      PEListEntry entry = (PEListEntry) leftHash.get (item);
      leftCombo.setSelectedItem ((PEListEntry) entry);
   }


   /**
    * Returns the selected index in the left combo box.
    *
    * @return   The leftComboSelectedIndex value
    */
   public int getLeftComboSelectedIndex()
   {
      return leftCombo.getSelectedIndex();
   }


   /**
    * Sets the selected index in the left combo box.
    *
    * @param index  The new leftComboSelectedIndex value
    */
   public void setLeftComboSelectedIndex (int index)
   {
      leftCombo.setSelectedIndex (index);
   }


   /**
    * Returns the selected item in the right combo box.
    *
    * @return   The rightComboSelectedItem value
    */
   public PEListEntry getRightComboSelectedItem()
   {
      return  ((PEListEntry) rightCombo.getSelectedItem());
   }


   /**
    * Sets the selected item in the right combo box.
    *
    * @param item  The new rightComboSelectedItem value
    */
   public void setRightComboSelectedItem (PEListEntry item)
   {
      rightCombo.setSelectedItem (item);
   }


   /**
    * Sets the selected item in the right combo box.
    *
    * @param item  The new rightComboSelectedItem value
    */
   public void setRightComboSelectedItem (Object item)
   {
      PEListEntry entry = (PEListEntry) rightHash.get (item);
      rightCombo.setSelectedItem ((PEListEntry) entry);
   }


   /**
    * Returns the selected index in the right combo box.
    *
    * @return   The rightComboSelectedIndex value
    */
   public int getRightComboSelectedIndex()
   {
      return rightCombo.getSelectedIndex();
   }


   /**
    * Sets the selected index in the right combo box.
    *
    * @param index  The new rightComboSelectedIndex value
    */
   public void setRightComboSelectedIndex (int index)
   {
      rightCombo.setSelectedIndex (index);
   }


   /**
    * The function setAddListener sets a listener for the add button
    *
    * @param listener  a valid reference of an action adapter
    */
   /*
    *  public void setAddListener (ActionListener listener)
    *  {
    *  addButton.setListener (listener);
    *  }
    */
   /**
    * Adds a ItemListener to the left and right combo box.
    *
    * @param listener  The object added.
    */
   public void addItemListener (ItemListener listener)
   {
      leftCombo.addItemListener (listener);
      rightCombo.addItemListener (listener);
   }


   /**
    * Removes a ItemListener from the left and right combo box.
    *
    * @param listener  No description provided
    */
   public void removeItemListener (ItemListener listener)
   {
      leftCombo.removeItemListener (listener);
      rightCombo.removeItemListener (listener);
   }


   /**
    * Repaints the whole component.
    *
    * @param g  No description provided
    */
   public void paint (Graphics g)
   {
      super.paint (g);

      Insets inset = getInsets();
      Dimension origSize = getSize();
      int height = getPreferredSize().height - inset.top - inset.bottom;

      // Note, no vertical adaption, horizontally expand the line.
      // Calculate the width only.
      g.setColor (Color.black);

      // draw left rectange two times, because no line features are available
      int leftWidth = leftCombo.getSize().width + 2 * getGapHorz();
      g.drawRect (inset.left, inset.top, leftWidth, height);
      g.drawRect (inset.left + 1, inset.top + 1, leftWidth - 2, height - 2);

      // draw right rectangle two times, because no line features are available
      int rightWidth = rightCombo.getSize().width + 2 * getGapHorz();
      g.drawRect (origSize.width - inset.right - rightWidth - 1, inset.top, rightWidth, height);
      g.drawRect (origSize.width - inset.right - rightWidth, inset.top + 1, rightWidth - 2, height - 2);

      // draw the connected line three times, because no line features are available
      g.drawLine (inset.left + leftWidth, inset.top + height / 2, origSize.width - inset.right - rightWidth - 1, inset.top + height / 2);
      g.drawLine (inset.left + leftWidth, inset.top + 1 + height / 2, origSize.width - inset.right - rightWidth - 1, inset.top + 1 + height / 2);
      g.drawLine (inset.left + leftWidth, inset.top - 1 + height / 2, origSize.width - inset.right - rightWidth - 1, inset.top - 1 + height / 2);

      // draw text "foreign key attributes" and "key attributes"
      g.drawString ("foreign key attributes", inset.left + leftWidth + 5, inset.top + height / 2 - 5);
      g.drawString ("referred attributes", origSize.width - inset.right - rightWidth - 5 - g.getFontMetrics().stringWidth ("referred attributes"), inset.top + height / 2 + 15);
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void doLayout()
   {
      Insets inset = getInsets();
      Dimension origSize = getSize();
      int height = getPreferredSize().height - inset.top - inset.bottom;

      // layout the left combo box
      Dimension dim = leftCombo.getPreferredSize();
      leftCombo.setSize (dim);

      int leftWidth = dim.width + 2 * getGapHorz();
      Point loc = new Point (inset.left +  (leftWidth - dim.width) / 2, inset.top +  (height - dim.height) / 2);
      leftCombo.setLocation (loc);

      // layout the right combo box
      dim = rightCombo.getPreferredSize();
      rightCombo.setSize (dim);

      int rightWidth = dim.width + 2 * getGapHorz();
      loc = new Point (origSize.width - rightWidth - inset.right - 1 +  (rightWidth - dim.width) / 2, inset.top +  (height - dim.height) / 2);
      rightCombo.setLocation (loc);

      // layout the add button
//      dim = addButton.getPreferredSize();
//      addButton.setSize (dim);

//      loc = new Point (inset.left + leftWidth +  (origSize.width - inset.left - inset.right - leftWidth - rightWidth - dim.width) / 2, height + inset.top - dim.height);
//      addButton.setLocation (loc);
   }


   /**
    * Access method for an one to n association.
    */
   protected void addComponents()
   {
   }


   /**
    * Sets the readOnly attribute of the PEDBSuggestedKeyAttrPanel object
    *
    * @param b  The new readOnly value
    */
   public void setReadOnly (boolean b)
   {
   }


   /**
    * Get the horzResizable attribute of the PEDBSuggestedKeyAttrPanel object
    *
    * @return   The horzResizable value
    */
   public boolean isHorzResizable()
   {
      return true;
   }


   /**
    * Get the vertResizable attribute of the PEDBSuggestedKeyAttrPanel object
    *
    * @return   The vertResizable value
    */
   public boolean isVertResizable()
   {
      return true;
   }


   /**
    * Sets the combosEnabled attribute of the PEDBSuggestedKeyAttrPanel object
    *
    * @param value  The new combosEnabled value
    */
   public void setCombosEnabled (boolean value)
   {
      rightCombo.setEnabled (value);
      leftCombo.setEnabled (value);
   }


   /**
    * Get the combosEnabled attribute of the PEDBSuggestedKeyAttrPanel object
    *
    * @return   The combosEnabled value
    */
   public boolean isCombosEnabled()
   {
      if (rightCombo.isEnabled() && leftCombo.isEnabled())
      {
         return true;
      }
      else
      {
         return false;
      }
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void fillLists()
   {
      Object own = keyEditor.getCurTable();
      if (own != null && own instanceof DBTable)
      {
         reloadLeftBox ((DBTable) own);
      }

      Object other = keyEditor.getRevTable();
      if (other != null && other instanceof DBTable)
      {
         reloadRightBox ((DBTable) other);
      }
   }


   /**
    * Reloads the values of the left combo box.
    *
    * @param table  No description provided
    */
   public void reloadLeftBox (DBTable table)
   {
      removeAllItemsLeft();

      Iterator it2 = table.iteratorOfAttributes();

      while (it2.hasNext())
      {
         DBTableAttribute attr = (DBTableAttribute) it2.next();
         addItemToLeftComboBox (attr);
      }
      setLeftComboSelectedIndex (-1);
      setRightComboSelectedIndex (-1);
   }


   /**
    * Reloads the values of the right combo box.
    *
    * @param table  No description provided
    */
   public void reloadRightBox (DBTable table)
   {
      removeAllItemsRight();

      Iterator it2 = table.iteratorOfAttributes();

      while (it2.hasNext())
      {
         DBTableAttribute attr = (DBTableAttribute) it2.next();
         addItemToRightComboBox (attr);
      }
      setLeftComboSelectedIndex (-1);
      setRightComboSelectedIndex (-1);
   }
}

/*
 * $Log: PEDBSuggestedForeignKey.java,v $
 * Revision 1.3  2003/10/07 07:21:52  ariseppi
 * misc. corrections
 *
 */
