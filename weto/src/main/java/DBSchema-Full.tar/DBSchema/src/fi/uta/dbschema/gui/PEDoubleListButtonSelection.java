/*
 * Created on 17.6.2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package fi.uta.dbschema.gui;

/**
 * @author as66033
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.util.Enumeration;

import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import de.uni_paderborn.fujaba.asg.ASGElement;
import de.uni_paderborn.fujaba.gui.BasicPropertyEditor;
import de.uni_paderborn.fujaba.gui.PEButton;
import de.uni_paderborn.fujaba.gui.PEColumn;
import de.uni_paderborn.fujaba.gui.PEHeaderComponent;
import de.uni_paderborn.fujaba.gui.PEResizable;
import de.uni_paderborn.fujaba.gui.PERow;

/**
 * Class to implements a selection component. A selection component contains two list called
 * added and removed and at least a add and a remove button to select and deselect from
 * the added to the removed list.
 *
 * @author    $Author: wag25 $
 * @created   $Date: 2003/10/30 16:13:38 $
 * @version   $Revision: 1.30 $
 */
public class PEDoubleListButtonSelection extends PEHeaderComponent implements PEResizable
{
	/**
		* No comment provided by developer, please add a comment to improve documentation.
		*/
	PEDBListIncr added;
	/**
		* No comment provided by developer, please add a comment to improve documentation.
		*/
	PEDBListIncr removed;

	/**
		* No comment provided by developer, please add a comment to improve documentation.
		*/
	PEColumn buttonCol = null;
	/**
		* No comment provided by developer, please add a comment to improve documentation.
		*/
	private PEButton mergeButton = null;
	/**
		* No comment provided by developer, please add a comment to improve documentation.
		*/
	private PEButton addButton = null;
	/**
		* No comment provided by developer, please add a comment to improve documentation.
		*/
	private PEButton removeButton = null;

	/**
		* Constructor for class PEDoubleListButtonSelection
		*
		* @param parent  No description provided
		*/
	public PEDoubleListButtonSelection(BasicPropertyEditor parent)
	{
		super();
		setParent(parent);
		added = new PEDBListIncr(this.parent, "Added");
		removed = new PEDBListIncr(this.parent, "Removed");
		added.addSelectionListener(new PEAddedSelectionListener(this));
		removed.addSelectionListener(new PERemovedSelectionListener(this));
		setLayout(getLayoutManager());
		addComponents();
	}

	/**
		* Sets the readOnly attribute of the PEDoubleListButtonSelection object
		*
		* @param b  The new readOnly value
		*/
	public void setReadOnly(boolean b)
	{
	}

	/**
		* Get the buttonColumn attribute of the PEDoubleListButtonSelection object
		*
		* @return   The buttonColumn value
		*/
	protected PEColumn getButtonColumn()
	{
		return buttonCol;
	}

	/**
		* Get the parentPE attribute of the PEDoubleListButtonSelection object
		*
		* @return   The parentPE value
		*/
	protected BasicPropertyEditor getParentPE()
	{
		return parent;
	}

	/**
		* Access method for an one to n association.
		*/
	protected void addComponents()
	{
		PEColumn column = new PEColumn(getParentPE());
		PERow row = new PERow(getParentPE());
		row.add(added);

		buttonCol = new PEColumn(getParentPE());
		buttonCol.setComponentName("buttons");

		// thsa : changed creation of buttons
		mergeButton = new PEButton(this, "combine");
		addButton = new PEButton(this, "add");
		removeButton = new PEButton(this, "remove");
		buttonCol.add(mergeButton);
		buttonCol.add(addButton);
		buttonCol.add(removeButton);

		row.add(buttonCol);

		row.add(removed);
		column.add(row);
		add(column);
	}

	/**
		* The function clearAdded () removes all entries of the added list.
		*/
	public void clearAdded()
	{
		added.removeAll();
	}

	/**
		* The function clearRemoved () removes all entries of the removed list
		*/
	public void clearRemoved()
	{
		removed.removeAll();
	}

	/**
		* The function getAddedSelectedIncr () returns a valid reference of an object of the AST.
		* The function returns the first entry, if more than one selected.
		*
		* @return   a valid reference to an object of the AST
		*/
	public ASGElement getAddedSelectedIncr()
	{
		return added.getSelectedIncrement();
	}

	/**
		* The function getRemovedIncr () returns a valid reference of an object of the AST.
		* The function returns the first entry, if more than one selected.
		*
		* @return   a valid reference to an object of the AST
		*/
	public ASGElement getRemovedSelectedIncr()
	{
		return removed.getSelectedIncrement();
	}

	/**
		* Sets the addedSelectedIncr attribute of the PEDoubleListButtonSelection object
		*
		* @param incr  The new addedSelectedIncr value
		*/
	public void setAddedSelectedIncr(ASGElement incr)
	{
		getAdded().selectIncrement(incr);
	}

	/**
		* Sets the destSelectedIncr attribute of the PEDoubleListButtonSelection object
		*
		* @param incr  The new destSelectedIncr value
		*/
	public void setRemovedSelectedIncr(ASGElement incr)
	{
		getRemoved().selectIncrement(incr);
	}

	/**
		* The function setMergeListener sets a listener for the merge button
		*
		* @param listener  a valid reference of an action adapter
		*/
	public void setMergeListener(ActionListener listener)
	{
		mergeButton.setListener(listener);
	}

	/**
		* The function setAddListener sets a listener for the add button
		*
		* @param listener  a valid reference of an action adapter
		*/
	public void setAddListener(ActionListener listener)
	{
		addButton.setListener(listener);
	}

	/**
		* The function setRemoveListener sets a listener for the remove button
		*
		* @param listener  a valid reference of an action adapter
		*/
	public void setRemoveListener(ActionListener listener)
	{
		removeButton.setListener(listener);
	}

	/**
		* The function setAddedMouseListener sets a listener for the added list
		*
		* @param listener  a valid reference of an action adapter
		*/
	public void setAddedMouseListener(MouseListener listener)
	{
		added.addMouseListener(listener);
	}

	/**
		* The function setRemovedMouseListener sets a listener for the removed list
		*
		* @param listener  a valid reference of an action adapter
		*/
	public void setRemovedMouseListener(MouseListener listener)
	{
		removed.addMouseListener(listener);
	}

	/**
		* The function addToAdded () adds a new entry represented by a valid reference to an object
		* of the AST to the added list.
		*
		* @param incr  a valid reference to an object of the AST
		*/
	public void addToAdded(ASGElement incr)
	{
		PEDBItem item = new PEDBItem(incr);
		added.add(item);
	}

	/**
		* The function addToAdded () adds a new entry represented by a valid reference to an object
		* of the AST and a string to the added list.
		*
		* @param incr  a valid reference to an object of the AST
		* @param s     a valid string represented the entry in the list
		*/
	public void addToAdded(ASGElement incr, String s)
	{
		PEDBItem item = new PEDBItem(incr, s);
		added.add(item);
	}

	/**
		* The function addToRemoved () adds a new entry represented by a valid reference to an object
		* of the AST to the removed list.
		*
		* @param incr  a valid reference to an object of the AST
		*/
	public void addToRemoved(ASGElement incr)
	{
		PEDBItem item = new PEDBItem(incr);
		removed.add(item);
	}

	/**
		* The function addToRemoved () adds a new entry represented by a valid reference to an object
		* of the AST and a string to the added list.
		*
		* @param incr  a valid reference to an object of the AST
		* @param s     a valid string represented the entry in the list
		*/

	public void addToRemoved(ASGElement incr, String s)
	{
		PEDBItem item = new PEDBItem(incr, s);
		removed.add(item);
	}

	/**
		* The function removeFromAdded () removes a existing entry from the added list. The entry
		* will be identified by the reference of the represented object.
		*
		* @param incr  a valid reference of an object
		*/
	public void removeFromAdded(ASGElement incr)
	{
		added.remove(incr);
	}

	/**
		* The function removeFromRemoved () removes a existing entry from the removed list.
		* The entry will be identified by the reference of the represented object.
		*
		* @param incr  a valid reference of an object
		*/
	public void removeFromRemoved(ASGElement incr)
	{
		removed.remove(incr);
	}

	/**
		* The function getAddedLsit returns a enumeration of the objects represented by the added
		* list.
		*
		* @return   a valid enumeration of the entries.
		*/
	public Enumeration getAddedList()
	{
		return added.elements();
	}

	/**
		* Get the added attribute of the PEDoubleListButtonSelection object
		*
		* @return   The added value
		*/
	public PEDBListIncr getAdded()
	{
		return added;
	}

	/**
		* Get the dest attribute of the PEDoubleListButtonSelection object
		*
		* @return   The dest value
		*/
	public PEDBListIncr getRemoved()
	{
		return removed;
	}

	/**
		* Override the function fillAddedList () to initialize the added list. This function
		* will be called if a increment will be set.
		*/
	protected void fillAddedList()
	{
	}

	/**
		* Override the function fillRemovedList () to initialize the removed list. This function
		* will be called if a increment will be set.
		*/
	protected void fillRemovedList()
	{
	}

	/**
		* No comment provided by developer, please add a comment to improve documentation.
		*/
	protected void addedSelectionChanged()
	{
	}

	/**
		* No comment provided by developer, please add a comment to improve documentation.
		*/
	protected void destSelectionChanged()
	{
	}

	/**
		* Get the addedIncrementByName attribute of the PEDoubleListButtonSelection object
		*
		* @param name  No description provided
		* @return      The addedIncrementByName value
		*/
	public ASGElement getAddedIncrementByName(String name)
	{
		return added.getIncrementByName(name);
	}

	/**
		* Get the destIncrementByName attribute of the PEDoubleListButtonSelection object
		*
		* @param name  No description provided
		* @return      The destIncrementByName value
		*/
	public ASGElement getRemovedIncrementByName(String name)
	{
		return removed.getIncrementByName(name);
	}

	/**
		* Get the horzResizable attribute of the PEDoubleListButtonSelection object
		*
		* @return   The horzResizable value
		*/
	public boolean isHorzResizable()
	{
		return true;
	}

	/**
		* Get the vertResizable attribute of the PEDoubleListButtonSelection object
		*
		* @return   The vertResizable value
		*/
	public boolean isVertResizable()
	{
		return true;
	}

	/**
		* No comment provided by developer, please add a comment to improve documentation.
		*
		* @param g  No description provided
		*/
	public void paint(Graphics g)
	{
		super.paint(g);
		g.drawString("test", 0, 0);
	}

	//////////////////////////////////////////////////////////////////////////
	// thsa : added some function to handle button events for
	// introduced buttons
	// --> to be overwritten by each subclass which
	// takes use of buttons add/remove/modify

	/**
		* No comment provided by developer, please add a comment to improve documentation.
		*
		* @param buttonIdentifier  No description provided
		* @param e                 No description provided
		* @return                  No description provided
		*/
	public boolean buttonActionPerformed(
		String buttonIdentifier,
		ActionEvent e)
	{
		return PEButton.remainedUnbound;
	}

	// added return functions for buttons
	/**
		* Get the mergeButton attribute of the PEDoubleListButtonSelection object
		*
		* @return   The addButton value
		*/
	protected PEButton getMergeButton()
	{
		return mergeButton;
	}
	/**
		* Get the addButton attribute of the PEDoubleListButtonSelection object
		*
		* @return   The addButton value
		*/
	protected PEButton getAddButton()
	{
		return addButton;
	}
	/**
		* Get the removeButton attribute of the PEDoubleListButtonSelection object
		*
		* @return   The addButton value
		*/
	protected PEButton getRemoveButton()
	{
		return removeButton;
	}

}

/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: wag25 $
 * @created   $Date: 2003/10/30 16:13:38 $
 * @version   $Revision: 1.30 $
 */
class PEAddedSelectionListener implements ListSelectionListener
{

	/**
		* No comment provided by developer, please add a comment to improve documentation.
		*/
	PEDoubleListButtonSelection adaptor;

	/**
		* Constructor for class PEAddedSelectionListener
		*
		* @param adapter  No description provided
		*/
	PEAddedSelectionListener(PEDoubleListButtonSelection adapter)
	{
		adaptor = adapter;
	}

	/**
		* No comment provided by developer, please add a comment to improve documentation.
		*
		* @param e  No description provided
		*/
	public void valueChanged(ListSelectionEvent e)
	{
		adaptor.addedSelectionChanged();
	}
}

/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: wag25 $
 * @created   $Date: 2003/10/30 16:13:38 $
 * @version   $Revision: 1.30 $
 */
class PERemovedSelectionListener implements ListSelectionListener
{

	/**
		* No comment provided by developer, please add a comment to improve documentation.
		*/
	PEDoubleListButtonSelection adaptor;

	/**
		* Constructor for class PERemovedSelectionListener
		*
		* @param adapter  No description provided
		*/
	PERemovedSelectionListener(PEDoubleListButtonSelection adapter)
	{
		adaptor = adapter;
	}

	/**
		* No comment provided by developer, please add a comment to improve documentation.
		*
		* @param e  No description provided
		*/
	public void valueChanged(ListSelectionEvent e)
	{
		adaptor.destSelectionChanged();
	}
}
