package fi.uta.dbschema.metamodel.parse;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import de.uni_paderborn.fujaba.asg.ASGElement;
import fi.uta.dbschema.metamodel.DBForeignKey;
import fi.uta.dbschema.metamodel.DBJunctionPair;
import fi.uta.dbschema.metamodel.DBSchema;
import fi.uta.dbschema.metamodel.DBTable;
import fi.uta.dbschema.metamodel.DBTableAttribute;
import fi.uta.dbschema.metamodel.DBTableAttributeJunction;
import fi.uta.dbschema.metamodel.DBUnique;

public class GuessKeys
{
	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param schema  No description provided
	 * @param minKey  No description provided
	 * @return        No description provided
	 */
	public static ArrayList guessKeys(DBSchema schema, boolean minKey)
	{
		ArrayList list = new ArrayList();

		ArrayList tableList = new ArrayList();

		Iterator iter = schema.iteratorOfItems();

		while (iter.hasNext())
		{
			Object obj = iter.next();
			if (obj instanceof DBTable)
			{
				tableList.add(obj);
			}
		}

		ArrayList sameAttrsOwn = new ArrayList();
		ArrayList sameAttrsOther = new ArrayList();
		HashMap attrs = new HashMap();

		for (int i = 0; i < tableList.size() - 1; i++)
		{
			attrs.clear();
			DBTable curTable = (DBTable) tableList.get(i);
			Iterator iter2 = curTable.iteratorOfAttributes();
			while (iter2.hasNext())
			{
				ASGElement curAttr = (ASGElement) iter2.next();
				attrs.put(curAttr.getName(), curAttr);
			}
			for (int i2 = i + 1; i2 < tableList.size(); i2++)
			{
				sameAttrsOwn.clear();
				sameAttrsOther.clear();
				DBTable otherTable = (DBTable) tableList.get(i2);

				Iterator iter3 = otherTable.iteratorOfAttributes();
				while (iter3.hasNext())
				{
					ASGElement otherAttr =
						(ASGElement) iter3.next();
					String otherAttrName = otherAttr.getName();

					Object ownAttr =
						attrs.get(otherAttrName);
					if (ownAttr != null)
					{
						sameAttrsOther.add(otherAttr);
						sameAttrsOwn.add(ownAttr);
					}
				}
				while (sameAttrsOther.size() > 0)
				{
					boolean unique1 = false;
					boolean primary1 = false;
					boolean unique2 = false;
					boolean primary2 = false;
					boolean swapped = false;
					Iterator iter4 = otherTable.iteratorOfAttributes();
					primary1 = true;
					// smallest key that can be formed from otherTable using the sameAttrs
					ArrayList bestKey1 = new ArrayList();
					// smallest key that can be formed from ownTable using the sameAttrs
					ArrayList bestKey2 = new ArrayList();
					ArrayList newKey = new ArrayList();
					while (iter4.hasNext() && primary1)
					{
						DBTableAttribute curAttr =
							(DBTableAttribute) iter4.next();
						if (curAttr.getPrimaryKeyValue())
						{
							if (!sameAttrsOther.contains(curAttr))
							{
								primary1 = false;
								bestKey1.clear();
							} else
							{
								bestKey1.add(curAttr);
							}
						}
					}
					Iterator iter5 = otherTable.iteratorOfUniques();
					while (iter5.hasNext())
					{
						boolean uniqueTemp = true;
						DBUnique uni = (DBUnique) iter5.next();
						if (uni.sizeOfAttributes() > sameAttrsOther.size())
						{
							uniqueTemp = false;
						}

						for (int i3 = 0;
							uniqueTemp && i3 < sameAttrsOther.size();
							i3++)
						{
							DBTableAttribute curAttr =
								(DBTableAttribute) sameAttrsOther.get(i3);
							if (!uni.hasInAttributes(curAttr))
							{
								uniqueTemp = false;
								newKey.clear();
							} else
							{
								newKey.add(curAttr);
							}
						}

						if (uniqueTemp == true)
						{
							unique1 = true;
							if(uni.sizeOfAttributes() < sameAttrsOther.size())
							{
								newKey.clear();
								Iterator uniIter = uni.iteratorOfAttributes();
								while(uniIter.hasNext())
								{
									newKey.add(uniIter.next());
								}
							}
						}

						if (minKey)
						{
							if (newKey.size() != 0
								&& (newKey.size() < bestKey1.size()
									|| bestKey1.size() == 0))
							{
								bestKey1 = newKey;
							}
						} else
						{
							if (newKey.size() > bestKey1.size())
							{
								bestKey1 = newKey;
							}
						}
						newKey = new ArrayList();
					}
					primary2 = true;
					Iterator iter6 = curTable.iteratorOfAttributes();
					while (iter6.hasNext() && primary2)
					{
						DBTableAttribute curAttr =
							(DBTableAttribute) iter6.next();
						if (curAttr.getPrimaryKeyValue())
						{
							if (!sameAttrsOwn.contains(curAttr))
							{
								primary2 = false;
								newKey.clear();
							} else
							{
								newKey.add(curAttr);
							}
						}
					}
					bestKey2 = newKey;
					newKey = new ArrayList();
					Iterator iter7 = curTable.iteratorOfUniques();
					while (iter7.hasNext())
					{
						boolean uniqueTemp = true;
						DBUnique uni = (DBUnique) iter7.next();

						if (uni.sizeOfAttributes() > sameAttrsOwn.size())
						{
							uniqueTemp = false;
						}

						for (int i3 = 0;
							uniqueTemp && i3 < sameAttrsOwn.size();
							i3++)
						{
							DBTableAttribute curAttr =
								(DBTableAttribute) sameAttrsOwn.get(i3);
							if (!uni.hasInAttributes(curAttr))
							{
								uniqueTemp = false;
								newKey.clear();
							} else
							{
								newKey.add(curAttr);
							}
						}
						if (uniqueTemp)
						{
							unique2 = true;
							if(uni.sizeOfAttributes() < sameAttrsOwn.size())
							{
								newKey.clear();
								Iterator uniIter = uni.iteratorOfAttributes();
								while(uniIter.hasNext())
								{
									newKey.add(uniIter.next());
								}
							}
						}

						if (minKey)
						{
							if (newKey.size() != 0
								&& (newKey.size() < bestKey2.size()
									|| bestKey2.size() == 0))
							{
								bestKey2 = newKey;
							}
						} else
						{
							if (newKey.size() > bestKey2.size())
							{
								bestKey2 = newKey;
							}
						}
						newKey = new ArrayList();
					}
					if (unique1 || primary1 || unique2 || primary2)
					{
						int[] counts =
							getSimilarityCount(
								curTable,
								otherTable,
								sameAttrsOther);

						ArrayList curKey = bestKey1;

						// The selection of bestKey defines which table has the foreign
						// key side and which has the unique/primary key side
						// The default is that the table with foreign key side is the table
						// that is being went through in outer for loop. The tables are
						// temporatory swapped (to swap the key sides) if
						//
						// - Either:
						//   * the outer loop table name has more in common with the attribute
						//     names than the other table AND
						//   * the attributes aren't a primary key for the other table and
						//     are for the outer loop table or a unique for the other table and
						//     unique or primary for the outer loop table
						// - or:
						//   * the attributes are a primary key for the outer loop table and
						//     not for the other table or a unique for the outer loop table and not
						//     unique or primary for the other table

						if ((counts[0] > counts[1]
						   && !(primary1 && !primary2) && !(unique1 && !(primary2 || unique2)))
							|| (!primary1 && primary2) || (!unique1 && (primary2 || unique2)))
						{
							DBTable tempTable = curTable;
							curTable = otherTable;
							otherTable = tempTable;
							ArrayList tempAttrs = sameAttrsOwn;
							sameAttrsOwn = sameAttrsOther;
							sameAttrsOther = tempAttrs;
							swapped = true;
							curKey = bestKey2;
						}

						DBForeignKey key = new DBForeignKey();
						key.setOriginalTable(curTable);
						key.setRevTable(otherTable);

						for (int i3 = 0; i3 < curKey.size(); i3++)
						{
							DBJunctionPair pair = new DBJunctionPair();
							key.addToJunctionPairs(pair);
							DBTableAttribute secondAttr =
								(DBTableAttribute) curKey.get(i3);
							DBTableAttributeJunction revJunc =
								new DBTableAttributeJunction(secondAttr);
							revJunc.setPair(pair);
							pair.setRevJunction(revJunc);
							DBTableAttribute firstAttr = null;
							if (secondAttr.getParent() == otherTable)
							{
								int index = sameAttrsOther.indexOf(secondAttr);
								sameAttrsOther.remove(index);
								firstAttr =
									(DBTableAttribute) sameAttrsOwn.remove(
										index);
							} else
							{
								int index = sameAttrsOwn.indexOf(secondAttr);
								sameAttrsOwn.remove(index);
								firstAttr =
									(DBTableAttribute) sameAttrsOther.remove(
										index);
							}
							DBTableAttributeJunction origJunc =
								new DBTableAttributeJunction(firstAttr);
							origJunc.setPair(pair);
							pair.setOriginalJunction(origJunc);
						}
						if (curKey.size() == 0)
						{
							sameAttrsOther.clear();
						} else
						{
							list.add(key);
						}
					} else
					{
						sameAttrsOther.clear();
						sameAttrsOwn.clear();
					}

					if (swapped)
					{
						swapped = false;
						DBTable tempTable = curTable;
						curTable = otherTable;
						otherTable = tempTable;
						ArrayList tempAttrs = sameAttrsOwn;
						sameAttrsOwn = sameAttrsOther;
						sameAttrsOther = tempAttrs;
					}
				}
			}
		}
		return list;
	}

	public static ArrayList guessKeys(
		DBSchema schema,
		boolean minKey,
		DBTable curTable)
	{
		ArrayList list = new ArrayList();

		ArrayList tableList = new ArrayList();

		Iterator iter = schema.iteratorOfItems();

		while (iter.hasNext())
		{
			Object obj = iter.next();
			if (obj instanceof DBTable && obj != curTable)
			{
				tableList.add(obj);
			}
		}

		ArrayList sameAttrsOwn = new ArrayList();
		ArrayList sameAttrsOther = new ArrayList();
		HashMap attrs = new HashMap();

		Iterator iter2 = curTable.iteratorOfAttributes();
		while (iter2.hasNext())
		{
			DBTableAttribute curAttr = (DBTableAttribute) iter2.next();
			attrs.put(curAttr.getName(), curAttr);
		}
		for (int i = 0; i < tableList.size(); i++)
		{
			sameAttrsOwn.clear();
			sameAttrsOther.clear();
			DBTable otherTable = (DBTable) tableList.get(i);

			Iterator iter3 = otherTable.iteratorOfAttributes();
			while (iter3.hasNext())
			{
				DBTableAttribute otherAttr = (DBTableAttribute) iter3.next();
				String otherAttrName = otherAttr.getName();

				DBTableAttribute ownAttr =
					(DBTableAttribute) attrs.get(otherAttrName);
				if (ownAttr != null)
				{
					sameAttrsOther.add(otherAttr);
					sameAttrsOwn.add(ownAttr);
				}
			}
			while (sameAttrsOther.size() > 0)
			{
				boolean unique1 = false;
				boolean primary1 = false;
				boolean unique2 = false;
				boolean primary2 = false;
				boolean swapped = false;
				Iterator iter4 = otherTable.iteratorOfAttributes();
				primary1 = true;
				// smallest key that can be formed from otherTable using the sameAttrs
				ArrayList bestKey1 = new ArrayList();
				// smallest key that can be formed from ownTable using the sameAttrs
				ArrayList bestKey2 = new ArrayList();
				ArrayList newKey = new ArrayList();
				while (iter4.hasNext() && primary1)
				{
					DBTableAttribute curAttr = (DBTableAttribute) iter4.next();
					if (curAttr.getPrimaryKeyValue())
					{
						if (!sameAttrsOther.contains(curAttr))
						{
							primary1 = false;
							bestKey1.clear();
						} else
						{
							bestKey1.add(curAttr);
						}
					}
				}
				Iterator iter5 = otherTable.iteratorOfUniques();
				while (iter5.hasNext())
				{
					boolean uniqueTemp = true;
					DBUnique uni = (DBUnique) iter5.next();
					if (uni.sizeOfAttributes() > sameAttrsOther.size())
					{
						uniqueTemp = false;
					}

					for (int i3 = 0;
						uniqueTemp && i3 < sameAttrsOther.size();
						i3++)
					{
						DBTableAttribute curAttr =
							(DBTableAttribute) sameAttrsOther.get(i3);
						if (!uni.hasInAttributes(curAttr))
						{
							uniqueTemp = false;
							newKey.clear();
						} else
						{
							newKey.add(curAttr);
						}
					}

					if (uniqueTemp == true)
					{
						unique1 = true;
						if(uni.sizeOfAttributes() < sameAttrsOther.size())
						{
							newKey.clear();
							Iterator uniIter = uni.iteratorOfAttributes();
							while(uniIter.hasNext())
							{
								newKey.add(uniIter.next());
							}
						}
					}

					if (minKey)
					{
						if (newKey.size() != 0
							&& (newKey.size() < bestKey1.size()
								|| bestKey1.size() == 0))
						{
							bestKey1 = newKey;
						}
					} else
					{
						if (newKey.size() > bestKey1.size())
						{
							bestKey1 = newKey;
						}
					}
					newKey = new ArrayList();
				}
				primary2 = true;
				Iterator iter6 = curTable.iteratorOfAttributes();
				while (iter6.hasNext() && primary2)
				{
					DBTableAttribute curAttr = (DBTableAttribute) iter6.next();
					if (curAttr.getPrimaryKeyValue())
					{
						if (!sameAttrsOwn.contains(curAttr))
						{
							primary2 = false;
							newKey.clear();
						} else
						{
							newKey.add(curAttr);
						}
					}
				}
				bestKey2 = newKey;
				newKey = new ArrayList();
				Iterator iter7 = curTable.iteratorOfUniques();
				while (iter7.hasNext())
				{
					boolean uniqueTemp = true;
					DBUnique uni = (DBUnique) iter7.next();

					if (uni.sizeOfAttributes() > sameAttrsOwn.size())
					{
						uniqueTemp = false;
					}

					for (int i3 = 0;
						uniqueTemp && i3 < sameAttrsOwn.size();
						i3++)
					{
						DBTableAttribute curAttr =
							(DBTableAttribute) sameAttrsOwn.get(i3);
						if (!uni.hasInAttributes(curAttr))
						{
							uniqueTemp = false;
							newKey.clear();
						} else
						{
							newKey.add(curAttr);
						}
					}
					if (uniqueTemp)
					{
						unique2 = true;
						if(uni.sizeOfAttributes() < sameAttrsOwn.size())
						{
							newKey.clear();
							Iterator uniIter = uni.iteratorOfAttributes();
							while(uniIter.hasNext())
							{
								newKey.add(uniIter.next());
							}
						}
					}

					if (minKey)
					{
						if (newKey.size() != 0
							&& (newKey.size() < bestKey2.size()
								|| bestKey2.size() == 0))
						{
							bestKey2 = newKey;
						}
					} else
					{
						if (newKey.size() > bestKey2.size())
						{
							bestKey2 = newKey;
						}
					}
					newKey = new ArrayList();
				}
				if (unique1 || primary1 || unique2 || primary2)
				{
					int[] counts =
						getSimilarityCount(
							curTable,
							otherTable,
							sameAttrsOther);

					ArrayList curKey = bestKey1;

					// The selection of bestKey defines which table has the foreign
					// key side and which has the unique/primary key side
					// The default is that the table with foreign key side is the table
					// that is being went through in outer for loop. The tables are
					// temporatory swapped (to swap the key sides) if
					//
					// - Either:
					//   * the outer loop table name has more in common with the attribute
					//     names than the other table AND
					//   * the attributes aren't a primary key for the other table and
					//     are for the outer loop table or a unique for the other table and
					//     unique or primary for the outer loop table
					// - or:
					//   * the attributes are a primary key for the outer loop table and
					//     not for the other table or a unique for the outer loop table and not
					//     unique or primary for the other table

					if ((counts[0] > counts[1]
					   && !(primary1 && !primary2) && !(unique1 && !(primary2 || unique2)))
						|| (!primary1 && primary2) || (!unique1 && (primary2 || unique2)))
					{
						DBTable tempTable = curTable;
						curTable = otherTable;
						otherTable = tempTable;
						ArrayList tempAttrs = sameAttrsOwn;
						sameAttrsOwn = sameAttrsOther;
						sameAttrsOther = tempAttrs;
						swapped = true;
						curKey = bestKey2;
					}
					DBForeignKey key = new DBForeignKey();
					key.setOriginalTable(curTable);
					key.setRevTable(otherTable);
					for (int i3 = 0; i3 < curKey.size(); i3++)
					{
						DBJunctionPair pair = new DBJunctionPair();
						key.addToJunctionPairs(pair);
						DBTableAttribute secondAttr =
							(DBTableAttribute) curKey.get(i3);
						DBTableAttributeJunction revJunc =
							new DBTableAttributeJunction(secondAttr);
						revJunc.setPair(pair);
						pair.setRevJunction(revJunc);
						DBTableAttribute firstAttr = null;
						if (secondAttr.getParent() == otherTable)
						{
							int index = sameAttrsOther.indexOf(secondAttr);
							sameAttrsOther.remove(index);
							firstAttr =
								(DBTableAttribute) sameAttrsOwn.remove(index);
						} else
						{
							int index = sameAttrsOwn.indexOf(secondAttr);
							sameAttrsOwn.remove(index);
							firstAttr =
								(DBTableAttribute) sameAttrsOther.remove(index);
						}
						DBTableAttributeJunction origJunc =
							new DBTableAttributeJunction(firstAttr);
						origJunc.setPair(pair);
						pair.setOriginalJunction(origJunc);
					}
					if (curKey.size() == 0)
					{
						sameAttrsOther.clear();
					} else
					{
						list.add(key);
					}
				} else
				{
					sameAttrsOther.clear();
					sameAttrsOwn.clear();
				}
				if (swapped)
				{
					swapped = false;
					DBTable tempTable = curTable;
					curTable = otherTable;
					otherTable = tempTable;
					ArrayList tempAttrs = sameAttrsOwn;
					sameAttrsOwn = sameAttrsOther;
					sameAttrsOther = tempAttrs;
				}
			}
		}
		return list;
	}

	/**
	 * Checks which of the tables has more in common with the attribute names. The comparison
	 * is made word by word and words are separated by '_' char.
	 *
	 * @param curTable        No description provided
	 * @param otherTable      No description provided
	 * @param sameAttrsOther  No description provided
	 * @return                The similarityCount value
	 */
	private static int[] getSimilarityCount(
		DBTable curTable,
		DBTable otherTable,
		ArrayList sameAttrsOther)
	{
		int[] counts = new int[2];
		counts[0] = 0;
		counts[1] = 0;
		String ownName = curTable.getName();
		String otherName = otherTable.getName();
		String[] ownNameArray = ownName.split("_");
		String[] otherNameArray = otherName.split("_");

		// check which table name has more in common with the attribute names

		for (int i3 = 0; i3 < sameAttrsOther.size(); i3++)
		{
			DBTableAttribute attr = (DBTableAttribute) sameAttrsOther.get(i3);
			String attrName = attr.getName();
			String[] attrNameArray = attrName.split("_");
			for (int i4 = 0; i4 < attrNameArray.length; i4++)
			{
				for (int i5 = 0; i5 < ownNameArray.length; i5++)
				{
					if (ownNameArray[i5].equals(attrNameArray[i4]) || (ownNameArray[i5] + "s").equals(attrNameArray[i4]))
					{
						counts[0]++;
					}
				}
				for (int i5 = 0; i5 < otherNameArray.length; i5++)
				{
					if (otherNameArray[i5].equals(attrNameArray[i4]) || (otherNameArray[i5] + "s").equals(attrNameArray[i4]))
					{
						counts[1]++;
					}
				}
			}
		}
		return counts;
	}
}