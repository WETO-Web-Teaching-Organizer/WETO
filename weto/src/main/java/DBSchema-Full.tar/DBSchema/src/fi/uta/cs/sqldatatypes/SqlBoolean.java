/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.cs.sqldatatypes;

import fi.uta.cs.sqldatamodel.InvalidValueException;
import fi.uta.cs.sqldatamodel.NullNotAllowedException;
import fi.uta.cs.sqldatamodel.ObjectNotValidException;

/**
 * Concrete implementation of boolean SQL data type.
 * 
 * Value data type is java.lang.Boolean.
 * JDBC data type is java.lang.Integer.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:49 $
 * @version   $Revision: $
 */
public class SqlBoolean extends SqlDataType {
	/**
	 * Value attribute (named as data for JavaBeans compatibility).
	 */
	private Integer data;
	
	/**
	 * Constructor for class SqlBoolean
	 */
	public SqlBoolean()
	{
		super();
		data = null;
	}
	
	/**
	 * Initializing constructor for Fujaba.
	 * 
	 * @param value Initial value as its string representation.
	 *  If an invalid value is given, the result is undefined
	 *  (a runtime exception may be thrown).
	 */
	public SqlBoolean( String value )
	{
		this();
		try {
			fromString( value );
		} catch( InvalidValueException e ) {
			// Ignored
		}
	}
	
//	======================================================================
//	Bean property methods
//	======================================================================
	
	/**
	 * Gets the value.
	 * 
	 * @return The current value. Passed by copy.
	 */
	public Boolean getValue() {
		if( data == null ) return null;
		if( data.intValue() == 0 ) return new Boolean(false);
		return new Boolean(true);
	}
	
	/**
	 * Sets the value.
	 * 
	 * @param value New value, passed by copy.
	 * 
	 * @throws NullNotAllowedException if a null-value is given, but
	 * 	not allowed.
	 */
	public void setValue( Boolean value ) throws NullNotAllowedException {
		if( value==null && !isNullAllowed() ) 
			throw new NullNotAllowedException();
		setValueUnchecked( value );
	}
	
	/**
	 * Sets the value without performing any checks.
	 * 
	 * @param value New value, passed by copy.
	 */
	public void setValueUnchecked( Boolean value ) {
		if( value == null ) {
			this.data = null;
		} else {
			if( value.booleanValue() ) this.data = new Integer(1);
				else this.data = new Integer(0);
		}
	}
	
//	======================================================================
//	JDBC property methods
//	======================================================================
	
	/**
	 * Gets the value as the type used with JDBC.
	 * 
	 * @return The current value.
	 */
	public Integer jdbcGetValue() throws ObjectNotValidException {
		return data;
	}
	
	/**
	 * Sets the value as the type used with JDBC.
	 * 
	 * @param value New value. 
	 * 
	 * @throws NullNotAllowedException if a null-value is given, but
	 * 	not allowed.
	 */
	public void jdbcSetValue( Integer value ) throws NullNotAllowedException {
		if( value == null ) {
			if( isNullAllowed() ) {
				data = null;
			} else {
				throw new NullNotAllowedException();
			}
		} else {
			data = new Integer(value.intValue());
		}
	}
	
//	======================================================================
//	SqlDataType methods
//	======================================================================

	public String toString() {
		if( data == null ) return "";
		return data.toString();
	}
	
	public void fromString( String str ) throws NullNotAllowedException {
		Boolean newValue = null;
		if( str!=null ) {
			if( str.length()>0 ) {
				newValue = Boolean.valueOf( str );
			}
		}
		setValue( newValue );
	}

	public boolean isValid() {
		if( (data==null) && (!isNullAllowed()) ) return false;
		return true;
	}

	public boolean equals(Object obj) {
		if( !(obj instanceof SqlBoolean) ) return false;
		SqlBoolean boolObj = (SqlBoolean)obj;
		
		if( data==null || boolObj.data==null ) {
			if( data==null && boolObj.data==null ) return true;
			return false;
		}
		
		return getValue().equals( boolObj.getValue() );
	}

	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	
	public String getLongestString() {
		return "FALSE";
	}
}

/*
 * $Log: SqlBoolean.java,v $
 * Revision 1.2  2003/10/07 07:21:49  ariseppi
 * misc. corrections
 *
 */

// End of file.
