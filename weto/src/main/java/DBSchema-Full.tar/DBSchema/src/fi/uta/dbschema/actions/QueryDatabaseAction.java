/*
 * Created on 22.6.2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package fi.uta.dbschema.actions;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

import de.uni_paderborn.fujaba.app.FrameMain;
import de.uni_paderborn.fujaba.uml.UMLProject;
import fi.uta.dbschema.gui.SelectTablesDialog;
import fi.uta.dbschema.metamodel.DBSchema;

/**
 * @author as66033
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class QueryDatabaseAction extends AbstractAction
{

	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e)
	{
		Object source = UMLProject.get().getCurrentDiagram();

		DBSchema dbSchema = null;
		if (source instanceof DBSchema)
		{
		   dbSchema = (DBSchema) source;
		}

		SelectTablesDialog selectDialog = new SelectTablesDialog (FrameMain.get().getFrame());
		selectDialog.setIncrement (dbSchema);
		selectDialog.showCentered();
	}

}
