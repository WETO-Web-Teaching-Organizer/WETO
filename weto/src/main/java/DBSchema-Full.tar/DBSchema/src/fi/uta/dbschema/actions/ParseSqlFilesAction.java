/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.actions;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.io.File;

import javax.swing.AbstractAction;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.filechooser.FileFilter;

import de.uni_paderborn.fujaba.app.FrameMain;
import fi.uta.dbschema.metamodel.parse.FileParser;


/**
 * @author
 * @created   $Date: 2003/10/07 07:21:50 $
 * @version   $Revision: 1.2 $
 */
public class ParseSqlFilesAction extends AbstractAction
{

   /*
    *  (non-Javadoc)
    *  @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
    */
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private static JFileChooser chooser = null;


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param event  No description provided
    */
   public void actionPerformed (ActionEvent event)
   {

      if (chooser == null)
      {
         chooser = new JFileChooser();
         chooser.setApproveButtonText ("Choose");
         chooser.setMultiSelectionEnabled (true);
         chooser.setFileFilter (new SQLFileFilter());
      }
      else
      {
         chooser.setSelectedFile (null);
      }
      int returnVal = chooser.showOpenDialog (FrameMain.get());

	File[] files;

      if (returnVal == JFileChooser.APPROVE_OPTION)
      {
         files = chooser.getSelectedFiles();
      }
      else
      {
         return;
      }
      StringBuffer sb = new StringBuffer();
      for (int i = 0; i < files.length; i++)
      {
         sb.append (FileParser.parseFile (files[i]));
      }
      String errors = sb.toString();
      if (!errors.equals (""))
      {
         JTextArea area = new JTextArea (errors);
         area.setEditable (false);
         JScrollPane pane = new JScrollPane (area);
         JDialog dialog = new JDialog (FrameMain.get(), "Parse errors", false);
         Dimension dim = new Dimension (400, 200);
         pane.setPreferredSize (dim);
         dialog.getContentPane().setLayout (new BorderLayout());
         dialog.getContentPane().add (pane, BorderLayout.CENTER);
         dialog.pack();
         dialog.setVisible (true);
      }
   }


   /**
    * No comment provided by developer, please add a comment to improve documentation.
    *
    * @author    $Author: ariseppi $
    * @created   $Date: 2003/10/07 07:21:50 $
    * @version   $Revision: 1.2 $
    */
   class SQLFileFilter extends FileFilter
   {
      /**
       * No comment provided by developer, please add a comment to ensure improve documentation.
       *
       * @param file  No description provided
       * @return      No description provided
       */
      public boolean accept (File file)
      {
         String name = file.getName();
         if (file.isDirectory() || name.endsWith (".sql") || name.endsWith (".txt"))
         {
            return true;
         }
         return false;
      }


      /**
       * Get the description attribute of the SQLFileFilter object
       *
       * @return   The description value
       */
      public String getDescription()
      {
         return "Likely SQL files (.sql, .txt)";
      }
   }
}

/*
 * $Log: ParseSqlFilesAction.java,v $
 * Revision 1.2  2003/10/07 07:21:50  ariseppi
 * misc. corrections
 *
 */
