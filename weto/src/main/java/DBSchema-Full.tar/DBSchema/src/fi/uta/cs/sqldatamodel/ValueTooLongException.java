/*
 * Created on Oct 4, 2004
 */
package fi.uta.cs.sqldatamodel;

/**
 * An exception indicating that the given value is too long.
 */
public class ValueTooLongException extends InvalidValueException {

	private static final long serialVersionUID = 8097559296308970743L;

	public ValueTooLongException() {
		super();
	}

	public ValueTooLongException(String message) {
		super(message);
	}
}

// End of file.
