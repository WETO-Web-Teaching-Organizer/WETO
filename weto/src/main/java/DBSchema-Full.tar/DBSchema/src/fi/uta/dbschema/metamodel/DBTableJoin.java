/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.metamodel;



/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:53 $
 * @version   $Revision: 1.2 $
 */
public class DBTableJoin
    extends DBSchemaItem
{
   /**
    * <pre>
    *           0..1       firstJunction       0..n
    * DBTableJunction ------------------------------------- DBTableJoin
    *         firstJunction               secondJunction
    * </pre>
    */
   private DBTableJunction firstJunction;

   /**
    * <pre>
    *          0..1     secondJunction      0..n
    * DBTableJunction ------------------------------- DBTableJoin
    *          secondJunction        firstJunction
    * </pre>
    */
   private DBTableJunction secondJunction;


   /**
    * Constructor for class DBTableJoin
    */
   public DBTableJoin()
   {
      super();
   }


   /**
    * Constructor for class DBTableJoin
    *
    * @param junction  No description provided
    */
   public DBTableJoin (DBTableJunction junction)
   {
      super();
      setFirstJunction (junction);
   }


   /**
    * Sets the firstJunction attribute of the DBTableJoin object
    *
    * @param value  The new firstJunction value
    * @return       No description provided
    */
   public boolean setFirstJunction (DBTableJunction value)
   {
      boolean changed = false;
      if (this.firstJunction != value)
      {
         this.firstJunction = value;
         changed = true;
         if (value != null)
         {
            value.setJoin (this);
         }
      }
      return changed;
   }


   /**
    * Sets the secondJunction attribute of the DBTableJoin object
    *
    * @param value  The new secondJunction value
    * @return       No description provided
    */
   public boolean setSecondJunction (DBTableJunction value)
   {
      boolean changed = false;
      if (this.secondJunction != value)
      {
         this.secondJunction = value;
         changed = true;
         if (value != null)
         {
            value.setJoin (this);
         }
      }
      return changed;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void removeYou()
   {
      firstJunction.removeYou();
      secondJunction.removeYou();
      setParent (null);
      super.removeYou();
   }


   /**
    * Get the firstJunction attribute of the DBTableJoin object
    *
    * @return   The firstJunction value
    */
   public DBTableJunction getFirstJunction()
   {
      return this.firstJunction;
   }


   /**
    * Get the secondJunction attribute of the DBTableJoin object
    *
    * @return   The secondJunction value
    */
   public DBTableJunction getSecondJunction()
   {
      return this.secondJunction;
   }


   /**
    * Get the text attribute of the DBTableJoin object
    *
    * @return   The parent value
    */
   public String getText()
   {
      return getFirstJunction().getText() + " - " + getSecondJunction().getText();
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @return   No description provided
    */
   public String toString()
   {
      StringBuffer result = new StringBuffer();

      result.append ("DBTableJoin[");
      result.append ("firstJunction=");
      result.append (getFirstJunction());
      result.append (",secondJunction=");
      result.append (getSecondJunction());
      result.append ("]");

      return result.toString();
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private DBSchemaItem parent;


   /**
    * Sets the parent attribute of the DBTableJoin object
    *
    * @param obj  The new parent value
    * @return     No description provided
    */
   public boolean setParent (DBSchemaItem obj)
   {
      boolean changed = false;

      if (this.parent != obj)
      {
         DBSchemaItem oldValue = this.parent;
         if (this.parent != null)
         {
            this.parent = null;
         }
         this.parent = obj;
         changed = true;

         // side effects

         firePropertyChange ("parent", oldValue, obj);
      }

      return changed;
   }


   /**
    * Get the parent attribute of the DBTableJoin object
    *
    * @return   The parent value
    */
   public DBSchemaItem getParent()
   {
      return parent;
   }
}

/*
 * $Log: DBTableJoin.java,v $
 * Revision 1.2  2003/10/07 07:21:53  ariseppi
 * misc. corrections
 *
 */
