/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.cs.dbswtool;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StreamTokenizer;
import java.util.Vector;


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:48 $
 * @version   $Revision: 1.2 $
 */
public class QueryVector implements RelAndQueryConstants, QueryStore
{
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private Vector queryVector;


   /**
    * Constructor for class QueryVector
    */
   public QueryVector()
   {
      queryVector = new Vector();
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   public void output()
   {
      System.out.println ("QueryVector with size " + queryVector.size());
      for (int i = 0; i < queryVector.size(); i++)
      {
         Query v = (Query) queryVector.elementAt (i);
         v.output();
      }
   }


   /**
    * Get the query attribute of the QueryVector object
    *
    * @param name  No description provided
    * @return      The query value
    */
   public Query getQuery (String name)
   {
      Query vFound = null;
      int i = 0;
      while ( (i < queryVector.size()) &&  (vFound == null))
      {
         Query v = (Query) queryVector.elementAt (i);
         i++;
         if (name.equals (v.getName()))
         {
            vFound = v;
         }
      }
      return vFound;
   }


   /**
    * Access method for an one to n association.
    *
    * @param newQuery  The object added.
    */
   public void addQuery (Query newQuery)
   {
      //	output();
      if (getQuery (newQuery.getName()) == null)
      {
         queryVector.add (newQuery);
      }
   }

   //   public int writeSQLFiles(String projectdir) {
   //	File sqlDir = new File(projectdir + "/" + sqlString);
   //	sqlDir.mkdir();
   //	for (int i=0; i<queryVector.size(); i++) {
   //	    Query v = (Query) queryVector.elementAt(i);
   //	    StringBuffer sb = new StringBuffer();
   //    sb.append(sqlDropQueryString + " " + v.getName() +
   //	      semicolon + endLine);
   //    sb.append(sqlCreateQueryString + " " + v.getName() +
   //	      " as" + endLine);
   //    sb.append("select * from " + sp);
   //    NameVector relationNameVector = v.getRelationNameVector();
   //    sb.append(relationNameVector.commaList());
   //    sb.append(endLine + "where " + v.getWhereClause());
   //    sb.append(semicolon + endLine);


   //    try {   // Write the contents of output to a file using a FileWriter
   //	File outFile = new File(projectdir + slashChar + sqlString + slashChar +
   //				v.getName()+ period + sqlString);
   //	FileWriter writer = new FileWriter(outFile);
   //	writer.write(sb.toString());
   //	writer.close();
   //    }
   //    catch (Exception e) {
   //	System.out.println(e);
   //    }
   //	}
   //	return 0;
   // }
   
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param projectdir  No description provided
    * @return            No description provided
    */
   public int writeHtmlFile (String projectdir)
   {
      //	String filename = attributeHtmlFileName;
      StringBuffer sb = new StringBuffer();
      sb.append (htmlFileHeader1);
      sb.append (htmlFileHeader2);
      sb.append (htmlFileHeader3);
      sb.append (htmlFileHeader4);

      // First write an index table of all query names
      sb.append (beginHtmlTable);
      sb.append (beginHtmlTableRow + endLine);
      sb.append (beginHtmlTableColumn + " " + queryNameHtmlString + " " + endHtmlTableColumn + endLine);
      sb.append (endHtmlTableRow + endLine);
      for (int i = 0; i < queryVector.size(); i++)
      {
         Query v = (Query) queryVector.elementAt (i);
         sb.append (beginHtmlTableRow + endLine);
         sb.append (beginHtmlTableColumn + " " + beginHtmlHref + v.getName() + endHtmlHref +
            " " + v.getName().toUpperCase() + " " + endHtmlA + endHtmlTableColumn + endLine);
         sb.append (endHtmlTableRow + endLine);
      }
      sb.append (endHtmlTable);
      sb.append (htmlParagraph);

      // Then each query
      for (int i = 0; i < queryVector.size(); i++)
      { // First the header
         sb.append (htmlParagraph);
         sb.append (htmlParagraph + endLine);
         Query v = (Query) queryVector.elementAt (i);
         sb.append (beginHtmlTarget + v.getName() + endHtmlTarget + " " +
            htmlBeginBold + v.getName().toUpperCase() + htmlEndBold + htmlLineBreak + endLine);
         sb.append ("select * from ");
         sb.append (v.getRelationNameVector().commaList());
         sb.append (htmlLineBreak + endLine);
         sb.append (" where " + v.getWhereClause() + htmlLineBreak + endLine);
      }

      sb.append (endHtmlFile);

      try
      { // Write the contents of output to a file using a FileWriter
         File outFile = new File (projectdir + slashChar + queryHtmlFileName);
         FileWriter writer = new FileWriter (outFile);
         writer.write (sb.toString());
         writer.close();
      }
      catch (Exception e)
      {
         System.out.println (e);
      }
      return 0;
   }



   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param projectdir  No description provided
    * @param rv          No description provided
    * @return            No description provided
    */
   public int writeJavaFiles (String projectdir, RelationVector rv)
   {
      File javaDir = new File (projectdir + slashChar + javaString);
      javaDir.mkdir();
      writeDbClassFiles (projectdir, rv);
      // writeBeanClassFiles(projectdir);
      writeMainClassFiles (projectdir);
      return 0;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @param projectdir  No description provided
    * @param filename    No description provided
    * @param rv          No description provided
    * @return            No description provided
    */
   public int readQueryFile (String projectdir, String filename, RelationVector rv)
   {

      String queryName = "";
      String packageName = "";
      String attributeName = "";
      String attributeRole = "";
      Boolean attributePrimaryKeyPart = new Boolean (false);
      Boolean attributeNotNull = new Boolean (false);

      // as.output();

      try
      {

         // Open the file, do the technicalities to get StreamTokenizer
         FileInputStream fis = new FileInputStream (projectdir + slashChar + filename);

         InputStreamReader isr = new InputStreamReader (fis);
         BufferedReader br = new BufferedReader (isr);
         StreamTokenizer st = new StreamTokenizer (br);
         st.slashSlashComments (false);
         st.wordChars ('_', '_');
         // st.wordChars('[','[');
         // st.wordChars(']',']');
         st.ordinaryChars ('0', '9');
         // st.wordChars('.','.');
         st.wordChars ('0', '9');
         st.quoteChar ('"');
         st.ordinaryChar (')');
         st.whitespaceChars ('(', '(');
         st.whitespaceChars (',', ',');

         int nextType = expectingQueryString;

         while (st.nextToken() != StreamTokenizer.TT_EOF)
         {
            if (st.ttype != StreamTokenizer.TT_WORD)
            {
               System.out.println ("Expecting a string, got " + st.toString());
            }
            else
            {
               if (!st.sval.equals (queryString))
               {
                  System.out.println ("Expexting '" + queryString +
                     "', got: " + st.toString());
               }
               else
               { // A query coming up, let's read it:
                  nextType = expectingQueryName;
                  Query v = new Query();
                  while ( (st.nextToken() != StreamTokenizer.TT_EOF) &&  (nextType != expectingQueryString))
                  {
                     if ( (st.ttype != StreamTokenizer.TT_WORD) &&  (nextType != expectingWhereClause))
                     {
                        System.out.println ("Expecting a string, got " + st.toString());
                     }
                     else
                     {
                        switch (nextType)
                        {
                           case expectingQueryName:
                              // System.out.println("Got query name " + st.sval);
                              queryName = st.sval.toLowerCase();
                              v.setName (queryName);
                              nextType = expectingPackageString;
                              break;
                           case expectingPackageString:
                              if (st.sval.equals (packageString))
                              {
                                 nextType = expectingPackageName;
                              }
                              else
                              {
                                 System.out.println ("I was expecting " +
                                    packageString + ", but I got " +
                                    st.toString());
                              }
                              break;
                           case expectingPackageName:
                              packageName = st.sval.toLowerCase();
                              v.setPackage (packageName);
                              nextType = expectingRelationsString;
                              break;
                           case expectingRelationsString:
                              if (st.sval.equals (relationsString))
                              {
                                 nextType = expectingRelations;
                              }
                              else
                              {
                                 System.out.println ("I was expecting " +
                                    relationsString + ", but I got " +
                                    st.toString());
                              }
                              break;
                           case expectingRelations:
                              NameVector relationNameVector = new NameVector();
                              try
                              {
                                 do
                                 {
                                    //System.out.println("Relation list for query " + v.getName() +
                                    //	       " and I just read " + st.toString());
                                    String name = st.sval.toLowerCase();
                                    if (st.ttype != closeParenthesisChar)
                                    {
                                       if (rv.getRelation (name) != null)
                                       {
                                          relationNameVector.addName (name);
                                       }
                                       else
                                       {
                                          System.out.println ("Relation " +
                                             st.sval + " not found for query " +
                                             v.getName() + ", got:" + st.toString());
                                       }
                                    }
                                    st.nextToken();
                                 } while (st.ttype != closeParenthesisChar);
                                 v.setRelationNameVector (relationNameVector);
                              }
                              catch (Exception e)
                              {
                                 System.out.println ("Error reading primary key for query " +
                                    v.getName());
                              }
                              nextType = expectingWhereString;
                              break;
                           case expectingWhereString:
                              if (st.sval.equals (whereString))
                              {
                                 nextType = expectingWhereClause;
                              }
                              else
                              {
                                 System.out.println ("I was expecting " +
                                    whereString + ", but I got " +
                                    st.toString());
                              }
                              break;
                           case expectingWhereClause:
                              String whereClause = st.sval.toLowerCase();
                              v.setWhereClause (whereClause);
                              nextType = expectingQueryString;
                              break;
                           default:
                              break;
                        } // end switch
                     } // end of "getting a string" else
                  } // end while - done reading a query
                  addQuery (v);
               } // end of "getting a query" else
            }
         }
         return queryFileReadOk;
      }
      catch (IOException e)
      {
         System.out.println (e);
         return queryFileReadFailed;
      }
   }
   
// ------------------------------------------------------------
// Class file output
// ------------------------------------------------------------

    /**
     * No comment provided by developer, please add a comment to ensure improve documentation.
     *
     * @param projectdir  No description provided
     * @param rv          No description provided
     * @return            No description provided
     */
    private int writeDbClassFiles (String projectdir, RelationVector rv) {
    	for (int i = 0; i < queryVector.size(); i++) {
    		StringBuffer sb = new StringBuffer();
    		Query v = (Query) queryVector.elementAt (i);
    		String className = javaDbPrefix 
				+ v.getName().substring (0, 1).toUpperCase()
				+ v.getName().substring (1, v.getName().length());
    		JavaClassWriter jcw = new JavaClassWriter( sb, className );
    		
    		// Package 
    		jcw.WritePackage( v.getPackage() );
    		
    		// Imports
    		jcw.WriteEmptyLine();
    		jcw.WriteDbImportsWithoutTypes();
    		NameVector importNames = new NameVector();
    		NameVector rn = v.getRelationNameVector();
    		importNames.addName( v.getPackage() );
    		for (int j = 0; j < rn.size(); j++) {
    			String relName = (String) rn.getVector().elementAt (j);
    			Relation rnRel = rv.getRelation (relName);
    			importNames.addName (rnRel.getPackage());
    		}
    		for (int impInd = 1; impInd < importNames.size(); impInd++) {
    			String packageName = (String) importNames.getVector().elementAt (impInd);
    			jcw.WriteImport( packageName + ".*" );
    		}
    		
    		// Class
    		jcw.WriteEmptyLine();
    		jcw.WriteClassJavaDocBegin();
    		jcw.WriteClassJavaDocLine("Generated database access class for query " + v.getName() + ".");
    		jcw.WriteClassJavaDocEnd();
    		jcw.WriteClass("extends SqlAssignableObject implements Cloneable");
    		
    		// Attributes
    		for (int j = 0; j < rn.size(); j++) {
    			String relationName = (String) rn.getVector().elementAt (j);
    			jcw.WritePrivateProperty(
    				relationName.substring (0, 1).toUpperCase() +
					relationName.substring (1, relationName.length()),
					relationName );
    		}

    		// Constructor
    		jcw.WriteEmptyLine();
    		jcw.WriteJavaDocBegin();
    		jcw.WriteJavaDocLine("Default constructor.");
    		jcw.WriteJavaDocEnd();
    		sb.append( tabString 
    			+ javaPublicString + " " + className  
				+ openParenthesis + closeParenthesis 
				+ " " + openCurly + endLine);
    		for (int j = 0; j < rn.size(); j++) { 
    			String relationName = (String) rn.getVector().elementAt (j);
    			sb.append( tab2String 
    				+ relationName + " = new " 
					+ relationName.substring (0, 1).toUpperCase() 
					+ relationName.substring (1, relationName.length()) 
					+ openParenthesis + closeParenthesis + semicolon 
					+ endLine);
    		}
    		sb.append (tabString + closeCurly + endLine );
         
    		// setFromResultSet
    		jcw.WriteEmptyLine();
    		jcw.WriteJavaDocBegin();
			jcw.WriteJavaDocLine("Updates the data from the given ResultSet object." );
			jcw.WriteJavaDocLine("@param resultSet ResultSet object containing the data.");
			jcw.WriteJavaDocLine("@param baseIndex Base index of the columns in the ResultSet (exclusive).");
			jcw.WriteJavaDocLine("@throws SQLException if the JDBC operation fails.");
			jcw.WriteJavaDocLine("@throws InvalidValueException if the attributes are invalid.");
			jcw.WriteJavaDocEnd();
    		sb.append( tabString
				+ javaPublicString
				+ " void setFromResultSet(ResultSet resultSet, int baseIndex) throws SQLException, InvalidValueException {"
				+ endLine);
    		int attrNo = 0;
    		for (int j = 0; j < rn.size(); j++) { 
                String relationName = (String) rn.getVector().elementAt (j);
                Relation r = rv.getRelation (relationName);
                sb.append( tab2String 
             		+ relationName 
					+ ".setFromResultSet( resultSet, "
				    + "baseIndex+" + attrNo + " );" + endLine);
                AttributeVector av = r.getAttributeVector();
                for (int k = 0; k < av.size(); k++) {
                	attrNo++;
                }
    		}
    		sb.append(tabString + "}" + endLine);
         
    		// equals
    		jcw.WriteEmptyLine();
    		sb.append( tabString + javaPublicString
		        + " boolean equals( Object obj ) {" + endLine + tab2String
				+ "if( obj == null ) return false;" + endLine + tab2String
				+ "if( !(obj instanceof " + className + ") ) return false;"
				+ endLine + tab2String + className + " dbObj = ("
				+ className + ")obj;" + endLine);
    		for (int j = 0; j < rn.size(); j++) { 
	            String relationName = (String) rn.getVector().elementAt (j);
	            sb.append( tab2String 
	            	+ "if( !" + relationName 
					+ ".equals( dbObj."
					+ relationName 
					+ " ) ) return false;" + endLine);
	         }
    		sb.append(tab2String 
    		    + "return true;" + endLine + tabString + "}"
				+ endLine);
         
    		// clone
    		jcw.WriteEmptyLine();
    		sb.append( tabString 
				+ "public Object clone() throws CloneNotSupportedException " 
				+ openCurly + endLine);
    		sb.append(tab2String + "return super.clone();" + endLine);
    		sb.append(tabString + closeCurly + endLine);

    		// Getters
    		for (int j = 0; j < rn.size(); j++) { 
    			String relationName = (String) rn.getVector().elementAt (j);
    			jcw.WriteEmptyLine();
    			jcw.WriteJavaDocBegin();
    			jcw.WriteJavaDocLine("Gets the data object for " + relationName + ".");
    			jcw.WriteJavaDocLine("@return Data object as " 
    				+ relationName.substring (0, 1).toUpperCase()
					+ relationName.substring (1, relationName.length()) + ".");
    			jcw.WriteJavaDocEnd();
    			sb.append( tabString + javaPublicString + " " 
					+ relationName.substring (0, 1).toUpperCase()
					+ relationName.substring (1, relationName.length()) + " " 
					+ "get" + relationName.substring (0, 1).toUpperCase() 
					+ relationName.substring (1, relationName.length()) 
					+ openParenthesis + closeParenthesis + openCurly + endLine);
    			sb.append (tab2String + javaReturnString + " " + relationName + semicolon + endLine);
    			sb.append (tabString + closeCurly + endLine );
    		}
         
    		// selectionIterator
    		String elementClass = 
			    v.getName().substring(0, 1).toUpperCase()
				+ v.getName().substring(1, v.getName().length());
    		jcw.WriteEmptyLine();
			jcw.WriteJavaDocBegin();
			jcw.WriteJavaDocLine("Constructs and returns a selection iterator for rows in database query " + v.getName() + ".\n"); 
			jcw.WriteJavaDocLine("@param con Open and active connection to the database.");	
			jcw.WriteJavaDocLine("@param whereClause Optional additional where clause. If null is given, all the rows matching the query are selected.\n");
			jcw.WriteJavaDocLine("@return Newly constructed iterator that returns objects of type " + elementClass 
				+ ". The iterator is closed when hasNext() returns false or the iterator is finalized.\n" );
			jcw.WriteJavaDocLine("@throws SQLException if the JDBC operation fails.\n");
			jcw.WriteJavaDocLine("Note that the iterator may throw SqlSelectionIteratorException (which is a runtime exception) when its methods are called.");
			jcw.WriteJavaDocEnd();
			String queryRelList = v.getRelationNameVector().commaList();
    		sb.append( tabString
				+ "public static Iterator selectionIterator( Connection con, String whereClause ) " 
				+ "throws SQLException {"
				+ endLine );
    		sb.append(tab2String
		        + "String prepareString;" + endLine
				+ tab2String
				+ "if( whereClause.equals(\"\") )" + endLine
				+ tab3String
				+ "prepareString = \"select * from " + queryRelList 
				+ " where " + v.getWhereClause() + "\";" + endLine
				+ tab2String
				+ "else" + endLine
				+ tab3String
				+ "prepareString = \"select * from " + queryRelList
				+ " where (" + v.getWhereClause() + ")"
				+ " and \" + whereClause;" + endLine
				+ tab2String
				+ "PreparedStatement ps = con.prepareStatement(prepareString);" + endLine
				+ tab2String
				+ "return new SqlSelectionIterator( ps, " 
				+ elementClass
				+ ".class );" + endLine
				+ tabString
				+ "}"
				+ endLine );

    		// Footer
    		jcw.WriteClassEndAndFooter();
		 
    		try { 
    			File outDir = new File( projectdir 
            		+ slashChar + javaString + slashChar 
					+ v.getPackage());
    			outDir.mkdir();
    			File outFile = new File( projectdir 
    				+ slashChar + javaString + slashChar 
					+ v.getPackage() + slashChar 
					+ className + period + javaString);
    			FileWriter writer = new FileWriter (outFile);
    			writer.write (sb.toString());
    			writer.close();
    		} catch (Exception e) {
    			System.out.println (e);
    		}
    	}
    	return 0;
    }

    /**
     * No comment provided by developer, please add a comment to ensure improve documentation.
     *
     * @param projectdir  No description provided
     * @return            No description provided
     */
    private int writeMainClassFiles (String projectdir) {
        for (int i = 0; i < queryVector.size(); i++) {
        	StringBuffer sb = new StringBuffer();
        	Query v = (Query) queryVector.elementAt (i);
        	String className = 
        		v.getName().substring (0, 1).toUpperCase() 
				+ v.getName().substring (1, v.getName().length());
        	JavaClassWriter jcw = new JavaClassWriter( sb, className );
        	
        	// Package
        	jcw.WritePackage( v.getPackage() );
        	
        	// Class
        	String extendsClassName = javaDbPrefix 
				+ v.getName().substring (0, 1).toUpperCase() +
				v.getName().substring (1, v.getName().length());
        	jcw.WriteEmptyLine();
        	jcw.WriteClassJavaDocBegin();
			jcw.WriteClassJavaDocLine("Skeleton class for application-specific functionality.");
			jcw.WriteClassJavaDocEnd();
        	jcw.WriteClass( "extends " + extendsClassName );
        	
        	// Constructor
        	jcw.WriteEmptyLine();
        	jcw.WriteJavaDocBegin();
        	jcw.WriteJavaDocLine("Default constructor.");
        	jcw.WriteJavaDocEnd();
        	jcw.WritePlainConstructor();
        	
			// Insertion comment
			jcw.WriteEmptyLine();
			sb.append( tabString + "// @todo Insert your additional attributes and methods here." + endLine );
			jcw.WriteEmptyLine();
         
        	// Footer
        	jcw.WriteClassEndAndFooter();

        	try { 
        		// Write the contents of output to a file using a FileWriter
        		File outDir = new File( projectdir 
        			+ slashChar + javaString + slashChar 
					+ v.getPackage());
        		outDir.mkdir();
        		File outFile = new File( projectdir 
        			+ slashChar + javaString + slashChar 
					+ v.getPackage() + slashChar 
					+ className + period + javaString);
        		FileWriter writer = new FileWriter (outFile);
        		writer.write (sb.toString());
        		writer.close();
        	} catch (Exception e) {
        		System.out.println (e);
        	}
        }
        return 0;
    }
}

/*
 * $Log: QueryVector.java,v $
 * Revision 1.2  2003/10/07 07:21:48  ariseppi
 * misc. corrections
 *
 */
