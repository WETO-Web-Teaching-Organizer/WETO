/*
 * Created on 23.6.2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package fi.uta.dbschema.actions;

import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.AbstractAction;

import de.uni_paderborn.fujaba.uml.UMLProject;
import fi.uta.cs.dbswtool.Attribute;
import fi.uta.cs.dbswtool.AttributeVector;
import fi.uta.cs.dbswtool.ForeignKey;
import fi.uta.cs.dbswtool.NameVector;
import fi.uta.cs.dbswtool.Relation;
import fi.uta.cs.dbswtool.RelationVector;
import fi.uta.cs.dbswtool.View;
import fi.uta.cs.dbswtool.ViewVector;
import fi.uta.cs.sqldatatypes.SqlDataType;
import fi.uta.cs.sqldatatypes.SqlString;
import fi.uta.dbschema.metamodel.DBForeignKey;
import fi.uta.dbschema.metamodel.DBJunctionPair;
import fi.uta.dbschema.metamodel.DBSchema;
import fi.uta.dbschema.metamodel.DBTable;
import fi.uta.dbschema.metamodel.DBTableAttribute;
import fi.uta.dbschema.metamodel.DBTableAttributeJunction;
import fi.uta.dbschema.metamodel.DBUnique;
import fi.uta.dbschema.metamodel.DBView;
import fi.uta.dbschema.metamodel.DBViewAttribute;
import fi.uta.dbschema.test.HsqldbController;

/**
 * @author as66033
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class CreateDBAction extends AbstractAction
{

	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent event)
	{
		DBSchema dbSchema = null;
		Object source = UMLProject.get().getCurrentDiagram();
		if (source instanceof DBSchema)
		{
			dbSchema = (DBSchema) source;
		} else
		{
			return;
		}

		Iterator iter = dbSchema.iteratorOfItems();

		RelationVector relVector = new RelationVector();
		ViewVector viewVector = new ViewVector();
		
		HashMap addedRelations = new HashMap();
		ArrayList notAddedRelations = new ArrayList();
		
		ArrayList views = new ArrayList();

		while (iter.hasNext())
		{
			Object obj = iter.next();
			if (obj instanceof DBTable)
			{
				DBTable table = (DBTable) obj;
				Relation rel = new Relation();
				rel.setName(table.getName());
				rel.setPackage(table.getJavaPackage());
				Iterator iter2 = table.iteratorOfAttributes();

				// Information about unique constraints is stored as a list
				// in DBTable, primary key information is stored as attribute
				// variables in DBTableAttributes.

				NameVector primaryKey = new NameVector();
				String[][] examples =
					new String[DBTableAttribute
						.exampleCount][table
						.sizeOfAttributes()];
				int attrInd = 0;
				while (iter2.hasNext())
				{
					DBTableAttribute attr = (DBTableAttribute) iter2.next();
					// DBTableAttribute uses datatype int instead of Integer for size and
					// scale with NO_NUMBER meaning null (since all the legal values are positive).
					int number = attr.getSqlSize();
					Integer size = null;
					if (number > DBTableAttribute.NO_NUMBER)
					{
						size = new Integer(number);
					}
					number = attr.getSqlScale();
					Integer scale = null;
					if (number > DBTableAttribute.NO_NUMBER)
					{
						scale = new Integer(number);
					}

					String sqlType = attr.getSqlType();
					if (size != null)
					{
						sqlType += "(" + size;
						if (scale != null)
						{
							sqlType += "," + scale;
						}
						sqlType += ")";
					}
					SqlDataType sdt = attr.getTypeClass();
					Boolean stringType = null;
					if (sdt instanceof SqlString)
					{
						stringType = new Boolean(true);
					} else
					{
						stringType = new Boolean(false);
					}

					Iterator iter3 = attr.iteratorOfExamples();
					int exampleInd = 0;
					while (iter3.hasNext())
					{
						examples[exampleInd][attrInd] = (String) iter3.next();
						exampleInd++;
					}
					attrInd++;

					// Attribute names are created by combining the attribute name in the
					// relation (attribute role) and table name.
					Attribute a =
						new Attribute(
							rel.getName() + "_" + attr.getName(),
							sqlType,
							attr.getJavaType(),
							stringType);
					a.setJavaTypeLength(size);
					a.setJavaTypeScale(scale);
					if (attr.getPrimaryKeyValue())
					{
						primaryKey.addName(attr.getName());
					}
					a.setRole(attr.getName());
					a.setNotNull(new Boolean(attr.getNotNullValue()));

					// Attribute is added to attribute vector and relation.
					rel.addAttribute(a);
				}
				for (int i = 0; i < DBTableAttribute.exampleCount; i++)
				{
					String[] example = (String[]) examples[i];
					boolean nonEmpty = false;
					for (int i2 = 0; i2 < table.sizeOfAttributes(); i2++)
					{
						if (example[i2] == null)
						{
							example[i2] = "";
						}
						if (!example[i2].equals(""))
						{
							nonEmpty = true;
						}
						if (example[i2].equals(""))
						{
							example[i2] = "null";
						} else if (example[i2].equals("\"\""))
						{
							example[i2] = "";
						}
					}
					if (nonEmpty)
					{
						rel.addExample(example);
					}
				}
				rel.setPrimaryKey(primaryKey);
				iter2 = table.iteratorOfUniques();
				while (iter2.hasNext())
				{
					DBUnique uni = (DBUnique) iter2.next();
					Iterator iter3 = uni.iteratorOfAttributes();
					NameVector uniqueConst = new NameVector();
					while (iter3.hasNext())
					{
						DBTableAttribute attr = (DBTableAttribute) iter3.next();
						uniqueConst.addName(attr.getName());
					}
					rel.addUnique(uniqueConst);
				}
				iter2 = table.iteratorOfRevForeignKeys();
				while (iter2.hasNext()) 
				{
					DBForeignKey key = (DBForeignKey) iter2.next();
					Iterator iter3 = key.iteratorOfJunctionPairs();
					NameVector ownAttributes = new NameVector();
					while (iter3.hasNext())
					{
						DBJunctionPair pair = (DBJunctionPair) iter3.next();
						DBTableAttributeJunction revJunc =
							pair.getRevJunction();
						DBTableAttribute revAttr = revJunc.getTarget();
						ownAttributes.addName(revAttr.getName());
					}
					if(!rel.isUnique(ownAttributes)) {
						rel.addUnique(ownAttributes);
					}
				}
				iter2 = table.iteratorOfForeignKeys();
				boolean add = true;
				while (iter2.hasNext())
				{
					DBForeignKey key = (DBForeignKey) iter2.next();
					DBTable revTable = key.getRevTable();
					String revTableName = revTable.getName();
					if(!addedRelations.containsKey(revTableName)) {
						add = false;
					}

					Iterator iter3 = key.iteratorOfJunctionPairs();
					NameVector ownAttributes = new NameVector();
					NameVector revAttributes = new NameVector();
					while (iter3.hasNext())
					{
						DBJunctionPair pair = (DBJunctionPair) iter3.next();
						DBTableAttributeJunction origJunc =
							pair.getOriginalJunction();
						DBTableAttribute origAttr = origJunc.getTarget();
						DBTableAttributeJunction revJunc =
							pair.getRevJunction();
						DBTableAttribute revAttr = revJunc.getTarget();
						ownAttributes.addName(origAttr.getName());
						revAttributes.addName(revAttr.getName());
					}
					ForeignKey toolKey = new ForeignKey();
					toolKey.setReferredTable(revTableName);
					toolKey.setReferredAttributes(revAttributes);
					toolKey.setOwnAttributes(ownAttributes);
					rel.addForeignKey(toolKey);
				}
				if(add) {
					addedRelations.put(rel.getName(), "");
					relVector.addRelation(rel);
				}
				else {
					notAddedRelations.add(rel);
				}
			}
			if (obj instanceof DBView)
			{
				views.add(obj);
			}
		}
		while(notAddedRelations.size() > 0) {
			for(int i = 0; i < notAddedRelations.size(); i++) {
				Relation rel = (Relation) notAddedRelations.get(i);
				Vector forVector = rel.getForeignKeyVector();
				boolean add = true;
				for(int i2 = 0; i2 < forVector.size(); i2++) {
					ForeignKey forKey = (ForeignKey) forVector.get(i2);
					if(!addedRelations.containsKey(forKey.getReferredTable())) {
						add = false;
					}
				}
				if(add) {
					relVector.addRelation(rel);
					notAddedRelations.remove(rel);
					addedRelations.put(rel.getName(), "");
					i--;
				}
			}
		}
		for(int i = 0; i < views.size(); i++) {
			DBView dbView = (DBView) views.get(i);
			View view = new View();
			view.setName(dbView.getName());
			view.setPackage(dbView.getJavaPackage());
			Iterator iter2 = dbView.iteratorOfAttributes();
			while (iter2.hasNext())
			{
				DBViewAttribute vAttr = (DBViewAttribute) iter2.next();
				DBTableAttribute tAttr =
					(DBTableAttribute) vAttr.getAttribute();
				String origName = tAttr.getName();
				
				view.addAttrOrigName(origName);
				view.addRelationName(tAttr.getParent().getName());
				Relation rel =
					relVector.getRelation(tAttr.getParent().getName());
				AttributeVector attrVec = rel.getAttributeVector();
				Attribute origAttr = attrVec.getAttributeByRole(origName);
				Attribute viewAttr =
					new Attribute(
						origAttr.getName(),
						origAttr.getSQLType(),
						origAttr.getJavaType(),
						origAttr.getStringType());
				viewAttr.setJavaTypeLength(origAttr.getJavaTypeLength());
				viewAttr.setJavaTypeScale(origAttr.getJavaTypeScale());
				viewAttr.setRole(vAttr.getName());
				view.addAttribute(viewAttr);
			}
			view.setWhereClause(dbView.getWhereClause());
			viewVector.addView(view);
		}
		HsqldbController.createDatabase(relVector, viewVector);
	}
}