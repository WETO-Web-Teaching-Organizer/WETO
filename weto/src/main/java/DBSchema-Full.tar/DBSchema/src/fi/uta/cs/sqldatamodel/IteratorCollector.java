/*
 * Created on Oct 5, 2004
 */
package fi.uta.cs.sqldatamodel;

import java.util.Iterator;
import java.util.List;
import java.util.LinkedList;

/**
 * Collects the elements returned by the given iterator to
 * a list.
 * 
 * @author csvera
 */
public class IteratorCollector {
	private LinkedList list;
	
	public IteratorCollector() {
		list = new LinkedList();
	}
	
	/**
	 * Sets the elements of this collection by going through
	 * the given iterator. The existing content is discarded.
	 * 
	 * @param iterator Iterator that specifies the new content.
	 */
	public void setElements( Iterator iterator ) {
		list.clear();
		while( iterator.hasNext() ) {
			list.add( iterator.next() );
		}
	}
		
	/**
	 * Gets the content of this collection as a list.
	 * 
	 * @return Reference to the content as a List.
	 */
	public List getList() {
		return list;
	}
}

// End of file.
