/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this source code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.cs.dbswtool;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StreamTokenizer;
import java.util.Vector;

/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:49 $
 * @version   $Revision: 1.5 $
 */
public class ViewVector implements RelAndQueryConstants, ViewStore
{
	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	private Vector viewVector;

	/**
	 * Constructor for class ViewVector
	 */
	public ViewVector()
	{
		viewVector = new Vector();
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 */
	public void output()
	{
		System.out.println("ViewVector with size " + viewVector.size());
		for (int i = 0; i < viewVector.size(); i++)
		{
			View v = (View) viewVector.elementAt(i);
			v.output();
		}
	}

	/**
	 * Get the view attribute of the ViewVector object
	 *
	 * @param name  No description provided
	 * @return      The view value
	 */
	public View getView(String name)
	{
		View vFound = null;
		int i = 0;
		while ((i < viewVector.size()) && (vFound == null))
		{
			View v = (View) viewVector.elementAt(i);
			i++;
			if (name.equals(v.getName()))
			{
				vFound = v;
			}
		}
		return vFound;
	}

	/**
	 * Access method for an one to n association.
	 *
	 * @param newView  The object added.
	 */
	public void addView(View newView)
	{
		//	output();
		if (getView(newView.getName()) == null)
		{
			viewVector.add(newView);
		}
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param projectdir  No description provided
	 * @return            No description provided
	 */
	public int writeSQLFiles(String projectdir)
	{
		File sqlDir = new File(projectdir + "/" + sqlString);
		sqlDir.mkdir();
		for (int i = 0; i < viewVector.size(); i++)
		{
			View v = (View) viewVector.elementAt(i);
			try
			{ // Write the contents of output to a file using a FileWriter
				File outFile =
					new File(
						projectdir
							+ slashChar
							+ sqlString
							+ slashChar
							+ v.getName()
							+ period
							+ sqlString);
				FileWriter writer = new FileWriter(outFile);
				writer.write(getSQLString(i).toString());
				writer.close();
			} catch (Exception e)
			{
				System.out.println(e);
			}
		}
		return 0;
	}

	public StringBuffer getSQLString(int i)
	{
		View v = (View) viewVector.elementAt(i);
		StringBuffer sb = new StringBuffer();
		sb.append("drop view " + v.getName() + " if exists;\n");
		sb.append("create view " + v.getName() + "(");

		AttributeVector av = v.getAttributeVector();
		for (int j = 0; j < av.size(); j++)
		{
			Attribute a = av.getAttribute(j);
			//	    String relname = (String) rv.elementAt(j);

			if (j > 0)
			{
				sb.append(", ");
			}
			sb.append(a.getRole());
		}
		sb.append(")\n");

		Vector nva = v.getAttrOrigNameVector().getVector();
		Vector rv = v.getRelationNameVector().getVector();
		sb.append(" as select ");

		for (int j = 0; j < nva.size(); j++)
		{
			String attrName = (String) nva.elementAt(j);
			String relName = (String) rv.elementAt(j);
			if (j > 0)
			{
				sb.append(", ");
			}
			sb.append(relName + "." + attrName);
		}

		NameVector nvr = v.getRelationNameSingleVector();
		sb.append("\n   from " + nvr.commaList());

		if (!v.getWhereClause().equals(""))
		{
			sb.append("\n   where " + v.getWhereClause() + ";");
		} else
		{
			sb.append(";");
		}
		return sb;
	}

	public String[] getSQLStrings(int i)
	{
		StringBuffer sb = new StringBuffer();
		if (i < 0 || i >= viewVector.size())
		{
			return null;
		}
		View v = (View) viewVector.elementAt(i);
		String[] stringArray = new String[2];
		
		stringArray[0] = "drop view " + v.getName() + " if exists;";
		sb.append("create view " + v.getName());
		/* + "(");
*/
		AttributeVector av = v.getAttributeVector();
	/*	for (int j = 0; j < av.size(); j++)
		{
			Attribute a = av.getAttribute(j);
			//	    String relname = (String) rv.elementAt(j);

			if (j > 0)
			{
				sb.append(", ");
			}
			sb.append(a.getRole());
		}
		sb.append(")");
*/
		Vector nva = v.getAttrOrigNameVector().getVector();
		Vector rv = v.getRelationNameVector().getVector();
		sb.append(" as select ");
		
		for (int j = 0; j < nva.size(); j++)
		{
			String attrName = (String) nva.elementAt(j);
			String relName = (String) rv.elementAt(j);
			Attribute attr = av.getAttribute(j);
			String newName = attr.getRole();
			if (j > 0)
			{
				sb.append(", ");
			}
			sb.append(relName + "." + attrName + " " + newName);
		}

		NameVector nvr = v.getRelationNameSingleVector();
		sb.append("   from " + nvr.commaList());

		if (!v.getWhereClause().equals(""))
		{
			sb.append("   where " + v.getWhereClause() + ";");
		} else
		{
			sb.append(";");
		}
		stringArray[1] = sb.toString();
		return stringArray;
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param projectdir  No description provided
	 * @return            No description provided
	 */
	public int writeHtmlFile(String projectdir)
	{
		//	String filename = attributeHtmlFileName;
		StringBuffer sb = new StringBuffer();
		sb.append(htmlFileHeader1);
		sb.append(htmlFileHeader2);
		sb.append(htmlFileHeader3);
		sb.append(htmlFileHeader4);

		// First write an index table of all relation names
		sb.append(beginHtmlTable);
		sb.append(beginHtmlTableRow + endLine);
		sb.append(
			beginHtmlTableColumn
				+ " <b>View Name</b> "
				+ endHtmlTableColumn
				+ endLine);
		sb.append(endHtmlTableRow + endLine);
		for (int i = 0; i < viewVector.size(); i++)
		{
			View v = (View) viewVector.elementAt(i);
			sb.append(beginHtmlTableRow + endLine);
			sb.append(
				beginHtmlTableColumn
					+ " "
					+ beginHtmlHref
					+ v.getName()
					+ endHtmlHref
					+ " "
					+ v.getName().toUpperCase()
					+ " "
					+ endHtmlA
					+ endHtmlTableColumn
					+ endLine);
			sb.append(endHtmlTableRow + endLine);
		}
		sb.append(endHtmlTable);
		sb.append(htmlParagraph);

		// Then a table for each relation
		for (int i = 0; i < viewVector.size(); i++)
		{ // First the header
			sb.append(htmlParagraph);
			sb.append(htmlParagraph);
			View v = (View) viewVector.elementAt(i);
			sb.append(
				beginHtmlTarget
					+ v.getName()
					+ endHtmlTarget
					+ " "
					+ htmlBeginBold
					+ v.getName().toUpperCase()
					+ htmlEndBold
					+ endLine);
			sb.append("<p><b>Description</b>: " + v.getDescription() + endLine);
			sb.append(beginHtmlTable);
			sb.append(beginHtmlTableRow + endLine);
			sb.append(
				beginHtmlTableColumn
					+ " "
					+ "<b>View Attribute</b>"
					+ " "
					+ endHtmlTableColumn
					+ endLine);
			sb.append(
				beginHtmlTableColumn
					+ " "
					+ baseAttributeHtmlString
					+ " "
					+ endHtmlTableColumn
					+ endLine);
			sb.append(
				beginHtmlTableColumn
					+ " "
					+ sqlHtmlString
					+ " "
					+ endHtmlTableColumn
					+ endLine);
			sb.append(
				beginHtmlTableColumn
					+ " "
					+ javaHtmlString
					+ " "
					+ endHtmlTableColumn
					+ endLine);
			sb.append(
				beginHtmlTableColumn
					+ " "
					+ "<b>Original Attribute Name</b>"
					+ " "
					+ endHtmlTableColumn
					+ endLine);
			sb.append(
				beginHtmlTableColumn
					+ " "
					+ "<b>Original Table Name</b>"
					+ " "
					+ endHtmlTableColumn
					+ endLine);
			sb.append(
				beginHtmlTableColumn
					+ " "
					+ "<b>Description</b>"
					+ " "
					+ endHtmlTableColumn
					+ endLine);
			sb.append(endHtmlTableRow + endLine);

			AttributeVector av = v.getAttributeVector();
			NameVector nva = v.getAttrOrigNameVector();
			Vector anv = nva.getVector();
			NameVector nvr = v.getRelationNameVector();
			Vector rnv = nvr.getVector();
			for (int j = 0; j < av.size(); j++)
			{ // Then the table rows, one for each attribute
				Attribute a = av.getAttribute(j);
				String origA = (String) anv.elementAt(j);
				String origR = (String) rnv.elementAt(j);

				sb.append(beginHtmlTableRow + endLine);
				sb.append(
					beginHtmlTableColumn
						+ " "
						+ a.getRole()
						+ " "
						+ endHtmlTableColumn
						+ endLine);
				sb.append(
					beginHtmlTableColumn
						+ " "
						+ a.getName()
						+ " "
						+ endHtmlTableColumn
						+ endLine);
				sb.append(
					beginHtmlTableColumn
						+ " "
						+ a.getSQLType()
						+ " "
						+ endHtmlTableColumn
						+ endLine);
				sb.append(
					beginHtmlTableColumn
						+ " "
						+ a.getJavaType()
						+ " "
						+ endHtmlTableColumn
						+ endLine);
				sb.append(
					beginHtmlTableColumn
						+ " "
						+ origA
						+ " "
						+ endHtmlTableColumn
						+ endLine);
				sb.append(
					beginHtmlTableColumn
						+ " "
						+ origR
						+ " "
						+ endHtmlTableColumn
						+ endLine);
				sb.append(
					beginHtmlTableColumn
						+ " "
						+ a.getDescription()
						+ " "
						+ endHtmlTableColumn
						+ endLine);
				sb.append(endHtmlTableRow + endLine);
			}
			sb.append(endHtmlTable + endLine);
		}

		sb.append(endHtmlFile);

		try
		{ // Write the contents of output to a file using a FileWriter
			File outFile = new File(projectdir + slashChar + viewHtmlFileName);
			FileWriter writer = new FileWriter(outFile);
			writer.write(sb.toString());
			writer.close();
		} catch (Exception e)
		{
			System.out.println(e);
		}
		return 0;
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param projectdir  No description provided
	 * @return            No description provided
	 */
	public int writeJavaFiles(String projectdir)
	{
		File javaDir = new File(projectdir + slashChar + javaString);
		javaDir.mkdir();
		writeDbClassFiles(projectdir);
		writeBeanClassFiles(projectdir);
		writeMainClassFiles(projectdir);
		return 0;
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param projectdir  No description provided
	 * @param filename    No description provided
	 * @param rv          No description provided
	 * @return            No description provided
	 */
	public int readViewFile(
		String projectdir,
		String filename,
		RelationVector rv)
	{

		String viewName = "";
		String packageName = "";
		String attributeName = "";
		String attributeRole = "";
		String attributeOriginalRole = "";
		String attributeOriginalRelation = "";

		// as.output();

		try
		{

			// Open the file, do the technicalities to get StreamTokenizer
			FileInputStream fis =
				new FileInputStream(projectdir + slashChar + filename);

			InputStreamReader isr = new InputStreamReader(fis);
			BufferedReader br = new BufferedReader(isr);
			StreamTokenizer st = new StreamTokenizer(br);
			st.slashSlashComments(false);
			st.wordChars('_', '_');
			// st.wordChars('[','[');
			// st.wordChars(']',']');
			st.ordinaryChars('0', '9');
			// st.wordChars('.','.');
			st.wordChars('0', '9');
			st.quoteChar('"');
			st.ordinaryChar(')');
			st.whitespaceChars('(', '(');
			st.whitespaceChars(',', ',');

			int nextType = expectingViewString;

			while (st.nextToken() != StreamTokenizer.TT_EOF)
			{
				if (st.ttype != StreamTokenizer.TT_WORD)
				{
					System.out.println(
						"Expecting a string, got " + st.toString());
				} else
				{
					if (!st.sval.equals(viewString))
					{
						System.out.println(
							"Expexting '"
								+ viewString
								+ "', got: "
								+ st.toString());
					} else
					{ // A view coming up, let's read it:
						nextType = expectingViewName;
						View v = new View();
						while ((st.nextToken() != StreamTokenizer.TT_EOF)
							&& (nextType != expectingViewString))
						{
							if ((st.ttype != StreamTokenizer.TT_WORD)
								&& (nextType != expectingWhereClause))
							{
								System.out.println(
									"Expecting a string, got " + st.toString());
							} else
							{
								switch (nextType)
								{
									case expectingViewName :
										// System.out.println("Got view name " + st.sval);
										viewName = st.sval.toLowerCase();
										v.setName(viewName);
										nextType = expectingPackageString;
										break;
									case expectingPackageString :
										if (st.sval.equals(packageString))
										{
											nextType = expectingPackageName;
										} else
										{
											System.out.println(
												"I was expecting "
													+ packageString
													+ ", but I got "
													+ st.toString());
										}
										break;
									case expectingPackageName :
										packageName = st.sval.toLowerCase();
										v.setPackage(packageName);
										nextType = expectingAttributeString;
										break;
									case expectingAttributeString :
										if (st.sval.equals(attributeString))
										{
											nextType = expectingOriginalRole;
										} else if (st.sval.equals(whereString))
										{
											nextType = expectingWhereClause;
										} else
										{
											System.out.println(
												"I was expecting "
													+ attributeString
													+ " or "
													+ whereString
													+ ", but I got "
													+ st.toString());
										}
										break;
									case expectingOriginalRole :
										attributeOriginalRole =
											st.sval.toLowerCase();
										nextType = expectingOriginalRelation;
										break;
									case expectingOriginalRelation :
										attributeOriginalRelation =
											st.sval.toLowerCase();
										nextType = expectingRole;
										break;
									case expectingRole :
										attributeRole = st.sval.toLowerCase();
										//System.out.println("Relation list for view " + v.getName() +
										//	       " and I just read " + st.toString());
										Relation rel =
											rv.getRelation(
												attributeOriginalRelation);
										AttributeVector av =
											rel.getAttributeVector();
										Attribute a =
											av.getAttributeByRole(
												attributeOriginalRole);
										if (a != null)
										{
											Attribute a2 =
												new Attribute(
													a.getName(),
													a.getSQLType(),
													a.getJavaType(),
													a.getStringType());
											a2.setRole(attributeRole);
											a2.setJavaTypeLength(
												a.getJavaTypeLength());
											a2.setJavaTypeScale(
												a.getJavaTypeScale());
											v.addAttribute(a2);
											v.addRelationName(
												attributeOriginalRelation);
											v.addAttrOrigName(
												attributeOriginalRelation
													+ "."
													+ attributeOriginalRole);
										} else
										{
											System.out.println(
												"Attribute "
													+ st.sval
													+ " not found for view "
													+ v.getName()
													+ ", got:"
													+ st.toString());
										}
										nextType = expectingAttributeString;
										break;
									case expectingWhereClause :
										String whereClause =
											st.sval.toLowerCase();
										v.setWhereClause(whereClause);
										nextType = expectingViewString;
										break;
									default :
										break;
								} // end switch
							} // end of "getting a string" else
						} // end while - done reading a view
						addView(v);
					} // end of "getting a view" else
				}
			}
			return viewFileReadOk;
		} catch (IOException e)
		{
			System.out.println(e);
			return viewFileReadFailed;
		}
	}

	public int size()
	{
		return viewVector.size();
	}
	
//  ------------------------------------------------------------
//  Class file output
//  ------------------------------------------------------------

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param projectdir  No description provided
	 * @return            No description provided
	 */
	private int writeDbClassFiles(String projectdir) {
		for (int i = 0; i < viewVector.size(); i++) { 
			StringBuffer sb = new StringBuffer();
			View v = (View) viewVector.elementAt(i);
			AttributeVector av = v.getAttributeVector();
			String className = javaDbPrefix
				+ v.getName().substring(0, 1).toUpperCase()
				+ v.getName().substring(1, v.getName().length());
			JavaClassWriter jcw = new JavaClassWriter(sb, className);
			
			// Package
			jcw.WritePackage(v.getPackage());
			
			// Imports
			jcw.WriteEmptyLine();
			jcw.WriteDbImports();
			
            // Class
			jcw.WriteEmptyLine();
			jcw.WriteClassJavaDocBegin();
			jcw.WriteClassJavaDocLine( "Generated database access class for view " + v.getName() + "." );
			jcw.WriteClassJavaDocLine( v.getDescription() );
			jcw.WriteClassJavaDocEnd();
			jcw.WriteClass(javaDbClassInheritance);
			
			// Attributes
			for (int j = 0; j < av.size(); j++) { 
				Attribute a = av.getAttribute(j);
				jcw.WritePrivateProperty( a.getJavaType(),
					a.getRole() + javaDbAttributeSuffix );
			}

			// Constructor (no primary key specials)
			jcw.WriteEmptyLine();
			jcw.WriteJavaDocBegin();
			jcw.WriteJavaDocLine( "Default constructor." );
			jcw.WriteJavaDocEnd();
			jcw.WriteDbConstructor( av, null, null );
			
			// setFromResultSet
			jcw.WriteEmptyLine();
			jcw.WriteJavaDocBegin();
			jcw.WriteJavaDocLine("Updates the data from the given ResultSet object." );
			jcw.WriteJavaDocLine("@param resultSet ResultSet object containing the data.");
			jcw.WriteJavaDocLine("@param baseIndex Base index of the columns in the ResultSet (exclusive).");
			jcw.WriteJavaDocLine("@throws SQLException if the JDBC operation fails.");
			jcw.WriteJavaDocLine("@throws InvalidValueException if the attributes are invalid.");
			jcw.WriteJavaDocEnd();
			jcw.WriteSetFromResultSet( av, null, null );
			
			// toString
			jcw.WriteEmptyLine();
			jcw.WriteDbToString( v.getName(), av );
			
			// equals
			jcw.WriteEmptyLine();
			jcw.WriteDbEquals( av );
			
			// clone
			jcw.WriteEmptyLine();
			jcw.WriteClone();

			// Getters
			for (int j = 0; j < av.size(); j++)
			{
				Attribute a = av.getAttribute(j);
				jcw.WriteEmptyLine();
				jcw.WriteJavaDocBegin();
				jcw.WriteJavaDocLine("Gets the raw data object for " + a.getRole() + " attribute.");
				jcw.WriteJavaDocLine("@return Data object as " + a.getJavaType() + "." );
				jcw.WriteJavaDocEnd();
				jcw.WriteGetter( a.getJavaType(),
					a.getRole() + javaDbAttributeSuffix );
			}
			
			// select
			jcw.WriteEmptyLine();
			jcw.WriteJavaDocBegin();
			jcw.WriteJavaDocLine("Selects the row of this object from the database view " + v.getName() 
				+ " and updates the attributes accordingly.");
			jcw.WriteJavaDocLine("@param con Open and active connection to the database.");
			jcw.WriteJavaDocLine("@throws SQLException if the JDBC operation fails.");
			jcw.WriteJavaDocLine("@throws InvalidValueException if the attributes are invalid.");
			jcw.WriteJavaDocLine("@throws NoSuchItemException if the row to be selected does not exist or is not unique.");
			jcw.WriteJavaDocEnd();
			jcw.WriteDbSelect( v.getName(), av, null );
			
			// selectionIterator
			String elementClass = 
			    v.getName().substring(0, 1).toUpperCase()
				+ v.getName().substring(1, v.getName().length());
			jcw.WriteEmptyLine();
			jcw.WriteJavaDocBegin();
			jcw.WriteJavaDocLine("Constructs and returns a selection iterator for rows in database view " + v.getName() + ".\n"); 
			jcw.WriteJavaDocLine("@param con Open and active connection to the database.");	
			jcw.WriteJavaDocLine("@param whereClause Optional where clause. If null is given, all the rows are selected.\n");
			jcw.WriteJavaDocLine("@return Newly constructed iterator that returns objects of type " + elementClass 
				+ ". The iterator is closed when hasNext() returns false or the iterator is finalized.\n" );
			jcw.WriteJavaDocLine("@throws SQLException if the JDBC operation fails.\n");
			jcw.WriteJavaDocLine("Note that the iterator may throw SqlSelectionIteratorException (which is a runtime exception) when its methods are called.");
			jcw.WriteJavaDocEnd();
			jcw.WriteDbSelectionIterator( v.getName(), elementClass );
			
			// Footer
			jcw.WriteClassEndAndFooter();

			try { 
				File outDir = new File( projectdir
					+ slashChar
					+ javaString
					+ slashChar
					+ v.getPackage());
				outDir.mkdir();
				File outFile = new File( projectdir
					+ slashChar
					+ javaString
					+ slashChar
					+ v.getPackage()
					+ slashChar
					+ className
					+ period
					+ javaString);
				FileWriter writer = new FileWriter(outFile);
				writer.write(sb.toString());
				writer.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
		return 0;
	}
	
	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param projectdir  No description provided
	 * @return            No description provided
	 */
	private int writeBeanClassFiles(String projectdir)
	{
		for (int i = 0; i < viewVector.size(); i++) {
			StringBuffer sb = new StringBuffer();
			View v = (View) viewVector.elementAt(i);
			AttributeVector av = v.getAttributeVector();
			String className = javaBeanPrefix
				+ v.getName().substring(0, 1).toUpperCase()
				+ v.getName().substring(1, v.getName().length());
			JavaClassWriter jcw = new JavaClassWriter(sb, className);
			
			// Package
			jcw.WritePackage( v.getPackage() );
			
			// Class
			jcw.WriteEmptyLine();
			jcw.WriteClassJavaDocBegin();
			jcw.WriteClassJavaDocLine("Generated bean class for " + v.getName() + ".");
			jcw.WriteClassJavaDocLine("This class extends the database access class by adding bean property getters.");
			jcw.WriteClassJavaDocEnd();
			jcw.WriteClass( "extends " 
				+ javaDbPrefix 
				+ v.getName().substring(0, 1).toUpperCase()
				+ v.getName().substring(1, v.getName().length()) );

			// Constructor
			jcw.WriteEmptyLine();
			jcw.WriteJavaDocBegin();
			jcw.WriteJavaDocLine("Default constructor.");
			jcw.WriteJavaDocEnd();
			jcw.WritePlainConstructor();
			
			// Getters and setters
			for (int j = 0; j < av.size(); j++) {
				Attribute a = av.getAttribute(j);
				jcw.WriteEmptyLine();
				jcw.WriteJavaDocBegin();
				jcw.WriteJavaDocLine("Gets the value of the property " + a.getRole() + ".");
				jcw.WriteJavaDocLine("@return Value as " + a.getBeanType() + ".");
				jcw.WriteJavaDocEnd();
				jcw.WriteBeanGetter(a.getBeanType(), a.getRole() );
			}
			
			// Footer
			jcw.WriteClassEndAndFooter();

			try { 
				// Write the contents of output to a file using a FileWriter
				File outDir = new File( projectdir
					+ slashChar
					+ javaString
					+ slashChar
					+ v.getPackage());
				outDir.mkdir();
				File outFile = new File( projectdir
					+ slashChar
					+ javaString
					+ slashChar
					+ v.getPackage()
					+ slashChar
					+ className
					+ period
					+ javaString);
				FileWriter writer = new FileWriter(outFile);
				writer.write(sb.toString());
				writer.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
		return 0;
	}

	/**
	 * No comment provided by developer, please add a comment to ensure improve documentation.
	 *
	 * @param projectdir  No description provided
	 * @return            No description provided
	 */
	private int writeMainClassFiles(String projectdir) {
		for (int i = 0; i < viewVector.size(); i++) {
			StringBuffer sb = new StringBuffer();
			View v = (View) viewVector.elementAt(i);
			String className =
				v.getName().substring(0, 1).toUpperCase()
				+ v.getName().substring(1, v.getName().length());
			JavaClassWriter jcw = new JavaClassWriter(sb, className );
			
			// Package
			jcw.WritePackage( v.getPackage() );
			
			// Class
			String extendsClassName =
				javaBeanPrefix 
				+ v.getName().substring(0, 1).toUpperCase()
				+ v.getName().substring(1, v.getName().length());
			jcw.WriteEmptyLine();
			jcw.WriteClassJavaDocBegin();
			jcw.WriteClassJavaDocLine("Skeleton class for application-specific functionality.");
			jcw.WriteClassJavaDocEnd();
			jcw.WriteClass( "extends " + extendsClassName );
			
			// Constructor
			jcw.WriteEmptyLine();
			jcw.WriteJavaDocBegin();
			jcw.WriteJavaDocLine("Default constructor.");
			jcw.WriteJavaDocEnd();
			jcw.WritePlainConstructor();
			
			// Insertion comment
			jcw.WriteEmptyLine();
			sb.append( tabString + "// @todo Insert your additional attributes and methods here." + endLine );
			jcw.WriteEmptyLine();
			
			// Footer
			jcw.WriteClassEndAndFooter();

			try	{ 
				// Write the contents of output to a file using a FileWriter
				File outDir = new File( projectdir
					+ slashChar
					+ javaString
					+ slashChar
					+ v.getPackage());
				outDir.mkdir();
				File outFile = new File( projectdir
					+ slashChar
					+ javaString
					+ slashChar
					+ v.getPackage()
					+ slashChar
					+ className
					+ period
					+ javaString);
				FileWriter writer = new FileWriter(outFile);
				writer.write(sb.toString());
				writer.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
		return 0;
	}
}

/*
 * $Log: ViewVector.java,v $
 * Revision 1.5  2003/10/07 07:21:49  ariseppi
 * misc. corrections
 *
 */
