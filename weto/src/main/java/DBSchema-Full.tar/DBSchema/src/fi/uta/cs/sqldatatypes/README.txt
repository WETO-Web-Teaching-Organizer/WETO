//
// 22.3.2003
// Jyrki Nummenmaa 
//
// These SQL datatype classes provide a uniform set of services
// and JDBC compatibility.
// 
// They provide the following methods, where T stands for the 
// Java class type to be used for JDBC data access and SqlT for
// our SQL data type, and JdbcT for the JDBC data type (often the same
// as T - however we use T=Short for JdbcT=Boolean.
// The class SqlT contains an attribute
//   private T data; 
// 
// Notice that we use wrapper classes: Integer for int, Float for float, 
// and then we use Short for boolean, as SQL data type BIT is
// not that well supported across various platforms.
//
// Also notice that T needs extra parameters for some data types,
// such as CHAR, VARCHAR, DECIMAL, etc.
//
// ---------------------------------------------------------------------- 
//
// static stringIsOk(String s) // checks if s is can be used to make data
//   A null string is accepted and taken as a null value
//   Takes extra parameters (e.g. length) for SqlChar, SqlVarchar, SqlDecimal
//
// SqlT()  // constructor without parameters
//
// SqlT(T d) // constructor with init value data
//
// SqlT(String s) // constructor with string, uses setString
//
// void set(T d) // sets d to be the new value for data
//   Note that set does not make a new copy of the parameter object d.
//
// void setJdbc(JdbcT d) // sets d to be the new value for data
//   Note that set does not make a new copy of the parameter object d.
//   
//
// void setString(String s) { 
//  if (s==null)
//    data=null;
//  else
//    if (s.equals("")) 
//      data=null;
//    else 
//      if (SLQT.stringOk()) 
//        construct data from s;
//  }
//
// Notice that for CHAR, VARCHAR and LONGVARCHAR an empty string
// will lead to a null value - you can avoid this by calling
// set(null) explicitly.
//
// T get() // return data
//
// JdbcT getJdbc() // return data in the data type for JDBC
//
// String toString() {
//   if (data==null)
//     return "";
//   else
//     return data.toString();
//   }
//
// boolean stringOk(String s) { // calls T.stringOk with 
//   possibly required extra parameters...
//  }
