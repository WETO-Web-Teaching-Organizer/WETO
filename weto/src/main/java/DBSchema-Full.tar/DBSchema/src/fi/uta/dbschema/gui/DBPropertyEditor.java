/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this added code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.gui;

import java.awt.Cursor;
import java.awt.Dialog;

import javax.swing.JFrame;

import de.uni_paderborn.fujaba.asg.ASGElement;
import de.uni_paderborn.fujaba.gui.BasicPropertyEditor;
import fi.uta.dbschema.metamodel.DBSchema;
import fi.uta.dbschema.metamodel.DBTable;


/**
 * No comment provided by developer, please add a comment to improve documentation.
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:51 $
 * @version   $Revision: 1.2 $
 */
public abstract class DBPropertyEditor extends BasicPropertyEditor
{
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private DBTable table = null;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private DBSchema schema = null;


   /**
    * Constructor for class DBPropertyEditor
    *
    * @param frame  No description provided
    */
   public DBPropertyEditor (JFrame frame)
   {
      super (frame);
      setTitle ("Property Editor");
   }


   /**
    * Create an DBPropertyEditor with an Dialog as owner So the new PE lies always upon its
    * owner
    *
    * @param dialog  The dialog (PE) which owns this PE
    */
   public DBPropertyEditor (Dialog dialog)
   {
      super (dialog);
      setTitle ("Property Editor");
   } // PropertyEditor


   /**
    * This functions sets the context to the AST see also getAsgElement () and getTableIncrement
    * ()
    *
    * @param incr  The new increment value
    */
   public void setIncrement (DBTable incr)
   {
      if (getFrame() != null)
      {
         getFrame().setCursor (Cursor.getPredefinedCursor (Cursor.WAIT_CURSOR));
      } // if

      asgElement = (ASGElement) incr;
      readOnly = false;
      if (incr instanceof DBTable)
      {
         table = (DBTable) incr;
      }
      unparse();
      if (getFrame() != null)
      {
         getFrame().setCursor (Cursor.getPredefinedCursor (Cursor.DEFAULT_CURSOR));
      } // if
   }


   /**
    * This functions sets the context to the AST see also getAsgElement () and getSchemaIncrement
    * ()
    *
    * @param incr  The new increment value
    */
   public void setIncrement (DBSchema incr)
   {
      if (getFrame() != null)
      {
         getFrame().setCursor (Cursor.getPredefinedCursor (Cursor.WAIT_CURSOR));
      } // if

      asgElement = (ASGElement) incr;
      readOnly = false;
      if (incr instanceof DBSchema)
      {
         schema = (DBSchema) incr;
      }
      unparse();
      if (getFrame() != null)
      {
         getFrame().setCursor (Cursor.getPredefinedCursor (Cursor.DEFAULT_CURSOR));
      } // if
   }


   /**
    * getTableIncrement returns a valid reference to an DBTable object if a class Object is
    * referenced by setAsgElement
    *
    * @return   valid reference of a class Object
    */
   public DBTable getTableIncrement()
   {
      return table;
   }


   /**
    * getSchemaIncrement returns a valid reference to an DBSchema object if a class Object
    * is referenced by setAsgElement
    *
    * @return   valid reference of a class Object
    */
   public DBSchema getSchemaIncrement()
   {
      return schema;
   }
}

/*
 * $Log: DBPropertyEditor.java,v $
 * Revision 1.2  2003/10/07 07:21:51  ariseppi
 * misc. corrections
 *
 */
