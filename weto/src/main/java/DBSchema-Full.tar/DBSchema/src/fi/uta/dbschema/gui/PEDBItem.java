/*
 * The FUJABA [Just Draw It!] project:
 *
 *   FUJABA is the acronym for 'From Uml to Java And Back Again'
 *   and originally aims to provide an environment for round-trip
 *   engineering using UML as visual programming language. During
 *   the last years, the environment has become a base for several
 *   research activities, e.g. distributed software, database
 *   systems, modelling mechanical and electrical systems and
 *   their simulation. Thus, the environment has become a project,
 *   where this added code is part of. Further details are avail-
 *   able via http://www.fujaba.de
 *
 *      Copyright (C) 1997-2002 Fujaba Development Group
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free
 *   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *   MA 02111-1307, USA or download the license under
 *   http://www.gnu.org/copyleft/lesser.html
 *
 * WARRANTY:
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU Lesser General Public License for more details.
 *
 * Contact adress:
 *
 *   Fujaba Management Board
 *   Software Engineering Group
 *   University of Paderborn
 *   Warburgerstr. 100
 *   D-33098 Paderborn
 *   Germany
 *
 *   URL  : http://www.fujaba.de
 *   email: fujaba@upb.de
 *
 */
package fi.uta.dbschema.gui;

// Based on de.uni_paderborn.fujaba.gui.PEItem

import de.uni_paderborn.fujaba.asg.ASGElement;
import fi.uta.dbschema.metamodel.DBTableAttribute;


/**
 * Similar to de.uni_paderborn.fujaba.gui.PEItem, but works with fi.uta.dbschema.metamodel.DBTableAttribute
 *
 * @author    $Author: ariseppi $
 * @created   $Date: 2003/10/07 07:21:51 $
 * @version   $Revision: 1.3 $
 */
class PEDBItem
{
   /**
    * Constructor for class PEDBItem
    *
    * @param incr  No description provided
    */
   PEDBItem (ASGElement incr)
   {
      increment = incr;
   }


   /**
    * Constructor for class PEDBItem
    *
    * @param incr  No description provided
    * @param s     No description provided
    */
   PEDBItem (ASGElement incr, String s)
   {
      increment = incr;
      text = s;
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private ASGElement increment;
   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    */
   private String text;


   /**
    * Get the increment attribute of the PEDBItem object
    *
    * @return   The increment value
    */
   public ASGElement getIncrement()
   {
      return increment;
   }


   /**
    * Get the visibility attribute of the PEDBItem object
    *
    * @return   The visibility value
    */
   /*
    *  public int getVisibility()
    *  {
    *  if (increment instanceof DBTableAttribute)
    *  {
    *  return  ((DBTableAttribute) increment).getVisibility();
    *  }
    *  return 0;
    *  }
    */
   /**
    * Get the text attribute of the PEDBItem object
    *
    * @return   The text value
    */
   public String getText()
   {
      return  ( (text != null) ? text : increment.getText());
   }


   /**
    * Sets the text attribute of the PEDBItem object
    *
    * @param s  The new text value
    */
   public void setText (String s)
   {
      text = s;
   }


   /**
    * Sets the increment attribute of the PEDBItem object
    *
    * @param i  The new increment value
    */
   public void setText (ASGElement i)
   {
      increment = i;
   }


   /**
    * Get the type attribute of the PEDBItem object
    *
    * @return   The type value
    */
   public String getType()
   {
      if (increment instanceof DBTableAttribute)
      {
         return  ((DBTableAttribute) increment).getSqlType();
      }
      return  ("");
   }


   /**
    * No comment provided by developer, please add a comment to ensure improve documentation.
    *
    * @return   No description provided
    */
   public String toString()
   {
      if (increment instanceof DBTableAttribute)
      {
         return  ( ((DBTableAttribute) increment).getText());
      }
      return  ("");
   }
}

/*
 * $Log: PEDBItem.java,v $
 * Revision 1.3  2003/10/07 07:21:51  ariseppi
 * misc. corrections
 *
 */
